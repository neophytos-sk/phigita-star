`.onLoad` <- function(lib,pkg) {
  cat("IBrokers version 0.2-6: (alpha)\n")
  cat("Implementing API Version 9.62\n\n")
  cat("This software comes with NO WARRANTY.  Not intended for production use!\n")
  cat("See ?IBrokers for details\n")
}
