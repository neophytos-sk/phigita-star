/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FIDAL_H
#define FIDAL_H

#include <stdio.h>

#ifndef FD_COMMON_H
    #include "fd_common.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int FD_UDBase;

/* Function to create a new unified database. */
FD_RetCode FD_UDBaseAlloc( FD_UDBase **newUDBase );

/* Function to free all ressource of an unified database. */
FD_RetCode FD_UDBaseFree( FD_UDBase *toBefreed );

#define FD_SOURCELOCATION_MAX_LENGTH  2048  /* Maximum number of character. */
#define FD_SOURCEINFO_MAX_LENGTH      1024  /* Maximum number of character. */
#define FD_CATEGORY_MAX_LENGTH        1024  /* Maximum number of character. */
#define FD_SYMBOL_MAX_LENGTH          1024  /* Maximum number of character. */

/* A category respecting the FIDAL guideline shall
 * respect the following limit for its 3 components.
 */
#define FD_CAT_COUNTRY_MAX_LENGTH     2  /* Max length for the country id.    */
#define FD_CAT_EXCHANGE_MAX_LENGTH    25 /* Max length for the exchange id.   */
#define FD_CAT_TYPE_MAX_LENGTH        10 /* Max length for the security type. */

/* Default category name. */
#define FD_DEFAULT_CATEGORY          "ZZ.OTHER.OTHER"
#define FD_DEFAULT_CATEGORY_COUNTRY  "ZZ"
#define FD_DEFAULT_CATEGORY_EXCHANGE "OTHER"
#define FD_DEFAULT_CATEGORY_TYPE     "OTHER"

/* The user build the "unified database" by specifying the
 * list of data source by calling FD_AddDataSource().
 * All data source, even when of different data format, are
 * transparently merged.
 *
 * See the API documentation for more info.
 */
typedef enum
{
   /* For a complete explanation on how to use these
    * data sources, see the HTML documentation.
    */
   FD_ASCII_FILE,
   FD_SIMULATOR,
   FD_YAHOO_WEB,
   FD_SQL,
   FD_CSI,
   FD_CSIM,
   FD_YAHOO_ONE_SYMBOL,
   FD_NUM_OF_SOURCE_ID
} FD_SourceId;

/* A group of flags can be specified to describe characteristics
 * of the data source.
 *
 * Some of these flags allow to enable/disable some functionality
 * for a specific data source.
 *
 * FD_AddDataSource will fail with FD_NOT_SUPPORTED if a flag request a
 * functionality not applicable to the data source.
 *
 * FD_REPLACE_ZERO_PRICE_BAR
 * =========================
 *    Some datasource return a price bar with some price to be zero as an
 *    an indication that there was no change in price. This option allows 
 *    to replace these "zero" price with the previous close.
 *    If the zero price are in the initial bars e.g. no previous valid close
 *    are known, these zero price bar will be ignored.
 *    Without this option, a "zero" detected in a price bar will be considered 
 *    an error and a call to FD_HistoryAlloc will fail. 
 *    A volume of zero is valid.
 *
 * FD_DO_NOT_SPLIT_ADJUST
 * ======================
 *    Return data that is not split adjusted.
 *
 * FD_DO_NOT_VALUE_ADJUST
 * ======================
 *    Return data that is not dividend adjusted.
 *
 * FD_SOURCE_USES_END_OF_PERIOD
 * ============================
 *    The datasource uses the convention that quotes periods are timestamed
 *    at the end of the period (by default, datasources set the timestamp
 *    at the beginning of the period). By using this option, a quotes record
 *    stamped by a 'timestamp' is interpreted as covering interval
 *    ['timestamp'-'period','timestamp).  Without this option, it would be
 *    interpreted as covering interval ['timestamp','timestamp'+'period').
 *
 */

typedef int FD_SourceFlag;
#define FD_NO_FLAGS  0
#define FD_REPLACE_ZERO_PRICE_BAR       (1<<0)
#define FD_DO_NOT_SPLIT_ADJUST          (1<<1)
#define FD_DO_NOT_VALUE_ADJUST          (1<<2)
#define FD_SOURCE_USES_END_OF_PERIOD    (1<<4)

typedef struct
{
   /* The whole structure should be first initialize
    * with zero, and only the relevant parameter
    * to your application needs to be set.
    *
    * The safest way is to ALWAYS do something like:
    *    FD_AddDataSourceParam param;
    *    memset( &param, 0, sizeof( FD_AddDataSourceParam ) );
    *    ... set only the parameter you need...
    *    retCode = FD_AddDataSource( udb, &param ); 
    *
    * Initializing the whole structure to zero assure
    * that the actual (or future) unused parameters
    * will not interfere.
    */

   /* Identify the data source. */
   FD_SourceId   id;

   /* Indicates the type of functionality that
    * must be enabled for this data source.
    */
   FD_SourceFlag flags;

   /* Indicates the period requested to be return 
    * for this data source.  Some data sources may
    * ignore this value and extract the period 
    * directly from the data or other parameters.
    */
   FD_Period period;

   /* The usage of the following two parameters are
    * data source dependent. See documentation.
    */
   const char *location;
   const char *info;

   /* For data source requiring authentication. */
   const char *username;
   const char *password;

   /* The category can be specified in two way.
    *
    * By setting "category" or by setting
    * individual category component following
    * the FIDAL guideline.
    * Example:
    *    param.category = "My Category";
    *
    *     or
    *
    *    param.country  = "US";
    *    param.exchange = "NASDAQ";
    *    param.type     = "STOCK";
    *
    * Some data source will ignore the category 
    * provided here.
    */
   const char *category;
   const char *country;
   const char *exchange;
   const char *type;

   /* The following is sometimes used for data source
    * that return only one symbol.
    */
   const char *symbol;

   /* The user can optionaly name this data source. */
   const char *sourceName;

} FD_AddDataSourceParam;

FD_RetCode FD_AddDataSource( FD_UDBase *unifiedDatabase,
                             const FD_AddDataSourceParam *param );


/* The following are some pre-defined ASCII file format.
 * These can be used for the 'sourceInfo' for FD_ASCII_FILE format.
 *
 * Note: If these file format are not convenient, you can
 *       specify your own. See documentation.
 */
#define FD_DOHLCV "[Y][M][D][O][H][L][C][V]"
#define FD_DOCHLV "[Y][M][D][O][C][H][L][V]"
#define FD_DOCV   "[Y][M][D][O][C][V]"
#define FD_DCV    "[Y][M][D][C][V]"

/* The following functions are used to obtain the list of
 * category found in an unified database.
 *
 * On success, it becomes the responsibility of the caller to
 * call FD_CategoryTableFree once the 'table' is no longuer needed.
 *
 * Simple example printing out all the category:
 *
 *   FD_StringTable *table;
 *   FD_RetCode retCode;
 *   int i;
 *
 *   retCode = FD_CategoryTableAlloc( udBase, &table );
 *
 *   if( retCode == FD_SUCCESS )
 *   {
 *      for( i=0; i < table->size; i++ )
 *         printf( "%s\n", table->string[i] );
 *
 *      FD_CategoryTableFree( table );
 *   }
 */
FD_RetCode FD_CategoryTableAlloc( FD_UDBase *unifiedDatabase,
                                  FD_StringTable **table );

FD_RetCode FD_CategoryTableFree ( FD_StringTable *table );

/* The following functions are used to obtain the list of
 * symbols provided by the unified database.
 *
 * Note: To obtain the list of symbol not classify under
 *       any particular category, just pass NULL for the
 *       category string.
 *
 * On success, it becomes the responsibility of the caller to
 * call FD_SymbolTableFree once the 'table' is no longuer needed.
 *
 * Example:
 * This code snippet will print out all the supported
 * symbol for the "US.NASDAQ.STOCK" category:
 *
 *   FD_StringTable *table;
 *   FD_RetCode retCode;
 *   int i;
 *
 *   retCode = FD_SymbolTableAlloc( udBase, "US.NASDAQ.STOCK", &table );
 *
 *   if( retCode == FD_SUCCESS )
 *   {
 *      for( i=0; i < table->size; i++ )
 *         printf( "%s\n", table->string[i] );
 *
 *      FD_SymbolTableFree( table );
 *   }
 */
FD_RetCode FD_SymbolTableAlloc( FD_UDBase *unifiedDatabase,
                                const char *category,
                                FD_StringTable **table );

FD_RetCode FD_SymbolTableFree ( FD_StringTable *table );


/* An alternate way to get the index of all symbols is
 * through the use of the FD_ForEachSymbol(). You can
 * setup a function to be called for each symbols currently
 * in the unified database.
 *
 * Example:
 *  This code will print the name and category of all symbols
 *  actually in the unified database.
 *
 *  void printSymbolInfo( FD_UDBase *udBase,
 *                        const char *category,
 *                        const char *symbol,
 *                        void *opaqueData )
 *  {
 *     printf( "Category=%s Symbol=%s\n", category, symbol );
 *  }
 *
 *  void printAll( FD_UDBase *udBase )
 *  {
 *     FD_ForEachSymbol( udBase, printSymbolInfo, NULL );
 *  }
 */
typedef void (*FD_ForEachSymbolFunc)( FD_UDBase *unifiedDatabase,
                                      const char *category,
                                      const char *symbol,
                                      void *opaqueData );

FD_RetCode FD_ForEachSymbol( FD_UDBase *unifiedDatabase,
                             FD_ForEachSymbolFunc functionToCall,
                             void *opaqueData );

/* The following functions allows to access historic data.
 * On success, it becomes the responsibility of the caller to
 * call FD_HistoryFree once the 'history' is no longuer needed.
 *
 * Example:
 *   This code will print out all the available daily close values of
 *   the company "LNUX". It is assume that this symbol is part of
 *   the unified database under the "US.NASDAQ.STOCK" category.
 *
 *   FD_History *history;
 *   FD_HistoryAllocParam param;
 *   FD_RetCode retCode;
 *   int i;
 *
 *   memset( param, 0, sizeof(FD_HistoryAllocParam) );
 *   param.category = "US.NASDAQ.STOCK";
 *   param.symbol   = "LNUX";
 *   param.period   = FD_DAILY;
 *   retCode = FD_HistoryAlloc( udBase, &param, &history );
 *
 *   if( retCode == FD_SUCCESS )
 *   {
 *      for( i=0; i < history->nbBars; i++ )
 *         printf( "Close = %f\n", history->close[i] );
 *
 *      FD_HistoryFree( history );
 *   }
 */
typedef int FD_Field;
#define FD_FIELD_ALL           0 /* Includes all fields available from database. */
#define FD_FIELD_OPEN         (1<<0)
#define FD_FIELD_HIGH         (1<<1)
#define FD_FIELD_LOW          (1<<2)
#define FD_FIELD_CLOSE        (1<<3)
#define FD_FIELD_VOLUME       (1<<4)
#define FD_FIELD_OPENINTEREST (1<<5)
#define FD_FIELD_TIMESTAMP    (1<<6)

typedef struct
{
   unsigned int nbBars; /* Nb of element into the following arrays. */
   FD_Period period;    /* Amount of time between each bar. */

   /* The arrays containing data. Unused array are set to NULL. */
   FD_Timestamp *timestamp;
   FD_Real      *open;
   FD_Real      *high;
   FD_Real      *low;
   FD_Real      *close;
   FD_Integer   *volume;
   FD_Integer   *openInterest;

   /* Enumerate all the data source that did contribute. */
   FD_StringTable listOfSource;

   /* Hidden data for internal use by FIDAL. Do not modify. */
   void *hiddenData;
} FD_History;


/* Flags that can be specified when allocating a FD_History.
 *
 * FD_ALLOW_INCOMPLETE_PRICE_BARS
 * ==============================
 *    When FIDAL does data consolidation to weekly, monthly, quarterly 
 *    and yearly period, the default behavior is to not return incomplete
 *    starting/ending price bars. This flag disable this filtering.
 *
 *    A starting price bar period is determine completed when one of 
 *    the following is true:
 *     - The end-of-day price bar for the first weekday of the target 
 *       period is available.
 *     - Some data is found for the previous price bar.
 *
 *    A ending price bar period is determine completed when one of 
 *    the following is true:
 *     - The end-of-day price bar for the last weekday of the target 
 *       period is available.
 *     - Some data is found for the next price bar.
 *
 *    Examples:
 *       (1) Requesting historical monthly data will not return the
 *           ending month until at least the last week day is available OR
 *           a price bar in the following month is found in the database.
 *
 *       (2) Requesting historical weekly data will not return the starting
 *           week if it was an incomplete week AND no data is found for 
 *           the previous week in the database.
 *
 *       (3) Requesting historical yearly data will not return the starting
 *           year if the first week day of the year is not available AND 
 *           no data is found for the previous year in the database.
 *
 * FD_USE_TOTAL_VOLUME
 * ===================
 *    This option makes FIDAL to sum the daily volume when doing price bar
 *    consolidation e.g. when converting daily data to period equal or greater 
 *    to weekly.Without this flag, the default behavior is to return the daily 
 *    average volume.
 *    
 *
 * FD_USE_TOTAL_OPENINTEREST
 * =========================
 *    This option makes FIDAL to sum the daily open interest when doing price 
 *    bar consolidation e.g. when converting daily data to period equal or  
 *    greater to weekly.Without this flag, the default behavior is to return 
 *    the daily average open interest.
 *
 *
 * FD_DISABLE_PRICE_VALIDATION
 * ===========================
 *    By default FIDAL fails a FD_HistoryAlloc call when an inconsistency is
 *    found among the high, low, close, open e.g. high<low. This option disable 
 *    these price validations and the caller is left on its own to detect 
 *    erroneous data.
 *
 * FD_USE_END_OF_PERIOD
 * ====================
 *    Retrieve the history data using the end-of-period logic, i.e. set the
 *    timestamps to the end of the period the records are covering rather than 
 *    the beginning of the period.
 *
 */
typedef int FD_HistoryFlag;
#define FD_ALLOW_INCOMPLETE_PRICE_BARS (1<<0)
#define FD_USE_TOTAL_VOLUME            (1<<1)
#define FD_USE_TOTAL_OPENINTEREST      (1<<2)
#define FD_DISABLE_PRICE_VALIDATION    (1<<3)
#define FD_USE_END_OF_PERIOD           (1<<4)

typedef struct
{
   /* The whole structure should be first initialize
    * with zero, and only the relevant parameter
    * to your application needs to be set.
    *
    * The safest way is to ALWAYS do something like:
    *    FD_HistoryAllocParam param;
    *    FD_History *history;
    *    memset( &param, 0, sizeof( FD_HistoryAllocParam ) );
    *    ... set only the parameter you need...
    *    retCode = FD_HistoryAlloc( udb, &param, &history ); 
    *
    * Initializing the whole structure to zero assure
    * that the actual (or future) unused parameters
    * will not interfere.
    */

   /* You can request the data from a particular source. Use the optional 
    * name who was provided with FD_AddDataSource. Leave to zero to 
    * let FIDAL choose a data source or perform data merging.    
    */    
   const char    *sourceName;

   /* Identify the instrument for which you want historical data. */
   const char    *category;
   const char    *symbol;   

   /* Amount of time for each price bar. FIDAL will consolidate the
    * data as needed.
    */
   FD_Period      period;

   /* Inclusive starting and ending date. Only the granularity specify
    * by period is consider from these timestamps. Example, requesting
    * with period equal FD_MONTHLY means that only the Year and Month 
    * component of start/end will be used and the day and time will be
    * ignored.
    */
   FD_Timestamp   start;
   FD_Timestamp   end;
   
   /* List of field to allocate. */
   FD_Field       field;

   /* Optional flags. */
   FD_HistoryFlag flags;

   /* Timeout
    *
    * Define the maximum amount of time that 
    * FIDAL should retry to get the data.
    *
    * Leave to zero for reasonable best-effort
    * retries: 
    *     - up to 1/2 hour for online data.
    *     - No retries for SQL and ASCII files.
    *     etc...
    */
   unsigned int timeout; /* Nb of seconds */

} FD_HistoryAllocParam;

FD_RetCode FD_HistoryAlloc( FD_UDBase *unifiedDatabase,
                            const FD_HistoryAllocParam *param,
                            FD_History **history );

FD_RetCode FD_HistoryFree( FD_History *history );

/* FD_HistoryEqual
 *  Return 1 if two FD_History are equivalent (same content).
 *  Return 0 if a difference is found.
 */
int FD_HistoryEqual( const FD_History *history1, const FD_History *history2 );

/* FD_Report is provided for printing out the
 * contents of the unified database.
 */

/* Flags that can be used for FD_Report. */
typedef int FD_ReportFlag;
#define FD_REPORT_SYMBOL    (1<<0)
#define FD_REPORT_CATEGORY  (1<<1)
#define FD_REPORT_SOURCE    (1<<2)
#define FD_REPORT_TOTAL     (1<<3)

FD_RetCode FD_Report( FD_UDBase *unifiedDatabase,
                      FILE *out,
                      FD_ReportFlag flags );

/* A utility function to fetch a web page and send the raw data
 * to the provided FILE pointer. This ptr could be "stdout" to
 * display on the console.
 *
 * Examples:
 *        FD_WebFetch( "www.yahoo.com", stdout );
 *           or
 *        FD_WebFetch( "http://www.yahoo.com//mt", myFile );
 */
FD_RetCode FD_WebFetch( const char *url, FILE *out );

#ifdef __cplusplus
}
#endif

#endif
