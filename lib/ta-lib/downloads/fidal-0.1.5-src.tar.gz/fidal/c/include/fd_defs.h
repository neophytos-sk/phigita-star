/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FD_DEFS_H
#define FD_DEFS_H

/*** The following block of code is to define:
 ***
 ***    UInt32  : 32 bits unsigned integer.
 ***    Int32   : 32 bits signed integer.
 ***    UInt64  : 64 bits unsigned integer.
 ***    Int64   : 64 bits signed integer.
 ***
 ***    INT_MIN : The minimal value for Int32
 ***    INT_MAX : The maximal value for Int32
 ***/
#if defined( _MANAGED )
  /* Int32, UInt32, Int64 and UInt64 are built-in for .NET */	
  #define INT_MIN (Int32::MinValue)
  #define INT_MAX (Int32::MaxValue)
#elif defined( _JAVA )
  #define INT_MIN Integer.MIN_VALUE
  #define INT_MAX Integer.MAX_VALUE
#else
  #include <limits.h>

  /* Identify if 64 bits platform with __64BIT__.
   * Can also be done from compiler command line. 
   */
  #if defined(_WIN64)
     #define __64BIT__ 1
  #endif

  #if defined( __LP64__ ) || defined( _LP64 )
     #define __64BIT__ 1
  #endif

  /* Check also for some known GCC def for 64 bits platform. */
  #if defined(__alpha__)\
      ||defined(__ia64__)\
      ||defined(__ppc64__)\
      ||defined(__s390x__)\
      ||defined(__x86_64__)
     #define __64BIT__ 1
  #endif		  
		   
  #if !defined(__MACTYPES__)
      typedef signed int   Int32;
      typedef unsigned int UInt32;

      #if defined(_WIN32) || defined(_WIN64)
         /* See "Windows Data Types". Platform SDK. MSDN documentation. */
         typedef signed __int64   Int64;
         typedef unsigned __int64 UInt64;
      #else
         #if defined(__64BIT__)
            /* Standard LP64 model for 64 bits Unix platform. */
            typedef signed long   Int64;
            typedef unsigned long UInt64;
         #else
            /* Standard ILP32 model for 32 bits Unix platform. */
            typedef signed long long   Int64;
            typedef unsigned long long UInt64;
         #endif
       #endif
  #endif

#endif

/* Enumeration and macros to abstract from syntax difference 
 * between C, C++, managed C++ and Java.
 */
#if defined( _MANAGED )
  #define ENUM_BEGIN(x) enum class x {
  #define ENUM_END(x) };  
  #define ENUM_CASE(namespace,value) namespace::value

  #define STRUCT_BEGIN(x) struct x {
  #define STRUCT_END(x) };
  #define NAMESPACE(x) x::

  #define UNUSED_VARIABLE(x)             (void)x

  #define VALUE_HANDLE_INT(name)           int name
  #define VALUE_HANDLE_DEREF(name)         name
  #define VALUE_HANDLE_DEREF_TO_ZERO(name) name = 0
  #define VALUE_HANDLE_OUT(name)           name

  #define VALUE_HANDLE_GET(name)         name
  #define VALUE_HANDLE_SET(name,x)       name = x

  #define CONSTANT_DOUBLE(x) const double x

  #define FUNCTION_CALL(x) x
  #define FUNCTION_CALL_DOUBLE(x) x
  #define LOOKBACK_CALL(x) x##_Lookback
#elif defined( _JAVA )
  #define ENUM_BEGIN(x) public enum x {
  #define ENUM_END(x) };
  #define ENUM_CASE(namespace,value) value

  #define STRUCT_BEGIN(x) public class x {
  #define STRUCT_END(x) };
  #define NAMESPACE(x) x.

  #define UNUSED_VARIABLE(x)

  #define VALUE_HANDLE_INT(name)            MInteger name = new MInteger()
  #define VALUE_HANDLE_DEREF(name)          name.value
  #define VALUE_HANDLE_DEREF_TO_ZERO(name)  name.value = 0
  #define VALUE_HANDLE_OUT(name)            name

  #define VALUE_HANDLE_GET(name)         name.value
  #define VALUE_HANDLE_SET(name,x)       name.value = x

  #define CONSTANT_DOUBLE(x) final double x

  #define FUNCTION_CALL(x) x
  #define FUNCTION_CALL_DOUBLE(x) x
  #define LOOKBACK_CALL(x) x##_Lookback
#else
  #define ENUM_BEGIN(x) typedef enum {
  #define ENUM_END(x) } x;
  #define ENUM_CASE(namespace,value) value

  #define STRUCT_BEGIN(x) typedef struct {
  #define STRUCT_END(x) } x;
  #define NAMESPACE(x)

  #define UNUSED_VARIABLE(x)              (void)x

  #define VALUE_HANDLE_INT(name)           int name
  #define VALUE_HANDLE_DEREF(name)         (*name)
  #define VALUE_HANDLE_DEREF_TO_ZERO(name) (*name) = 0
  #define VALUE_HANDLE_OUT(name)           &name

  #define VALUE_HANDLE_GET(name)          name
  #define VALUE_HANDLE_SET(name,x)        name = x

  #define CONSTANT_DOUBLE(x) const double x

  #define FUNCTION_CALL(x) FD_PREFIX(x)
  #define FUNCTION_CALL_DOUBLE(x) FD_##x
  #define LOOKBACK_CALL(x) FD_##x##_Lookback
#endif

/* min/max value for a FD_Integer */
#define FD_INTEGER_MIN (INT_MIN+1)
#define FD_INTEGER_MAX (INT_MAX)

/* min/max value for a FD_Real 
 *
 * Use fix value making sense in the
 * context of FIDAL (avoid to use DBL_MIN
 * and DBL_MAX standard macro because they
 * are troublesome with some compiler).
 */
#define FD_REAL_MIN (-3e+37)
#define FD_REAL_MAX (3e+37)

/* A value outside of the min/max range 
 * indicates an undefined or default value.
 */
#define FD_INTEGER_DEFAULT (INT_MIN)
#define FD_REAL_DEFAULT    (-4e+37)

ENUM_BEGIN(FD_RetCode)
    /****** FIDAL Error Code *****/
    /*   0 */  FD_SUCCESS,            /* No error */
    /*   1 */  FD_LIB_NOT_INITIALIZE, /* FD_Initialize was not sucessfully called */
    /*   2 */  FD_BAD_PARAM,          /* A parameter is out of range */
    /*   3 */  FD_ALLOC_ERR,          /* Possibly out-of-memory */
    /*   4 */  FD_ACCESS_FAILED,      /* File system access failed */
    /*   5 */  FD_NO_DATA_SOURCE,     /* No data was added */
    /*   6 */  FD_SYMBOL_NOT_FOUND,   /* Symbol not found in this category */
    /*   7 */  FD_CATEGORY_NOT_FOUND, /* Category not found in the data base */
    /*   8 */  FD_KEY_NOT_FOUND,
    /*   9 */  FD_INDEX_FILE_NOT_ACCESSIBLE,
    /*  10 */  FD_INDEX_NOT_VALID,
    /*  11 */  FD_INVALID_FIELD,
    /*  12 */  FD_INVALID_PATH,
    /*  13 */  FD_INTERNAL_ERR,
    /*  14 */  FD_FATAL_ERR,
    /*  15 */  FD_NO_NEW_DATA,
    /*  16 */  FD_NOT_SUPPORTED,
    /*  17 */  FD_END_OF_INDEX,
    /*  18 */  FD_ENOUGH_DATA,
    /*  19 */  FD_MISSING_FIELD,
    /*  20 */  FD_REDUNDANT_FIELD,
    /*  21 */  FD_INVALID_DATE,
    /*  22 */  FD_INVALID_PRICE,
    /*  23 */  FD_GROUP_NOT_FOUND,
    /*  24 */  FD_FUNC_NOT_FOUND,
    /*  25 */  FD_INVALID_HANDLE,
    /*  26 */  FD_INVALID_PARAM_HOLDER,
    /*  27 */  FD_INVALID_PARAM_HOLDER_TYPE,
    /*  28 */  FD_INVALID_PARAM_FUNCTION,
    /*  29 */  FD_INPUT_NOT_ALL_INITIALIZE,
    /*  30 */  FD_OUTPUT_NOT_ALL_INITIALIZE,
    /*  31 */  FD_OUT_OF_RANGE_START_INDEX,
    /*  32 */  FD_OUT_OF_RANGE_END_INDEX,
    /*  33 */  FD_BAD_OBJECT,
    /*  34 */  FD_MEM_LEAK,
    /*  35 */  FD_ADDR_NOT_FOUND,
    /*  36 */  FD_SOCKET_LIB_INIT_ERR,
    /*  37 */  FD_END_OF_STREAM,
    /*  38 */  FD_BAD_STREAM_CRC,
    /*  39 */  FD_UNSUPPORTED_STREAM_VERSION,
    /*  40 */  FD_BAD_STREAM_HEADER_CRC,
    /*  41 */  FD_BAD_STREAM_HEADER,
    /*  42 */  FD_BAD_STREAM_CONTENT,
    /*  43 */  FD_BAD_YAHOO_IDX_HDR,
    /*  44 */  FD_UNSUPORTED_YAHOO_IDX_VERSION,
    /*  45 */  FD_BAD_YAHOO_IDX_INDICATOR_AF,
    /*  46 */  FD_BAD_YAHOO_IDX_INDICATOR_EB,
    /*  47 */  FD_BAD_YAHOO_IDX_INDICATOR_F2,
    /*  48 */  FD_NO_INTERNET_CONNECTION,
    /*  49 */  FD_INTERNET_ACCESS_FAILED,
    /*  50 */  FD_INTERNET_OPEN_FAILED,
    /*  51 */  FD_INTERNET_NOT_OPEN_TRY_AGAIN,
    /*  52 */  FD_INTERNET_SERVER_CONNECT_FAILED,
    /*  53 */  FD_INTERNET_OPEN_REQUEST_FAILED,
    /*  54 */  FD_INTERNET_SEND_REQUEST_FAILED,
    /*  55 */  FD_INTERNET_READ_DATA_FAILED,
    /*  56 */  FD_UNSUPPORTED_COUNTRY,
    /*  57 */  FD_BAD_HTML_SYNTAX,
    /*  58 */  FD_PERIOD_NOT_AVAILABLE,
    /*  59 */  FD_FINISH_TABLE,
    /*  60 */  FD_INVALID_SECURITY_EXCHANGE,
    /*  61 */  FD_INVALID_SECURITY_SYMBOL,
    /*  62 */  FD_INVALID_SECURITY_COUNTRY,
    /*  63 */  FD_INVALID_SECURITY_TYPE,
    /*  64 */  FD_MISSING_DATE_OR_TIME_FIELD,
    /*  65 */  FD_OBJECT_NOT_EQUAL,
    /*  66 */  FD_INVALID_LIST_TYPE,
    /*  67 */  FD_YAHOO_IDX_EXPIRED,
    /*  68 */  FD_YAHOO_IDX_UNAVAILABLE_1, /* Local cache does not have a Yahoo! index */
    /*  69 */  FD_YAHOO_IDX_FAILED,
    /*  70 */  FD_LIBCURL_GLOBAL_INIT_FAILED, /* libCurl shared library missing? */
    /*  71 */  FD_LIBCURL_INIT_FAILED,        /* libCurl shared library missing? */
    /*  72 */  FD_INSTRUMENT_ID_BAD,          /* FD_Instrument not initialized. */
    /*  73 */  FD_TRADE_LOG_NOT_INITIALIZED,  /* FD_TradeLog corrupted or not initialized */
    /*  74 */  FD_BAD_TRADE_TYPE,
    /*  75 */  FD_BAD_START_DATE,
    /*  76 */  FD_BAD_END_DATE,
    /*  77 */  FD_INTERNET_SET_RX_TIMEOUT_FAILED,
    /*  78 */  FD_NO_TRADE_LOG,
    /*  79 */  FD_ENTRY_TRANSACTION_MISSING,
    /*  80 */  FD_INVALID_VALUE_ID,
    /*  81 */  FD_BAD_STARTING_CAPITAL,
    /*  82 */  FD_TRADELOG_ALREADY_ADDED,  /* This FD_TradeLog is already added to this FD_PM. */
    /*  83 */  FD_YAHOO_IDX_UNAVAILABLE_2, /* Possibly timeout of internet connection */
    /*  84 */  FD_YAHOO_IDX_UNAVAILABLE_3, /* Failed to find a Yahoo! index */
    /*  85 */  FD_NO_WEEKDAY_IN_DATE_RANGE,
    /*  86 */  FD_VALUE_NOT_APPLICABLE,            /* This PM value is not applicable to these trades. */
    /*  87 */  FD_DATA_GAP,                        /* Data source returned data with gaps */
    /*  88 */  FD_NOT_IMPLEMENTED,                 /* Feature not implemented */
    /*  89 */  FD_PM_REFERENCE_EXIST,              /* Can not free a FD_TradeLog when added to a FD_PM */
    /*  90 */  FD_PRICE_BAR_CONTAINS_ZERO,         /* A price of zero is invalid in a price bar */
    /*  91 */  FD_MISSING_CLOSE_PRICE_FIELD,       /* Close must be provided with FD_REPLACE_ZERO_PRICE_BAR flag. */
    /*  92 */  FD_UNSUPPORTED_REPLACE_ZERO_PRICE_BAR, /* FD_REPLACE_ZERO_PRICE_BAR flag is not supported for this data source. */
    /*  93 */  FD_MISSING_INPUT_DIGITS,            /* A digit was missing in one of the price bar field */
    /*  94 */  FD_DICT_TYPE_MISMATCH,              /* Error with handling of dictionary */
    /*  95 */  FD_YAHOO_IDX_UNAVAILABLE_4,         /* Failed to find a Yahoo! index */
    /*  96 */  FD_OBSOLETED_SYMBOL,                /* This symbol is no longuer valid */
    /*  97 */  FD_BAD_QUERY,                       /* Query could not be executed or syntax error in query */
    /*  98 */  FD_UNSUPPORTED_DO_NOT_SPLIT_ADJUST, /* FD_DO_NOT_SPLIT_ADJUST flag is not supported by this data source */
    /*  99 */  FD_UNSUPPORTED_DO_NOT_VALUE_ADJUST, /* FD_DO_NOT_VALUE_ADJUST flag is not supported by this data source */
    /* 100 */  FD_MISSING_PRICE_FOR_ADJUSTMENT,    /* At least one price field must be requested when doing price adjustment. */
    /* 101 */  FD_INVALID_DATABASE_TYPE,           /* location parameter does not refer to a supported database type. */
    /* 102 */  FD_UNEXPECTED_SQL_TYPE,             /* One of the field is not of the expected SQL type. */
    /* 103 */  FD_UNEXPECTED_SQL_TYPE_FOR_OPEN,    /* Open price field is not of the expected SQL type. */
    /* 104 */  FD_UNEXPECTED_SQL_TYPE_FOR_HIGH,    /* High price field is not of the expected SQL type. */
    /* 105 */  FD_UNEXPECTED_SQL_TYPE_FOR_LOW,     /* Low price field is not of the expected SQL type. */
    /* 106 */  FD_UNEXPECTED_SQL_TYPE_FOR_CLOSE,   /* Close price field is not of the expected SQL type. */
    /* 107 */  FD_UNEXPECTED_SQL_TYPE_FOR_VOLUME,  /* Volume field is not of the expected SQL type. */
    /* 108 */  FD_UNEXPECTED_SQL_TYPE_FOR_OI,      /* Open interest field is not of the expected SQL type. */
    /* 109 */  FD_LIMIT_OF_ONE_SERVER_EXCEEDED,    /* Only one server is expected for the location parameter. */
    /* 110 */  FD_LIMIT_OF_ONE_COUNTRY_ID_EXCEEDED,/* Only one country id is expected for the location parameter. */
    /* 111 */  FD_INVALID_YAHOO_DIVIDEND,          /* Yahoo! dividend data corrupted. Use unadjusted data for this stock. */
    /* 112 */  FD_LOCATION_PARAM_INVALID,          /* Error in the location parameter. */
    /* 113 */  FD_DAFD_ERROR_VOLUME_IS_NEGATIVE,   /* A data source returned a price bar with a negative volume. */
    /* 114 */  FD_DAFD_ERROR_TIMESTAMP_ORDER,      /* A data source returned a price bar not in chronological order. */
    /* 115 */  FD_DAFD_ERROR_OI_IS_NEGATIVE,       /* A data source returned a price bar with a negative open interest .*/
    /* 116 */  FD_DAFD_ERROR_CLOSE_IS_NEGATIVE,    /* A data source returned a price bar with a negative close. */
    /* 117 */  FD_DAFD_ERROR_OPEN_IS_NEGATIVE,     /* A data source returned a price bar with a negative open. */
    /* 118 */  FD_DAFD_ERROR_HIGH_IS_NEGATIVE,     /* A data source returned a price bar with a negative high. */
    /* 119 */  FD_DAFD_ERROR_LOW_IS_NEGATIVE,      /* A data source returned a price bar with a negative low. */
    /* 120 */  FD_DAFD_ERROR_LOW_EXCEED_HIGH,      /* A data source returned a price bar with low greater than high. */
    /* 121 */  FD_DAFD_ERROR_OPEN_EXCEED_HIGH,     /* A data source returned a price bar with open greater than high. */
    /* 122 */  FD_DAFD_ERROR_OPEN_BELOW_LOW,       /* A data source returned a price bar with open less than low. */
    /* 123 */  FD_DAFD_ERROR_CLOSE_EXCEED_HIGH,    /* A data source returned a price bar with close greater than high. */
    /* 124 */  FD_DAFD_ERROR_CLOSE_BELOW_LOW,      /* A data source returned a price bar with close less than low. */
    /* 125 */  FD_INTERNET_NO_CONTENT,             /* No content was found at the specified URL. */
    /* 126 */  FD_DAFD_RETREIVE_TIMEOUT,           /* Timeout at user specified value from FD_HistoryAlloc (or 30 min default). */

    /****** IP Error Code *****/
    /* 700 */  FD_IP_NOSOCKETS = 700,  /* Sockets not supported      */
    /* 701 */  FD_IP_BADHOST,          /* Host not known             */
    /* 702 */  FD_IP_BADSERVICE,       /* Service or port not known  */
    /* 703 */  FD_IP_BADPROTOCOL,      /* Invalid protocol specified */
    /* 704 */  FD_IP_SOCKETERROR,      /* Error creating socket      */
    /* 705 */  FD_IP_CONNECTERROR,     /* Error making connection    */
    /* 706 */  FD_IP_BINDERROR,        /* Error binding socket       */
    /* 707 */  FD_IP_LISTENERROR,      /* Error preparing to listen  */
    /* 708 */  FD_IP_WRITE_ERROR,      /* Error writing to socket    */
    /* 709 */  FD_IP_READ_ERROR,       /* Error reading from socket  */
    /* 710 */  FD_IP_UNKNOWN_ERR,

    /****** HTTP Error Code (RFC1945) *****/
    /* 800 */  FD_HTTP_NO_HEADER = 800, /* HTTP header not found.     */
    /* 801 */  FD_HTTP_SC_301,          /* Moved Permanently          */
    /* 802 */  FD_HTTP_SC_302,          /* Moved Temporarily          */
    /* 803 */  FD_HTTP_SC_304,          /* Not Modified               */
    /* 804 */  FD_HTTP_SC_400,          /* Bad Request                */
    /* 805 */  FD_HTTP_SC_401,          /* Unauthorized               */
    /* 806 */  FD_HTTP_SC_403,          /* Forbidden                  */
    /* 807 */  FD_HTTP_SC_404,          /* Not Found                  */
    /* 808 */  FD_HTTP_SC_500,          /* Internal Server Error      */
    /* 809 */  FD_HTTP_SC_501,          /* Not Implemented            */
    /* 810 */  FD_HTTP_SC_502,          /* Bad Gateway                */
    /* 811 */  FD_HTTP_SC_503,          /* Service Unavailable        */
    /* 812 */  FD_HTTP_SC_UNKNOWN,      /* Unknown error code.        */ 

    /****** CSI Error Code *****/
    /* 900 */  FD_CSI_UNABLE_OPEN_QMASTER_FILE = 900, /* QMaster file unaccessible */
    /* 901 */  FD_CSI_QMASTER_READ_ERROR,             /* QMaster file read error */
    /* 902 */  FD_CSI_QMASTER_BAD_PERIOD,             /* QMaster has invalid period */
    /* 903 */  FD_CSI_QMASTER_INVALID_STOCKCOM_FIELD, /* QMaster has invalid Stock/Commodity field */
    /* 904 */  FD_CSI_QMASTER_INVALID_DELETED_FIELD,  /* QMaster has invalid Deleted field */
    /* 905 */  FD_CSI_QMASTER_INVALID_PUTCALL_FIELD,  /* QMaster has invalid Put/Call field */
    /* 906 */  FD_CSI_UNABLE_OPEN_QMASTER2_FILE,      /* QMaster2 file unaccessible */
    /* 907 */  FD_CSI_QMASTER2_READ_ERROR,            /* QMaster2 file read error */
    /* 908 */  FD_CSI_QMASTER2_BAD_PERIOD,            /* QMaster2 has invalid period */
    /* 909 */  FD_CSI_QMASTER2_INVALID_STOCKCOM_FIELD,/* QMaster2 has invalid Stock/Commodity field */
    /* 910 */  FD_CSI_QMASTER2_INVALID_DELETED_FIELD, /* QMaster2 has invalid Deleted field */
    /* 911 */  FD_CSI_UNKNOWN_QMASTER_VERSION,        /* Unknown QMaster file version */
    /* 912 */  FD_CSI_DAFD_FILE_HEADER_READ_ERROR,    /* Read failure on CSI data file header */
    /* 913 */  FD_CSI_DAFD_FILE_READ_ERROR,           /* Read failure on CSI data file */
    /* 914 */  FD_CSI_DAFD_FILE_HEADER_READ_ERROR_2,  /* Read failure on CSI data file header (Version 2) */
    /* 915 */  FD_CSI_DAFD_FILE_READ_ERROR_2,         /* Read failure on CSI data file (Version 2) */
    /* 916 */  FD_CSI_UNKNOWN_DAFD_FILE_VERSION,      /* Unknown data file version */
    /* 917 */  FD_CSI_DAFD_FILE_MISSING,              /* No CSI data file file found */
    /* 918 */  FD_CSI_DAFD_FILE_ACCESS_FAILED,        /* Unable to open CSI data file */
    /* 919 */  FD_CSI_MASTER_FILE_NOT_FOUND,          /* 'master' file not found */
    /* 920 */  FD_CSI_MASTER_FILE_ACCESS_FAILED,      /* Unable to open 'master' file */
    /* 921 */  FD_CSI_MASTER_BAD_PERIOD,              /* Bad period in 'master' file */
    /* 922 */  FD_CSI_MISSING_CSIM_DAFD_FILE,         /* Missing CSIM data file */
    /* 923 */  FD_CSI_FAIL_TO_OPEN_CSIM_DAFD_FILE,    /* Unable to open CSIM data file */
    /* 924 */  FD_CSI_READ_FAIL_CSIM_HEADER_FILE,     /* Read failure on CSIM data file header */
    /* 925 */  FD_CSI_READ_FAIL_CSIM_DAFD_FILE,       /* Read failure on CSIM data file */
    /* 926 */  FD_CSI_HEADER_READ_FAILED_CSIM,        /* Failed to read CSIM header file */
    /* 927 */  FD_CSI_UNABLE_FIND_QMASTER_FILE,       /* No QMaster or QMaster2 files found */

    /****** FIDAL Internal Error Code *****/

    /* 5000 */ FD_INTERNAL_ERROR = 5000, /* Internal Error - Contact fidalsoft.org */

    /****** FIDAL Contributors: See fd_trace.h for the FD_INTERNAL_ERROR macro *****/

    FD_UNKNOWN_ERR = 0xFFFF
ENUM_END(FD_RetCode)

#endif
