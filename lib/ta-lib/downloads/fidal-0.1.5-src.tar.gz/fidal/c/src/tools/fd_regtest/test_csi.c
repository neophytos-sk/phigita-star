/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  032004 MF   First version.
 *
 */

/* Description:
 *    Test the CSI data source.
 */

/**** Headers ****/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "fidal.h"
#include "fd_common.h"
#include "fd_test_priv.h"
#include "fd_system.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
static ErrorNumber test_source( FD_UDBase *udb, FD_SourceId id, const char *symbol );

static ErrorNumber checkRangeSame( FD_UDBase           *udb,
                                   const FD_History    *historyRef,
                                   const FD_Timestamp  *start,
                                   const FD_Timestamp  *end,
                                   FD_Period            period,
                                   unsigned int         startIdx,
                                   unsigned int         nbPRiceBar,
                                   const char          *symbol );

/**** Global functions definitions.   ****/
ErrorNumber test_csi( void )
{
   ErrorNumber retValue;
   FD_UDBase *udb;

   printf( "Testing CSI data source\n" );

   retValue = allocLib( &udb );
   if( retValue != FD_TEST_PASS )
      return retValue;    

   retValue = test_source( udb, FD_CSI, "9" );
   if( retValue != FD_TEST_PASS )
   {       
      printf( "Error #%d\n", retValue );
      return retValue;
   }

   retValue = freeLib( udb );
   if( retValue != FD_TEST_PASS )
      return retValue;

   retValue = allocLib( &udb );
   if( retValue != FD_TEST_PASS )
      return retValue;    

   retValue = test_source( udb, FD_CSIM, "0" );
   if( retValue != FD_TEST_PASS )
   {       
      printf( "Error #%d\n", retValue );
      return retValue;
   }

   retValue = freeLib( udb );
   if( retValue != FD_TEST_PASS )
      return retValue;

   return FD_TEST_PASS;
}


/**** Local functions definitions.     ****/
static ErrorNumber test_source( FD_UDBase *udb, FD_SourceId id, const char *symbol )
{
   FD_RetCode retCode;
   FD_AddDataSourceParam param;
   FD_History *history;
   ErrorNumber errNumber;
   FD_HistoryAllocParam histParam;

   /* Add the CSI data source. */
   memset( &param, 0, sizeof( param ) );
   param.id = id;
   param.location = "..\\src\\tools\\fd_regtest\\csidata";

   retCode = FD_AddDataSource( udb, &param );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_AddDataSource", retCode );

      return FD_CSI_ADDDATASOURCE_FAILED;
   }

   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "CSI_ID";
   histParam.symbol   = symbol;
   histParam.field    = FD_FIELD_ALL;
   histParam.period   = FD_DAILY;
   retCode = FD_HistoryAlloc( udb, &histParam, &history );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryAlloc", retCode );
      return FD_CSI_HISTORYALLOC_1_FAILED;
   }

   if( history->nbBars != 29 )
   {
      printf( "Insufficient nbBars returned for ticker test (%d != 29)\n", history->nbBars );
      return FD_CSI_VALUE_1_FAILED;
   }

   if( !history->close || !history->open || !history->low || !history->high ||
       !history->timestamp || !history->volume )
   {
      return FD_CSI_FIELD_MISSING_1;
   }

   errNumber = checkRangeSame( udb, history, &history->timestamp[0], &history->timestamp[0], FD_DAILY, 0, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting first price bar only.\n" );
      return errNumber;
   }

   errNumber = checkRangeSame( udb, history, &history->timestamp[1], &history->timestamp[1], FD_DAILY, 1, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting second price bar only.\n" );
      return errNumber;
   }

   errNumber = checkRangeSame( udb, history,
                               &history->timestamp[history->nbBars-2],
                               &history->timestamp[history->nbBars-2],
                               FD_DAILY, history->nbBars-2, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting before last price bar only.\n" );
      return errNumber;
   }
   
   errNumber = checkRangeSame( udb, history,
                               &history->timestamp[history->nbBars-1],
                               &history->timestamp[history->nbBars-1],
                               FD_DAILY, history->nbBars-1, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting last price bar only.\n" );
      return errNumber;
   }
   
   errNumber = checkRangeSame( udb, history,
                               &history->timestamp[history->nbBars-9],
                               &history->timestamp[history->nbBars-1],
                               FD_DAILY, history->nbBars-9, 9, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting last 9 price bars only.\n" );
      return errNumber;
   }
   
   errNumber = checkRangeSame( udb, history, &history->timestamp[0], &history->timestamp[10], FD_DAILY, 0, 11, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting first 11 price bars only.\n" );
      return errNumber;
   }

   retCode = FD_HistoryFree( history );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryFree", retCode );
      return FD_CSI_HISTORYFREE_FAILED;
   }

   /* Do again the same test, but using Monthly data this time. */      
   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "CSI_ID";
   histParam.symbol   = symbol;
   histParam.field    = FD_FIELD_ALL;
   histParam.period   = FD_MONTHLY;
   histParam.flags    = FD_ALLOW_INCOMPLETE_PRICE_BARS;
   retCode = FD_HistoryAlloc( udb, &histParam, &history );

   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryAlloc for Monthly data", retCode );
      return FD_CSI_HISTORYALLOC_3_FAILED;
   }
   
   errNumber = checkRangeSame( udb, history, &history->timestamp[0], &history->timestamp[0], FD_MONTHLY, 0, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting first price bar only. (Monthly)\n" );
      return errNumber;
   }

   errNumber = checkRangeSame( udb, history, &history->timestamp[1], &history->timestamp[1], FD_MONTHLY, 1, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting second price bar only. (Monthly)\n" );
      return errNumber;
   }

   errNumber = checkRangeSame( udb, history, &history->timestamp[history->nbBars-2], &history->timestamp[history->nbBars-2], FD_MONTHLY, history->nbBars-2, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting before last price bar only. (Monthly)\n" );
      return errNumber;
   }
   
   errNumber = checkRangeSame( udb, history, &history->timestamp[history->nbBars-1], &history->timestamp[history->nbBars-1], FD_MONTHLY, history->nbBars-1, 1, symbol );
   if( errNumber != FD_TEST_PASS )
   {
      printf( "Failed: Test getting last price bar only. (Monthly)\n" );
      return errNumber;
   }

   retCode = FD_HistoryFree( history );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryFree", retCode );
      return FD_CSI_HISTORYFREE_FAILED;
   }

   /* Check that incomplete month are not return. */
   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "CSI_ID";
   histParam.symbol   = symbol;
   histParam.field    = FD_FIELD_ALL;
   histParam.period   = FD_MONTHLY;
   retCode = FD_HistoryAlloc( udb, &histParam, &history );

   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryAlloc for complete Monthly data", retCode );
      return FD_CSI_HISTORYALLOC_4_FAILED;
   }

   if( history->nbBars != 1 )
   {
      printf( "Incomplete month wrongly returned (%d != 1)\n", history->nbBars );
      return FD_CSI_HISTORYALLOC_5_FAILED;
   }

   retCode = FD_HistoryFree( history );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryFree", retCode );
      return FD_CSI_HISTORYFREE_FAILED;
   }

   return FD_TEST_PASS;
}

static ErrorNumber checkRangeSame( FD_UDBase          *udb,
                                   const FD_History   *historyRef,
                                   const FD_Timestamp *start,
                                   const FD_Timestamp *end,      
                                   FD_Period           period,                             
                                   unsigned int        startIdx,
                                   unsigned int        nbPriceBar,
                                   const char         *symbol )
{
   FD_History *history;
   unsigned int i;
   FD_RetCode retCode;
   FD_HistoryAllocParam histParam;

   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "CSI_ID";
   histParam.symbol   = symbol;
   histParam.field    = FD_FIELD_ALL;
   histParam.period   = period;
   histParam.start    = *start;
   histParam.end      = *end;
   histParam.flags    = FD_ALLOW_INCOMPLETE_PRICE_BARS;
   retCode = FD_HistoryAlloc( udb, &histParam, &history );

   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryAlloc", retCode );
      return FD_CSI_CRS_HISTORYALLOC_FAILED;
   }

   /* Check that the expected number of price bar is returned. */
   if( history->nbBars != nbPriceBar )
   {
      printf( "Failed: nbBars (received != requested)=(%d != %d)\n",
              history->nbBars, nbPriceBar );

      FD_HistoryFree( history );
      return FD_CSI_CRS_NBBARSBAD;
   }

   /* Check that the data is the same for the range. */
   for( i=0; i < nbPriceBar; i++ )
   {
      if( !FD_TimestampEqual( &history->timestamp[i], &historyRef->timestamp[startIdx+i] ) ||
          (history->open[i] != historyRef->open[startIdx+i]) ||
          (history->high[i] != historyRef->high[startIdx+i]) ||
          (history->low[i] != historyRef->low[startIdx+i]) ||
          (history->close[i] != historyRef->close[startIdx+i]) ||
          (history->volume[i] != historyRef->volume[startIdx+i]) )
      {
         printf( "Failed: Price Bar value different\n" );
         printf( "Failed: Data = %d/%d/%d : %f,%f,%f,%f,%d\n",
                                             FD_GetMonth(&history->timestamp[i]),
                                             FD_GetDay(&history->timestamp[i]),
                                             FD_GetYear(&history->timestamp[i]),
                                             history->open[i],
                                             history->high[i],         
                                             history->low[i],
                                             history->close[i],
                                             history->volume[i] );
         printf( "Failed: Ref  = %d/%d/%d : %f,%f,%f,%f,%d\n",
                                             FD_GetMonth(&historyRef->timestamp[i]),
                                             FD_GetDay(&historyRef->timestamp[i]),
                                             FD_GetYear(&historyRef->timestamp[i]),
                                             historyRef->open[startIdx+i],
                                             historyRef->high[startIdx+i],     
                                             historyRef->low[startIdx+i],
                                             historyRef->close[startIdx+i],
                                             historyRef->volume[startIdx+i] );

         FD_HistoryFree( history );
         return FD_CSI_CRS_PRICEBARBAD;
      }
   }

   retCode = FD_HistoryFree( history );
   if( retCode != FD_SUCCESS )
   {
      reportError( "FD_HistoryFree", retCode );
      return FD_CSI_HISTORYFREE_FAILED;
   }

   return FD_TEST_PASS;
}
