#ifndef FD_TEST_PRIV_H
#define FD_TEST_PRIV_H

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_ERROR_NUMBER_H
   #include "fd_error_number.h"
#endif

ErrorNumber test_period( FD_UDBase *unifiedDatabase );
ErrorNumber test_end_of_period( FD_UDBase *unifiedDatabase );
ErrorNumber test_ascii ( void );
ErrorNumber test_yahoo ( void );
ErrorNumber test_csi   ( void );
ErrorNumber test_datasource_merge( void );
ErrorNumber test_internals( void );
ErrorNumber test_abstract( void );

ErrorNumber freeLib( FD_UDBase  *uDBase );
ErrorNumber allocLib( FD_UDBase **uDBasePtr );

void reportError( const char *str, FD_RetCode retCode );

ErrorNumber checkDataSame( const FD_Real *data,
                           const FD_Real *originalInput,
                           unsigned int nbElement );

/* Check that the content of the first buffer
 * is found in the second buffer (when the elements
 * in the first buffer is NAN, no check is done for
 * this paricular element).
 *
 * Return FD_TEST_PASS if no difference are found.
 */
ErrorNumber checkSameContent( FD_Real *buffer1,
                              FD_Real *buffer2 );

/* Print out info about a retCode */
void printRetCode( FD_RetCode retCode );

/* Function to print character to show that the software is still alive. */
void showFeedback(void);
void hideFeedback(void);

#endif

