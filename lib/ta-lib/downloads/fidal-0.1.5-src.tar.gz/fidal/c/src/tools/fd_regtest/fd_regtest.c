/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  063001 MF   First version (initial framework only).
 *  090404 MF   Add test_candlestick
 */

/* Description:
 *    Perform regression testing of the FIDAL.
 */

/**** Headers ****/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "fd_test_priv.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
static ErrorNumber test_with_simulator( void );
static ErrorNumber testHistoryAlloc( void );

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/
int main( int argc, char **argv )
{
   ErrorNumber retValue;

   (void)argv;

   printf( "\n" );
   printf( "fd_regtest V%s - Regression Tests of FIDAL code\n", FD_GetVersionString() );
   printf( "\n" );

   if( argc > 1 )
   {
      printf( "Usage: fd_regtest\n" );
      printf( "\n" );
      printf( "   No parameter needed.\n" );
      printf( "\n" );
      printf( "   This tool will execute a series of tests to\n" );
      printf( "   make sure that the library is behaving as\n" );
      printf( "   expected.\n\n");

      printf( "   ** Must be run from the 'bin' directory.\n\n" );

      printf( "   On success, the exit code is 0.\n" );
      printf( "   On failure, the exit code is a number that can be\n" );
      printf( "   found in c/src/tools/fd_regtest/fd_error_number.h\n" );

      return FD_REGTEST_BAD_USER_PARAM;
   }

   /* Some tests are using randomness. */
   srand( (unsigned)time( NULL ) );

   /* Test utility like List/Stack/Dictionary/Memory Allocation etc... */
   retValue = test_internals();
   if( retValue != FD_TEST_PASS )
   {
      printf( "\nFailed an internal test with code=%d\n", retValue );
      return retValue;
   }

   /* Test the merging of multiple data source */
   retValue = test_datasource_merge();
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Test the CSI data source. */
#ifdef __64BIT__
   printf( "Skipping testing CSI source - known not working on 64bit systems (bug #1201009)\n" );
#else
   retValue = test_csi();
   if( retValue != FD_TEST_PASS )
      return retValue;
#endif

   /* Test history alloc. */
   retValue = testHistoryAlloc();
   if( retValue != FD_TEST_PASS )
   {
      printf( "Failed FD_HistoryAlloc test with code=%d\n", retValue );
      return retValue;
   }

   /* Test the ASCII data source. */
   retValue = test_ascii();
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Perform all the tests using the FD_SIMULATOR data */
   retValue = test_with_simulator();
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Test the Yahoo! data source. */
   retValue = test_yahoo();
   if( retValue != FD_TEST_PASS )
      return retValue;

   printf( "\n* All tests succeed. Enjoy the library. *\n" );

   return FD_TEST_PASS; /* Everything succeed !!! */
}

/**** Local functions definitions.     ****/
static ErrorNumber test_with_simulator( void )
{
   FD_UDBase  *uDBase;
   FD_History *history;
   FD_AddDataSourceParam param;
   FD_RetCode  retCode;
   ErrorNumber retValue;
   FD_HistoryAllocParam histParam;

   /* Initialize the library. */
   retValue = allocLib( &uDBase );
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Add a datasource using pre-defined data.
    * This data is embedded in the library and does
    * not required any external data provider.
    * The test functions may assume that this data will
    * be unmodified forever by FIDAL.
    */
   memset( &param, 0, sizeof( FD_AddDataSourceParam ) );
   param.id = FD_SIMULATOR;
   retCode = FD_AddDataSource( uDBase, &param );

   if( retCode != FD_SUCCESS )
   {
      printf( "FD_AddDataSource failed [%d]\n", retCode );
      freeLib( uDBase );
      return FD_REGTEST_ADDDATASOURCE_FAILED;
   }

   /* Regression testing of the functionality provided
    * by fd_period.c
    */
   retValue = test_period( uDBase );
   if( retValue != FD_TEST_PASS )
   {
      freeLib( uDBase );
      return retValue;
   }

   /* Test fd_period using end-of-period functionality. */
   retValue = test_end_of_period( uDBase );
   if( retValue != FD_TEST_PASS )
   {
      freeLib( uDBase );
      return retValue;
   }


   /* Allocate the reference historical data. */
   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "FD_SIM_REF";
   histParam.symbol   = "DAILY_REF_0";
   histParam.field    = FD_FIELD_ALL;

   /* first some negative testing - calls that should fail */
   histParam.period   = FD_1MIN;
   retCode = FD_HistoryAlloc( uDBase, &histParam, &history );
   if( retCode != FD_PERIOD_NOT_AVAILABLE )
   {
       printf( "FD_HistoryAlloc did not report FD_PERIOD_NOT_AVAILABLE [%d]\n", retCode );
       freeLib( uDBase );
       return FD_REGTEST_HISTORYALLOC_FAILED;
   }

   /* now allocate the "correct" history */
   histParam.period   = FD_DAILY;
   retCode = FD_HistoryAlloc( uDBase, &histParam, &history );

   if( retCode != FD_SUCCESS )
   {
      printf( "FD_HistoryAlloc failed [%d]\n", retCode );
      freeLib( uDBase );
      return FD_REGTEST_HISTORYALLOC_FAILED;
   }

   /* Clean-up and exit. */

   retCode = FD_HistoryFree( history );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_HistoryFree failed [%d]\n", retCode );
      freeLib( uDBase );
      return FD_REGTEST_HISTORYFREE_FAILED;
   }

   retValue = freeLib( uDBase );
   if( retValue != FD_TEST_PASS )
      return retValue;

   return FD_TEST_PASS; /* All test succeed. */
}


static ErrorNumber testHistoryAlloc( void )
{
   FD_UDBase *unifiedDatabase;
   FD_History *data;
   FD_RetCode retCode;
   FD_InitializeParam param;
   FD_AddDataSourceParam addParam;
   FD_HistoryAllocParam histParam;

   memset( &param, 0, sizeof( FD_InitializeParam ) );
   param.logOutput = stdout;
   retCode = FD_Initialize( &param );

   if( retCode != FD_SUCCESS )
   {
      printf( "Cannot initialize FIDAL (%d)!", retCode );
      return FD_REGTEST_HISTORYALLOC_0;
   }

   /* Create an unified database. */
   if( FD_UDBaseAlloc( &unifiedDatabase ) != FD_SUCCESS )
   {
      FD_Shutdown();
      return FD_REGTEST_HISTORYALLOC_1;
   }
   
   /* USE SIMULATOR DATA */
   memset( &addParam, 0, sizeof( FD_AddDataSourceParam ) );
   addParam.id = FD_SIMULATOR;

   addParam.flags = FD_NO_FLAGS;
   retCode = FD_AddDataSource( unifiedDatabase, &addParam );

   /* Now, display all daily close price available
    * for the DAILY_REF_0 symbol.
    */
   if( retCode != FD_SUCCESS )
      return FD_REGTEST_ADDDSOURCE_FAILED;

   #if defined __BORLANDC__
      #pragma warn -ccc
      #pragma warn -rch
   #endif
      
   #define CHECK_FIELDSUBSET(field_par) \
         { \
            memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) ); \
            histParam.category = "FD_SIM_REF"; \
            histParam.symbol   = "DAILY_REF_0"; \
            histParam.field    = field_par; \
            histParam.period   = FD_DAILY; \
            retCode = FD_HistoryAlloc( unifiedDatabase, &histParam, &data ); \
            if( retCode == FD_SUCCESS ) \
            { \
               if( (field_par) & FD_FIELD_OPEN ) \
               { \
                  if( !data->open ) \
                     return FD_REGTEST_HISTORYALLOC_2; \
                  if( data->open[0] != 92.5 ) \
                     return FD_REGTEST_HISTORYALLOC_3; \
               } \
               else \
               { \
                  if( data->open ) \
                     return FD_REGTEST_HISTORYALLOC_4; \
               } \
               if( (field_par) & FD_FIELD_HIGH ) \
               { \
                  if( !data->high ) \
                     return FD_REGTEST_HISTORYALLOC_5; \
                  if( data->high[0] != 93.25 ) \
                     return FD_REGTEST_HISTORYALLOC_6; \
               } \
               else \
               { \
                  if( data->high ) \
                     return FD_REGTEST_HISTORYALLOC_7; \
               } \
               if( (field_par) & FD_FIELD_LOW ) \
               { \
                  if( !data->low ) \
                     return FD_REGTEST_HISTORYALLOC_8; \
                  if( data->low[0] != 90.75 ) \
                     return FD_REGTEST_HISTORYALLOC_9; \
               } \
               else \
               { \
                  if( data->low ) \
                     return FD_REGTEST_HISTORYALLOC_10; \
               } \
               if( (field_par) & FD_FIELD_CLOSE ) \
               { \
                  if( !data->close ) \
                     return FD_REGTEST_HISTORYALLOC_11; \
                  if( data->close[0] != 91.50 ) \
                     return FD_REGTEST_HISTORYALLOC_12; \
               } \
               else \
               { \
                  if( data->close ) \
                     return FD_REGTEST_HISTORYALLOC_13; \
               } \
               if( (field_par) & FD_FIELD_VOLUME ) \
               { \
                  if( !data->volume ) \
                     return FD_REGTEST_HISTORYALLOC_14; \
                  if( data->volume[0] != 4077500) \
                     return FD_REGTEST_HISTORYALLOC_15; \
               } \
               else \
               { \
                  if( data->volume ) \
                     return FD_REGTEST_HISTORYALLOC_16; \
               } \
               if( (field_par) & FD_FIELD_TIMESTAMP ) \
               { \
                  if( !data->timestamp ) \
                     return FD_REGTEST_HISTORYALLOC_17; \
               } \
               else \
               { \
                  if( data->timestamp ) \
                     return FD_REGTEST_HISTORYALLOC_18; \
               } \
               FD_HistoryFree( data ); \
            } \
            else \
            { \
               printf( "Cannot FD_HistoryAlloc for FD_SIM_REF (%d)!\n", retCode ); \
               return FD_REGTEST_HISTORYALLOC_19; \
            } \
         } 
         /* 6 Fields */
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)

         /* 5 Fields */
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_VOLUME)

         /* 4 Fields */
         CHECK_FIELDSUBSET(FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH)

         /* 3 Fields */
         CHECK_FIELDSUBSET(FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_CLOSE|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_CLOSE|FD_FIELD_HIGH|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_LOW|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_VOLUME)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_LOW)

         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE|FD_FIELD_HIGH)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_HIGH)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_HIGH|FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_HIGH|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_HIGH|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_LOW|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_LOW|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE|FD_FIELD_VOLUME)

         /* Two field. */
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_OPEN)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_HIGH)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_HIGH)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_OPEN|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_HIGH|FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_HIGH|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_HIGH|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_LOW|FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_LOW|FD_FIELD_VOLUME)

         CHECK_FIELDSUBSET(FD_FIELD_CLOSE|FD_FIELD_VOLUME)

         /* One Field */
         CHECK_FIELDSUBSET(FD_FIELD_TIMESTAMP);
         CHECK_FIELDSUBSET(FD_FIELD_OPEN);
         CHECK_FIELDSUBSET(FD_FIELD_HIGH)
         CHECK_FIELDSUBSET(FD_FIELD_LOW)
         CHECK_FIELDSUBSET(FD_FIELD_CLOSE)
         CHECK_FIELDSUBSET(FD_FIELD_VOLUME)

   #undef CHECK_FIELDSUBSET

   /* Clean-up and exit. */
   FD_UDBaseFree( unifiedDatabase );
   FD_Shutdown();
   return FD_SUCCESS;
}
