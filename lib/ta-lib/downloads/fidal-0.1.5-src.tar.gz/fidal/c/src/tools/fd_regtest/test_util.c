/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  112400 MF   First version.
 *
 */

/* Description:
 *     Provide utility function internally used in fd_regtest only.
 */

/**** Headers ****/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fd_test_priv.h"
#include "trionan.h"
#include "fd_memory.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/*FD_FILE_INFO;*/

/* Global temporary buffers used while testing. */
#define RESV_PATTERN_MEMGUARD_1   (2.4789205E-150)
#define RESV_PATTERN_MEMGUARD_2   (4.2302468E-165)

#define RESV_PATTERN_PREFIX       (9.1349043E-200)
#define RESV_PATTERN_SUFFIX       (8.1489031E-158)
#define RESV_PATTERN_IMPROBABLE   (-2.849284E-199)

#define RESV_PATTERN_PREFIX_INT     (FD_INTEGER_DEFAULT)
#define RESV_PATTERN_SUFFIX_INT     (FD_INTEGER_DEFAULT)
#define RESV_PATTERN_IMPROBABLE_INT (FD_INTEGER_DEFAULT)

#define FD_BUF_PREFIX 100
#define FD_BUF_SUFFIX 100
#define FD_BUF_SIZE   (FD_BUF_PREFIX+MAX_NB_TEST_ELEMENT+FD_BUF_SUFFIX)

#define FD_NB_OUT 3
#define FD_NB_IN  1
#define FD_NB_OUT_IN (FD_NB_OUT+FD_NB_IN)

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
static void myFatalHandler( void );

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/
static int fd_g_val = 0;
static const char *fd_g_wheel = "-\\|/";
void showFeedback()
{
   if( fd_g_wheel[fd_g_val] == '\0' )
      fd_g_val = 0; 
   putchar('\b');
   putchar(fd_g_wheel[fd_g_val]);
   fflush(stdout);
   fd_g_val++;
}

void hideFeedback()
{
   putchar('\b');
   fflush(stdout);
   fd_g_val = 0;
}

ErrorNumber allocLib( FD_UDBase **uDBasePtr )
{
   FD_InitializeParam initializeParam;
   FD_RetCode retCode;
   FD_UDBase *uDBase;

   /* Initialize the library. */
   memset( &initializeParam, 0, sizeof( FD_InitializeParam ) );
   initializeParam.logOutput = stdout;

   retCode = FD_Initialize( &initializeParam );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_Initialize failed [%d]\n", retCode );
      return FD_TESTUTIL_INIT_FAILED;
   }
   
   /* Install a fatal error handler. */
   retCode = FD_SetFatalErrorHandler( myFatalHandler );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_SetFatalErrorHandler failed [%d]\n", retCode );
      FD_Shutdown();
      return FD_TESTUTIL_SET_FATAL_ERROR_FAILED;
   }
      
   /* Create an unified database. */
   retCode = FD_UDBaseAlloc( &uDBase );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_UDBaseAlloc failed [%d]\n", retCode );
      FD_Shutdown();
      return FD_TESTUTIL_UDBASE_ALLOC_FAILED;
   }

   *uDBasePtr = uDBase;

   return FD_TEST_PASS;
}

ErrorNumber freeLib( FD_UDBase  *uDBase )
{
   FD_RetCode retCode;

   /* For testing purpose */
   /* FD_FATAL_RET( "Test again", 100, 200, 0 ); */

   retCode = FD_UDBaseFree( uDBase );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_UDBaseFree failed [%d]\n", retCode );
      return FD_TESTUTIL_UDBASE_FREE_FAILED;
   }

   retCode = FD_Shutdown();
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_Shutdown failed [%d]\n", retCode );
      return FD_TESTUTIL_SHUTDOWN_FAILED;
   }

   return FD_TEST_PASS;
}

void reportError( const char *str, FD_RetCode retCode )
{
   FD_RetCodeInfo retCodeInfo;

   FD_SetRetCodeInfo( retCode, &retCodeInfo );

   printf( "%s,%d==%s\n", str, retCode, retCodeInfo.enumStr );
   printf( "[%s]\n", retCodeInfo.infoStr );
}

/* Need to be called only once. */

void printRetCode( FD_RetCode retCode )
{
   FD_RetCodeInfo retCodeInfo;

   FD_SetRetCodeInfo( retCode, &retCodeInfo );
   printf( "\nFailed: ErrorCode %d=%s:[%s]\n", retCode,
           retCodeInfo.enumStr,
           retCodeInfo.infoStr );
}



/**** Local functions definitions.     ****/
static void myFatalHandler( void )
{
   FD_FatalReport( stdout );

#if 0
   /* Can be used for testing purpose */
   char *b = (char *)malloc(FD_FATAL_ERROR_BUF_SIZE);
   if( b )
   {
      FD_FatalReportToBuffer( b, FD_FATAL_ERROR_BUF_SIZE );
      printf( b );
   }
#endif
}
