This directory contains data used for the self-tests
and regression tests of the FIDAL. 

- The perl scripts in this directory shall be used only
by FIDAL developper for re-generating some of the
data files.

- The "gen_data.c" is used to create the gen_data executable.
This executable generates the .c that are going to be link
with the FIDAL library. This is how the data is embedded
into the library!

