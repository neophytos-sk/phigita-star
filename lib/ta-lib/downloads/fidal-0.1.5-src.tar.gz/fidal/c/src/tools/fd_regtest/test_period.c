/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  PK       Pawel Konieczny
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070401 MF   First version.
 *  062203 MF   Add intra-day to daily test using the "ES.CSV" file.
 *  082404 MF   Adapt to new date logic for price bar. Now the
 *              date represent the begining of an interval instead
 *              of the end.
 *  062105 PK   Added end-of-period tests.
 */

/* Description:
 *         Regression testing of the functionality provided
 *         by the file fd_period.c
 */

/**** Headers ****/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fd_test_priv.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   const char *symbol;
   FD_Period period;
   FD_HistoryFlag flags;
   unsigned int nbExpectedPriceBar;
   FD_Integer thePriceBarToCheck;
   unsigned int expected_year;
   unsigned int expected_month;
   unsigned int expected_day;
   unsigned int expected_hour;
   unsigned int expected_min;
   unsigned int expected_sec;
   FD_Real expected_open;
   FD_Real expected_high;
   FD_Real expected_low;
   FD_Real expected_close;
   FD_Integer expected_volume;
   FD_Integer expected_openInterest;
} FD_PriceBarCheck;

typedef struct
{
   FD_Timestamp *start;
   FD_Timestamp *end;
   unsigned int  expectedDelta;
} WeekDayCheck;

/**** Local functions declarations.    ****/
static ErrorNumber compare_period_series( FD_History *history1, FD_History *history2 );
static ErrorNumber validate_end_of_period_series_intraday( FD_History *historyBop, FD_History *historyEop, FD_Period period );
static ErrorNumber validate_end_of_period_series_dailyplus( FD_History *historyBop, FD_History *historyEop, FD_Period period );
static ErrorNumber testTimestampDelta( void );

/**** Local variables definitions.     ****/
const char *fail_header = "Fail: test_period,Test #";

static FD_PriceBarCheck checkTable[] = 
{

  { "ES", FD_WEEKLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
     1,   0, 2003,  5, 18,   0,  0,  0,  921.50,  925.75,  911.25,  920.00,  (713627+765554)/2, 0 },

  { "ES", FD_WEEKLY, 0,
    0, 0, 0,  0, 0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0, 0 },

  { "ES", FD_5MINS, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    482, 258, 2003,  5, 21,   0,  0,  0,  920.75,  920.75,  920.25,  920.50,  44, 0 },

  { "ES", FD_5MINS, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    482,   0, 2003,  5, 20,   0, 45,  0,  921.50,  922.00,  921.50,  922.00,  12, 0 },

  { "ES", FD_5MINS, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    482, 257, 2003,  5, 20,  22, 55,  0,  920.50,  920.50,  920.50,  920.50,   1, 0 },

  { "ES", FD_5MINS, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    482, 481, 2003,  5, 21,  19, 15,  0,  920.25,  920.25,  920.00,  920.00,  19, 0 },

  { "ES", FD_DAILY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    2,   1, 2003,  5, 21,   0,  0,  0,  920.75,  924.25,  913.25,  920.00,  765554, 0 },

  { "ES", FD_DAILY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    2,   0, 2003,  5, 20,   0,  0,  0,  921.50,  925.75,  911.25,  920.50,  713627, 0 },

  { "ES", FD_MONTHLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    1,   0, 2003,  5,  1,   0,  0,  0,  921.50,  925.75,  911.25,  920.00,  (713627+765554)/2, 0 },

  { "ES", FD_QUARTERLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    1,   0, 2003,  4,  1,   0,  0,  0,  921.50,  925.75,  911.25,  920.00,  (713627+765554)/2, 0 },
 
  { "ES", FD_YEARLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    1,   0, 2003,  1,  1,   0,  0,  0,  921.50,  925.75,  911.25,  920.00,  (713627+765554)/2, 0 },


  { "DAILY_REF_0", FD_WEEKLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    52,   0, 1999,  1,  3,   0,  0,  0,  92.500,  96.375,  90.750,  93.780,  4511420, 0 },

  { "DAILY_REF_0", FD_WEEKLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    52,   1, 1999,  1, 10,   0,  0,  0,  94.500,  95.000,  89.440,  92.470,  3973160, 0 },

  { "DAILY_REF_0", FD_WEEKLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    52,  50, 1999, 12, 19,   0,  0,  0,  109.060, 110.440, 107.750, 108.620,  4539425, 0 },

  { "DAILY_REF_0", FD_WEEKLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    52,  51, 1999, 12, 26,   0,  0,  0,  109.690, 110.750, 106.620, 107.870,  3363920, 0 },

  { "DAILY_REF_0", FD_MONTHLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    12,   0, 1999,  1,  1,   0,  0,  0,  92.500,  99.625,  86.750,  91.625,  6494478, 0 },

  { "DAILY_REF_0", FD_MONTHLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    12,   1, 1999,  2,  1,   0,  0,  0,  92.250,  92.250,  80.875,  84.875,  5347410, 0 },

  { "DAILY_REF_0", FD_MONTHLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    12,  11, 1999, 12,  1,   0,  0,  0,  102.560, 122.120, 102.250, 107.870,  7213263, 0 },

  { "DAILY_REF_0", FD_QUARTERLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    4,   0, 1999,  1,  1,   0,  0,  0,  92.500,  99.625,  80.875,  88.625,  5580475, 0 },

  { "DAILY_REF_0", FD_QUARTERLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    4,   1, 1999,  4,  1,   0,  0,  0,  88.655, 132.000,  81.500, 129.250,  6024341, 0 },

  { "DAILY_REF_0", FD_QUARTERLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    4,   2, 1999,  7,  1,   0,  0,  0,  130.000, 139.190, 117.560, 121.000,  6397878, 0 },

  { "DAILY_REF_0", FD_QUARTERLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    4,   3, 1999, 10,  1,   0,  0,  0,  121.000, 123.250,  89.000, 107.870, 10614132, 0 },

  { "DAILY_REF_0", FD_YEARLY, FD_ALLOW_INCOMPLETE_PRICE_BARS,
    1,   0, 1999,  1,  1,   0,  0,  0,  92.500, 139.190,  80.875, 107.870,  7177425, 0 }

};
#define CHECK_TABLE_SIZE (sizeof(checkTable)/sizeof(FD_PriceBarCheck))

static FD_Timestamp sundayTS,  mondayTS,  tuesdayTS,  wednesdayTS,  thursdayTS,  fridayTS,  saturdayTS,
                    sunday2TS, monday2TS, tuesday2TS, wednesday2TS, thursday2TS, friday2TS, saturday2TS;                    
static WeekDayCheck toCheck[] = { 
   { &sundayTS, &sundayTS, 0 },
   { &sundayTS, &mondayTS, 1 },
   { &sundayTS, &tuesdayTS, 2 },
   { &sundayTS, &wednesdayTS, 3 },
   { &sundayTS, &thursdayTS, 4 },
   { &sundayTS, &fridayTS, 5 },
   { &sundayTS, &saturdayTS, 5 },
   { &sundayTS, &sunday2TS, 5 },
   { &sundayTS, &monday2TS, 6 },
   { &sundayTS, &tuesday2TS, 7 },
   { &sundayTS, &wednesday2TS, 8 },
   { &sundayTS, &thursday2TS, 9 },
   { &sundayTS, &friday2TS, 10 },
   { &sundayTS, &saturday2TS, 10 },

   { &mondayTS, &sundayTS, 1}, /* Test #14 */
   { &mondayTS, &mondayTS, 1 },
   { &mondayTS, &tuesdayTS, 2 },
   { &mondayTS, &wednesdayTS, 3 },
   { &mondayTS, &thursdayTS, 4 },
   { &mondayTS, &fridayTS, 5 },
   { &mondayTS, &saturdayTS, 5 },
   { &mondayTS, &sunday2TS, 5 },
   { &mondayTS, &monday2TS, 6 },
   { &mondayTS, &tuesday2TS, 7 },
   { &mondayTS, &wednesday2TS, 8 },
   { &mondayTS, &thursday2TS, 9 },
   { &mondayTS, &friday2TS, 10 },
   { &mondayTS, &saturday2TS, 10 } };

#define NB_WEEKDAY_CHECK_TO_DO (sizeof(toCheck)/sizeof(WeekDayCheck))

/**** Global functions definitions.   ****/
/* None */

/**** Local functions definitions.     ****/
ErrorNumber test_period( FD_UDBase *unifiedDatabase )
{
   FD_RetCode retCode;
   FD_History *history;
   const FD_Timestamp *timestamp;
   unsigned int i;
   ErrorNumber retValue;
   FD_AddDataSourceParam addParam;
   FD_HistoryAllocParam histParam;

   printf( "Testing period/timeframe conversion\n" );

   /* Add access to some intra-day data. */
   memset( &addParam, 0, sizeof( FD_AddDataSourceParam) );
   addParam.id = FD_ASCII_FILE;
   addParam.location = "..\\src\\tools\\fd_regtest\\sampling\\ES.csv";
   addParam.info ="[YY][MM][DD][HH][MN=5][O][H][L][C][V]";
   addParam.category = "FD_SIM_REF";
   retCode = FD_AddDataSource( unifiedDatabase,&addParam );
   if( retCode != FD_SUCCESS )
   {
      printf( "Can't access [%s] (%d)\n", addParam.location, retCode );
      return FD_PERIOD_HISTORYALLOC_FAILED;
   }

   /* Because period transformation are very
    * dependent on the "delta" timestamp functions,
    * let's independently verify some of these.
    */
   retValue = testTimestampDelta();
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Verify everything from the checkTable. */
   for( i=0; i < CHECK_TABLE_SIZE; i++ )
   {
      /* Validate by requesting all the data in a
       * different timeframe.
       */
      memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
      histParam.category = "FD_SIM_REF";
      histParam.symbol   = checkTable[i].symbol;
      histParam.field    = FD_FIELD_ALL;
      histParam.period   = checkTable[i].period;
      histParam.flags    = checkTable[i].flags;
      retCode = FD_HistoryAlloc( unifiedDatabase, &histParam, &history );

      if( retCode != FD_SUCCESS )
      {
         printf( "%s%d.1 [%d]\n", fail_header, i, retCode );
         return FD_PERIOD_HISTORYALLOC_FAILED;
      }

      if( history->nbBars != checkTable[i].nbExpectedPriceBar )
      {
         printf( "%s%d.2 [%d != %d]\n",
                 fail_header, i,
                 history->nbBars,
                 checkTable[i].nbExpectedPriceBar );
         FD_HistoryFree( history );
         return FD_PERIOD_NBBAR_INCORRECT;
      }

      /* If the call is expected to return an empty history, no further check are done. */
      if( checkTable[i].nbExpectedPriceBar == 0 )
      {
         retCode = FD_HistoryFree( history );
         if( retCode != FD_SUCCESS )
         {
           printf( "%s%d.16 [%d]\n", fail_header, i, retCode );
           return FD_PERIOD_HISTORYFREE_FAILED;
         }
         continue;
      }

      #define CHECK_VALUE_OK(varName, subtestNo ) \
      { \
         if( history->varName[checkTable[i].thePriceBarToCheck] != checkTable[i].expected_##varName ) \
         { \
            printf( "%s%d.%d [%f != %f]\n", \
                    fail_header, i, subtestNo, \
                    (FD_Real) history->varName[checkTable[i].thePriceBarToCheck], \
                    (FD_Real) checkTable[i].expected_##varName ); \
            FD_HistoryFree( history ); \
            return FD_PERIOD_PRICE_INCORRECT; \
         } \
      }

      CHECK_VALUE_OK( open,   3 );
      CHECK_VALUE_OK( high,   4 );
      CHECK_VALUE_OK( low,    5 );
      CHECK_VALUE_OK( close,  6 );
      CHECK_VALUE_OK( volume, 7 );

      if( history->openInterest != NULL )
      {
         printf( "%s%d.8\n", fail_header, i );
         FD_HistoryFree( history );
         return FD_PERIOD_OPENINTEREST_INCORRECT;
      }

      timestamp = &history->timestamp[checkTable[i].thePriceBarToCheck];
      if( FD_GetYear( timestamp ) != checkTable[i].expected_year )
      {
         printf( "%s%d.9 %d\n", fail_header, i, FD_GetYear(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_YEAR_INCORRECT;
      }

      if( FD_GetMonth( timestamp ) != checkTable[i].expected_month )
      {
         printf( "%s%d.10 %d\n", fail_header, i, FD_GetMonth(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_MONTH_INCORRECT;
      }

      if( FD_GetDay( timestamp ) != checkTable[i].expected_day )
      {
         printf( "%s%d.11 %d\n", fail_header, i, FD_GetDay(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_DAY_INCORRECT;
      }

      if( FD_GetHour( timestamp ) != checkTable[i].expected_hour )
      {
         printf( "%s%d.12 %d\n", fail_header, i, FD_GetHour(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_DAY_INCORRECT;
      }

      if( FD_GetMin( timestamp ) != checkTable[i].expected_min )
      {
         printf( "%s%d.13 %d\n", fail_header, i, FD_GetMin(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_DAY_INCORRECT;
      }

      if( FD_GetSec( timestamp ) != checkTable[i].expected_sec )
      {
         printf( "%s%d.14 %d\n", fail_header, i, FD_GetSec(timestamp) );
         FD_HistoryFree( history );
         return FD_PERIOD_TIMESTAMP_DAY_INCORRECT;
      }

      retCode = FD_HistoryFree( history );
      if( retCode != FD_SUCCESS )
      {
         printf( "%s%d.15 [%d]\n", fail_header, i, retCode );
         return FD_PERIOD_HISTORYFREE_FAILED;
      }
   }

   return 0; /* Succcess. */
}


ErrorNumber test_end_of_period( FD_UDBase *mainDatabase )
{
   FD_RetCode  retCode;
   ErrorNumber retValue;
   FD_AddDataSourceParam  sourceParam;
   FD_HistoryAllocParam  histParam;
   FD_History  *historyBop, *historyEop;
   FD_UDBase  *localDatabase;

#define CLEANUP_AND_RETURN_WITH_ERROR(errorMsg,retCode,retValue)  \
   {                                                              \
      printf(errorMsg, retCode);                                  \
      if (historyBop)                                             \
         FD_HistoryFree( historyBop );                            \
      if (historyEop)                                             \
         FD_HistoryFree( historyEop );                            \
                                                                  \
      retCode = FD_UDBaseFree( localDatabase );                   \
      if( retCode != FD_SUCCESS )                                 \
      {                                                           \
         printf( "FD_UDBaseFree failed [%d]\n", retCode );        \
      }                                                           \
                                                                  \
      return retValue;                                            \
   }

   /* The main database uses the beginning-of-period logic.
    * The "localDatabase" will use end-of-period logic.
    */
   retCode = FD_UDBaseAlloc( &localDatabase );
   if( retCode != FD_SUCCESS )
   {
      printf( "FD_UDBaseAlloc failed [%d]\n", retCode );
      return FD_TESTUTIL_UDBASE_ALLOC_FAILED;
   }

   /* Adding end-of-period source to an empty database 
    * should always succeed.
    */
   memset( &sourceParam, 0, sizeof( FD_AddDataSourceParam ) );
   sourceParam.id = FD_SIMULATOR;
   sourceParam.flags = FD_SOURCE_USES_END_OF_PERIOD;
   historyBop = historyEop = NULL;
   retCode = FD_AddDataSource( localDatabase, &sourceParam );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_AddDataSource (end->empty) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_ADD_FAILED
      );

   /* Check whether history flags are treated consistently */
   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = "FD_SIM_REF";
   histParam.symbol   = "INTRA_REF_0";
   histParam.period   = FD_10MINS;  /* no consolidation */
   histParam.field    = FD_FIELD_ALL;
   histParam.flags    = FD_NO_FLAGS;
   
   /* Allocating regular history (no conversion) should succeed */
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin->begin) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );

   /* No conversion but end-of-period logic history */
   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (end->end) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );

   /* Test whether the EOP history is indeed end-of-period stamped */
   retValue = validate_end_of_period_series_intraday( historyBop, historyEop, FD_10MINS );

   if( retValue != FD_TEST_PASS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "End-of-period stamped quotes are invalid [%d]\n",
         retCode,
         retValue
      );

   /* Test whether conversion from BOP to EOP works */
   /* Use the same history parameters as before, but request from the main database (BOP) */
   FD_HistoryFree( historyEop );
   historyEop = NULL;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyEop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin->end) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );

   /* Test whether the EOP history is indeed end-of-period stamped */
   retValue = validate_end_of_period_series_intraday( historyBop, historyEop, FD_10MINS );

   if( retValue != FD_TEST_PASS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "Converted end-of-period stamped quotes are invalid [%d]\n",
         retCode,
         retValue
      );

   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;

   /* Try retrieving some consolidated data */
   histParam.period   = FD_30MINS;
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin consolidated) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );

   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (end consolidated) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );

   /* Test whether the consolidated EOP history is correct */
   retValue = validate_end_of_period_series_intraday( historyBop, historyEop, FD_30MINS );

   if( retValue != FD_TEST_PASS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "End-of-period stamped consolidated quotes are invalid [%d]\n",
         retCode,
         retValue
      );

   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;

   /* testing consolidation from intraday to daily */
   histParam.period   = FD_DAILY;
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );
   
   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin consolidated, daily) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );
   
   if( retCode != FD_SUCCESS && retCode != FD_PERIOD_NOT_AVAILABLE )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (end consolidated, daily) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   /* If the consolidation is implemented, test whether the consolidated EOP history is correct */
   if( retCode == FD_SUCCESS )
   {
      retValue = validate_end_of_period_series_dailyplus( historyBop, historyEop, FD_DAILY );
   
      if( retValue != FD_TEST_PASS )
         CLEANUP_AND_RETURN_WITH_ERROR(
            "End-of-period stamped consolidated quotes (daily) are invalid [%d]\n",
            retCode,
            retValue
         );
   }

   /* Test whether conversion & consolidation from EOP to BOP works */
   /* Request BOP from the local database (EOP) */
   FD_HistoryFree( historyEop );  /* reusing historyEop as historyBop2 */
   historyEop = NULL;
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );

   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (end->begin consolidated, daily) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );

   /* Test whether the converted BOP2 history is identical to the original */
   retValue = compare_period_series( historyBop, historyEop );

   if( retValue != FD_TEST_PASS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "Converted end-of-period stamped quotes (daily) are invalid [%d]\n",
         retCode,
         retValue
      );

   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;

   /* testing EOD daily data, unconsolidated */
   histParam.symbol   = "DAILY_REF_0";
   histParam.period   = FD_DAILY;  /* no consolidation */
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );
   
   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin, daily) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );
   
   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );
   
   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (end, daily) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_HISTORY_FAILED
      );
   
   /* Test whether the consolidated EOP history is correct */
   retValue = validate_end_of_period_series_dailyplus( historyBop, historyEop, FD_DAILY );
   
   if( retValue != FD_TEST_PASS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "End-of-period stamped quotes (daily) are invalid [%d]\n",
         retCode,
         retValue
      );
   
   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;


   /* testing EOD consolidation to weekly data */
   histParam.period   = FD_WEEKLY;  /* consolidate */
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );
   
   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
         "FD_HistoryAlloc (begin consolidated, weekly) failed [%d]\n",
         retCode,
         FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );
   
   if( retCode != FD_SUCCESS && retCode != FD_PERIOD_NOT_AVAILABLE )
      CLEANUP_AND_RETURN_WITH_ERROR(
      "FD_HistoryAlloc (end consolidated, weekly) failed [%d]\n",
      retCode,
      FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   /* If the consolidation is implemented, test whether the consolidated EOP history is correct */
   if( retCode == FD_SUCCESS )
   {
      retValue = validate_end_of_period_series_dailyplus( historyBop, historyEop, FD_WEEKLY );

      if( retValue != FD_TEST_PASS )
         CLEANUP_AND_RETURN_WITH_ERROR(
            "End-of-period stamped quotes (weekly) are invalid [%d]\n",
            retCode,
            retValue
         );
   }
   
   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;
   

   /* testing EOD consolidation to monthly data */
   histParam.period   = FD_MONTHLY;  /* consolidate */
   histParam.flags   &= ~FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( mainDatabase, &histParam, &historyBop );
   
   if( retCode != FD_SUCCESS )
      CLEANUP_AND_RETURN_WITH_ERROR(
      "FD_HistoryAlloc (begin consolidated, monthly) failed [%d]\n",
      retCode,
      FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   histParam.flags   |= FD_USE_END_OF_PERIOD;
   retCode = FD_HistoryAlloc( localDatabase, &histParam, &historyEop );
   
   if( retCode != FD_SUCCESS && retCode != FD_PERIOD_NOT_AVAILABLE )
      CLEANUP_AND_RETURN_WITH_ERROR(
      "FD_HistoryAlloc (end consolidated, monthly) failed [%d]\n",
      retCode,
      FD_PERIOD_END_OF_PERIOD_CONSOLIDATED_FAILED
      );
   
   /* If the consolidation is implemented, test whether the consolidated EOP history is correct */
   if( retCode == FD_SUCCESS )
   {
      retValue = validate_end_of_period_series_dailyplus( historyBop, historyEop, FD_MONTHLY );
 
      if( retValue != FD_TEST_PASS )
         CLEANUP_AND_RETURN_WITH_ERROR(
         "End-of-period stamped quotes (monthly) are invalid [%d]\n",
         retCode,
         retValue
         );
   }
   
   FD_HistoryFree( historyBop );
   FD_HistoryFree( historyEop );
   historyBop = historyEop = NULL;
   
   

#undef CLEANUP_AND_RETURN_WITH_ERROR

   retCode = FD_UDBaseFree( localDatabase );
   if( retCode != FD_SUCCESS )
   {
       printf( "FD_UDBaseFree failed [%d]\n", retCode );
   }

   return FD_TEST_PASS; /* Success. */
}



static ErrorNumber compare_period_series( FD_History *history1, FD_History *history2 )
{
   FD_RetCode retCode;
   unsigned int i;

   if( !history1 || !history2 )
   {
      printf( "History series is null\n");
      return FD_PERIOD_HISTORYCOMPARE_FAILED;
   }
   
   if( history1->nbBars != history2->nbBars )
   {
       printf( "History series not equal length\n");
       return FD_PERIOD_HISTORYCOMPARE_FAILED;
   }

   for ( i = 0;  i < history1->nbBars && i < history2->nbBars;  i++)
   {
       retCode = FD_TimestampValidate( &history1->timestamp[i] );
       if( retCode != FD_SUCCESS )
       {
           printf( "History 1 timestamp invalid [%d]\n", retCode );
           return FD_PERIOD_HISTORYCOMPARE_FAILED;
       }

       retCode = FD_TimestampValidate( &history2->timestamp[i] );
       if( retCode != FD_SUCCESS )
       {
           printf( "History 2 timestamp invalid [%d]\n", retCode );
           return FD_PERIOD_HISTORYCOMPARE_FAILED;
       }

       /* the timestamps of both series should be shifted by period */
       if( ! FD_TimestampEqual( &history1->timestamp[i], &history2->timestamp[i] ) )
       {
           printf( "Compared history timestamp unequal\n" );
           return FD_PERIOD_HISTORYCOMPARE_FAILED;
       }

       /* check whether quotes match */
#define CHECK_HISTORY_FIELD(field)                                        \
       if( history1->field && history2->field )                           \
       {                                                                  \
           if( history1->field[i] != history2->field[i] )                 \
           {                                                              \
               printf( "History series unequal, field: %s, record: %d\n", #field, i ); \
               return FD_PERIOD_HISTORYCOMPARE_FAILED;                    \
           }                                                              \
       } else if( history1->field != history2->field )                    \
       {                                                                  \
           printf( "History series unequal, field: %s\n", #field );       \
           return FD_PERIOD_HISTORYCOMPARE_FAILED;                        \
       }

       CHECK_HISTORY_FIELD(open)
       CHECK_HISTORY_FIELD(high)
       CHECK_HISTORY_FIELD(low)
       CHECK_HISTORY_FIELD(close)
       CHECK_HISTORY_FIELD(volume)
       CHECK_HISTORY_FIELD(openInterest)

#undef CHECK_HISTORY_FIELD

   }

   return FD_TEST_PASS;
}



static ErrorNumber validate_end_of_period_series_intraday( FD_History *historyBop, FD_History *historyEop, FD_Period period )
{
   FD_RetCode retCode;
   FD_Timestamp ts;
   unsigned int i;

   if( !historyBop || !historyEop )
   {
      printf( "History series is null\n");
      return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
   }
   
   if( historyBop->nbBars != historyEop->nbBars )
   {
       printf( "History series not equal length\n");
       return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
   }

   for ( i = 0;  i < historyBop->nbBars && i < historyEop->nbBars;  i++)
   {
       retCode = FD_TimestampValidate( &historyBop->timestamp[i] );
       if( retCode != FD_SUCCESS )
       {
           printf( "History BOP timestamp invalid [%d]\n", retCode );
           return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
       }

       retCode = FD_TimestampValidate( &historyEop->timestamp[i] );
       if( retCode != FD_SUCCESS )
       {
           printf( "History EOP timestamp invalid [%d]\n", retCode );
           return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
       }

       /* the timestamps of both series should be shifted by period */
       FD_AddTimeToTimestamp( &ts, &historyBop->timestamp[i], period );
       if( ! FD_TimestampEqual( &ts, &historyEop->timestamp[i] ) )
       {
           printf( "End-of-period history timestamp incorrect\n" );
           return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
       }

       /* check whether quotes match */
#define CHECK_HISTORY_FIELD(field)                                        \
       if( historyBop->field && historyEop->field )                       \
       {                                                                  \
           if( historyBop->field[i] != historyEop->field[i] )             \
           {                                                              \
               printf( "History series inconsistent, field: %s, record: %d\n", #field, i ); \
               return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;              \
           }                                                              \
       } else if( historyBop->field != historyEop->field )                \
       {                                                                  \
           printf( "History series inconsistent, field: %s\n", #field );  \
           return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;                  \
       }

       CHECK_HISTORY_FIELD(open)
       CHECK_HISTORY_FIELD(high)
       CHECK_HISTORY_FIELD(low)
       CHECK_HISTORY_FIELD(close)
       CHECK_HISTORY_FIELD(volume)
       CHECK_HISTORY_FIELD(openInterest)

#undef CHECK_HISTORY_FIELD

   }

   return FD_TEST_PASS;
}



static ErrorNumber validate_end_of_period_series_dailyplus( FD_History *historyBop, FD_History *historyEop, FD_Period period )
{
   FD_RetCode retCode;
   unsigned int i;
   unsigned int delta;

   if( !historyBop || !historyEop )
   {
      printf( "History series is null\n");
      return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
   }
   
   if( historyBop->nbBars != historyEop->nbBars )
   {
      printf( "History series not equal length (%u != %u)\n", historyBop->nbBars, historyEop->nbBars);
      return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
   }
   
   for ( i = 0;  i < historyBop->nbBars && i < historyEop->nbBars;  i++)
   {
      retCode = FD_TimestampValidate( &historyBop->timestamp[i] );
      if( retCode != FD_SUCCESS )
      {
         printf( "History BOP timestamp invalid [%d]\n", retCode );
         return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
      }
      
      retCode = FD_TimestampValidate( &historyEop->timestamp[i] );
      if( retCode != FD_SUCCESS )
      {
         printf( "History EOP timestamp invalid [%d]\n", retCode );
         return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
      }
      
      /* for daily (and up) data, time should be 00:00:00
       */
      if ( FD_GetHour(&historyBop->timestamp[i]) != 0 ||
           FD_GetMin( &historyBop->timestamp[i]) != 0 ||
           FD_GetSec( &historyBop->timestamp[i]) != 0 ) 
      {
         printf( "History BOP timestamp time incorrect\n" );
         return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
      }

      if ( FD_GetHour(&historyEop->timestamp[i]) != 0 ||
           FD_GetMin( &historyEop->timestamp[i]) != 0 ||
           FD_GetSec( &historyEop->timestamp[i]) != 0 ) 
      {
         printf( "History EOP timestamp time incorrect\n" );
         return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
      }
      
      switch( period) 
      {
      case FD_DAILY:
         /* EOP should be a day after BOP */
         FD_TimestampDeltaDay( &historyBop->timestamp[i], &historyEop->timestamp[i], &delta );
         if( ! FD_TimestampDateLess( &historyBop->timestamp[i], &historyEop->timestamp[i] )
            || (delta != 2) )
         {
            printf( "End-of-period history timestamp incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         break;

      case FD_WEEKLY:
         /* weeks are timestamped on Sunday */
         if ( FD_GetDayOfTheWeek( &historyBop->timestamp[i] ) != FD_SUNDAY )
         {
            printf( "Weekly history BOP timestamp date incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         if ( FD_GetDayOfTheWeek( &historyEop->timestamp[i] ) != FD_SUNDAY )
         {
            printf( "Weekly history EOP timestamp date incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         /* as for the rest, EOP has to be one week after BOP */
         if( FD_GetWeekOfTheYear( &historyBop->timestamp[i] )+1 != FD_GetWeekOfTheYear( &historyEop->timestamp[i] ) )
         {
            /* condone special case - end of year */
            if (FD_GetWeekOfTheYear( &historyBop->timestamp[i] ) == 51 && FD_GetWeekOfTheYear( &historyEop->timestamp[i] ) == 0)
               break;
            if (FD_GetWeekOfTheYear( &historyBop->timestamp[i] ) == 52 && FD_GetWeekOfTheYear( &historyEop->timestamp[i] ) == 1)
               break;

            printf( "End-of-period weekly history timestamp incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         break;

      case FD_MONTHLY:
         /* months are timestamped on 1st */
         if ( FD_GetDay( &historyBop->timestamp[i] ) != 1 )
         {
            printf( "Monthly history BOP timestamp date incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         if ( FD_GetDay( &historyBop->timestamp[i] ) != 1 )
         {
            printf( "Monthly history EOP timestamp date incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         /* as for the rest, EOP has to be one month after BOP */
         if ( FD_GetMonth( &historyBop->timestamp[i] )+1 != FD_GetMonth( &historyEop->timestamp[i] ) )
         {
            if ( FD_GetMonth( &historyBop->timestamp[i] ) != 12 
                && FD_GetMonth( &historyEop->timestamp[i]) != 1 
                && FD_GetYear( &historyBop->timestamp[i] )+1 != FD_GetYear( &historyEop->timestamp[i] ) )
            {
               printf( "End-of-period monthly history timestamp incorrect\n" );
               return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
            }
         }
         else if ( FD_GetYear( &historyBop->timestamp[i] ) != FD_GetYear( &historyEop->timestamp[i] ) )
         {
            printf( "End-of-period monthly history timestamp incorrect\n" );
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;
         }
         break;

      default:
         ; /* no further checks */
      }

      /* check whether quotes match */
#define CHECK_HISTORY_FIELD(field)                                                 \
   if( historyBop->field && historyEop->field )                                    \
      {                                                                            \
         if( historyBop->field[i] != historyEop->field[i] )                        \
         {                                                                         \
            printf( "History series inconsistent, field: %s, record: %d\n", #field, i ); \
            return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;                          \
         }                                                                         \
      } else if( historyBop->field != historyEop->field )                          \
      {                                                                            \
         printf( "History series inconsistent, field: %s\n", #field );             \
         return FD_PERIOD_END_OF_PERIOD_WRONG_HISTORY;                             \
      }
      
      CHECK_HISTORY_FIELD(open)
         CHECK_HISTORY_FIELD(high)
         CHECK_HISTORY_FIELD(low)
         CHECK_HISTORY_FIELD(close)
         CHECK_HISTORY_FIELD(volume)
         CHECK_HISTORY_FIELD(openInterest)
         
#undef CHECK_HISTORY_FIELD
         
   }
   
   return FD_TEST_PASS;
}






/* Period transformation is highly dependable on
 * the function evaluating the 'delta' between
 * two timestamp, so this is verified here.
 */
static ErrorNumber testTimestampDelta( void )
{
   FD_RetCode retCode;
   unsigned int i, delta; 

   /* !!! A lot more of testing could be added !!! */

   /* Test weekday delta. */
   FD_SetDate( 2002, 12, 29, &sundayTS );
   FD_SetDate( 2002, 12, 30, &mondayTS );
   FD_SetDate( 2002, 12, 31, &tuesdayTS );
   FD_SetDate( 2003,  1,  1, &wednesdayTS );
   FD_SetDate( 2003,  1,  2, &thursdayTS );
   FD_SetDate( 2003,  1,  3, &fridayTS );
   FD_SetDate( 2003,  1,  4, &saturdayTS );

   FD_SetDate( 2003,  1,  5, &sunday2TS );
   FD_SetDate( 2003,  1,  6, &monday2TS );
   FD_SetDate( 2003,  1,  7, &tuesday2TS );
   FD_SetDate( 2003,  1,  8, &wednesday2TS );
   FD_SetDate( 2003,  1,  9, &thursday2TS );
   FD_SetDate( 2003,  1, 10, &friday2TS );
   FD_SetDate( 2003,  1, 11, &saturday2TS );

   for( i=0; i < NB_WEEKDAY_CHECK_TO_DO; i++ )
   {
      retCode = FD_TimestampDeltaWeekday( toCheck[i].start,
                                          toCheck[i].end,                                          
                                          &delta );
      if( retCode != FD_SUCCESS )
      {
         printf( "Failed: Weekday delta test #%d\n", i );
         return FD_PERIOD_DELFD_WEEKDAY_FAILED;
      }

      if( delta != toCheck[i].expectedDelta )
      {
         printf( "Failed: Expected delta != delta (%d!=%d) for test #%d\n", toCheck[i].expectedDelta, delta, i );
         return FD_PERIOD_DELFD_WEEKDAY_FAILED_1;
      }
   }

   return FD_TEST_PASS; /* Success. */
}
