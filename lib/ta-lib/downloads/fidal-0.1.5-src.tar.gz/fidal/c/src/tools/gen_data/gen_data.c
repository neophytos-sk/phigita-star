/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fidal.h"

char buffer[1024];

int gen_ta_mrg_0( void );
int gen_ta_sim_ref_0( void );

static void FD_WriteRefCFile( FD_UDBase *unifiedDatabase,
                              const char *category,
                              const char *symbol,
                              void *opaqueData );

int main( int argc, char *argv[] )
{
   int retValue;

   (void)argv; /* Get rid of compiler warning. */

   if( argc > 1 )
   {
      printf( "\n" );
      printf( "gen_data V%s - Embbeded data generator\n", FD_GetVersionString() );
      printf( "\n" );
      printf( "Usage: gen_data\n" );
      printf( "\n" );
      printf( "  No parameter needed.\n" );
      printf( "\n" );      
      printf( "  This tool will takes some .CSV files and generate the\n" );
      printf( "  corresponding static data in 'C'. This tool is useful\n" );
      printf( "  only for developers modifying the FIDAL for generating\n" );
      printf( "  new data being used by the FD_SIMULATOR data source.\n" );
      printf( "\n" );
      printf( "  See fidal/c/src/tools/gen_data for the input/output files.\n" );
      printf( "\n" );
      printf( "  ** Must be directly run from the 'bin' directory.\n" );
      printf( "\n" );
      printf( "  On failure, the exit code is -1.\n" );
      printf( "  On success, the exit code is  0.\n" );
      exit(-1);
   }

   retValue = gen_ta_mrg_0();
   if( retValue != 0 )
      return retValue;

   printf( "\n" );
   printf( "Generating data for the FD_SIMULATOR data source\n" );
   printf( "Type gen_data -? for more info\n" );

   retValue = gen_ta_sim_ref_0();
   if( retValue != 0 )
      return retValue;

   printf( "\nDone\n" );
   return 0;
}

void myFatalHandler( void )
{
   printf( "\nFatal Error Handler Called\n " );
   FD_FatalReport( stdout );
}

int gen_ta_sim_ref_0( void )
{
   FD_UDBase *unifiedDatabase;
   FD_InitializeParam initializeParam;
   FD_AddDataSourceParam param;
   FD_RetCode retCode;

   /* Initialize the FIDAL. */
   memset( &initializeParam, 0, sizeof( FD_InitializeParam ) );
   initializeParam.logOutput = stdout;
   retCode = FD_Initialize( &initializeParam );
   if( retCode != FD_SUCCESS )
      return -10;

   /* Install the FD_Fatal handler, just for better debugging.  */
   retCode = FD_SetFatalErrorHandler( myFatalHandler );
   if( retCode != FD_SUCCESS )
      return retCode;
 
   /* Create the unified database. */
   retCode = FD_UDBaseAlloc( &unifiedDatabase );
   if( retCode == FD_SUCCESS )
   {
      /* Add the reference data in the unified database. */
      memset( &param, 0, sizeof( FD_AddDataSourceParam ) );
      param.id       = FD_ASCII_FILE;
      param.location = "..\\src\\tools\\gen_data\\daily_ref_0.csv";
      param.info     = "[M][D][YYYY][O][H][L][C][V]";
      param.category = "FD_SIM_REF";
      retCode = FD_AddDataSource( unifiedDatabase, &param );

      if( retCode != FD_SUCCESS )
         printf( "Cannot open daily_ref_0.csv %d\n", retCode );
      else
      {
         param.location = "..\\src\\tools\\gen_data\\intra_ref_0.csv";
         param.info     = "[M][D][YYYY][HH][MN=10][O][H][L][C]";
         param.category = "FD_SIM_REF";
         retCode = FD_AddDataSource( unifiedDatabase, &param );
         if( retCode != FD_SUCCESS )
            printf( "Cannot open intra_ref_0.csv %d\n", retCode );
         else
         {
            retCode = FD_Report( unifiedDatabase, stdout, 0xFF );
            if( retCode != FD_SUCCESS )
               printf( "FD_Report failed %d\n", retCode );
            else
            {
               /* Generate the 'c' files from all the symbols... */
               FD_ForEachSymbol( unifiedDatabase, FD_WriteRefCFile, NULL );
            }
         }
      }

      retCode = FD_UDBaseFree( unifiedDatabase );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   retCode = FD_Shutdown();
   if( retCode != FD_SUCCESS )
      return -20;

   return 0;
}

int gen_ta_mrg_0( void )
{
   FILE *in, *out;
   unsigned int i, j;
   unsigned char data_out;

   printf( "Generating fd_mrg_0.c\n");
   
   #if defined( WIN32 )
   in = fopen( "..\\src\\tools\\gen_data\\mrg.in", "r" );
   #else
   in = fopen( "../src/tools/gen_data/mrg.in", "r" );
   #endif

   if( !in )
   {
      printf( "Cannot open mrg.in\n" );
      return -1;
   }

   #if defined( WIN32 )
   out = fopen( "..\\src\\tools\\gen_data\\ta_mrg_0.c", "w" );
   #else
   out = fopen( "../src/tools/gen_data/ta_mrg_0.c", "w" );
   #endif

   if( !out )
   {
      printf( "Cannot open fd_mrg_0.c" );
      return -1;
   }

   fprintf( out, "/* This file is generated by gen_data. Do not modify. */\n\n" );

   fprintf( out, "\n\nconst char FD_MRG_0_DAFD_PRIV[1000] = {" );

   for( i=0; i < 1000; i++ )
   {
      fgets( buffer, 1024, in );
      /* printf( "%s", buffer ); */
      data_out = 0;
      for( j=0; j < 4; j++ )
      {
         switch( buffer[j] )
         {
         case '1':
            data_out |= 0x01;
            break;
         case '0':
            break;
         case 'X':
         case 'x':
            data_out |= 0x11;
            break;
         default:
            printf( "Invalid data at line %d\n", i );
            return -2;
         }
         data_out <<= 2;
      }
      fprintf( out, "%s0x%02X%s", 
               i%25 == 0?"\n":"", data_out,
               i != 999?",":"};" );
   }

   fprintf( out, "\n" );

   fclose( in );
   fclose( out );

   return 0;
}

static void FD_WriteRefCFile( FD_UDBase *unifiedDatabase,
                              const char *category,
                              const char *symbol,
                              void *opaqueData )
{
   FD_RetCode retCode;
   FD_Period period;
   FILE *out;
   FD_History *history;
   unsigned int i;
   const char *tmpStr;
   FD_HistoryAllocParam histParam;

   (void)opaqueData; /* Get ride of compiler warning. */

   /* Identify the period for this symbol. */
   if( strcmp( symbol, "intra_ref_0" ) == 0 )
      period = FD_1MIN * 10;
   else
      period = FD_DAILY;

   if( (strlen( symbol ) + 6) > 1024 )
   {
      printf( "Symbol name too large [%s]\n", symbol );
      return;
   }

   memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
   histParam.category = category;
   histParam.symbol = symbol;
   histParam.period = period;
   histParam.field = FD_FIELD_ALL;
   retCode = FD_HistoryAlloc( unifiedDatabase, &histParam, &history );

   if( retCode != FD_SUCCESS )
      printf( "Processing of %s failed (%d)\n", symbol, retCode );
   else
   {
      sprintf( buffer, "..\\src\\tools\\gen_data\\ta_%s.c", symbol );

      out = fopen( buffer, "w" );
      if( !out )
         printf( "Failed to open [%s]\n", buffer );
      else
      {
         fprintf( out, "/* This file is generated by gen_data.c. \n" );
         fprintf( out, " * DO NOT MODIFY THIS FILE DIRECTLY. \n" );
         fprintf( out, " */\n" );

         fprintf( out, "#include \"fidal.h\"\n\n" );
      
         if( history->timestamp )
         {
            fprintf( out, "FD_Timestamp FD_SREF_timestamp_%s_PRIV[%d] = {", symbol, history->nbBars );
            for( i=0; i < history->nbBars; i++ )
            {
               if( (i+1) == history->nbBars )
                  tmpStr = "};\n\n";
               else
                  tmpStr = ",";

               fprintf( out, "{0x%08X,", (unsigned int)history->timestamp[i].date );
               fprintf( out, "0x%08X}", (unsigned int)history->timestamp[i].time );
               fprintf( out, tmpStr );

               if( (i != 0) && (i%10 == 0) )
                  fprintf( out, "\n" );
            }
         }

         #define WRITE_REAL_DATA(varName) \
         if( history->varName ) \
         { \
            fprintf( out, "FD_Real FD_SREF_%s_%s_PRIV[%d] = {", #varName, symbol, history->nbBars ); \
            for( i=0; i < history->nbBars; i++ ) \
            { \
               fprintf( out, "%f%s", (float)history->varName[i],  \
                        i+1 == history->nbBars? "};\n\n":"," ); \
               if( (i != 0) && (i%10 == 0) ) \
                  fprintf( out, "\n" ); \
            } \
         }

         #define WRITE_INTEGER_DATA(varName) \
         if( history->varName ) \
         { \
            fprintf( out, "FD_Integer FD_SREF_%s_%s_PRIV[%d] = {", #varName, symbol, history->nbBars ); \
            for( i=0; i < history->nbBars; i++ ) \
            { \
               fprintf( out, "%d%s", history->varName[i],  \
                        i+1 == history->nbBars? "};\n\n":"," ); \
               if( (i != 0) && (i%10 == 0) ) \
                  fprintf( out, "\n" ); \
            } \
         }

         WRITE_REAL_DATA(open);
         WRITE_REAL_DATA(high);
         WRITE_REAL_DATA(low);
         WRITE_REAL_DATA(close);
         WRITE_INTEGER_DATA(volume);
         WRITE_INTEGER_DATA(openInterest);
         #undef WRITE_REAL_DATA
         #undef WRITE_INTEGER_DATA

         fclose( out );
      }

      retCode = FD_HistoryFree( history );
      if( retCode != FD_SUCCESS )
         printf( "Freeing %s history failed %d\n", symbol, retCode );
   }

}

