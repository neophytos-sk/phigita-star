/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070401 MF   First version.
 *
 */

/* Description:
 *         Regression testing of the functionality provided
 *         by the ASCII data source.
 *
 *         Indirectly, this will exercise the FD_FileIndex and
 *         FD_ReadOp objects.
 *
 * This test assume that the software is running from
 * the directory fidal/c/bin.
 *
 * This test assume that the following directory structure
 * exist in src/tools/fd_regtest/tstdir:
 *
 *  a\x.txt
 *  B\XYZ.TXT
 *  AA\X1.TXT
 *  AB\X2.TXT
 *  AAC\ASD.TX0
 *  AAC\ASD.TX
 *  AAC\ASD.TX1
 *  AAC\ASDF.TX1
 *  L1\L2\z1.DAT
 *  L1\L2\L3\z2.DAT
 *  L1\L22\L31\z3.DAT
 *  L1\L22\L32\z4.DAT
 *  L1\L22\L32\Z4\z5.DAT
 *
 * The content of the file is irrelevant.
 */

/**** Headers ****/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "fd_test_priv.h"
#include "sfl.h"
#include "fd_trace.h"


/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   const char *category;
   const char *symbol;
} FD_CatSym;

typedef struct
{
   unsigned int testId;
   unsigned int linkToNext; /* Boolean */
   const char *theLocationString;
   FD_CatSym  **theListOfExpectedCatSym; /* All expected category/symbol. */
   FD_RetCode expectedRetCode;           /* Some are expected to fail. */
} FD_FileGlobingTest;

typedef struct
{
   FD_CatSym **theListOfExpectedCatSym;
   unsigned int nbSymbolNotFound;
   unsigned int nbSymbolFound;
} FD_ForEachCatSymData;


static void FD_VerifyEachSymbolInCatSymTable( FD_UDBase *unifiedDatabase,
                                              const char *category,
                                              const char *symbol,
                                              void *opaqueData );

typedef struct
{
   FD_CatSym symbolToFind;
   unsigned int found; /* boolean */
} FD_IndexSearchData;

static void FD_SearchInIndexForCatSym( FD_UDBase *unifiedDatabase,
                                       const char *category,
                                       const char *symbol,
                                       void *opaqueData );

/**** Local functions declarations.    ****/
static int test_file_globing( FD_UDBase *uDBase, const FD_FileGlobingTest *tstData );
static int test_parsing_equivalence( void );

/**** Local variables definitions.     ****/

/* List of possible Category/Symbol combination */
FD_CatSym ZZdotOTHERdotOTHERcommaX    = {"ZZ.OTHER.OTHER","X"};
FD_CatSym ZZdotOTHERdotOTHERcommaXYZ  = {"ZZ.OTHER.OTHER","XYZ"};
FD_CatSym ZZdotOTHERdotOTHERcommaX1   = {"ZZ.OTHER.OTHER","X1"};
FD_CatSym ZZdotOTHERdotOTHERcommaX2   = {"ZZ.OTHER.OTHER","X2"};

FD_CatSym ZZdotOTHERdotOTHERcommaASDdotTX0  = {"ZZ.OTHER.OTHER","ASD.TX0"};
FD_CatSym ZZdotOTHERdotOTHERcommaASDdotTX   = {"ZZ.OTHER.OTHER","ASD.TX" };
FD_CatSym ZZdotOTHERdotOTHERcommaASDdotTX1  = {"ZZ.OTHER.OTHER","ASD.TX1" };
FD_CatSym ZZdotOTHERdotOTHERcommaASDFdotTX1 = {"ZZ.OTHER.OTHER","ASDF.TX1"};

FD_CatSym AcommaX   = {"A","X"};
FD_CatSym BcommaXYZ = {"B","XYZ"};
FD_CatSym AAcommaX1 = {"AA","X1"};
FD_CatSym ABcommaX2 = {"AB","X2"};

FD_CatSym AdotOTHERdotOTHERcommaXdotTXT   = {"A.OTHER.OTHER","X.TXT"};
FD_CatSym BdotOTHERdotOTHERcommaXYZdotTXT = {"B.OTHER.OTHER","XYZ.TXT"};
FD_CatSym AAdotOTHERdotOTHERcommaX1dotTXT = {"AA.OTHER.OTHER","X1.TXT"};
FD_CatSym ABdotOTHERdotOTHERcommaX2dotTXT = {"AB.OTHER.OTHER","X2.TXT"};

FD_CatSym ZZdotAdotOTHERcommaX1 = {"ZZ.A.OTHER","X1"};
FD_CatSym ZZdotBdotOTHERcommaX2 = {"ZZ.B.OTHER","X2"};

FD_CatSym TDIdotAdotOTHERcommaX   = {"TDI.A.OTHER","X"};
FD_CatSym TDIdotBdotOTHERcommaXYZ = {"TDI.B.OTHER","XYZ"};
FD_CatSym TDIdotAAdotOTHERcommaX1 = {"TDI.AA.OTHER","X1"};
FD_CatSym TDIdotABdotOTHERcommaX2 = {"TDI.AB.OTHER","X2"};

FD_CatSym AACdotOTHERdotOTHERcommaASDdotTX   = { "AAC.OTHER.OTHER", "ASD.TX"};
FD_CatSym AACdotOTHERdotOTHERcommaASDdotTX0  = { "AAC.OTHER.OTHER", "ASD.TX0"};
FD_CatSym AACdotOTHERdotOTHERcommaASDdotTX1  = { "AAC.OTHER.OTHER", "ASD.TX1"};
FD_CatSym AACdotOTHERdotOTHERcommaASDFdotTX1 = { "AAC.OTHER.OTHER", "ASDF.TX1"};

FD_CatSym ZZdotAdotOTHERcommaX   = {"ZZ.A.OTHER", "X" };
FD_CatSym AdotOTHERdotOTHERcommaX = {"A.OTHER.OTHER", "X" };
FD_CatSym ZZdotOTHERdotAcommaX   = {"ZZ.OTHER.A", "X" };

FD_CatSym DIRdotAdotACcommaDdotTX0 = {"DIR.A.AC","D.TX0"};
FD_CatSym DIRdotAdotACcommaDdotTX  = {"DIR.A.AC","D.TX"};
FD_CatSym DIRdotAdotACcommaDdotTX1 = {"DIR.A.AC","D.TX1"};
FD_CatSym DIRdotAdotACcommaDFdotTX1= {"DIR.A.AC","DF.TX1"};

/* The expected result of each of the file globing test. */
FD_CatSym *test1Result[] = 
{
   &ZZdotOTHERdotOTHERcommaX,
   &ZZdotOTHERdotOTHERcommaXYZ,
   &ZZdotOTHERdotOTHERcommaX1,
   &ZZdotOTHERdotOTHERcommaX2,
   NULL
};

FD_CatSym *test2Result[] = 
{
   &AcommaX,
   &BcommaXYZ,
   &AAcommaX1,
   &ABcommaX2,
   NULL
};

FD_CatSym *test3Result[] = 
{
   &AdotOTHERdotOTHERcommaXdotTXT,
   &BdotOTHERdotOTHERcommaXYZdotTXT,
   &AAdotOTHERdotOTHERcommaX1dotTXT,
   &ABdotOTHERdotOTHERcommaX2dotTXT,
   &AACdotOTHERdotOTHERcommaASDdotTX, 
   &AACdotOTHERdotOTHERcommaASDdotTX0,
   &AACdotOTHERdotOTHERcommaASDdotTX1, 
   &AACdotOTHERdotOTHERcommaASDFdotTX1,
   NULL
};

FD_CatSym *test4Result[] = 
{
   &ZZdotAdotOTHERcommaX1,
   &ZZdotBdotOTHERcommaX2,
   NULL
};

FD_CatSym *test5Result[] = 
{
   &TDIdotAdotOTHERcommaX,
   &TDIdotBdotOTHERcommaXYZ,
   &TDIdotAAdotOTHERcommaX1,
   &TDIdotABdotOTHERcommaX2,
   NULL
};

FD_CatSym *test6Result[] ={ &ZZdotAdotOTHERcommaX,NULL };
FD_CatSym *test7Result[] ={ &ZZdotOTHERdotAcommaX,NULL };
FD_CatSym *test8Result[] ={ &AdotOTHERdotOTHERcommaX,NULL };

FD_CatSym *test9Result[] =
{
   &DIRdotAdotACcommaDdotTX0,
   &DIRdotAdotACcommaDdotTX,
   &DIRdotAdotACcommaDdotTX1,
   &DIRdotAdotACcommaDFdotTX1,
   NULL
};

static FD_FileGlobingTest fileGlobingTestTable[] =
{
   /* Side Note: FIDAL will adapt on Windows/Unix for using
    *            the correct directory seperator. So there
    *            is no problem to mix these here.
    */

   /*** Result 1 ***/

   /* Add the file individually. */
   {100, 1, "..\\src\\tools\\fd_regtest\\TSTDIR\\A\\X.TXT",          NULL, FD_SUCCESS},
   {100, 1, "..\\src\\tools\\fd_regtest\\TSTDIR\\B\\XYZ.TXT",        NULL, FD_SUCCESS},
   {100, 1, "..\\src\\tools\\fd_regtest\\TSTDIR\\AA\\X1.TXT",        NULL, FD_SUCCESS},
   {100, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\AB\\X2.TXT", test1Result, FD_SUCCESS},

   /* Add the file individually + use some wildcard directory. */
   {101, 1, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\X.TXT",          NULL, FD_SUCCESS},
   {101, 1, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\XYZ.TXT",        NULL, FD_SUCCESS},
   {101, 1, "..\\?rc\\tools\\fd_regtest\\TSTDIR\\*\\X1.TXT",         NULL, FD_SUCCESS},
   {101, 0, "..\\sr?\\tools\\fd_regtest\\TSTDIR\\*\\X2.TXT",  test1Result, FD_SUCCESS},

   /* Add the file individually + use some wildcard directory + some empty source. */
   {102, 1, "..\\src\\DO_NOT_EXIST\\XYZ.TXT",                        NULL, FD_NO_DATA_SOURCE },
   {102, 1, "..\\src\\tools\\fd_regtest\\??????\\*\\X.TXT",          NULL, FD_SUCCESS},
   {102, 1, "..\\src/DO_NOT_EXIST\\XYZ.TXT",                         NULL, FD_NO_DATA_SOURCE },
   {102, 1, "..\\src\\tools\\fd_regtest\\*\\*\\XYZ.TXT",             NULL, FD_SUCCESS},
   {102, 1, "..\\src/DO_NOT_EXIST/XYZ.TXT",                          NULL, FD_NO_DATA_SOURCE },
   {102, 1, "..\\src\\tools\\fd_regtest\\TSTDI?\\*\\X1.TXT",         NULL, FD_SUCCESS},
   {102, 1, "..\\src\\tools\\fd_regtest\\?STDIR\\*\\XBAD.TXT",       NULL, FD_NO_DATA_SOURCE },
   {102, 0, "..\\src\\tools\\fd_regtest\\?STDIR\\*\\X2.TXT",  test1Result, FD_SUCCESS},

   /* Test some simple directory/symbol '*' wildcard. */
   {110, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\*.TXT",    test1Result, FD_SUCCESS },
   {111, 0, "../src/tools/fd_regtest/TSTDIR/*/*.TXT",          test1Result, FD_SUCCESS },
   {112, 0, "../src\\tools/fd_regtest\\TSTDIR/*\\*.TXT",       test1Result, FD_SUCCESS },
   {113, 0, "..\\src/tools\\fd_regtest/TSTDIR\\*/*.TXT",       test1Result, FD_SUCCESS },

   /* These '?' should fail since there is no symbol field. */
   {130, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\????.TXT",     NULL, FD_INVALID_PATH },
   {131, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//???.TXT",      NULL, FD_INVALID_PATH },
   {132, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.TXT",        NULL, FD_INVALID_PATH },
   {133, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.?XT",        NULL, FD_INVALID_PATH },
   {134, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.?XT",        NULL, FD_INVALID_PATH },
   {135, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.T?T",        NULL, FD_INVALID_PATH },
   {136, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.TX?",        NULL, FD_INVALID_PATH },
   {137, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.?",          NULL, FD_INVALID_PATH },
   {138, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?",            NULL, FD_INVALID_PATH },
   {139, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//??",           NULL, FD_INVALID_PATH },
   {140, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*//?.???",        NULL, FD_INVALID_PATH },
   {141, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\?.???",        NULL, FD_INVALID_PATH },
   {142, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*\\????????.???", NULL, FD_INVALID_PATH },
   {143, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\*/????????.???",  NULL, FD_INVALID_PATH },

   /* Make sure that the '.' is well supported. */
   {150, 0, ".\\..\\src\\tools\\fd_regtest\\TSTDIR\\*\\*.TXT",  test1Result, FD_SUCCESS },
   {151, 0, "./..\\src\\tools\\fd_regtest\\TSTDIR\\*\\*.TXT",  test1Result, FD_SUCCESS },
   {152, 0, ".\\..\\.\\src\\tools\\fd_regtest\\TSTDIR\\*\\*.TXT",  test1Result, FD_SUCCESS },
   {153, 0, "./.././src\\tools\\fd_regtest\\TSTDIR\\*\\*.TXT",  test1Result, FD_SUCCESS },
   {154, 0, "./.././src\\tools\\fd_regtest\\TSTDIR\\*\\.\\*.TXT",  test1Result, FD_SUCCESS },
   {155, 0, "./.././src\\tools\\fd_regtest\\TSTDIR\\*/./*.TXT",  test1Result, FD_SUCCESS },
   /*** Result 2 ***/
   /* Check that CAT field is working. */
   {200, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\[CAT]\\[SYM].TXT", test2Result, FD_SUCCESS},

   /*** Result 3 ***/
   /* Check that CATC field is working. */
   {300, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\[CATC]\\[SYM]", test3Result, FD_SUCCESS},

   /*** Result 4 ***/
   /* Check that CATX field is working. */
   {400, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\A[CATX]\\[SYM].TXT", test4Result, FD_SUCCESS},

   /*** Result 5 ***/
   /* Check that CATX+CATC field combination are working. */
   {500, 0, "..\\src\\tools\\fd_regtest\\TS[CATC]R\\[CATX]\\[SYM].TXT", test5Result, FD_SUCCESS},

   /*** Result 6 ***/
   /* Test one character CATX. */
   {600, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\[CATX]\\X.TXT", test6Result, FD_SUCCESS},

   /*** Result 7 ***/
   /* Test one character CATT. */
   {700, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\[CATT]\\X.TXT", test7Result, FD_SUCCESS},

   /*** Result 8 ***/
   /* Test one character CATC. */
   {800, 0, "..\\src\\tools\\fd_regtest\\TSTDIR\\[CATC]\\X.TXT", test8Result, FD_SUCCESS},

   /*** Result 9 ***/
   /* Test the combination of all category component. */
   {900, 0, "..\\src\\tools\\fd_regtest\\TST[CATC]\\A[CATT]\\[CATX].TXT", NULL, FD_INVALID_PATH},
   {901, 0, "..\\src\\tools\\fd_regtest\\TST[CATC]\\A[CATT]\\[CATX]S[SYM]", test9Result, FD_SUCCESS}

   /* As bug are found or time is available, a lot more 
    * of systematic regression tests needs to be added.
    */
};

#define nbFileGlobingTest (sizeof(fileGlobingTestTable)/sizeof(FD_FileGlobingTest))

typedef struct
{
   const char *fileInfo;
} FieldDef;

FieldDef fieldTable[] =
{
   {"[-H][M][D][Y][O][H][L][C][V]"},   
   {"[M][D][Y][HOUR][MIN][L][O][C][H][V]"},
};

#define FD_NB_FIELD_DEF (sizeof(fieldTable)/sizeof(FieldDef))

/**** Global functions definitions.   ****/
ErrorNumber test_ascii( void )
{
   unsigned int again, i, startupDatasource;
   ErrorNumber retValue;
   int testRetValue;
   FD_UDBase *udb;

   printf( "Testing ASCII data source\n" );

   /* A "dummy" test just to verify that these two
    * utility function do not cause memory leak.
    */
   retValue = allocLib( &udb );
   if( retValue != FD_TEST_PASS )
      return retValue;    
   retValue = freeLib( udb );
   if( retValue != FD_TEST_PASS )
      return retValue;

   /* Test directory/category/file globing. */
   for( i=0; i < nbFileGlobingTest; i++ )
   {
      retValue = allocLib( &udb );
      if( retValue != FD_TEST_PASS )
         return retValue;

      startupDatasource = i;
      do
      {
         again = 0;
         testRetValue = test_file_globing( udb, &fileGlobingTestTable[i] );

         if( testRetValue == -1 )
         {
            i++;
            again = 1;
         }
      } while( again && i < nbFileGlobingTest );

      if( i == nbFileGlobingTest )
      {
         printf( "fd_regtest reference data %d is invalid.\n", startupDatasource );
         return FD_INTERNAL_ERROR(128);
      }

      if( testRetValue != FD_TEST_PASS )
      {
         printf( "File globing test #%d failed with value %d.\n",
                 fileGlobingTestTable[i].testId, testRetValue );
         freeLib( udb );
         return testRetValue;
      }

      retValue = freeLib( udb );
      if( retValue != FD_TEST_PASS )
         return retValue;
   }

   /* Verify reading of ASCII data. */

   /* Test equivalence file. All files in the
    * fidal/src/tools/fd_regtest/sampling have
    * a specific name format TST[X]\Z[S].TXT
    * 
    * [X]   represent a group of file that have ALL the same data
    *       (but the content could be presentend differently).
    *
    * [S]   is a unique id. It is further decompose in two
    *       fields 'xxx_yyy'
    *
    * 'xxx' is a unique number to make the filename unique.
    *
    * 'yyy' represent the order of the fields.
    *
    * Examples:
    *      TST001\Z001_001.TXT
    *      TST001\Z001_002.TXT
    *      TST003\Z001_002.TXT
    *
    * The idea is to test ALL file having the same [X] for
    * being equivalent with FD_HistoryAlloc.
    */
   retValue = test_parsing_equivalence();
   if( retValue != FD_SUCCESS )
   {
      printf( "ASCII Test equivalence failed test with value %d.\n",
              retValue );
      return retValue;
   }

   return FD_TEST_PASS; /* Succcess. */
}

/**** Local functions definitions.     ****/
static int test_file_globing( FD_UDBase *uDBase, const FD_FileGlobingTest *tstData )
{  
   FD_RetCode retCode;
   FD_AddDataSourceParam param;
   FD_ForEachCatSymData  catSymData;
   FD_IndexSearchData    indexSearchData;
   unsigned int i;
   FD_CatSym **catSymTablePtr;

   /* Add all datasource having the same testId.  */
   memset( &param, 0, sizeof( FD_AddDataSourceParam ) );
   param.id = FD_ASCII_FILE;
   param.location = tstData->theLocationString;
   param.info     = "[Y][O]"; /* Mandatory, but not important for the test. */

   retCode = FD_AddDataSource( uDBase, &param );
   if( retCode != tstData->expectedRetCode )
   {
      printf( "FD_AddDataSource did not behave as expected.\n" );
      printf( "Expected value: %d, returned value: %d\n",
              tstData->expectedRetCode, retCode );

      return FD_TESTASCII_UNEXPECTED_RETCODE;
   }

   /* Return to the caller for adding another data source. */
   if( tstData->linkToNext )
      return -1;

   /* FD_Report( uDBase, stdout, NULL ); */

   if( retCode == FD_SUCCESS )
   {
       /* On FD_SUCCESS, 2 verifications are done:
        * 
        * (1) Verify that all symbols in the unified database
        *     are in the list of expected symbol.
        *
        * (2) Verify that all symbols in the expected list
        *     are in the unified database.
        */
    
       /*** (1) ***/
       catSymData.nbSymbolFound    = 0;
       catSymData.nbSymbolNotFound = 0;
       catSymData.theListOfExpectedCatSym = tstData->theListOfExpectedCatSym;
       
       retCode = FD_ForEachSymbol( uDBase, FD_VerifyEachSymbolInCatSymTable, &catSymData );
       if( retCode != FD_SUCCESS )
       {
          printf( "FD_ForEachSymbol failed [%d]\n", retCode );
          return FD_TESTASCII_FOREACHSYMBOL_FAILED;
       }

       if( catSymData.nbSymbolNotFound != 0 )
          return FD_TESTASCII_CATSYM_NOT_FOUND;
       
       /*** (2) ***/
       i = 0;
       catSymTablePtr = tstData->theListOfExpectedCatSym;
       while( catSymTablePtr[i] != NULL)
       {
          indexSearchData.found = 0;
          indexSearchData.symbolToFind.category = catSymTablePtr[i]->category;
          indexSearchData.symbolToFind.symbol   = catSymTablePtr[i]->symbol;
          retCode = FD_ForEachSymbol( uDBase, FD_SearchInIndexForCatSym, &indexSearchData );
          if( retCode != FD_SUCCESS )
          {
             printf( "FD_ForEachSymbol failed [%d]\n", retCode );
             return FD_TESTASCII_SEARCHININDEX_FAILED;
          }
    
          if( !indexSearchData.found )
          {
             printf( "Can't find %s.%s in the FIDAL index.\n", 
                     indexSearchData.symbolToFind.category,
                     indexSearchData.symbolToFind.symbol );
             return FD_TESTASCII_CANTFIND_CATSYM_IN_INDEX;
          }
    
          i++;
       }
   }   

   return FD_TEST_PASS; /* Success. */
}

static void FD_VerifyEachSymbolInCatSymTable( FD_UDBase *unifiedDatabase,
                                              const char *category,
                                              const char *symbol,
                                              void *opaqueData )
{
   FD_ForEachCatSymData *catSymData;
   FD_CatSym **catSymTablePtr;
   unsigned int i;

   (void) unifiedDatabase;

   /* Ignore CVS related directories */
   if( (lexcmp( symbol, "Entries" ) == 0) ||
       (lexcmp( symbol, "Repository" ) == 0) ||
       (lexcmp( symbol, "Root" ) == 0) ||
       (lexcmp( category, "CVS.OTHER.OTHER") == 0))
      return;

   catSymData = (FD_ForEachCatSymData *)opaqueData;
   catSymTablePtr = catSymData->theListOfExpectedCatSym;

   i = 0;
   while( catSymTablePtr[i] != NULL)
   {
      if( (lexcmp( catSymTablePtr[i]->category, category) == 0) &&
          (lexcmp( catSymTablePtr[i]->symbol, symbol ) == 0))
      {
         catSymData->nbSymbolFound++;
         return;
      }

      i++;
   }

   printf( "CatSym not found for %s,%s\n", category, symbol );
   catSymData->nbSymbolNotFound++;
}

static void FD_SearchInIndexForCatSym( FD_UDBase *unifiedDatabase,
                                       const char *category,
                                       const char *symbol,
                                       void *opaqueData )
{
   FD_IndexSearchData *searchData;

   (void) unifiedDatabase;

   searchData = (FD_IndexSearchData *)opaqueData;

   if( (lexcmp( searchData->symbolToFind.category, category ) == 0) &&
       (lexcmp( searchData->symbolToFind.symbol, symbol) == 0) )
      searchData->found = 1;
}

static int test_parsing_equivalence( void )
{
   int retValue, fieldNb;
   FD_AddDataSourceParam param;
   FD_UDBase *udb, *udbEqv;
   FD_RetCode retCode;
   FD_StringTable *catTable, *symTable;
   unsigned int i,j;
   FD_History *history;
   FD_History *refHistory;
   char buffer1024[1024];
   char buffer200[200];
   FD_Timestamp ts1, ts2;
   int period;
   FD_HistoryAllocParam histParam;

   retValue = allocLib( &udb );
   if( retValue != FD_TEST_PASS )
      return retValue;    

   /* Get the complete list of files to process. */
   memset( &param, 0, sizeof( FD_AddDataSourceParam ) );  
   param.id = FD_ASCII_FILE;
   param.location = "..\\src\\tools\\fd_regtest\\sampling\\TST[CAT]\\Z[SYM].TXT";
   param.info = "[Y]"; /* Mandatory, but not used. */
   retCode = FD_AddDataSource( udb, &param );
   if( retCode != FD_SUCCESS )
   {
      printf( "Cannot access ASCII sampling directory\n" );
      reportError( "FD_AddDataSource", retCode );
      return FD_TESTASCII_SAMPLING_FILE_NOT_FOUND;
   }

   /* FD_Report( udb, stdout, NULL ); */

   retCode = FD_CategoryTableAlloc( udb, &catTable );
   if( retCode != FD_SUCCESS )
   {      
      freeLib( udb );
      return FD_TESTASCII_CATTABLE_ALLOC_ERROR;
   }
   else
   {
      for( i=0; i < catTable->size; i++ )
      {
         retCode = FD_SymbolTableAlloc( udb, catTable->string[i], &symTable );
         if( retCode != FD_SUCCESS )
         {
            FD_CategoryTableFree( catTable );
            freeLib( udb );
            return FD_TESTASCII_SYMTABLE_ALLOC_ERROR;
         }

         refHistory = NULL;
         udbEqv = NULL;

         for( j=0; j < symTable->size; j++ )
         {
            retCode = FD_UDBaseAlloc( &udbEqv );
         
            sprintf( buffer1024, 
                     "..\\src\\tools\\fd_regtest\\sampling\\TST%s\\Z%s.TXT",
                     catTable->string[i],
                     symTable->string[j] );

            strcpy( buffer200, "Z" );
            strcat( buffer200, symTable->string[j] );

            /* Validate the very specific file name nomenclature. */
            if( !isdigit( buffer200[1] ) ||
                !isdigit( buffer200[2] ) ||
                !isdigit( buffer200[3] ) ||
                !isdigit( buffer200[5] ) ||
                !isdigit( buffer200[6] ) ||
                !isdigit( buffer200[7] ) ||
                buffer200[4] != '_'      ||
                buffer200[8] != '\0' )
            {
               printf( "Invalid file name %s\n", buffer200 );
               if( refHistory )
                  FD_HistoryFree( refHistory );
               FD_SymbolTableFree( symTable );
               FD_CategoryTableFree( catTable );
               if( udbEqv )
                  FD_UDBaseFree( udbEqv );
               freeLib( udb );
               return FD_TESTASCII_EQV_BAD_FILENAME;
            }

            /* Identify the field who is going to be used for FD_AddDataSourfce. */
            fieldNb = atoi(&buffer200[5]);
            if( (fieldNb <= 0) || (fieldNb > (int)FD_NB_FIELD_DEF) )
            {
               printf( "Invalid file name %s\n", buffer200 );
               if( refHistory )
                  FD_HistoryFree( refHistory );
               FD_SymbolTableFree( symTable );
               FD_CategoryTableFree( catTable );
               if( udbEqv )
                  FD_UDBaseFree( udbEqv );
               freeLib( udb );
               return FD_TESTASCII_EQV_BAD_FIELD_ID;
            }

            memset( &param, 0, sizeof( FD_AddDataSourceParam ) );  
            param.id = FD_ASCII_FILE;
            param.location = &buffer1024[0];
            param.info = fieldTable[fieldNb-1].fileInfo;
            param.category = catTable->string[i];
            
            /* Test #2 is specifically to test the FD_REPLACE_ZERO_PRICE_BAR flag */
            if( strcmp( catTable->string[i], "002" ) == 0 )
               param.flags = FD_REPLACE_ZERO_PRICE_BAR;

            retCode = FD_AddDataSource( udbEqv, &param );
            if( retCode != FD_SUCCESS )
            {
               printf( "FD_AddDataSource failed with %d (%s)\n", retCode, &buffer200[0] );
               if( refHistory )
                  FD_HistoryFree( refHistory );
               FD_SymbolTableFree( symTable );
               FD_CategoryTableFree( catTable );
               if( udbEqv )
                  FD_UDBaseFree( udbEqv );
               freeLib( udb );
               return FD_TESTASCII_EQV_ADDDATASOURCE;
            }

            /* Test #2 use minutes data */
            if( strcmp( catTable->string[i], "002" ) == 0 )
               period = FD_1MIN;
            else
               period = FD_DAILY;

            memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
            histParam.category = catTable->string[i];
            histParam.symbol   = &buffer200[0];
            histParam.period   = period;
            histParam.field    = FD_FIELD_ALL;
            histParam.flags    = FD_DISABLE_PRICE_VALIDATION; /* This flag should not make a difference. */
            retCode = FD_HistoryAlloc( udbEqv, &histParam, &history );

            if( retCode != FD_SUCCESS )
            {
               printf( "FD_HistoryAlloc failed with %d (%s)\n", retCode, symTable->string[j] );
               if( refHistory )
                  FD_HistoryFree( refHistory );
               FD_SymbolTableFree( symTable );
               FD_CategoryTableFree( catTable );
               if( udbEqv )
                  FD_UDBaseFree( udbEqv );
               freeLib( udb );
               return FD_TESTASCII_EQV_HISTORYALLOC;
            }

            if( refHistory == NULL )
               refHistory = history;
            else
            {
               retValue = FD_TEST_PASS; /* Will change if something goes wrong */

               if( refHistory->nbBars != history->nbBars )
               {
                  printf( "Nb bar different with TST%s,Z%s (ref:%d,tst:%d)\n",
                          catTable->string[i],symTable->string[j],
                          refHistory->nbBars,
                          history->nbBars);
                  retValue = FD_TESTASCII_EQV_DIFF_NBBARS;
               }
               else if( refHistory->period != history->period )
               {
                  printf( "Period different with TST%s,%s (ref:%d,tst:%d)\n",
                          catTable->string[i],symTable->string[j],
                          refHistory->period,
                          history->period);
                  retValue = FD_TESTASCII_EQV_DIFF_PERIOD;
               }
               #define CHECK_MEMBER(param) \
               else if( (refHistory->param && !history->param) || \
                        (!refHistory->param && history->param) ) \
               { \
                  printf( "Interpretation error with TST%s,Z%s,%s (ref:%d,tst:%d)\n", \
                          catTable->string[i],symTable->string[j], \
                          #param, \
                          refHistory->param?1:0, \
                          history->param?1:0); \
                  retValue = FD_TESTASCII_EQV_DIFF_HISTORY_PTR; \
               }

               CHECK_MEMBER( open )
               CHECK_MEMBER( high )
               CHECK_MEMBER( low )
               CHECK_MEMBER( close )
               CHECK_MEMBER( volume )
               CHECK_MEMBER( openInterest )
               CHECK_MEMBER( timestamp )
               #undef CHECK_MEMBER
               else if( !FD_HistoryEqual( refHistory, history ) )
               {
                  printf( "FD_HistoryEqual sees difference with TST%s,Z%s\n",
                          catTable->string[i],symTable->string[j] );
                  retValue = FD_TESTASCII_EQV_DIFF_DATA;
               }

               if( retValue != FD_TEST_PASS )
               {
                  FD_HistoryFree( history );
                  if( refHistory )
                     FD_HistoryFree( refHistory );
                  FD_SymbolTableFree( symTable );
                  FD_CategoryTableFree( catTable );
                  if( udbEqv )
                     FD_UDBaseFree( udbEqv );
                  freeLib( udb );
                  return retValue;                  
               }

               retCode = FD_HistoryFree( history );
               if( retCode != FD_SUCCESS )
               {
                  if( refHistory )
                     FD_HistoryFree( refHistory );
                  FD_SymbolTableFree( symTable );
                  FD_CategoryTableFree( catTable );
                  if( udbEqv )
                     FD_UDBaseFree( udbEqv );
                  freeLib( udb );
                  return FD_TESTASCII_HISTORYFREE_FAILED;
               }

               /* Test #1 check ranging with start and end parameter. */
               if( strcmp( catTable->string[i], "001" ) == 0 )
               {
                  /* Test start-end */
                  FD_SetDefault(&ts1);
                  FD_SetDefault(&ts2);
                  FD_SetDate( 4567,1,23,&ts1);
                  FD_SetDate( 4568,12,31,&ts2);
                  FD_SetTime( 0, 0, 0, &ts2 );

                  memset( &histParam, 0, sizeof( FD_HistoryAllocParam ) );
                  histParam.category = catTable->string[i];
                  histParam.symbol   = &buffer200[0];
                  histParam.period   = FD_DAILY;
                  histParam.field    = FD_FIELD_ALL;
                  FD_TimestampCopy( &histParam.start, &ts1 );
                  FD_TimestampCopy( &histParam.end, &ts2 );
                  retCode = FD_HistoryAlloc( udbEqv, &histParam, &history );
   
                  if( retCode != FD_SUCCESS )
                  {
                     printf( "FD_HistoryAlloc failed with %d (%s)\n", retCode, symTable->string[j] );
                     if( refHistory )
                        FD_HistoryFree( refHistory );
                     FD_SymbolTableFree( symTable );
                     FD_CategoryTableFree( catTable );
                     if( udbEqv )
                        FD_UDBaseFree( udbEqv );
                     freeLib( udb );
                     return FD_TESTASCII_EQV_HISTORYALLOC;
                  }

                  if( history->nbBars != 3 )
                  {
                     printf( "Less than 3 price bar read (%d)\n", history->nbBars );
                     FD_HistoryFree( history );
                     if( refHistory )
                        FD_HistoryFree( refHistory );
                     FD_SymbolTableFree( symTable );
                     FD_CategoryTableFree( catTable );
                     if( udbEqv )
                        FD_UDBaseFree( udbEqv );
                     freeLib( udb );
                     return FD_TESTASCII_EQV_HISTORYALLOC;
                  }

                  retCode = FD_HistoryFree( history );
                  if( retCode != FD_SUCCESS )
                  {
                     if( refHistory )
                        FD_HistoryFree( refHistory );
                     FD_SymbolTableFree( symTable );
                     FD_CategoryTableFree( catTable );
                     if( udbEqv )
                        FD_UDBaseFree( udbEqv );
                     freeLib( udb );
                     return FD_TESTASCII_HISTORYFREE_FAILED;
                  }
               }
            }
         }

         if( refHistory )
         {
            retCode = FD_HistoryFree( refHistory );
            if( retCode != FD_SUCCESS )
            {
               FD_SymbolTableFree( symTable );
               FD_CategoryTableFree( catTable );
               if( udbEqv )
                  FD_UDBaseFree( udbEqv );
               freeLib( udb );
               return FD_TESTASCII_REFHISTORYFREE_FAILED;
            }
         }

         retCode = FD_SymbolTableFree( symTable );
         if( retCode != FD_SUCCESS )
         {
            FD_CategoryTableFree( catTable );
            if( udbEqv )
               FD_UDBaseFree( udbEqv );
            freeLib( udb );
            return FD_TESTASCII_SYMTABLE_FREE_ERROR;
         }

         if( udbEqv )
         {
            retCode = FD_UDBaseFree( udbEqv );
            if( retCode != FD_SUCCESS )
            {
               printf( "FD_UDBaseFree failed with %d\n", retCode );
               FD_CategoryTableFree( catTable );
               freeLib( udb );
               return FD_TESTASCII_UDBASEFREE_FAILED;
            }
         }
      }

      retCode = FD_CategoryTableFree( catTable );
      if( retCode != FD_SUCCESS )
      {
         printf( "FD_CategoryTableFree failed with %d\n", retCode );
         freeLib( udb );
         return FD_TESTASCII_CATTABLE_FREE_ERROR;         
      }
   }

   retValue = freeLib( udb );
   if( retValue != FD_TEST_PASS )
      return retValue;

   return FD_TEST_PASS;
}
