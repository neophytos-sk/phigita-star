#ifndef FD_PARALLEL_H
#define FD_PARALLEL_H

#ifndef FD_SYSTEM_H
   #include "fd_system.h"
#endif

#ifndef FD_GLOBAL_H
   #include "fd_global.h"
#endif

/*************************************************************************
 * NOTE: DO NOT USE THAT FUNCTIONALITY YET. IT IS UNDER DEVELOPMENT.
 *       IT WILL NOT WORK UNTIL SOME GLUE CODE ARE ADDED.
 *************************************************************************
 *************************************************************************
 *************************************************************************
 *************************************************************************
 */

/* Very basic parallel support.
 *
 * This interface is not intended to be a "full blown" parallel/multithread
 * support. It is specifically kept simple for internal use in the FIDAL.
 *
 * The functions/macro defined here can be used even on uni-processor system.
 * The library will attempt to run things in parallel only if FD_PARALLEL
 * is defined and only when it makes sense.
 *
 * When FD_PARALLEL is NOT defined, the functions/macros are non-obstrusive
 * and the processing is done sequentially.
 *
 * There is two kind of support. One for General purpose usage and the other
 * specifically for the TA-FUNC functions. These functions are not I/O bound so
 * they required a slightly different treatment.
 *
 * Interface for general purpose (I/O Bound processing thread usually):
 *   An unlimited number of thread can be spawn with FD_PAR_EXEC.
 *
 *   Example:
 *   This example starts two threads. At the FD_PAR_JOIN point, execution of the
 *   mainThread is block until all thread returned.
 *
 *      void threadedFunction( void *args )
 *      {
 *         puts( (char *)args );
 *      }
 *
 *      void mainThread( void )
 *      {
 *         FD_PAR_VARS;
 *
 *         FD_PAR_INIT;
 *
 *         FD_PAR_EXEC( threadedFunction, "Hello"  );
 *         FD_PAR_EXEC( threadedFunction, "world!" );
 *
 *         ... some processing can be added here too...
 *
 *         FD_PAR_JOIN;
 *
 *         FD_PAR_END;
 *      }
 *
 * Interface specifically for function from the TA-FUNC library:
 *    All technical analysis functions in the TA-FUNC library can be called
 *    for parallel processing. There is no guarantee that the processing
 *    will be done in parallel. This is due to the fact that these technical
 *    analysis function are CPU bound and generally never I/O bound. Consequently
 *    there is generally no advantage to run more thread than there is procesors
 *    reachable for parallel processing.
 *    This interface provides simple and automatic protection against CPU
 *    trashing because of "over-threading".
 *
 *    Example:
 *      void FD_NewIndicator( ... )
 *      {
 *         FD_PAR_VARS;
 *
 *         FD_PAR_INIT();
 *
 *         FD_PAR_FUNC( FD_MA( ... ) );
 *         FD_PAR_FUNC( FD_EMA( ... ) );
 *         FD_PAR_JOIN;
 *
 *         FD_PAR_FUNC( FD_RSI( ... ) );
 *         ... some processing can be added here too...
 *         FD_PAR_JOIN;
 *
 *         FD_PAR_END;
 *      }
 *
 *    Note 1: ONLY technical analysis functions that has a prototype in the
 *            "fd_func.h" can be called with FD_PAR_FUNC( ). A link error will
 *            occured if an unsupported function is called.
 *
 *    Note 2: Parallel processing shall be done only on DISTINCTIVE input and
 *            output, else you kill the performance (because of possible memory
 *            cache trashing).
 */

#if defined(FD_PARALLEL) && !defined( FD_SINGLE_THREAD )
   #define FD_PAR_VARS    FD_BarrierSync FD_PAR_BS
   #define FD_PAR_INIT()  {FD_BarrierSyncInit(&FD_PAR_BS);}
   #define FD_PAR_JOIN    {FD_BarrierSyncWaitAllDone(&FD_PAR_BS);}
   #define FD_PAR_END     {FD_BarrierSyncDestroy(&FD_PAR_BS);}

   /* FD_PAR_FUNC is exclusively for function found in "ta_func.h" */
   #define FD_PAR_FUNC(rc,x) {FD_BarrierSyncThreadAdd(&FD_PAR_BS); rc = MAC_PAR_##x;}

   /* FD_PAR_EXEC is for general purpose parallelism. */
   #define FD_PAR_EXEC(x,w) FD_PAR_EXEC_F( &FD_PAR_BS, x, w )

   /* The FD_BarrierSync is a support tool for the above macro.
    * Should never be called directly.
    */
   typedef struct
   {
      FD_Sema mutexSema; /* Mutex for this structure. */
      volatile unsigned int nbThread; /* Nb thread left to be done. */
      FD_Sema barrierSema;   /* Stay block until all thread are done. */
   } FD_BarrierSync;

   FD_RetCode FD_BarrierSyncInit       ( FD_BarrierSync *bs );
   FD_RetCode FD_BarrierSyncDestroy    ( FD_BarrierSync *bs );
   FD_RetCode FD_BarrierSyncThreadAdd  ( FD_BarrierSync *bs );
   FD_RetCode FD_BarrierSyncThreadDone ( FD_BarrierSync *bs );
   FD_RetCode FD_BarrierSyncWaitAllDone( FD_BarrierSync *bs );

   /* FD_PAR_EXEC_F is a support function for the above macros.
    * Should never be called directly.
    */
   void FD_PAR_EXEC_F( FD_BarrierSync *bs, FD_ThreadFunction newThread, void *args );
#else
   #define FD_PAR_VARS
   #define FD_PAR_INIT()
   #define FD_PAR_FUNC(rc,x) rc=x
   #define FD_PAR_JOIN
   #define FD_PAR_END
   #define FD_PAR_EXEC(x,w) {x(w);}
#endif


#if 0
The following code works! TRICK TO REMEMBER!!!

void PAR_call( int i, const char *str )
{
   printf( "You made it %d [%s]!", i, str );
}

/* The following macro will be generated by gen_code */
#define D_call(param) PAR_call( z, param )
#define PAR(func) D_##func

/* Call example: */
int main(int argc, char* argv[])
{
int z;

z = 12;

PAR( call( "Bouh!" ) );
getchar();
        return 0;
}

#endif

#endif
