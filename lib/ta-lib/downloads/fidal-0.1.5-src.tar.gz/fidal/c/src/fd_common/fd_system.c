/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  032704 MF   Add FD_AdjustPath
 *  122904 MF   Fix#1023151 for memory leak cause by open_dir/close_dir
 */

/* Description:
 *    Make abstraction of the operating system. These functions are not
 *    meant to be general purpose. They are written for being used in
 *    the context of the FIDAL. So let's try to keep it simple.
 *
 *    Note: Because semaphores are used very EARLY in the initialization
 *          of the library, these FD_SemaXXXX function shall not call any
 *          other FIDAL function to avoid dependency. Keep these simple.
 */

/**** Headers ****/

/* First, define which of the following is desired:
 *
 *   USE_WIN32_API - Optimized by using Win32 API calls.
 *
 *   USE_OSLAYER   - Use a portable operating system abstraction layer.
 *                   Use Posix for thread/semaphore, use ANSI C for file
 *                   access.
 *
 * Notice that in this file, the USE_WIN32_API is preferred to the
 * usual WIN32, the reason being that we wish sometimes to compile
 * with USE_OSLAYER even on a WIN32 platform (for test purpose).
 */
#if !defined( USE_OSLAYER ) && !defined( USE_WIN32_API )
   #if defined( WIN32 )
      #define USE_WIN32_API
   #else
      #define USE_OSLAYER
   #endif
#endif

#if defined( USE_WIN32_API )
   #include <windows.h>
   #include <process.h>
   #include <io.h>
#endif

#include <limits.h>
#include "fd_trace.h"
#include "fd_system.h"
#include "fd_memory.h"
#include "fd_global.h"
#include "fd_string.h"
#include "fd_stream.h"

#if defined( USE_OSLAYER )
   /* iMatix SFL Library is used for providing
    * some portability.
    */
   #include <stdio.h>
   #include "sfl.h"
   #if !defined( WIN32 )
   #include <pthread.h>
   #include <semaphore.h>
   #endif
#endif

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   #if defined( USE_WIN32_API )
   HANDLE        handle;
   LPVOID        allocBuffer;
   DWORD         allocBufferSize;
   #else
   FILE         *handle;
   void         *allocBuffer;
   unsigned int  allocBufferSize;
   #endif

   /* Set only when the data is from 
    * a stream instead of a file.
    */
   FD_StreamAccess *streamAccess;
   FD_Stream *stream;

   /* Keep a copy of the path/filename. */
   const char *path;
} FD_FileHandlePriv;

#define FILE_HANDLE

typedef struct
{
   #if defined( USE_WIN32_API )
   unsigned int sysInfoInitialized;
   SYSTEM_INFO sysInfo;
   #endif

   FD_StringCache *dirnameCache;
   FD_StringCache *filenameCache;
   unsigned int    lastError;
} FD_SystemGlobal;

#if !defined( USE_WIN32_API )
   /* All non-win32 API use a fix buffer size for I/O.
    * Can be fine tune here for your platform.
    */
   #define FILE_BUFFER_SIZE 2048
#endif

#ifndef MAX_PATH
   #define MAX_PATH 1024
#endif

/**** Local functions declarations.    ****/
static void stringListFree( FD_StringCache *stringCache, FD_List *list );

static FD_RetCode FD_SystemGlobalInit    ( void **globalToAlloc );
static FD_RetCode FD_SystemGlobalShutdown( void *globalAllocated );

#if defined( USE_WIN32_API )
static LPVOID allocDiskBuffer( const char *path, DWORD *nbByteAlloc );
static FD_RetCode freeDiskBuffer( LPVOID buffer, DWORD nbByteAlloc );
static void initSysInfo( FD_SystemGlobal *global );
#endif

/**** Local variables definitions.     ****/
FD_FILE_INFO;

const FD_GlobalControl FD_SystemGlobalControl =
{
   FD_SYSTEM_GLOBAL_ID,
   FD_SystemGlobalInit,
   FD_SystemGlobalShutdown
};

/**** Global functions definitions.   ****/
int FD_GetLastError( void )
{
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return 0;

   return global->lastError;
}

int FD_IsSeparatorChar( int c )
{
   if( (c == '\\') || (c == '/') )
      return 1;

   return 0;
}

int FD_SeparatorASCII( void )
{
#if defined( WIN32 )
   return '\\';
#else
   return '/';
#endif
}

int FD_WildCharASCII( void )
{
   return '?';
}

int FD_WildASCII( void )
{
   return '*';
}

void FD_AdjustPath( char *path )
{
   /* This function might change the 'path' string.
    * It will not modify the size of the string, only
    * the content.
    */
   char car;
   char sep;

   /* Replace the separator character in path. */
   sep = FD_SeparatorASCII();
   car = *path;
   while( car != '\0' )
   {
      if( FD_IsSeparatorChar( car ) )
          *path = sep;
      path++;
      car = *path;
   }
}

FD_RetCode FD_DirectoryAlloc( const char *path,
                              FD_Directory **directory )
{
   #if defined( USE_WIN32_API )
   HANDLE handle;
   WIN32_FIND_DATA data;
   DWORD win32Error;
   #endif

   #if defined( USE_OSLAYER )
   DIRST dirHandle;
   const char *filePattern;
   char *basePath;
   #endif

   unsigned pathLength;

   int findNextRetCode;

   FD_Directory *dir;
   FD_String *string;
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   const char   *entryName;
   unsigned int  entryIsDirectory;

   *directory = NULL;

   if( (path == NULL) || (directory == NULL) )
      return FD_BAD_PARAM;

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return retCode;

   dir = (FD_Directory *)FD_Malloc( sizeof( FD_Directory ) );

   if( dir == NULL )
      return FD_ALLOC_ERR;

   dir->nbFile = 0;
   dir->nbDirectory = 0;

   dir->listOfFile = FD_ListAlloc();
   dir->listOfDirectory = FD_ListAlloc();

   if( (dir->listOfFile == NULL) || (dir->listOfDirectory == NULL) )
   {
      FD_DirectoryFree( dir );
      return FD_ALLOC_ERR;
   }

   /* Verify that the path is valid. */
   pathLength = strlen( path );

   if( (pathLength == 0) || (pathLength >= MAX_PATH) )
   {
      FD_DirectoryFree( dir );
      return FD_BAD_PARAM;
   }

   /* Now get the directory from the operating system. */
   #if defined( USE_WIN32_API )

   handle = FindFirstFile( path, &data );
   if( handle == INVALID_HANDLE_VALUE )
   {
      win32Error = GetLastError();
      global->lastError = win32Error;

      if( (win32Error != ERROR_FILE_NOT_FOUND) &&
          (win32Error != ERROR_PATH_NOT_FOUND) )
      {
         FD_DirectoryFree( dir );
         return FD_ACCESS_FAILED;
      }

      /* No files or directory... but still have to pass the result
       * to the caller.
       */
      *directory = dir;

      return FD_SUCCESS;
   }

   entryName = data.cFileName;
   entryIsDirectory = data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY;
   #endif

   #if defined( USE_OSLAYER )
   /* Split the path into the basePath and the filePattern. */
   basePath = FD_Malloc( pathLength+1 ); 
   memcpy( basePath, path, pathLength+1 );
   filePattern = split_path_and_file( basePath );

   if( !filePattern )
   {
      /* With no filePattern, no file can be found...
       * so return an empty directory to the caller.
       */
      *directory = dir;
      FD_Free( basePath );
      return FD_SUCCESS;
   }

   /* Look for last separetor. */
   if( !open_dir(&dirHandle, basePath ) )
   {
      /* Errors, or no files or no directory... but
       * still have to pass the result to the caller.
       */      
      close_dir(&dirHandle);
      FD_Free( basePath );
      *directory = dir;
      return FD_SUCCESS;
   }

   entryName = dirHandle.file_name;
   entryIsDirectory = dirHandle.file_attrs & ATTR_SUBDIR;
   #endif

   do
   {
      #if defined( USE_OSLAYER )
      if( file_matches( entryName, filePattern ) )
      {
      #endif
         if( entryIsDirectory )
         {
            if( entryName[0] != '.' )
            {
               string = FD_StringAlloc( global->dirnameCache, entryName );

               if( string == NULL )
               {
                  #if defined( USE_OSLAYER )
                     close_dir(&dirHandle);
                     FD_Free( basePath );
                  #endif
                  FD_DirectoryFree( dir );
                  return FD_ALLOC_ERR;
               }

               retCode = FD_ListAddTail( dir->listOfDirectory, (void *)string );

               if( retCode != FD_SUCCESS )
               {
                  #if defined( USE_OSLAYER )
                     close_dir(&dirHandle);
                     FD_Free( basePath );
                  #endif
                  FD_DirectoryFree( dir );
                  return retCode;
               }
               dir->nbDirectory++;
            }
         }
         else
         {
            string = FD_StringAlloc( global->filenameCache, entryName );

            if( string == NULL )
            {
               #if defined( USE_OSLAYER )
                  close_dir(&dirHandle);
                  FD_Free( basePath );
               #endif
               FD_DirectoryFree( dir );
               return FD_ALLOC_ERR;
            }

            retCode = FD_ListAddTail( dir->listOfFile, (void *)string );

            if( retCode != FD_SUCCESS )
            {
               #if defined( USE_OSLAYER )
                  close_dir(&dirHandle);
                  FD_Free( basePath );
               #endif
               FD_DirectoryFree( dir );
               return retCode;
            }
            dir->nbFile++;
         }
      #if defined( USE_OSLAYER )
      }
      #endif
      
      #if defined( USE_WIN32_API )
      findNextRetCode = FindNextFile( handle, &data );
      entryName = data.cFileName;
      entryIsDirectory = data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY;
      #endif

      #if defined( USE_OSLAYER )
      findNextRetCode = read_dir( &dirHandle );
      entryName = dirHandle.file_name;
      entryIsDirectory = dirHandle.file_attrs & ATTR_SUBDIR;
      #endif
   }
   while( findNextRetCode == TRUE );


   #if defined( USE_OSLAYER )
   FD_Free( basePath );
   if( !close_dir(&dirHandle) )
   {
      FD_DirectoryFree( dir );
      return FD_INTERNAL_ERROR(11);
   }
   #endif

   #if defined( USE_WIN32_API )   
   if( FindClose( handle ) != TRUE )
   {
      global->lastError = GetLastError();
      FD_DirectoryFree( dir );
      return FD_INTERNAL_ERROR(12);
   }
   #endif

   /* Pass the result to the caller. */
   *directory = dir;

   return FD_SUCCESS;
}

FD_RetCode FD_DirectoryFree( FD_Directory *directory )
{
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return retCode;

   if( directory )
   {
      stringListFree( global->filenameCache, directory->listOfFile );
      stringListFree( global->dirnameCache, directory->listOfDirectory );
      FD_Free( directory );
   }

   return FD_SUCCESS;
}

int FD_IsFileSystemCaseSensitive( void )
{
   #if defined(__WIN32__) || defined(__MSDOS__) || defined(WIN32)
      /* MS-DOS/Windows is not case sensitive. */
      return 0;
   #else
      /* For the time being, assume yes for all
       * other platform.
       */
      return 1;
   #endif
}

int FD_NbProcessor( void )
{
#if defined( USE_WIN32_API )
   FD_RetCode retCode;

   FD_SystemGlobal *global;
   
   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return 1;

   /* Run time function checking the number of processor on that system.
    * Will eventually allows to make better decision for parallelism.
    */
   initSysInfo(global);
   return global->sysInfo.dwNumberOfProcessors;
#else   
   /* For the time being... do not assume more than one
    * processor on other platform.    
    */
   return 1;
#endif

}

/* Simplified thread functionality.
 *   A thread is created/started by calling FD_ThreadExec.
 */
#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_ThreadExec( FD_ThreadFunction newThreadEntryPoint, void *args )
{

    #if defined(WIN32)
    unsigned long thread_id;
    thread_id = _beginthread(newThreadEntryPoint,8192*4,(void *)args);
    if( thread_id == (unsigned long)-1 )
       return FD_INTERNAL_ERROR(13);
    #else    
    pthread_t thread_id;

    if( pthread_create(&thread_id, NULL,newThreadEntryPoint, args) != 0 )
       return FD_INTERNAL_ERROR(14);
    #endif

    return FD_SUCCESS;
}
#endif

void FD_Sleep( unsigned int seconds )
{
   #if defined( USE_WIN32_API )
      Sleep( seconds * 1000 );
   #endif

   #if defined( USE_OSLAYER )
      sleep( seconds );
   #endif
}

/* Implementation of counting semaphores. */
#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaInc( FD_Sema *sema, unsigned int *prevCount )
{
   #if defined( USE_WIN32_API )
   BOOL retValue;
   #endif

   if( sema == NULL )
      return FD_BAD_PARAM;

   /* Fail if not initialized. */
   if( !(sema->flags & FD_SEMA_INITIALIZED) )
      return FD_INTERNAL_ERROR(15);

   #if defined( USE_WIN32_API )
   retValue = ReleaseSemaphore( sema->theSema, 1, (LPLONG)prevCount );
   if( retValue != 0 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(16);
   #endif

   #if defined( USE_OSLAYER )  
   #if defined( USE_NAMED_SEMAPHORES )
   (void)prevCount;
   if( sem_post( sema->theSema ) != -1 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(17);
   #else
   (void)prevCount;
   if( sem_post( &sema->theSema ) != -1 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(17);
   #endif
   #endif
}
#endif

#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaDec( FD_Sema *sema )
{
   #if defined( USE_WIN32_API ) 
   DWORD retValue;
   #endif

   if( sema == NULL )
      return FD_BAD_PARAM;

   /* Fail if not initialized. */
   if( !(sema->flags & FD_SEMA_INITIALIZED) )
      return FD_INTERNAL_ERROR(18);

   #if defined( USE_WIN32_API ) 
   retValue = WaitForSingleObject( sema->theSema, INFINITE );

   if( retValue == WAIT_OBJECT_0 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(19);
   #endif

   #if defined( USE_OSLAYER )
   #if defined( USE_NAMED_SEMAPHORES )
   if( sem_wait( sema->theSema ) != -1 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(20);
   #else
   if( sem_wait( &sema->theSema ) != -1 )
      return FD_SUCCESS;
   else
      return FD_INTERNAL_ERROR(20);
   #endif
   #endif
}
#endif

#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaWait( FD_Sema *sema )
{
   return FD_SemaDec( sema );
}
#endif

#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaPost( FD_Sema *sema )
{
   return FD_SemaInc( sema, NULL );
}
#endif

#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaInit( FD_Sema *sema, unsigned int initialValue )
{
   if( sema == NULL )
      return FD_BAD_PARAM;

   #if defined( USE_WIN32_API )
   sema->theSema = CreateSemaphore( (LPSECURITY_ATTRIBUTES)NULL, (LONG)initialValue, (LONG)LONG_MAX, (LPCTSTR)NULL );
   
   if( sema->theSema )
   {
      sema->flags = FD_SEMA_INITIALIZED;
      return FD_SUCCESS;
   }
   else
   {
      sema->flags = 0;
      return FD_INTERNAL_ERROR(21);
   }
   #endif
   
   #if defined( USE_OSLAYER )
   #if defined( USE_NAMED_SEMAPHORES )
   sprintf(sema->name, "fidal_sema_%i_%p", getpid(), sema);
   sema->theSema = sem_open( sema->name, O_CREAT | O_EXCL, 0644, initialValue );
   if ( sema->theSema != (void *)-1 )
   {
      sema->flags = FD_SEMA_INITIALIZED;
      return FD_SUCCESS;
   }
   else
   {
      sema->flags = 0;
      return FD_INTERNAL_ERROR(22);
   }  
   #else
   if ( sem_init( &sema->theSema, 0, initialValue ) != -1 )
   {
      sema->flags = FD_SEMA_INITIALIZED;
      return FD_SUCCESS;
   }
   else
   {
      sema->flags = 0;
      return FD_INTERNAL_ERROR(22);
   }  
   #endif
   #endif
}
#endif

#if !defined( FD_SINGLE_THREAD )
FD_RetCode FD_SemaDestroy( FD_Sema *sema )
{
   #if defined( USE_WIN32_API )
   BOOL retValue;
   #endif

   if( sema == NULL )
      return FD_BAD_PARAM;

   if( !(sema->flags & FD_SEMA_INITIALIZED) )
      return FD_SUCCESS; /* Do nothing if not initialized. */

   #if defined( USE_WIN32_API )
   retValue = CloseHandle( sema->theSema );

   if( !retValue )
      return FD_INTERNAL_ERROR(23);
   else
      return FD_SUCCESS;
   #endif
   
   #if defined( USE_OSLAYER )
   #if defined( USE_NAMED_SEMAPHORES )
   sem_close( sema->theSema );
   sem_unlink( sema->name );
   return FD_SUCCESS;
   #else
   sem_destroy( &sema->theSema );
   return FD_SUCCESS;
   #endif
   #endif
}
#endif

/* Like FD_FileSeqOpen, but work with a stream instead. */
FD_RetCode FD_FileSeqOpenFromStream( FD_Stream *stream,
                                     FD_FileHandle **handle )
{
   FD_PROLOG
   FD_FileHandlePriv *fileHandlePriv;

   FD_TRACE_BEGIN(  FD_FileSeqOpen );

   FD_ASSERT( stream != NULL );
   FD_ASSERT( handle != NULL );

   /* Allocate the private file handle. */
   fileHandlePriv = (FD_FileHandlePriv *)FD_Malloc( sizeof( FD_FileHandlePriv ) );
   if( !fileHandlePriv )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( fileHandlePriv, 0, sizeof( FD_FileHandlePriv ) );

   /* There is NO file... */
   #if defined( USE_WIN32_API )
   fileHandlePriv->handle = INVALID_HANDLE_VALUE; 
   #endif

   #if defined( USE_OSLAYER )
   fileHandlePriv->handle = (FILE *)NULL;
   #endif

   /* ... use a stream instead. */
   fileHandlePriv->stream = stream;
   fileHandlePriv->streamAccess = FD_StreamAccessAlloc( stream );
   if( !fileHandlePriv->streamAccess )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Success! Return the info to the caller. */
   *handle = (FD_FileHandle *)fileHandlePriv;
   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_FileSeqOpen( const char *path, FD_FileHandle **handle )
{
   FD_PROLOG
   FD_FileHandlePriv *fileHandlePriv;

   FD_TRACE_BEGIN(  FD_FileSeqOpen );

   FD_ASSERT( path != NULL );
   FD_ASSERT( handle != NULL );

   fileHandlePriv = (FD_FileHandlePriv *)FD_Malloc( sizeof( FD_FileHandlePriv ) );
   if( !fileHandlePriv )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( fileHandlePriv, 0, sizeof( FD_FileHandlePriv ) );

   #if defined( USE_WIN32_API )
   fileHandlePriv->handle = CreateFile( path, GENERIC_READ, FILE_SHARE_READ,
                                        NULL, OPEN_EXISTING,
                                        FILE_FLAG_NO_BUFFERING|FILE_FLAG_SEQUENTIAL_SCAN,
                                        NULL );

   if( fileHandlePriv->handle == INVALID_HANDLE_VALUE )
   {
      FD_FileSeqClose( (FD_FileHandle *)fileHandlePriv );
      FD_TRACE_RETURN( FD_ACCESS_FAILED );
   }
   #else
   /* For all non-win32 platform, use standard ANSI C I/O */
   fileHandlePriv->handle = fopen( path, "rb" );

   if( fileHandlePriv->handle == 0 )
   {
      FD_FileSeqClose( (FD_FileHandle *)fileHandlePriv );
      FD_TRACE_RETURN( FD_ACCESS_FAILED );
   }
   #endif

   /* Allocate buffer memory. */
   #if defined( USE_WIN32_API )
      fileHandlePriv->allocBuffer = allocDiskBuffer( path, &fileHandlePriv->allocBufferSize );
      if( !fileHandlePriv->allocBuffer || (fileHandlePriv->allocBufferSize == 0) )
      {
         FD_FileSeqClose( (FD_FileHandle *)fileHandlePriv );
         FD_TRACE_RETURN( FD_ACCESS_FAILED );
      }
   #else
      fileHandlePriv->allocBuffer = FD_Malloc( FILE_BUFFER_SIZE );
      fileHandlePriv->allocBufferSize = FILE_BUFFER_SIZE;
      if( !fileHandlePriv->allocBuffer )
      {
         FD_FileSeqClose( (FD_FileHandle *)fileHandlePriv );
         FD_TRACE_RETURN( FD_ACCESS_FAILED );
      }
   #endif

   /* Keep a ptr on the path. */
   fileHandlePriv->path = path;

   /* Success! Return the info to the caller. */
   *handle = (FD_FileHandle *)fileHandlePriv;
   FD_TRACE_RETURN( FD_SUCCESS );
}

unsigned int FD_FileSize( FD_FileHandle *handle )
{
   #if defined( USE_WIN32_API )
   BY_HANDLE_FILE_INFORMATION bhfi;
   #endif

   FD_FileHandlePriv *fileHandlePriv;
   unsigned int fileSize;

   FD_ASSERT_RET( handle != NULL, 0 );

   fileHandlePriv = (FD_FileHandlePriv *)handle;

   if( fileHandlePriv->streamAccess )
   {
      /* Use the stream instead of the file. */
      fileSize = FD_StreamSizeInByte( fileHandlePriv->stream );
   }
   else
   {
      #if defined( USE_WIN32_API )
         FD_ASSERT_RET( fileHandlePriv->handle != INVALID_HANDLE_VALUE, 0 );
         GetFileInformationByHandle( fileHandlePriv->handle, &bhfi );
         fileSize = bhfi.nFileSizeLow;
      #endif

      #if defined( USE_OSLAYER )
         FD_ASSERT_RET( fileHandlePriv->handle != NULL, 0 );
         fileSize = get_file_size( fileHandlePriv->path );
      #endif
   }

   return fileSize;
}

const char *FD_FileSeqRead( FD_FileHandle *handle, unsigned int *nbByteRead )
{
   #if defined( USE_WIN32_API )
   BOOL retValue;
   DWORD nbByteReadLocal;
   #else
   size_t nbByteReadLocal;
   #endif

   FD_FileHandlePriv *fileHandlePriv;
   const char *returnValue;
   FD_RetCode retCode;

   FD_ASSERT_RET( handle != NULL, (char *)NULL );
   FD_ASSERT_RET( nbByteRead != NULL, (char *)NULL );

   fileHandlePriv = (FD_FileHandlePriv *)handle;

   if( fileHandlePriv->streamAccess )
   {
      /* Use the stream instead of the file. 
       * Get the data chunk by chunk.
       */
      retCode = FD_StreamAccessGetBuffer( fileHandlePriv->streamAccess,
                                          &returnValue,
                                          nbByteRead );
      if( retCode != FD_SUCCESS )
         return 0;
   }  
   else
   { 
	   
      FD_ASSERT_RET( fileHandlePriv->allocBuffer != NULL, (char *)NULL );
      FD_ASSERT_RET( fileHandlePriv->allocBufferSize >= 128, (char *)NULL );

      *nbByteRead = 0;

      #if defined( USE_WIN32_API )
         FD_ASSERT_RET( fileHandlePriv->handle != INVALID_HANDLE_VALUE, (char *)NULL );
         retValue = ReadFile( fileHandlePriv->handle,
                              fileHandlePriv->allocBuffer,
                              fileHandlePriv->allocBufferSize,
                              &nbByteReadLocal,
                              NULL );

         if( retValue == 0 )
            return NULL;
      #else
         FD_ASSERT_RET( fileHandlePriv->handle != NULL, (char *)NULL );
         if( feof(fileHandlePriv->handle) || ferror(fileHandlePriv->handle) )
            return NULL;

         nbByteReadLocal = fread( fileHandlePriv->allocBuffer, 1, 
                                  fileHandlePriv->allocBufferSize,
                                  fileHandlePriv->handle );
      #endif

      *nbByteRead = nbByteReadLocal;

      if( *nbByteRead == 0 )
         return NULL;

      returnValue = fileHandlePriv->allocBuffer;
   }

   return returnValue;
}

FD_RetCode FD_FileSeqClose( FD_FileHandle *handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileHandlePriv *fileHandlePriv;
   FD_SystemGlobal *global;
   #if defined( USE_WIN32_API )
   DWORD win32Error;
   BOOL retValue;
   #endif

   FD_TRACE_BEGIN(  FD_FileSeqClose );

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( handle != NULL );

   fileHandlePriv = (FD_FileHandlePriv *)handle;

   if( fileHandlePriv )
   {
      #if defined( USE_WIN32_API )
         if( fileHandlePriv->handle != INVALID_HANDLE_VALUE )
         {
            retValue = CloseHandle( fileHandlePriv->handle );
            if( retValue == 0 )
            {
               win32Error = GetLastError();
               global->lastError = win32Error;
               FD_FATAL(  NULL, 0, win32Error );
            }
         }
         if( fileHandlePriv->allocBuffer )
         {
            freeDiskBuffer( fileHandlePriv->allocBuffer,
                            fileHandlePriv->allocBufferSize );
         }
      #endif

      #if defined( USE_OSLAYER )
         if( fileHandlePriv->handle != NULL )
            fclose( fileHandlePriv->handle );
         if( fileHandlePriv->allocBuffer )
            FD_Free( fileHandlePriv->allocBuffer );
      #endif

      if( fileHandlePriv->streamAccess )
      {
         FD_StreamAccessFree( fileHandlePriv->streamAccess );
      }

      FD_Free( fileHandlePriv );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}
/**** Local functions definitions.     ****/
static void stringListFree( FD_StringCache *stringCache, FD_List *list )
{
   FD_String *node;

   if( list == NULL )
      return;

   while( (node = (FD_String *)FD_ListRemoveHead( list )) != NULL )
   {
      FD_StringFree( stringCache, node );
   }

   FD_ListFree( list );
}

#if defined( USE_WIN32_API )
static LPVOID allocDiskBuffer( const char *path, DWORD *nbByteAlloc )
{
   BOOL retValue;
   LPCTSTR lpRootPathName; /* address of root path */
   DWORD lpSectorsPerCluster; /* address of sectors per cluster */
   DWORD lpBytesPerSector; /* address of bytes per sector */
   DWORD lpNumberOfFreeClusters; /* address of number of free clusters */
   DWORD lpTotalNumberOfClusters; /* address of total number of clusters */
   LPVOID allocatedMem;
   DWORD win32Error;
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return (LPVOID)NULL;

   lpRootPathName = path;

   *nbByteAlloc = 0;


   retValue = GetDiskFreeSpace( NULL/*lpRootPathName*/,
                                &lpSectorsPerCluster,
                                &lpBytesPerSector,
                                &lpNumberOfFreeClusters,
                                &lpTotalNumberOfClusters );

   if( retValue == 0 )
   {
      win32Error = GetLastError();
      global->lastError = win32Error;
      return (LPVOID)NULL;
   }

   allocatedMem = VirtualAlloc( NULL, /* No specific address needed. */
                                lpBytesPerSector, /* size of region */
                                MEM_COMMIT|MEM_RESERVE, /* type of allocation */
                                PAGE_READWRITE/* type of access protection */ );

   if( !allocatedMem )
   {
      win32Error = GetLastError();
      global->lastError = win32Error;
      return (LPVOID)NULL;
   }

   /* Success... return information to caller. */
   *nbByteAlloc = lpBytesPerSector;
   return allocatedMem;
}
#endif

#if defined( USE_WIN32_API )
static FD_RetCode freeDiskBuffer( LPVOID buffer, DWORD nbByteAlloc )
{
   FD_PROLOG
   BOOL retValue;
   DWORD win32Error;
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   FD_TRACE_BEGIN(  freeDiskBuffer );

   retCode = FD_GetGlobal(  &FD_SystemGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Uncommit all pages. */
   retValue = VirtualFree( buffer, nbByteAlloc, MEM_DECOMMIT );
   if( retValue == 0 )
   {
      win32Error = GetLastError();
      global->lastError = win32Error;
      FD_FATAL(  "Win32 Cannot free paged mem", nbByteAlloc, win32Error );
   }

   /* Unreserve all pages. */
   retValue = VirtualFree( buffer, 0, MEM_RELEASE );
   if( retValue == 0 )
   {
      win32Error = GetLastError();
      global->lastError = win32Error;
      FD_FATAL(  "Win32 Cannot free paged mem", 0, win32Error );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}
#endif

#if defined( USE_WIN32_API )
static void initSysInfo( FD_SystemGlobal *global )
{
   if( global->sysInfoInitialized == 0 )
   {
      GetSystemInfo( &global->sysInfo );
      global->sysInfoInitialized = 1;
   }
}
#endif

static FD_RetCode FD_SystemGlobalInit( void **globalToAlloc )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_SystemGlobal *global;

   FD_TRACE_BEGIN( FD_SystemGlobalInit );

   FD_ASSERT( globalToAlloc != NULL );

   *globalToAlloc = NULL;

   global = (FD_SystemGlobal *)FD_Malloc( sizeof( FD_SystemGlobal ) );
   if( !global )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   memset( global, 0, sizeof( FD_SystemGlobal ) );

   retCode = FD_StringCacheAlloc( &global->dirnameCache );
   if( retCode != FD_SUCCESS )
   {
      FD_Free( global );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   retCode = FD_StringCacheAlloc( &global->filenameCache );
   if( retCode != FD_SUCCESS )
   {
      FD_StringCacheFree( global->dirnameCache );
      FD_Free( global );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Success! Return the global to the caller. */
   *globalToAlloc = global;
   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode FD_SystemGlobalShutdown( void *globalAllocated )
{
   FD_PROLOG
   FD_RetCode retCode, finalRetCode;
   FD_SystemGlobal *global;

   FD_TRACE_BEGIN( FD_SystemGlobalShutdown );

   /* No need to shutdown if the initialization failed. */
   if( globalAllocated == NULL )
   {
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   finalRetCode = FD_SUCCESS;

   global = (FD_SystemGlobal *)globalAllocated;

   if( global->dirnameCache )
   {
      retCode = FD_StringCacheFree( global->dirnameCache );
      FD_ASSERT( retCode == FD_SUCCESS );
      if( retCode != FD_SUCCESS )
         finalRetCode = retCode;
   }

   if( global->filenameCache )
   {
      retCode = FD_StringCacheFree( global->filenameCache );
      FD_ASSERT( retCode == FD_SUCCESS );
      if( retCode != FD_SUCCESS )
         finalRetCode = retCode;
   }

   FD_Free( global );

   FD_TRACE_RETURN( finalRetCode );
}

void FD_Printf( FD_PrintfVar *outp, char *format, ... )
{
  int retValue;
  va_list args;

  va_start(args,format);
  
  if( outp )
  {
     if( outp->file )
        vfprintf( outp->file, format, args );
  
     if( outp->buffer && (outp->size > 1) )
     {
        #if defined( WIN32 )
           retValue = _vsnprintf( outp->buffer, outp->size-1, format, args );
        #else
           retValue = vsnprintf( outp->buffer, outp->size-1, format, args );
        #endif
        if( retValue >= 0 )
        {
           outp->buffer += retValue;
           outp->size   -= retValue;
        }
        else
        {
           outp->buffer = NULL;
           outp->size = 0;
        }
     }
  }
}
