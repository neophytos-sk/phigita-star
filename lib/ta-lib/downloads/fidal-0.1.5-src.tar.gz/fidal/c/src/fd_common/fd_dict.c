/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  031900 MF   First version.
 *
 */

/* Implementation Description:
 *        This module is simply encapsulating the Kazlib library
 *        who is providing the whole dictionary functionality.
 *        This dictionary is attempting to simplify the allocation
 *        and de-allocation of the object belonging to the
 *        dictionary.
 */

/**** Headers ****/
#include <string.h>
#include "fd_common.h"
#include "fd_dict.h"
#include "fd_memory.h"
#include "kazlib/dict.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   dict_t d;
   void (*freeValueFunc)(void *);
   dnode_t *accessNode;
   unsigned int flags;
} FD_PrivDictInfo;

/**** Local functions declarations.    ****/
static int compareFunction_S ( const void *key1, const void *key2);
static int compareFunction_I ( const void *key1, const void *key2);

/*static const char *stringDuplicate( const char *string );*/

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/
FD_Dict *FD_DictAlloc( unsigned int flags, void (*freeValueFunc)( void *) )                       
{
   FD_PrivDictInfo *theDict;

   /* Alloc the structure used as an handle for this dictionary. */
   theDict = (FD_PrivDictInfo *) FD_Malloc( sizeof( FD_PrivDictInfo ) );

   if( !theDict )
      return NULL;

   theDict->flags = flags;

   /* Create the Kazlib dictionary. */
   if( flags & FD_DICT_KEY_ONE_STRING )
      dict_init( &theDict->d, DICTCOUNT_T_MAX, compareFunction_S );
   else if( flags & FD_DICT_KEY_TWO_STRING )
      dict_init( &theDict->d, DICTCOUNT_T_MAX, compareFunction_S );
   else if( flags & FD_DICT_KEY_INTEGER )
      dict_init( &theDict->d, DICTCOUNT_T_MAX, compareFunction_I );

   /* Keep a copy of the freeValueFunc pointer for later use. */
   theDict->freeValueFunc = freeValueFunc;

   return (FD_Dict *)theDict;
}

FD_RetCode FD_DictFree( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;

   dnode_t   *node;
   dnode_t   *next;
   FD_String *stringToDelete;
   void      *valueToDelete;
   dict_t    *kazlibDict;
   int        flags;

   theDict = (FD_PrivDictInfo *)dict;

   if( theDict == NULL )
      return FD_BAD_PARAM;

   kazlibDict = &theDict->d;

   /* Delete all the key-value pair sequentially. */
   node = dict_first( kazlibDict );

   while (node != NULL)
   {
      /* Get the next node. */
      next = dict_next( kazlibDict, node );

      /* Free the 'node, the 'key' string and the 'value'. */
      flags = theDict->flags;
      valueToDelete  = dnode_get(node);
      if( flags & (FD_DICT_KEY_TWO_STRING|FD_DICT_KEY_ONE_STRING) )
      {
         stringToDelete = FD_StringFromChar(dnode_getkey(node));
         dict_delete_free( kazlibDict, node );
         FD_StringFree( FD_GetGlobalStringCache(), stringToDelete );
      }
      else
         dict_delete_free( kazlibDict, node );

      if( flags & FD_DICT_KEY_TWO_STRING )
      {
         /* The value is a dictionary. Delete it. */
         FD_DictFree( (FD_Dict *)valueToDelete );
      }
      else if( theDict->freeValueFunc )
         theDict->freeValueFunc( valueToDelete );

      node = next;
   }

   /* Free the FD_PrivDictInfo */
   FD_Free( theDict );

   return FD_SUCCESS;
}


FD_RetCode FD_DictAddPair_S2( FD_Dict *dict,
                              FD_String *key1,
                              FD_String *key2,
                              void *value )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;
   FD_String *dupKey;
   FD_Dict *subDict;
   dict_t  *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) ||
       (key1 == NULL) || (key2 == NULL) || (value == NULL) )
      return FD_BAD_PARAM;
   kazlibDict = &theDict->d;

   /* Verify if a a dictionary already exist for key1. */
   node = dict_lookup( kazlibDict, FD_StringToChar(key1) );

   if( node )
   {
      /* A dictionary already exist with the same key1... re-use it. */
      subDict = (FD_Dict *)dnode_get( node );
   }
   else
   {
      /* Alloc a new directory corresponding to key1. */
      subDict = FD_DictAlloc( FD_DICT_KEY_ONE_STRING, theDict->freeValueFunc );

      if( !subDict )
         return FD_ALLOC_ERR;

      dupKey = FD_StringDup( FD_GetGlobalStringCache(  ), key1 );

      if( !dupKey )
      {
         FD_DictFree( subDict );
         return FD_ALLOC_ERR;
      }

      if( !dict_alloc_insert( kazlibDict, FD_StringToChar(dupKey), subDict ) )
      {
         FD_DictFree( subDict );
         FD_StringFree( FD_GetGlobalStringCache(  ), dupKey );
         return FD_ALLOC_ERR;
      }
   }

   /* Insert the string in the subDict using key2 */
   return FD_DictAddPair_S( subDict, key2, value );
}

FD_RetCode FD_DictAddPair_S( FD_Dict *dict,
                             FD_String *key,
                             void *value )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;
   FD_String *dupKey;
   dict_t  *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (key == NULL) || (value == NULL) )       
      return FD_BAD_PARAM;
   kazlibDict = &theDict->d;

   /* Verify if an entry exist already with the same key. */
   node = dict_lookup( kazlibDict, FD_StringToChar(key) );

   if( node )
   {
      /* An entry already exist with the same key...
       * Re-use the existing node. Just replace the
       * 'value' part.
       * De-allocate the older 'value'.
       */
      if( theDict->freeValueFunc )
         (*theDict->freeValueFunc)( dnode_get( node ) );
      dnode_put( node, value );
   }
   else
   {
      /* Alloc/insert a new key-value pair in the dictionary. */
      dupKey = FD_StringDup( FD_GetGlobalStringCache(  ), key );

      if( !dupKey )
         return FD_ALLOC_ERR;

      if( !dict_alloc_insert( kazlibDict, FD_StringToChar(dupKey), value ) )
      {
         FD_StringFree( FD_GetGlobalStringCache(  ), dupKey );
         return FD_ALLOC_ERR;
      }
   }

   return FD_SUCCESS;
}

FD_RetCode FD_DictAddPair_I( FD_Dict *dict,
                             int key,
                             void *value )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;
   dict_t  *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (value == NULL) )
      return FD_BAD_PARAM;

   kazlibDict = &theDict->d;

   /* Verify if an entry exist already with the same key. */
   node = dict_lookup( kazlibDict, (void *)(long)key );

   if( node )
   {
      /* An entry already exist with the same key...
       * Re-use the existing node. Just replace the
       * 'value' part.
       * De-allocate the older 'value'.
       */
      if( theDict->freeValueFunc )
         (*theDict->freeValueFunc)( dnode_get( node ) );
      dnode_put( node, value );
   }
   else
   {
      /* Insert the new key-value pair in the dictionary. */
      if( !dict_alloc_insert( kazlibDict, (void *)(long)key, value ) )
         return FD_ALLOC_ERR;
   }

   return FD_SUCCESS;
}

FD_RetCode FD_DictDeletePair_S( FD_Dict *dict, const char *key )
{
   FD_PrivDictInfo *theDict;
   FD_String *stringToDelete;
   void      *valueToDelete;
   dnode_t   *node;
   dict_t    *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (key == NULL) )
      return FD_BAD_PARAM;
   kazlibDict = &theDict->d;

   /* Find the key-value pair. */
   node = dict_lookup( kazlibDict, key );

   if( node )
   {
      /* Free the 'node', the 'key' string and the 'value'. */
      stringToDelete = FD_StringFromChar( dnode_getkey(node) );
      valueToDelete  = dnode_get(node);
      dict_delete_free( kazlibDict, node );
      FD_StringFree( FD_GetGlobalStringCache(  ), stringToDelete );
      if( theDict->freeValueFunc )
         theDict->freeValueFunc( valueToDelete );
   }
   else
      return FD_KEY_NOT_FOUND;

   return FD_SUCCESS;
}

FD_RetCode FD_DictDeletePair_S2( FD_Dict *dict, const char *key1, const char *key2 )
{
   FD_PrivDictInfo *theDict;
   FD_String *stringToDelete;
   dnode_t   *node;
   FD_Dict   *subDict;
   FD_RetCode retCode;
   dict_t    *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL)    ||
       (key1 == NULL)       || 
       (key2 == NULL))
      return FD_BAD_PARAM;
   kazlibDict = &theDict->d;

   /* Find the dictionary for this 'key1'. */
   node = dict_lookup( kazlibDict, key1 );

   if( !node )
      return FD_KEY_NOT_FOUND;

   subDict = (FD_Dict *)dnode_get(node);

   retCode = FD_DictDeletePair_S( subDict, key2 );

   /* Delete the dictionary if it is empty. */
   if( (retCode == FD_SUCCESS) && (FD_DictSize(subDict) == 0) )
   {
      FD_DictFree( subDict );
      /* Free the 'node' and the 'key1' string. */
      stringToDelete = FD_StringFromChar( dnode_getkey(node) );
      dict_delete_free( kazlibDict, node );
      FD_StringFree( FD_GetGlobalStringCache(), stringToDelete );
   }
   return FD_SUCCESS;
}

FD_RetCode FD_DictDeletePair_I( FD_Dict *dict, int key )
{
   FD_PrivDictInfo *theDict;
   void      *valueToDelete;
   dnode_t   *node;
   dict_t    *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( theDict == NULL )
      return FD_BAD_PARAM;
   kazlibDict = &theDict->d;

   /* Find the key-value pair. */
   node = dict_lookup( kazlibDict, (void *)(long)key );

   if( node )
   {
      /* Free the 'node' and the 'value'. */
      valueToDelete  = dnode_get(node);
      dict_delete_free( kazlibDict, node );
      if( theDict->freeValueFunc )
         theDict->freeValueFunc( valueToDelete );
   }
   else
      return FD_KEY_NOT_FOUND;

   return FD_SUCCESS;
}

void *FD_DictGetValue_S( FD_Dict *dict, const char *key )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (key == NULL) )
      return NULL;

   /* Find the key-value pair. */
   node = dict_lookup( &theDict->d, key );

   if( !node )
      return NULL;

   return dnode_get(node);
}

void *FD_DictGetValue_S2( FD_Dict *dict, const char *key1, const char *key2 )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;
   FD_PrivDictInfo *subDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (key1 == NULL) || (key2 == NULL))
      return NULL;

   /* Find the dictionary for key1. */
   node = dict_lookup( &theDict->d, key1 );

   if( !node )
      return NULL;

   subDict = dnode_get(node);

   /* Find the key-value pair using key2. */
   node = dict_lookup( &subDict->d, key2 );

   if( !node )
      return NULL;

   return dnode_get(node);
}

void *FD_DictGetValue_I( FD_Dict *dict, int key )
{
   FD_PrivDictInfo *theDict;
   dnode_t *node;

   theDict = (FD_PrivDictInfo *)dict;

   if( theDict == NULL )
      return NULL;

   /* Find the key-value pair. */
   node = dict_lookup( &theDict->d, (void *)(long)key );

   if( !node )
      return NULL;

   return dnode_get(node);
}

int FD_DictAccessFirst( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;
   dict_t *kazlibDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( theDict == NULL )
      return (int)NULL;
   kazlibDict = &theDict->d;

   if( !(theDict->flags & FD_DICT_KEY_ONE_STRING) )
      return 0; /* All other dictionary type are not supported. */

   /* Get the first node. */
   theDict->accessNode = dict_first( kazlibDict );

   if( !theDict->accessNode )
      return 0;

   return dict_count( kazlibDict );
}

FD_String *FD_DictAccessKey( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (theDict->accessNode == NULL) )
      return NULL;

   return FD_StringFromChar( dnode_getkey( theDict->accessNode ) );
}

void *FD_DictAccessValue( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (theDict->accessNode == NULL) )
      return NULL;

   return dnode_get( theDict->accessNode );
}

int FD_DictAccessNext( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( (theDict == NULL) || (theDict->accessNode == NULL) )
      return 0;

   /* Move to the next node. */
   theDict->accessNode = dict_next( &theDict->d, theDict->accessNode );

   if( !theDict->accessNode )
   {
      /* There is no element left... */
      return 0;
   }

   return 1;
}

unsigned int FD_DictSize( FD_Dict *dict )
{
   FD_PrivDictInfo *theDict;

   theDict = (FD_PrivDictInfo *)dict;

   if( theDict == NULL)
      return 0;

   return (unsigned int)dict_count( &theDict->d );
}

#if 0
FD_RetCode FD_DictMerge( FD_Dict *dest, const FD_Dict *src )
{
   const FD_PrivDictInfo *srcDict;
   FD_PrivDictInfo *destDict;

   srcDict  = (const FD_PrivDictInfo *)src;
   destDict = (FD_PrivDictInfo *)dest;

   if( !srcDict || !destDict )
      return FD_BAD_PARAM;

   /* Make sure both dictionary are of the same type. */
   #define DICT_TYPE_MASK (FD_DICT_KEY_ONE_STRING|FD_DICT_KEY_TWO_STRING|FD_DICT_KEY_INTEGER)
   if( (srcDict->flags&DICT_TYPE_MASK) != (destDict->flags&DICT_TYPE_MASK) )
      return FD_DICT_TYPE_MISMATCH;

      dict_init( &theDict->d, DICTCOUNT_T_MAX, compareFunction_I );

   dict_merge( &destDict->d, &srcDict->d );

   TO BE COMPLETED
}
#endif


/**** Local functions definitions.     ****/
static int compareFunction_S( const void *key1, const void *key2 )
{
   return strcmp( key1, key2 );
}

static int compareFunction_I( const void *key1, const void *key2 )
{
   long res = (long)key1 - (long)key2;
   return (res > 0)? 1 : (res < 0)? -1 : 0;
}
