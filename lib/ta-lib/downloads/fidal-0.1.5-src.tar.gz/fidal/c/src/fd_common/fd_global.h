#ifndef FD_GLOBAL_H
#define FD_GLOBAL_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_SYSTEM_H
   #include "fd_system.h"
#endif

/* This interface is used exclusively INTERNALY to FIDAL.
 * There is nothing for the end-user here ;->
 */

/* Provides functionality for managing global ressource
 * throughout the FIDAL.
 *
 * Since not all module are used/link in the application,
 * the fd_common simply provides the mechanism for the module
 * to optionnaly "register" its initialization/shutdown
 * function.
 *
 * A function shall access its global variable by calling 
 * FD_GetGlobal. This function will appropriatly call the 
 * initialization function if its global are not yet initialized.
 * 
 * The call of the init and shutdown function are guaranteed
 * to be multithread protected. It is also guarantee that
 * these function will always get called in alternance (in
 * other word, following an initialization only a shutdown
 * can get called).
 */

typedef enum
{
   /* Module will be shutdown in the order specified here. */
   	
   FD_ABSTRACTION_GLOBAL_ID,
   FD_FUNC_GLOBAL_ID,
   FD_DAFD_GLOBAL_ID,

   FD_NETWORK_GLOBAL_ID,   /* Network/internet support. */
   FD_SYSTEM_GLOBAL_ID,    /* OS specific ressources. */

   FD_TRACE_GLOBAL_ID,  /* Must be before last. */
   FD_MEMORY_GLOBAL_ID, /* Must be last.        */

   FD_NB_GLOBAL_ID
} FD_GlobalModuleId;

typedef FD_RetCode (*FD_GlobalInitFunc)    ( void **globalToAlloc );
typedef FD_RetCode (*FD_GlobalShutdownFunc)( void *globalAllocated );

typedef struct
{
   const FD_GlobalModuleId     id;
   const FD_GlobalInitFunc     init;
   const FD_GlobalShutdownFunc shutdown;
} FD_GlobalControl;

FD_RetCode FD_GetGlobal( const FD_GlobalControl * const control,
                         void **global );

FD_StringCache *FD_GetGlobalStringCache( void );

/* Occasionaly, code tracing must be disable.
 * Example:
 *  - The memory module needs to know if the tracing is
 *    still enabled or not when freeing memory on shutdown.
 *  - We do not want to recursively trace while the tracing
 *    function themselves gets called ;->
 */
int  FD_IsTraceEnabled( void );
void FD_TraceEnable   ( void );
void FD_TraceDisable  ( void );

/* If enabled by the user, use stdio for debugging.
 * Will return NULL if not enabled.
 */
FILE *FD_GetStdioFilePtr( void );

/* If enabled by the user, use a local drive
 * for configuration and/or temporary file.
 * FIDAL must NEVER assume such local drive 
 * is available.
 */
const char *FD_GetLocalCachePath( void );

typedef struct
{
  #if !defined( FD_SINGLE_THREAD )
  FD_Sema sema;
  #endif
  unsigned int initialize;
  const FD_GlobalControl * control;
  void *global;
} FD_ModuleControl;

/* This is the hidden implementation of FD_Libc. */
typedef struct
{
   unsigned int magicNb; /* Unique identifier of this object. */
   FD_StringCache *dfltCache;
   FD_ModuleControl moduleControl[FD_NB_GLOBAL_ID];

   unsigned int traceEnabled;
   unsigned int stdioEnabled;
   FILE *stdioFile;

   const char *localCachePath;
} FD_LibcPriv;

/* The following global is used all over the place 
 * and is the entry point for all other globals.
 */
extern FD_LibcPriv *FD_Globals;

#endif

