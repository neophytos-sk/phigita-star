/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  111800 MF   First version.
 *
 */

/* Description:
 *     Basic support for local parallelism. Most of the work is done with
 *     macros in 'fd_parallel.h'.
 *
 *     For the time being, the only type of parallelism supported is for
 *     multiprocessor (SMP system).
 */

/**** Headers ****/
#include <stddef.h>
#include <stdio.h>
#include "fd_parallel.h"
#include "fd_system.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   FD_ThreadFunction newThread;
   void *newThreadArgs;
   FD_BarrierSync *bs;
   FD_Sema threadGotParameters;
} FD_ThreadFrameParam;

/**** Local functions declarations.    ****/
void threadFrame( void *args );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_BarrierSyncInit( FD_BarrierSync *bs )
{
   FD_PROLOG
   FD_RetCode retCode;

   FD_TRACE_BEGIN(FD_BarrierSyncInit);

   FD_ASSERT( bs != NULL );

   bs->nbThread = 0;

   /* Initialize the barrier to an unblock state. */
   retCode = FD_SemaInit( &(bs->barrierSema), 1 );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, bs );
   }
   else
   {
      /* Initialize mutex (unblock state). */
      retCode = FD_SemaInit( &(bs->mutexSema), 1 );
      if( retCode != FD_SUCCESS )
      {
         FD_FATAL( NULL, retCode, bs );
      }
   }

   FD_TRACE_RETURN(retCode);
}

FD_RetCode FD_BarrierSyncDestroy( FD_BarrierSync *bs )
{
   FD_PROLOG
   FD_RetCode retCode;

   FD_TRACE_BEGIN(FD_BarrierSyncDestroy);

   FD_ASSERT( bs != NULL );

   /* Just to be on the safe side, make sure there is no
    * thread left to be joined.
    */
   if( bs->nbThread > 0 )
   {
      retCode = FD_BarrierSyncWaitAllDone( bs );
      if( retCode != FD_SUCCESS )
      {
         FD_FATAL( NULL, retCode, FD_GetLastError() );
      }
   }

   /* Make sure no one is left in the 'bs' critical section. */
   retCode = FD_SemaWait( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, FD_GetLastError() );
   }
   retCode = FD_SemaPost( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, FD_GetLastError() );
   }

   /* At this point it is safe to destroy all the 'bs' semaphores. */
   retCode = FD_SemaDestroy( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, FD_GetLastError() );
   }

   retCode = FD_SemaDestroy( &(bs->barrierSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, FD_GetLastError() );
   }

   FD_TRACE_RETURN(FD_SUCCESS);
}

FD_RetCode FD_BarrierSyncThreadAdd( FD_BarrierSync *bs )
{
   FD_PROLOG
   FD_RetCode retCode;
   unsigned int temp;

   FD_TRACE_BEGIN(FD_BarrierSyncThreadAdd);

   FD_ASSERT( bs != NULL );

   retCode = FD_SemaWait( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL(  NULL, retCode, FD_GetLastError() );
   }

   /*** Begin critical section. ***/
   temp = ++(bs->nbThread);
   if( temp == 1 )
   {
      /* First thread being launch, change the state of the barrier to block. */
      retCode = FD_SemaDec( &(bs->barrierSema) );
      if( retCode != FD_SUCCESS )
      {
         FD_SemaPost( &(bs->mutexSema) );
         FD_FATAL( NULL, retCode, FD_GetLastError() );
      }
   }
   /*** End critical section. ***/

   retCode = FD_SemaPost( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL(  NULL, retCode, FD_GetLastError() );
   }

   FD_TRACE_RETURN(FD_SUCCESS);
}

FD_RetCode FD_BarrierSyncThreadDone( FD_BarrierSync *bs )
{
   FD_PROLOG
   FD_RetCode retCode;
   unsigned int temp;

   FD_TRACE_BEGIN(FD_BarrierSyncThreadDone);

   FD_ASSERT( bs != NULL );

   retCode = FD_SemaWait( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL( NULL, retCode, FD_GetLastError() );
   }

   /*** Begin critical section. ***/
   FD_ASSERT( bs->nbThread >= 1 );
   temp = --(bs->nbThread);
   if( temp == 0 )
   {
      /* Last thread being done, change the state of the barrier to unblock. */
      retCode = FD_SemaInc( &(bs->barrierSema), NULL );
      if( retCode != FD_SUCCESS )
      {
         FD_SemaPost( &(bs->mutexSema) );
         FD_FATAL( NULL, retCode, FD_GetLastError() );
      }
   }

   /*** End critical section. ***/

   retCode = FD_SemaPost( &(bs->mutexSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL(  NULL, retCode, FD_GetLastError() );
   }

   FD_TRACE_RETURN(FD_SUCCESS);
}


FD_RetCode FD_BarrierSyncWaitAllDone( FD_BarrierSync *bs )
{
   FD_PROLOG
   FD_RetCode retCode;
   
   FD_TRACE_BEGIN(FD_BarrierSyncWaitAllDone);

   FD_ASSERT( bs != NULL );

   retCode = FD_SemaDec( &(bs->barrierSema) );
   if( retCode != FD_SUCCESS )
   {
      FD_FATAL(  NULL, retCode, FD_GetLastError() );
   }

   FD_TRACE_RETURN(FD_SUCCESS);
}


void FD_PAR_EXEC_F( FD_BarrierSync *bs, FD_ThreadFunction newThread, void *args )
{
   FD_RetCode retCode;
   FD_Sema threadGotParameters;
   FD_ThreadFrameParam threadParam;

   if( bs != NULL )
      return;

   FD_BarrierSyncThreadAdd( bs );

   /* Initialize semaphore in block state. */
   retCode = FD_SemaInit( &threadGotParameters, 0 );

   if( retCode != FD_SUCCESS )
      return;

   /* For safe multi-thread execution, and to avoid memory allocation,
    * the main thread will be block until the new thread have a chance
    * to run and make a copy of the 'args' pointer.
    * 
    * All this synchronization and copy is done within the threadFrame.
    * Consequently, the newThread does not have to bother about all this.
    */
   threadParam.newThread           = newThread;
   threadParam.newThreadArgs       = args;
   threadParam.bs                  = bs;
   threadParam.threadGotParameters = threadGotParameters;

   /* Call the threadFrame function who is going to take care of
    * all the coordination for a safe execution of the newThread.
    */
   retCode = FD_ThreadExec( threadFrame, &threadParam );

   if( retCode != FD_SUCCESS )
      return;

   /* Semaphore will get posted when the threadFrame made a local copy of the
    * parameters.
    */
   retCode = FD_SemaWait( &threadGotParameters );
   if( retCode != FD_SUCCESS )
      return;

   retCode = FD_SemaDestroy( &threadGotParameters );
   if( retCode != FD_SUCCESS )
      return;
}


/**** Local functions definitions.     ****/
void threadFrame( void *args )
{
   FD_RetCode retCode;
   FD_ThreadFunction newThread;
   void *newThreadArgs;
   FD_BarrierSync *bs;
   FD_ThreadFrameParam *param;
   FD_Sema threadGotParameters;

   /* This code is the new thread. */

   /* This threadFrame take care of the code 
    * surrounding the user provided entry and
    * exit point.
    */

   /* Get a pointer on the argument being
    * pass to the user entry point.
    * Once a copy of the args is done,
    * signal to the main thread that
    * it can release the 'param' structure.
    */
   param = (FD_ThreadFrameParam *)args;
   newThread = param->newThread;
   newThreadArgs = param->newThreadArgs;
   bs = param->bs;
   threadGotParameters = param->threadGotParameters;

   retCode = FD_SemaPost( &threadGotParameters );
   if( retCode != FD_SUCCESS )
   {
      #if defined( WIN32 )      
         _endthread();
      #else
         pthread_exit();
      #endif

      return;
   }

   /* Call the user provided "thread" entry point. */
   (*newThread)(newThreadArgs);

   FD_BarrierSyncThreadDone( bs );

   #if defined( WIN32 )      
      _endthread();
   #else
      pthread_exit();
   #endif
}

