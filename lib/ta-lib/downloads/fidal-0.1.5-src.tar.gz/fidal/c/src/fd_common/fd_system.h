#ifndef FD_SYSTEM_H
#define FD_SYSTEM_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FD_STREAM_H
   #include "fd_stream.h"
#endif

#ifdef WIN32
   #include <process.h>
#endif

#include <stdio.h>
#include <stdarg.h>

/* This file defines the interface to functions that must be adapted
 * to the particular OS on which the library is running.
 *
 * This allows FIDAL to abstract the Operating System when using
 * files, directory, thread, semaphore etc...
 *
 * There is no intent to make that abstraction do a complete and perfect
 * abstracation. Only the functionality needed in the context of FIDAL
 * is going to be implemented.
 */

/* Get the list of files/directories in a certain directory.
 *
 * The pattern can include wildcard used by this filesystem.
 */
typedef struct
{
   unsigned int nbFile;
   unsigned int nbDirectory;
   FD_List *listOfDirectory; /* List of FD_String. */
   FD_List *listOfFile;      /* List of FD_String. */
} FD_Directory;

FD_RetCode FD_DirectoryAlloc( const char *path,
                              FD_Directory **directory );

FD_RetCode FD_DirectoryFree( FD_Directory *directory );

/* Identify if the specified character is a seperator
 * used to seperates the directories in a path.
 *
 * Return 1 if this is a seperator character, else 0.
 */
int FD_IsSeparatorChar( int c );

/* Return the wild characters used by the file system. */
int FD_WildCharASCII( void );
int FD_WildASCII( void );

/* Return separator used to build path. */
int FD_SeparatorASCII( void );

/* Replace the separator depending of the platform. */
void FD_AdjustPath( char *path );

/* Return some information system specific. */
int FD_IsFileSystemCaseSensitive( void );
int FD_NbProcessor( void );

/* When an operation fails, the operating system may provides additional
 * information on the reason of the failure of the most recent OS call.
 * This information can be extracted by calling FD_GetLastError().
 * Note: the error code can be misleading if you are in a multithread
 *       situation.
 */
int FD_GetLastError( void );

/* Simplified thread functionality.
 *   A thread is created and started by calling FD_ThreadExec.
 *   The function pointed by 'newThreadEntryPoint' can simply return
 *   when execution is completed. Cannot be more simple than that...
 *
 *  Example:
 *     void printThread( void *string )
 *     {
 *        unsigned int i;
 *        for( i=0; i < 10; i++ )
 *        {
 *           FD_Sleep( rand() % 2 );
 *           puts( (char *)string );
 *        }
 *
 *     }
 *
 *     {
 *        ....
 *        FD_ThreadExec( printThread, (void *)"Thread #1" );
 *        FD_ThreadExec( printThread, (void *)"Thread #2" );
 *        FD_ThreadExec( printThread, (void *)"Thread #3" );
 *        ...
 *     }
 *
 */
#if defined( WIN32 )
   typedef void (*FD_ThreadFunction)( void *args );
#else
   typedef void *(*FD_ThreadFunction)( void *args );
#endif

FD_RetCode FD_ThreadExec( FD_ThreadFunction newThreadEntryPoint, void *args );
FD_RetCode FD_ThreadExit( void );

/* Sleep the current thread (in seconds).
 * A value of zero causes the thread to relinquish the remainder of its
 * time slice to any other thread of equal priority that is ready to run.
 */
void FD_Sleep( unsigned int seconds );

/* Support for counting semaphore. */

#if !defined( FD_SINGLE_THREAD )

/* Bitmap for FD_Sema flags */
#define FD_SEMA_INITIALIZED 0x00000001

/* If named semaphores are used, set the maximum name length */
#if defined( USE_NAMED_SEMAPHORES )
#define FD_MAX_SEMAPHORE_NAME_LENGTH 256
#endif

#if defined( WIN32 )
   #include <windows.h>
   typedef struct {
      HANDLE theSema;
      unsigned int flags; /* 1 when initialized. */
   } FD_Sema;
#else
   #include <pthread.h>
   #include <semaphore.h>
   typedef struct {
      #if defined( USE_NAMED_SEMAPHORES )
      char name[FD_MAX_SEMAPHORE_NAME_LENGTH];
      sem_t *theSema;
      #else
      sem_t theSema;
      #endif
      unsigned int flags; /* 1 when initialized. */
   } FD_Sema;
#endif

FD_RetCode FD_SemaInit( FD_Sema *sema, unsigned int initialValue );
FD_RetCode FD_SemaDestroy( FD_Sema *sema );

FD_RetCode FD_SemaWait( FD_Sema *sema );
FD_RetCode FD_SemaPost( FD_Sema *sema );

FD_RetCode FD_SemaInc( FD_Sema *sema, unsigned int *prevCount );
FD_RetCode FD_SemaDec( FD_Sema *sema );

#endif

/* Simple support for fast sequential read only access of files.
 *
 * These functions attempts to be memory and speed efficient
 * depending of the operating system.
 *
 * FD_FileSeqOpen : Return FD_Success and set the fileHandle on success.
 *
 * FD_FileSeqRead: Return a pointer on the data read. The number of byte is
 *             returned through the parameter 'nbByteRead'. Return NULL
 *             when there is no further byte to read.
 *             The returned pointer is valid only until the next call to
 *             FD_FileSeqRead. If the data is still needed beyond that
 *             tiemframe, you must proceed to a local copy.
 *
 * FD_FileSeqClose: Free ressources that were allocated for this file handle.
 *
 * To avoid memory allocation, it is assumed that "path" is a valid ptr until
 * the file is closed.
 */
typedef unsigned int FD_FileHandle; /* Hidden implementation. */

FD_RetCode FD_FileSeqOpen( const char *path, FD_FileHandle **handle );
const char *FD_FileSeqRead( FD_FileHandle *handle, unsigned int *nbByteRead );
FD_RetCode FD_FileSeqClose( FD_FileHandle *handle );
unsigned int FD_FileSize( FD_FileHandle *handle );

/* Like FD_FileSeqOpen, but work with a stream instead. Following this FD_FileSeqRead,
 * FD_FileSeqClose and FD_FileSize can be called as if it was a real file.
 *
 * This is a speed efficient way to access a stream sequentially (because the
 * data is returned in "chunks" and often a stream will be compose of just a
 * few large block).
 */
FD_RetCode FD_FileSeqOpenFromStream( FD_Stream *stream, FD_FileHandle **handle );

/* Equivalent to printf, but allows to output to a buffer and/or a FILE. 
 * The function will stop to write in the buffer once fill up.
 *
 * Example 1:  output to stdout and a buffer
 *     FD_PrintfVar outp;
 *     memset( outp, 0, sizeof(outp) );
 *     outp.file   = stdio; 
 *     outp.buffer = buffer; 
 *     outp.size   = sizeof(buffer); 
 *     FD_Printf( outp, ... );
 *
 * Example 2:  output to a buffer only
 *     FD_PrintfVar outp;
 *     memset( outp, 0, sizeof(outp) );
 *     outp.buffer = buffer; 
 *     outp.size   = sizeof(buffer); 
 *     FD_Printf( outp, ... );
 *
 * Example 3:  output to a file only
 *     FD_PrintfVar outp;
 *     memset( outp, 0, sizeof(outp) );
 *     outp.file = fopen( ... );
 *     FD_Printf( outp, ... );
 *
 */
typedef struct
{
   FILE *file;
   char *buffer;
   int   size;
} FD_PrintfVar;

void FD_Printf( FD_PrintfVar *outp, char *format, ... );

#endif

