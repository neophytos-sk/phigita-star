/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070101 MF   First version.
 *  062803 MF   Make FD_StreamAccessSearch case insensitive
 */

/* Description:
 *    Provides bit streaming functionality.
 *
 *    Streams can be merged, compress, expanded, validated with CRC, etc...
 *
 *    Provides also a portable streaming of FD_Integer, FD_Timestamp and FD_Real.
 *
 *    Although at first the implementation may seems complexe, this module
 *    is design in a way to make possible to make some very good speed
 *    optimization... eventually.
 *
 *    A stream is similar to a "buffer descriptor" mechanism provided by
 *    certain embedded OS. It is particularly needed in a protocol stack
 *    for adding header and trailer to the data while moving in the
 *    stack. The same can be done here with a FD_Stream.
 */

/**** Headers ****/
#include <stdlib.h>

#include "fd_common.h"
#include "fd_trace.h"
#include "fd_memory.h"
#include "fd_magic_nb.h"
#include "fd_global.h"

#include "sfl.h"

#ifndef FD_STREAM_H
   #include "fd_stream.h"
#endif

#include "bzip2/bzlib.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
struct FD_Stream_struct
{
  unsigned int    magicNb;

  unsigned char  *data;         /* Start of the data. */
  unsigned int    nbBitWritten; /* Number of bit in this block. */

  void           *freeData;   /* Ptr used to free the data. */
  FD_FreeFuncPtr  freeFunc;   /* FD_Free will be called when NULL. */
  void           *opaqueData; /* Transparently pass to the freeFunc. */

  unsigned int    allocSize;  /* Total nb byte allocated for 'freeData' */

  unsigned int    writePos; /* Indicate where the next bit will be written. */
  unsigned char   writeMask;

  unsigned int    nbByteToSkip; /* When decapsulating a FD_Stream, the header
                                 * bytes must be skip by the access functions.
                                 */

  struct FD_Stream_struct *next;
  struct FD_Stream_struct *lastBlock;
};

typedef struct FD_Stream_struct FD_StreamPriv;

typedef struct
{
  unsigned int     magicNb;

  unsigned int     endOfStream; /* No more bit in the stream. */

  const FD_StreamPriv *currentBlock;
  unsigned int         nbBitRead;   /* Nb bit read in the currentBlock. */

  /* Iterator within the currenBlock->freeData */
  unsigned int     readPos;
  unsigned char    readMask;
} FD_StreamAccessPriv;

/* A complete stream is a link list of block.
 * The size of the first block can be different
 * of the size of the block added (when the first block
 * is full).
 *
 * Note: These are the default size. Many blocks
 *       won't be of that size.
 */
#define FD_STREAM_FIRST_BLOCK_SIZE (8192)
#define FD_STREAM_OTHER_BLOCK_SIZE (4096)

/* There is no plan for this stream module to support more than 3 different
 * compression format (with the uncompress format, that makes a total of no
 * more than 4 types). This limit of 4 allows to code the type on two bits.
 * These two bits are append in front of the compressed information.
 * Of course, these two bits will allow the "decompresor" to use the right
 * algorithm.
 */
typedef enum
{
    FD_STREAM_NO_COMPRESSION,   /* No compression.   */
    FD_STREAM_BZIP2,            /* BZIP2 compression algorithm. */
    FD_STREAM_COMP2,            /* Undefined algorithm for the time being. */
    FD_STREAM_COMP3             /* Undefined algorithm for the time being. */
} FD_StreamType;

/**** Local functions declarations.    ****/
static FD_RetCode streamJumpToNextByteBoundary( FD_StreamPriv *stream, unsigned int *nbBitAdded );
static FD_RetCode accessJumpToNextByteBoundary( FD_StreamAccessPriv *streamAcc );
static FD_StreamPriv *streamAllocSize( unsigned int nbByte );
static FD_RetCode streamCompressBZIP2( const FD_StreamPriv *streamToCompress, FD_StreamPriv **retStream );
static FD_RetCode streamDecompressBZIP2( FD_StreamPriv *stream, FD_StreamAccessPriv *streamToDecompress );
static int accessMoveToNextBlock( FD_StreamAccessPriv *access );

static FD_RetCode streamPrivInit( FD_StreamPriv *streamPriv,
                                  unsigned char *data,
                                  unsigned int nbByte,
                                  FD_FreeFuncPtr freeFunc,
                                  void *opaqueData );

static void freeData( FD_StreamPriv *streamPriv );

static FD_RetCode calcCRC( FD_Stream *stream,
                           unsigned int start, /* First byte to include. Zero base. */
                           unsigned int stop,  /* Last byte to include. Zero base. */
                           unsigned int *crc32 );

static FD_RetCode markByteForSkip( FD_Stream *stream, unsigned int nbByteToSkip );


static void accessPrivCopy( FD_StreamAccessPriv *src, FD_StreamAccessPriv *dst );

static FD_RetCode streamGetHTMLTable( FD_StreamAccess *access,
                                      unsigned int maxElementSize,
                                      char *buffer,
                                      char *hrefBuffer,
                                      FD_HTMLTableFuncPtr funcPtr,
                                      void *opaqueData );

static FD_RetCode streamGetHREF( FD_StreamAccess *access,
                                 char *buffer,
                                 unsigned int bufferSize );
 
/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

/* Use to alloc/dealloc a stream for the user. */
FD_Stream *FD_StreamAlloc( void )
{
   return (FD_Stream *)streamAllocSize( FD_STREAM_FIRST_BLOCK_SIZE );
}

FD_RetCode FD_StreamFree( FD_Stream *stream )
{
   FD_StreamPriv *streamPriv;
   FD_StreamPriv *tmp;

   streamPriv = (FD_StreamPriv *)stream;
   
   while( streamPriv )
   {
      if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
         return FD_BAD_OBJECT;

      freeData( streamPriv );

      tmp = streamPriv->next;
      FD_Free(  streamPriv );
      streamPriv = tmp;
   }

   return FD_SUCCESS;
}

FD_Stream *FD_StreamAllocFromBuffer( unsigned char *data,
                                     unsigned int dataSize,
                                     FD_FreeFuncPtr freeFunc,
                                     void *opaqueData )
{
   FD_StreamPriv *newStreamPriv;

   if( !data || !dataSize )
      return (FD_Stream *)NULL;

   newStreamPriv = (FD_StreamPriv *)FD_Malloc( sizeof( FD_StreamPriv ) );
   if( !newStreamPriv )
      return (FD_Stream *)NULL;

   newStreamPriv->data = data;
   newStreamPriv->freeData = data;

   /* Variables allowing to know how to free the data. */
   newStreamPriv->opaqueData = opaqueData;
   newStreamPriv->freeFunc = freeFunc; 

   /* Variables for keeping track on where the next bit is written. */
   newStreamPriv->writePos     = dataSize-1;     /* All byte written.  */
   newStreamPriv->writeMask    = 0x00;
   newStreamPriv->nbBitWritten = dataSize << 3;  /* All bit written.  */

   newStreamPriv->allocSize = dataSize; /* Nb of byte allocated. */

   /* Will allow to link this block to others. */
   newStreamPriv->next      = NULL;
   newStreamPriv->lastBlock = newStreamPriv;

   /* and the rest... */
   newStreamPriv->nbByteToSkip  = 0;
   newStreamPriv->magicNb   = FD_STREAM_MAGIC_NB;

   return (FD_Stream *)newStreamPriv;
}

/* Use to add an element at the end of the output stream. */
FD_RetCode FD_StreamAddBit( FD_Stream *stream, unsigned int bit )
{
   FD_StreamPriv *lastBlock;
   FD_StreamPriv *tempBlock;
   FD_StreamPriv *streamPriv;

   streamPriv = (FD_StreamPriv *)stream;

   if( !streamPriv )
      return FD_BAD_PARAM;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
     return FD_BAD_OBJECT;

   lastBlock = streamPriv->lastBlock;

   /* Verify if a new byte is needed. */
   if( lastBlock->writeMask == 0x00 )
   {
      if( lastBlock->writePos >= (lastBlock->allocSize-1) )
      {
         /* Allocate a new block for the stream and add it at the end
          * of the link list of block.
          */
         tempBlock = streamAllocSize( FD_STREAM_OTHER_BLOCK_SIZE );
         if( !tempBlock )
            return FD_ALLOC_ERR;

         lastBlock->next       = tempBlock;
         streamPriv->lastBlock = lastBlock->next;
         lastBlock             = streamPriv->lastBlock;
      }
      else
      {
         lastBlock->writeMask = 0x80;
         lastBlock->writePos++;
      }

      lastBlock->data[lastBlock->writePos] = 0x00;
   }

   /* Write the bit and move the index to next one. */
   if( bit )
      lastBlock->data[lastBlock->writePos] |= lastBlock->writeMask;

   lastBlock->writeMask >>= 1;
   lastBlock->nbBitWritten++;

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddByte( FD_Stream *stream, unsigned char data )
{
   unsigned char mask = 0x80;
   FD_RetCode retCode;
   FD_StreamPriv *streamPriv;
   FD_StreamPriv *lastBlock;

   streamPriv = (FD_StreamPriv *)stream;

   if( !streamPriv )
      return FD_BAD_PARAM;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
     return FD_BAD_OBJECT;

   lastBlock = streamPriv->lastBlock;

   /* Add byte in one shot if already on a byte boundary, else
    * add the 8 bits one by one with FD_StreamAddBit.
    */
#if 0
   !!! TO BE DEBUG

   if( (lastBlock->writeMask & 0x7F) == 0x00 )
   {
      /* Next byte written on a byte boundary. */
      if( lastBlock->writePos >= (lastBlock->allocSize-1) )
      {
         /* Allocate a new block for the stream and add it at the end
          * of the link list of block.
          */
         tempBlock = streamAllocSize( FD_STREAM_OTHER_BLOCK_SIZE );
         if( !tempBlock )
            return FD_ALLOC_ERR;

         lastBlock->next       = tempBlock;
         streamPriv->lastBlock = lastBlock->next;
         lastBlock             = streamPriv->lastBlock;
      }
      else
         lastBlock->writePos++;

      lastBlock->data[lastBlock->writePos] = data;
   }
   else
#endif

   {
      /* Add the bits one by one. */
      mask = 0x80;
      while( mask )
      {
         retCode = FD_StreamAddBit( stream, data & mask );
         if( retCode != FD_SUCCESS )
            return retCode;

         mask >>= 1;
      }
   }

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddInt16( FD_Stream *stream, unsigned short data )
{
   FD_RetCode retCode;
   unsigned char temp;

   temp = (unsigned char)(data>>8);
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   temp = (unsigned char)data;
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddInt32( FD_Stream *stream, unsigned int data )
{
   FD_RetCode retCode;
   unsigned char temp;

   temp = (unsigned char)(data>>24);
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   temp = (unsigned char)(data>>16);
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   temp = (unsigned char)(data>>8);
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   temp = (unsigned char)data;
   retCode = FD_StreamAddByte( stream, temp );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddInteger( FD_Stream *stream, FD_Integer data )
{
   /* Value store in a FD_Integer are assumed to not exceed 
    * a 32 bits value.
    */
   return FD_StreamAddInt32( stream, data );
}

FD_RetCode FD_StreamAddDouble( FD_Stream *stream, double data )
{
   int i;
   FD_RetCode retCode;

   /* !!! This is probably NOT portable and further
    * !!! research shall be done on this... eventually.
    */
   typedef union
   {
      double d;
      unsigned char b[8];
   } OUTDATA;

   OUTDATA outdata;
   FD_StreamPriv *streamPriv;

   streamPriv = (FD_StreamPriv *)stream;

   if( !streamPriv )
      return FD_BAD_PARAM;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
     return FD_BAD_OBJECT;

   outdata.d = data;
   for( i=sizeof(double)-1; i >= 0; i-- )
   {
      retCode = FD_StreamAddByte( stream, outdata.b[i] );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddReal( FD_Stream *stream, FD_Real data )
{
   /* Portable!? */
   return FD_StreamAddDouble( stream, data );
}

FD_RetCode FD_StreamAddBuffer( FD_Stream *stream,
                               unsigned char *data,
                               unsigned int dataSize,
                               FD_FreeFuncPtr freeFunc,
                               void *opaqueData )
{
   FD_StreamPriv *newStreamPriv;
   FD_StreamPriv *firstStreamPriv;

   if( !data || !stream || (dataSize <= 0) )
      return FD_BAD_PARAM;
   
   firstStreamPriv = (FD_StreamPriv *) stream;

   if( firstStreamPriv->magicNb != FD_STREAM_MAGIC_NB )
      return FD_BAD_OBJECT;

   newStreamPriv = (FD_StreamPriv *)FD_Malloc( sizeof( FD_StreamPriv ) );
   if( !newStreamPriv )
      return FD_ALLOC_ERR;

   newStreamPriv->data = data;
   newStreamPriv->freeData = data;

   /* Variables allowing to know how to free the data. */
   newStreamPriv->opaqueData = opaqueData;
   newStreamPriv->freeFunc = freeFunc; 

   /* Variables for keeping track on where the next bit is written. */
   newStreamPriv->writePos     = dataSize-1;     /* All byte written.  */
   newStreamPriv->writeMask    = 0x00;
   newStreamPriv->nbBitWritten = dataSize << 3;  /* All bit written.  */

   newStreamPriv->allocSize = dataSize; /* Nb of byte allocated. */

   /* Will allow to link this block to others. */
   newStreamPriv->next      = NULL;
   newStreamPriv->lastBlock = newStreamPriv;

   /* and the rest... */
   newStreamPriv->nbByteToSkip  = 0;
   newStreamPriv->magicNb   = FD_STREAM_MAGIC_NB;

   return FD_StreamMerge( stream, (FD_Stream *)newStreamPriv );
}

FD_RetCode FD_StreamAddString( FD_Stream *stream, const FD_String *string )
{
   FD_RetCode retCode;
   const char *strChar;
   unsigned int length, i;

   strChar = FD_StringToChar(string);

   length = strlen( strChar );
   if( length > 255 )
      return FD_BAD_PARAM;

   retCode = FD_StreamAddByte( stream, (unsigned char)length );
   if( retCode != FD_SUCCESS )
      return retCode;

   for( i=0; i < length; i++ )
   {
      retCode = FD_StreamAddByte( stream, strChar[i] );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddTimestamp( FD_Stream *stream, const FD_Timestamp *timestamp )
{
   FD_RetCode retCode;

   retCode = FD_StreamAddInt32( stream, timestamp->date );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAddInt32( stream, timestamp->time );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

/* Use to read the stream sequentially. */
FD_StreamAccess *FD_StreamAccessAlloc( const FD_Stream *stream )
{
   FD_StreamAccessPriv *accessPriv;
   const FD_StreamPriv *streamPriv;

   streamPriv = (const FD_StreamPriv *)stream;

   if( !streamPriv )
      return (FD_StreamAccess *)NULL;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
      return (FD_StreamAccess *)NULL;
     
   accessPriv = (FD_StreamAccessPriv *) FD_Malloc( sizeof( FD_StreamAccessPriv ) );

   if( !accessPriv )
      return (FD_StreamAccess *)NULL;

   accessPriv->currentBlock = streamPriv;
   accessPriv->readPos      = 0;
   accessPriv->readMask     = 0x80;
   accessPriv->nbBitRead    = 0;
   accessPriv->endOfStream  = 0;
   accessPriv->magicNb      = FD_STREAM_ACCESS_MAGIC_NB;

   if( streamPriv->nbBitWritten == 0 )
   {
      /* The first block is totally skipped. Attempt to 
       * go to the next block having data.
       */
      accessMoveToNextBlock( accessPriv );
   }

   return (FD_StreamAccess *)accessPriv;
}

FD_RetCode FD_StreamAccessFree( FD_StreamAccess *access )
{
   FD_StreamAccessPriv *accessPriv;

   if( access )
   {
      accessPriv = (FD_StreamAccessPriv *)access;
      if( accessPriv->magicNb != FD_STREAM_ACCESS_MAGIC_NB )
         return FD_BAD_OBJECT;

      FD_Free( access );
   }

   return FD_SUCCESS;
}

FD_StreamAccess *FD_StreamAccessAllocCopy( const FD_StreamAccess *stream )
{
    FD_StreamAccessPriv *accessPriv = (FD_StreamAccessPriv *)stream;

    if( !stream )
       return NULL;
    if( accessPriv->magicNb != FD_STREAM_ACCESS_MAGIC_NB )
       return NULL;

    return FD_StreamAccessAlloc( (FD_Stream *)accessPriv->currentBlock );
}

/* Bypass the number of specified byte. */
FD_RetCode FD_StreamAccessBypass( FD_StreamAccess *access, unsigned int nbByteToBypass )
{
    unsigned int i;
    unsigned char dummy;
    FD_RetCode retCode;

    /* This function could be definitely re-written for speed optimization! */
    for( i=0; i < nbByteToBypass; i++ )
    {
        retCode = FD_StreamAccessGetByte(access, &dummy );
        if( retCode != FD_SUCCESS )
           return retCode;
    }

    return FD_SUCCESS;
}

FD_RetCode FD_StreamAccessGetBit( FD_StreamAccess *access, unsigned int nbBit, unsigned int *data )
{
    FD_StreamAccessPriv *accessPriv;
    unsigned int returnData = 0;
    unsigned int i;
    int bit;
  
    /* Note: This function could/should be easily speed optimized. */

    accessPriv = (FD_StreamAccessPriv *)access;

    /* Read only a maximum of 32 bits. */    
    if( nbBit > 32 )
       return FD_BAD_PARAM;

    if( accessPriv->endOfStream )
       return FD_END_OF_STREAM;

    /* The first bit read will be the MSB. */
    for( i=0; i < nbBit; i++ )
    {
        /* Read the bit. */
        bit = accessPriv->currentBlock->data[accessPriv->readPos] & accessPriv->readMask;
        returnData <<= 1;
        if( bit )
            returnData |= 1;

        accessPriv->nbBitRead++;

        /* Move to the next bit. */
        accessPriv->readMask >>= 1;

        /* Verify if a new byte is needed. */
        if( accessPriv->readMask == 0x00 )
        {
            accessPriv->readMask = 0x80;
            accessPriv->readPos++;
        }

        /* Verify if a new block is needed. */
        if( accessPriv->nbBitRead == accessPriv->currentBlock->nbBitWritten )
        {
            /* No more bit available in the current block.
             *
             * Move to the next block. Set endOfStream if no
             * other block available.
             */
            if( !accessMoveToNextBlock( accessPriv ) )
            {
                *data = returnData;
                accessPriv->endOfStream = 1;
                return FD_SUCCESS;
            }
        }
    }

    *data = returnData;

    return FD_SUCCESS;
}

FD_RetCode FD_StreamAccessGetByte( FD_StreamAccess *access, unsigned char *data )
{
    FD_RetCode retValue;
    unsigned int tmp;

    retValue = FD_StreamAccessGetBit( access, 8, &tmp );
    *data = (unsigned char)tmp;

    return retValue;
}

FD_RetCode FD_StreamAccessGetBuffer( FD_StreamAccess *streamAccess,
                                     const char   **theBuffer,
                                     unsigned int *theBufferSize )
{
    FD_StreamAccessPriv *accessPriv;
     
    accessPriv = (FD_StreamAccessPriv *)streamAccess;

    if( accessPriv->endOfStream )
       return FD_END_OF_STREAM;

    if( !theBuffer || !theBufferSize )
       return FD_BAD_PARAM;

    /* Return the current buffer. */
    *theBuffer = (const char *)&accessPriv->currentBlock->data[0];
    *theBufferSize = accessPriv->currentBlock->nbBitWritten>>3;

    /* Move to the next buffer. */
    if( !accessMoveToNextBlock( accessPriv ) )
       accessPriv->endOfStream = 1;

    return FD_SUCCESS;
}

/* Only the lowest 16 bits are significative. */
FD_RetCode FD_StreamAccessGetInt16( FD_StreamAccess *access, unsigned int *data )
{
    return FD_StreamAccessGetBit( access, 16, data );
}

FD_RetCode FD_StreamAccessGetInt32( FD_StreamAccess *access, unsigned int *data )
{
    return FD_StreamAccessGetBit( access, 32, data );
}

FD_RetCode FD_StreamAccessGetDouble( FD_StreamAccess *access, double *data )
{
    FD_RetCode retCode;
    unsigned int i;

    typedef union
    {
       double d;
       unsigned char b[8];
    } OUTDATA;

    OUTDATA outdata;

    outdata.d = 0; /* To get ride of warning. */

    if( !data )
       return FD_BAD_PARAM;

    for( i=0; i < sizeof(double); i++ )
    {
       retCode = FD_StreamAccessGetByte( access, &outdata.b[i] );
       if( retCode != FD_SUCCESS )
          return retCode;
    }

    *data = outdata.d;

    return FD_SUCCESS;
}

FD_RetCode FD_StreamAccessGetTimestamp( FD_StreamAccess *access,
                                        FD_Timestamp *data )
{
   FD_RetCode retCode;

   retCode = FD_StreamAccessGetInt32( access, (unsigned int *)&data->date );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAccessGetInt32( access, (unsigned int *)&data->time );
   if( retCode != FD_SUCCESS )
      return retCode;
 
   return FD_SUCCESS;
}

FD_RetCode FD_StreamAccessGetString( FD_StreamAccess *access, FD_String **string )
{
   char length;
   FD_RetCode retCode;
   unsigned char buffer[256];
   FD_String *stringPtr;
   int i;
   FD_StringCache *stringCache;
   FD_StreamAccessPriv *accessPriv;

   if( !string || !access )
      return FD_BAD_PARAM;

   accessPriv = (FD_StreamAccessPriv *)access;

   if( accessPriv->magicNb != FD_STREAM_ACCESS_MAGIC_NB )
      return FD_BAD_OBJECT;

   *string = NULL;

   retCode = FD_StreamAccessGetByte( access, (unsigned char *)&length );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Could be speed optimized, but let's keep it simple for the time being. */
   for( i=0; i < length; i++ )
   {
      retCode = FD_StreamAccessGetByte( access, &buffer[i] );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   stringCache = FD_GetGlobalStringCache();
       
   stringPtr = FD_StringAllocN( stringCache, (const char *)&buffer[0], length );
   if( !stringPtr )
      return FD_ALLOC_ERR;

   /* Success. Return the string to the caller. */
   *string = stringPtr;

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAccessSearch( FD_StreamAccess *source, const char *stringToFind )
{
   FD_RetCode retCode;
   FD_StreamAccessPriv movingPosition;
   unsigned int foundInString, stringLength;
   unsigned char data;

   /* The whole function could be speed optimized. Easily! */
   stringLength = strlen(stringToFind);
   if( stringLength == 0 )
      return FD_SUCCESS; /* Nothing to do. */

   /* Use a copy of the iterator for searching. */
   accessPrivCopy( (FD_StreamAccessPriv *)source, &movingPosition );

   foundInString = 0;
   while( foundInString != stringLength )
   {
      retCode = FD_StreamAccessGetByte( (FD_StreamAccess *)&movingPosition, &data );
      if( retCode != FD_SUCCESS )
         return retCode;
      if( toupper(stringToFind[foundInString]) == toupper(data) )
      {
         foundInString++;
      }         
      else
         foundInString = 0;         
   }
   
   /* On success, move the caller provided iterator
    * after the string.
    */
   accessPrivCopy( &movingPosition, (FD_StreamAccessPriv *)source );
  
   return FD_SUCCESS; 
}

FD_RetCode FD_StreamAccessGetHTMLTable( FD_StreamAccess *access,
                                        unsigned int maxElementSize,
                                        FD_HTMLTableFuncPtr funcPtr,
                                        void *opaqueData )
{
   FD_RetCode retCode;
   char *buffer;
   char *hrefBuffer;

   buffer = FD_Malloc( maxElementSize+1 );
   if( !buffer )
      return FD_ALLOC_ERR;

   hrefBuffer = FD_Malloc( maxElementSize+1 );
   if( !hrefBuffer )
   {
      FD_Free(  buffer );
      return FD_ALLOC_ERR;
   }

   buffer[maxElementSize] = '\0';
   hrefBuffer[maxElementSize] = '\0';

   retCode = streamGetHTMLTable( access, maxElementSize, buffer, hrefBuffer, funcPtr, opaqueData );

   FD_Free( buffer );
   FD_Free( hrefBuffer );

   return retCode;
}

/* Skip the next HTML Table.
 * (the access will point after the </table> tag)
 */
FD_RetCode FD_StreamAccessSkipHTMLTable( FD_StreamAccess *access )
{
   return FD_StreamAccessSearch( access, "</table>" );
}

unsigned int FD_StreamSizeInBit( const FD_Stream *stream )
{
    unsigned int totalSize = 0;
    FD_StreamPriv *streamPriv;

    streamPriv = (FD_StreamPriv *)stream;

    /* Add the size (in bits) found in all blocks of that stream. */
    while( streamPriv )
    {
       if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
          return 0;

       totalSize += streamPriv->nbBitWritten;
       streamPriv = streamPriv->next;
    }

    return totalSize;
}

unsigned int FD_StreamSizeInByte( const FD_Stream *stream )
{
    unsigned int tmp;
    unsigned int nbByte = 0;

    tmp = FD_StreamSizeInBit( stream );

    nbByte = tmp/8;
    if( tmp%8 )
       nbByte += 1;

    return nbByte;
}

FD_RetCode FD_StreamAppendCopy( FD_Stream *dst, const FD_Stream *src )
{
    FD_PROLOG
    FD_RetCode retCode;
    FD_StreamPriv *tmpStreamPriv;
    FD_StreamPriv *dstStreamPriv;
    FD_StreamPriv *srcStreamPriv;

    unsigned int nbByteToCopy;

    if( !dst || !src )
       return FD_BAD_PARAM;

    dstStreamPriv = (FD_StreamPriv *)dst;
    srcStreamPriv = (FD_StreamPriv *)src;

    if( (dstStreamPriv->magicNb != FD_STREAM_MAGIC_NB) ||
        (srcStreamPriv->magicNb != FD_STREAM_MAGIC_NB) )
       return FD_BAD_OBJECT;

    FD_TRACE_BEGIN( FD_StreamAppendCopy );
     
    /* The append is certainly not very efficient.
     * This function could easily be optimized in both speed
     * and memory efficiency by using a different algorithm.
     */

    /* Copy/Append block per block. */
    while( srcStreamPriv )
    {
        /* Make a copy of the 'src' block into a FD_Stream. */
        FD_ASSERT( srcStreamPriv->nbByteToSkip <= srcStreamPriv->allocSize );

        /* Do not bother to copy if there is no data in this block. */
        if( srcStreamPriv->nbBitWritten != 0 )
        {
           /* Could be more memory efficient by allocating only
            * the required bytes.
            */
           nbByteToCopy = srcStreamPriv->allocSize-srcStreamPriv->nbByteToSkip;

           tmpStreamPriv = streamAllocSize( nbByteToCopy );
           if( !tmpStreamPriv )
           {
              FD_TRACE_RETURN( FD_ALLOC_ERR );
           }

           memcpy( tmpStreamPriv->data, srcStreamPriv->data, nbByteToCopy );
  
           tmpStreamPriv->nbBitWritten = srcStreamPriv->nbBitWritten;
           tmpStreamPriv->allocSize    = nbByteToCopy;
           tmpStreamPriv->writePos     = srcStreamPriv->writePos;
           tmpStreamPriv->writeMask    = srcStreamPriv->writeMask;
           tmpStreamPriv->nbByteToSkip = 0;
           
           retCode = FD_StreamMerge( dst, (FD_Stream *)tmpStreamPriv );
           if( retCode != FD_SUCCESS )
           {
              FD_TRACE_RETURN( retCode );
           }
        }

        srcStreamPriv = srcStreamPriv->next;
    }

    FD_TRACE_RETURN( FD_SUCCESS );
}

unsigned int FD_StreamCountChar( const FD_Stream *stream, char toCount )
{
   FD_StreamAccess *streamAccess;
   FD_RetCode retCode;
   const char *theBuffer;
   unsigned int theBufferSize, total, i;

   /* !!! Could be speed optimized by avoiding a memory
    *     allocation here.
    */
   streamAccess = FD_StreamAccessAlloc( stream );

   if( !streamAccess )
      return 0;

   total = 0;

   do
   {   
      theBufferSize = 0;
      retCode = FD_StreamAccessGetBuffer( streamAccess,
                                          &theBuffer,
                                          &theBufferSize );
      if(retCode == FD_SUCCESS )
      {
         for( i=0; i < theBufferSize; i++ )
         {
            if( theBuffer[i] == toCount )
               total++;
         }
      }
   } while( retCode == FD_SUCCESS );

   FD_StreamAccessFree( streamAccess );

   return total;
}

FD_RetCode FD_StreamMerge( FD_Stream *firstStream, FD_Stream *secondStream )
{
    FD_StreamPriv *firstStreamPriv, *secondStreamPriv;

    if( !firstStream || !secondStream )
       return FD_SUCCESS;

    firstStreamPriv = (FD_StreamPriv *)firstStream;
    secondStreamPriv = (FD_StreamPriv *)secondStream;

    if( secondStreamPriv->nbBitWritten == 0 )
        FD_StreamFree( secondStream ); /* Free secondStream block and data. */
    else if( firstStreamPriv->nbBitWritten == 0 )
    {
        freeData( firstStreamPriv );
        *firstStreamPriv = *secondStreamPriv;

        /* No next block? Make sure we point to ourselve as the lastBlock. */
        if( !secondStreamPriv->next )
           firstStreamPriv->lastBlock = firstStreamPriv;

        FD_Free( secondStreamPriv ); /* Free only the block, not the data! */
    }
    else
    {
        /* Just append the second stream. */
        firstStreamPriv->lastBlock->next = secondStreamPriv;
        firstStreamPriv->lastBlock       = secondStreamPriv->lastBlock;
    }

    return FD_SUCCESS;
}

FD_RetCode FD_StreamCompress( FD_Stream *stream, const FD_Stream *streamToCompress )
{
    FD_PROLOG
    FD_RetCode retCode;
    FD_StreamPriv *bzipOutputStreamPriv;

    FD_StreamPriv *mostEfficientStreamPriv;
    FD_StreamType  mostEfficientType;
    unsigned int   mostEfficientSize;

    unsigned int nbBitWritten, nbBitAdded;

    FD_StreamPriv *streamToCompressPriv;
    FD_StreamPriv *streamPriv;

    if( !stream || !streamToCompress )
       return FD_BAD_PARAM;

    streamToCompressPriv = (FD_StreamPriv *)streamToCompress;
    streamPriv = (FD_StreamPriv *)stream;

    if( (streamToCompressPriv->magicNb != FD_STREAM_MAGIC_NB) ||
        (streamPriv->magicNb != FD_STREAM_MAGIC_NB) )
       return FD_BAD_OBJECT;

    FD_TRACE_BEGIN( FD_StreamCompress );

    /* Set variables used to keep track of the most efficient
     * compression algorithm.
     * Start by assuming the uncompress stream is the most
     * efficient.
     */
    mostEfficientType       = FD_STREAM_NO_COMPRESSION;
    mostEfficientSize       = FD_StreamSizeInBit( streamToCompress );
    mostEfficientStreamPriv = NULL;

    /* Perform BZIP2 compression. */
    retCode = streamCompressBZIP2( streamToCompressPriv, &bzipOutputStreamPriv );
    if( retCode != FD_SUCCESS )
    {
       FD_TRACE_RETURN( retCode );
    }

    /* Verify if BZIP is more efficient. */
    if( bzipOutputStreamPriv )
    {
        nbBitWritten = FD_StreamSizeInBit( (FD_Stream *)bzipOutputStreamPriv );
        if( nbBitWritten < mostEfficientSize )
        {
           mostEfficientType       = FD_STREAM_BZIP2;
           mostEfficientStreamPriv = bzipOutputStreamPriv;
           mostEfficientSize       = nbBitWritten;
        }
        else
            FD_StreamFree( (FD_Stream *)bzipOutputStreamPriv );
    }

    /* Write the compression type to the output stream. */
    retCode = FD_StreamAddBit( stream, mostEfficientType & 0x02 );
    if( retCode != FD_SUCCESS )
    {
       if( mostEfficientStreamPriv )
          FD_StreamFree( (FD_Stream *)mostEfficientStreamPriv );
       return retCode;
    }

    retCode = FD_StreamAddBit( stream, mostEfficientType & 0x01 );
    if( retCode != FD_SUCCESS )
    {
       if( mostEfficientStreamPriv )
          FD_StreamFree( (FD_Stream *)mostEfficientStreamPriv );
       return retCode;
    }

    /* Change the size to a 'byte' size if the data has been compressed
     * into another stream. This is because it is assumed the result of the
     * compression is ALWAYS on a byte boundary.
     */
    if( mostEfficientStreamPriv )
       mostEfficientSize = FD_StreamSizeInByte( (FD_Stream *)mostEfficientStreamPriv );

    /* Write the stream size (first bit indicates if the size is coded on
     * 16 or 32 bits).
     */
    if( mostEfficientSize < 65536 )
    {
        FD_StreamAddBit( stream, 0 ); /* 16 bit size */
        FD_StreamAddInt16( stream, (unsigned short)mostEfficientSize );
    }
    else
    {
        FD_StreamAddBit( stream, 1 ); /* 32 bit size */
        FD_StreamAddInt32( stream, mostEfficientSize );
    }

    /* Force the output stream on a byte boundary. */
    retCode = streamJumpToNextByteBoundary( (FD_StreamPriv *)stream, &nbBitAdded );
    if( retCode != FD_SUCCESS )
    {
       if( mostEfficientStreamPriv )
          FD_StreamFree( (FD_Stream *)mostEfficientStreamPriv );
       return retCode;
    }

    /* Add the compressed information to the output. */
    if( mostEfficientStreamPriv )
    {
        /* Merge with the compressed stream. */
        retCode = FD_StreamMerge( stream, (FD_Stream *)mostEfficientStreamPriv );
        if( retCode != FD_SUCCESS )
        {
           FD_StreamFree( (FD_Stream *)mostEfficientStreamPriv );
           return retCode;
        }
    }
    else
    {
        /* Copy the un-compress stream as-is. */
        retCode = FD_StreamAppendCopy( stream, streamToCompress );
        if( retCode != FD_SUCCESS )
           return retCode;
    }

    /* End-up the stream on a byte boundary. */
    streamJumpToNextByteBoundary( (FD_StreamPriv *)stream, &nbBitAdded );

    FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_StreamDecompress( FD_StreamAccess *streamToDecompress,
                                FD_Stream **newAllocatedStream )
{
    FD_RetCode retCode;
    unsigned int  data;
    unsigned int  size, nbBit, nbByte;
    unsigned int i;
    FD_StreamType type;

    FD_StreamPriv *streamPriv;
    FD_Stream *stream;

    FD_StreamAccessPriv *accessPriv;

    if( !newAllocatedStream || !streamToDecompress )
       return FD_BAD_PARAM;

    *newAllocatedStream = NULL;

    accessPriv = (FD_StreamAccessPriv *)streamToDecompress;

    if( accessPriv->magicNb != FD_STREAM_ACCESS_MAGIC_NB )
       return FD_BAD_OBJECT;

    /* This function needs some re-work for being speed optimized as much
     * as possible.
     */

    /* Get the type. */
    retCode = FD_StreamAccessGetBit( streamToDecompress, 2, (unsigned int *)&type );
    if( retCode != FD_SUCCESS )
       return retCode;

    /* Get the size of the uncompress data. */
    retCode = FD_StreamAccessGetBit( streamToDecompress, 1, (unsigned int *)&data );
    if( retCode != FD_SUCCESS )
       return retCode;

    if( data == 0 )
    {
        retCode = FD_StreamAccessGetInt16( streamToDecompress, &size );
        if( retCode != FD_SUCCESS )
           return retCode;
    }
    else
    {
        retCode = FD_StreamAccessGetInt32( streamToDecompress, &size );
        if( retCode != FD_SUCCESS )
           return retCode;
    }

    if( size == 0 )
       return FD_BAD_PARAM;

    /* Translate the size in bit / byte. */
    switch( type )
    {
    case FD_STREAM_NO_COMPRESSION:
       nbBit = size;
       nbByte = nbBit/8;
       if( nbBit%8 )
          nbByte += 1;
       break;
    case FD_STREAM_BZIP2:
       nbByte = size;
       nbBit  = size << 3;
       break;
    default: /* Unrecognized compression. */
       return FD_BAD_PARAM;
    }

    /* Following the header, the data to decompress is assumed to be on
     * a byte boundary.
     */
    accessJumpToNextByteBoundary( (FD_StreamAccessPriv *)streamToDecompress );

    /* Allocate the target stream. */
    streamPriv = streamAllocSize( nbByte );
    if( !streamPriv )
       return FD_ALLOC_ERR;
    stream = (FD_Stream *)streamPriv;

    switch( type )
    {
    case FD_STREAM_NO_COMPRESSION:
        /* Make a bit per bit copy for the time being.
         * Could be easily speed optimized.
         */
        for( i=0;  i < nbBit; i++ )
        {
            retCode = FD_StreamAccessGetBit( streamToDecompress, 1, &data );
            if( retCode != FD_SUCCESS )
            {
               FD_StreamFree( stream );
               return retCode;
            }
            retCode = FD_StreamAddBit( stream, data );
            if( retCode != FD_SUCCESS )
            {
               FD_StreamFree( stream );
               return retCode;
            }
        }
        break;
    case FD_STREAM_BZIP2:
        retCode = streamDecompressBZIP2( streamPriv, accessPriv );
        if( retCode != FD_SUCCESS )
        {
           FD_StreamFree( stream );
           return retCode;
        }
        break;
    default:
        FD_StreamFree( stream );
        return FD_INTERNAL_ERROR(7);
    }

    /* Eat-up bits that could have been added at the end to keep things
     * on a byte boundary.
     */
    accessJumpToNextByteBoundary( (FD_StreamAccessPriv *)streamToDecompress );

    /* Success! Return the uncompress stream to the caller. */
    *newAllocatedStream = stream;

    return FD_SUCCESS;
}


/* Return a CRC-32 of the data in the stream. */
FD_RetCode FD_StreamCRC_32( FD_Stream *stream, unsigned int *crc32 )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_StreamPriv *streamPriv;
   qbyte runningData, temp;
   FD_StreamAccess *access;
   unsigned char data, lastData;

   temp = 0; /* To get ride of warning. */

   if( !stream || !crc32 )
      return FD_BAD_PARAM;

   streamPriv = (FD_StreamPriv *)stream;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
      return FD_BAD_OBJECT;

   FD_TRACE_BEGIN(  FD_StreamCRC_32 );

   runningData = 0xFFFFFFFFL;

   access = FD_StreamAccessAlloc( stream );
   if( !access )
      return FD_SUCCESS;

   retCode = FD_StreamAccessGetByte( access, &data );
   while( retCode == FD_SUCCESS )
   {
      temp = calculate_running_crc( &runningData, &data, 1 );
      lastData = data;
      retCode = FD_StreamAccessGetByte( access, &data );
   } 

   FD_StreamAccessFree( access );

   if( retCode != FD_END_OF_STREAM  )
      return retCode;

   *crc32 = temp;
      
   FD_TRACE_RETURN( FD_SUCCESS );

   #if 0
   Possible speed optimization!?!?
   do
   {    
      if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
      {
          FD_TRACE_RETURN( FD_INTERNAL_ERROR(8) );
      }

      /* How many bytes in this block? */
      nbByteToInclude = streamPriv->allocSize-streamPriv->nbByteToSkip;
      nbByteWritten = streamPriv->nbBitWritten/8;
      if( (streamPriv->nbBitWritten)%8 )
         nbByteWritten += 1;
      nbByteToInclude = min(nbByteWritten, nbByteToInclude);

      /* Calculate the CRC for this block. */
      if( nbByteToInclude > 0 )
         temp = calculate_running_crc( &runningData, streamPriv->data, nbByteToInclude );

      /* Next block. */
      streamPriv = streamPriv->next;
   } while( streamPriv );
   #endif
}


FD_RetCode FD_StreamDecapsulate( FD_Stream *stream,
                                 FD_Timestamp *userTimestamp,
                                 FD_Integer   *userIdentifier )
{
   FD_RetCode retCode;
   FD_StreamAccess *access;   
   unsigned char data;
   unsigned int i, streamSize, streamSizeInByte;
   qbyte crc32Temp, crc32Header, crc32Content;

   if( !stream || !userTimestamp || !userIdentifier )
      return FD_BAD_PARAM;

   access = FD_StreamAccessAlloc( stream );
   if( !access )
      return FD_ALLOC_ERR;

   /* Only encoding V0.1 is currently supported. */
   retCode = FD_StreamAccessGetByte( access, &data );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( access );
      return retCode;
   }
   if( data != 0x01 )
   {
      FD_StreamAccessFree( access );
      return FD_UNSUPPORTED_STREAM_VERSION;
   }  

   /* Skip the unused bytes. */
   for( i=0; i < 3; i++ )
   {
      retCode = FD_StreamAccessGetByte( access, &data );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamAccessFree( access );
         return retCode;
      }
   }

   /* Get the user timestamp. */
   retCode = FD_StreamAccessGetTimestamp( access, userTimestamp );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( access );
      return retCode;
   }

   /* Get the user identifier. */
   retCode = FD_StreamAccessGetInt32( access, (unsigned int *)userIdentifier );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( access );
      return retCode;
   }

   /* Get the size of the content. */
   retCode = FD_StreamAccessGetInt32( access, &streamSize );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( access );
      return retCode;
   }
   streamSizeInByte = streamSize / 8;
   if( streamSize % 8 )
      streamSizeInByte++;

   /* Get content CRC-32 */
   retCode = FD_StreamAccessGetInt32( access, (unsigned int *)&crc32Content );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( access );
      return retCode;
   }
   
   /* Get header CRC-32 */
   retCode = FD_StreamAccessGetInt32( access, (unsigned int *)&crc32Header );
   FD_StreamAccessFree( access );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Calculate and verify the CRC of the header. */
   retCode = calcCRC( stream, 0, 23, (unsigned int *)&crc32Temp );
   if( retCode != FD_SUCCESS )
      return FD_BAD_STREAM_HEADER;

   if( crc32Temp != crc32Header )
      return FD_BAD_STREAM_HEADER_CRC;

   /* Calculate and verify the CRC of the content. */   
   retCode = calcCRC( stream, 28, 27+streamSizeInByte, (unsigned int *)&crc32Temp );
   if( retCode != FD_SUCCESS )
      return FD_BAD_STREAM_CONTENT;

   if( crc32Temp != crc32Content )
      return FD_BAD_STREAM_CRC;

   /* Mark the header for being skip from now on by all other
    * FD_StreamAccessXXXXX() functions.
    */
   retCode = markByteForSkip( stream, 28 );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAdjustToBoundary( FD_Stream *stream )
{
   unsigned int nbBitAdded;

   if( !stream )
      return FD_BAD_PARAM;

   return streamJumpToNextByteBoundary( (FD_StreamPriv *)stream, &nbBitAdded );
}

FD_RetCode FD_StreamEncapsulate( FD_Stream    **ptrToStream,
                                 FD_Timestamp  *userTimestamp,
                                 FD_Integer     userIdentifier )
{
   FD_RetCode retCode;
   FD_StreamPriv *streamPriv;
   unsigned int i, totalSize, nbBitAdded;
   FD_Stream *header;
   FD_Stream *stream;
   qbyte crc32;

   if( !ptrToStream || !userTimestamp )
      return FD_BAD_PARAM;

   stream = *ptrToStream;
   streamPriv = (FD_StreamPriv *)stream;

   if( !streamPriv )
      return FD_BAD_PARAM;

   if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
      return FD_BAD_OBJECT;

   /* Stream is completed to a byte boundary. */
   retCode = streamJumpToNextByteBoundary( (FD_StreamPriv *)stream, &nbBitAdded );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* An header will be prefixed to the original FD_Stream:
    *     8 bits headerVersion (Version of this mechanism)
    *     8 bits nb bit appended to bring on byte boundary.
    *    16 bits RESERVED (unused for the time being)
    *    64 bits optional FD_Timestamp
    *    32 bits optional user data
    *    32 bits streamSize    (Size of the original stream in bit)
    *    32 bits streamCRC32   (CRC-32 of the original stream)
    *    32 bits headerCRC32   (CRC-32 of the header)
    */
   header = (FD_Stream *)streamAllocSize( sizeof( qbyte ) * 4 );
   if( !header )
      return FD_ALLOC_ERR;

   /* Add the version of the header encoding (V0.01) */
   retCode = FD_StreamAddByte( header, 0x01 );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Indicate the number of bits appended to bring the stream on a byte boundary. */
   retCode = FD_StreamAddByte( header, (unsigned char)nbBitAdded );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Add 16 unused bits to keep things on a 32 bit boundary. */
   for( i=0; i < 2; i++ )
   {
      retCode = FD_StreamAddByte( header, 0xCC );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamFree( header );
         return retCode;
      }
   }

   /* Add the user timestamp. */
   retCode = FD_StreamAddTimestamp( header, userTimestamp );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Add the user identifier. */
   retCode = FD_StreamAddInt32( header, userIdentifier );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Add the size of the content in bits. */
   totalSize = FD_StreamSizeInBit( stream );
   if( totalSize == 0 )
   {
      FD_StreamFree( header );
      return FD_BAD_PARAM;
   }
   retCode = FD_StreamAddInt32( header, totalSize );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Add the CRC-32 of the content. */
   retCode = FD_StreamCRC_32( stream, (unsigned int *)&crc32 );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }
   retCode = FD_StreamAddInt32( header, crc32 );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Add the CRC-32 of the header at the end of the header. */
   retCode = FD_StreamCRC_32( header, (unsigned int *)&crc32 );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }
   retCode = FD_StreamAddInt32( header, crc32 );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }
   
   /* Merge the header to the content.  */
   retCode = FD_StreamMerge( header, stream );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( header );
      return retCode;
   }

   /* Everything succeed, the 'header' is the new stream */
   *ptrToStream = header; 
   return FD_SUCCESS;   
}

FD_RetCode FD_StreamToFile( FD_Stream *stream, FILE *out )
{
   FD_RetCode retCode;
   FD_StreamAccess *access;
   unsigned char data;

   access = FD_StreamAccessAlloc( stream );

   if( !access )
      return FD_ALLOC_ERR;

   retCode = FD_StreamAccessGetByte( access, &data );
   while( retCode == FD_SUCCESS )
   {
      fwrite(&data, 1, 1, out );
      retCode = FD_StreamAccessGetByte( access, &data );
   }

   FD_StreamAccessFree( access );

   return FD_SUCCESS;
}

FD_RetCode FD_StreamAddFile( FD_Stream *stream, FILE *in )
{
   FD_RetCode retCode;
   unsigned char data;
   unsigned int again; /* Boolean */

   /* !!! Could be speed optimized... shall we consider
    * a version using FD_FileSeq instead?
    */
   again = 1;
   do
   {
      if( !fread( &data, 1, 1, in ) )
         again = 0;
      else
      {
         retCode = FD_StreamAddByte( stream, data );
         if( retCode != FD_SUCCESS )
            return retCode;
      }
   } while( again && !feof(in) );

   return FD_SUCCESS;
}

#ifdef FD_DEBUG
FD_RetCode FD_StreamPrint( FD_Stream *stream )
{
   FD_StreamPriv *streamPriv;
   FD_StreamAccess *access;
   FD_RetCode retCode;
   FILE *out;

   unsigned char byte0,byte1,byte2,byte3,data;
   unsigned int firstIteration;

   streamPriv = (FD_StreamPriv *)stream;

   if( !stream )
      return FD_BAD_PARAM;

   out = FD_GetStdioFilePtr();

   access = FD_StreamAccessAlloc(stream);
   if( !access )
   {
      fprintf( out, "Printing stream failed: Mem alloc problem\n" );
      return FD_ALLOC_ERR;
   }

   byte0 = byte1 = byte2 = byte3 = 0xCD;

   retCode = FD_StreamAccessGetByte( access, &byte0 );
   firstIteration = 1;
   while( retCode == FD_SUCCESS )
   {      
      retCode = FD_StreamAccessGetByte( access, &data );

      if( retCode == FD_SUCCESS )
      {
         byte2 = byte3;
         byte3 = data;
      }

      if( firstIteration )
      {
         byte1 = data;
         firstIteration = 0;
      }
   }

   fprintf( out, "Stream %08lX:[%02X,%02X..%02X,%02X] NBit:%d NByte:%d Pos:%d,%02X\n",
                 (unsigned long)stream,
                 byte0, byte1, byte2, byte3,
                 FD_StreamSizeInBit ( stream ),
                 FD_StreamSizeInByte( stream ),
                 streamPriv->writePos, streamPriv->writeMask );
       
   retCode = FD_StreamAccessFree( access );

   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}
#endif

/**** Local functions definitions.     ****/
static int accessMoveToNextBlock( FD_StreamAccessPriv *accessPriv )
{
    FD_StreamPriv *nextBlock;
    int again;
    int retValue;

    retValue = 0;
    again = 1;
    while( again )
    {
       nextBlock = accessPriv->currentBlock->next;
       if( !nextBlock )
       {
          /* No next block available. Then make sure
           * the stream access point to the end of the current block,
           * and return an error.
           * From that point, that stream access should never work again.
           */
          accessPriv->nbBitRead = accessPriv->currentBlock->nbBitWritten;
          retValue = 0;
          again = 0;
       }
       else
       {
          accessPriv->currentBlock = nextBlock;
          if( nextBlock->nbBitWritten != 0 )
          {
             accessPriv->readPos      = 0;
             accessPriv->readMask     = 0x80;
             accessPriv->nbBitRead    = 0;

             retValue = 1;
             again = 0;
          }
       }
    }

    return retValue;
}

static FD_RetCode streamJumpToNextByteBoundary( FD_StreamPriv *stream, unsigned int *nbBitAdded )
{
   FD_RetCode retCode;
   int nbBitAdd;

   nbBitAdd = 0;

   while( (stream->lastBlock->writeMask) &&
          (stream->lastBlock->writeMask != 0x80))
   {
       retCode = FD_StreamAddBit( (FD_Stream *)stream, 0 );
       if( retCode != FD_SUCCESS )
          return retCode;

       nbBitAdd++;
   }

   *nbBitAdded = nbBitAdd;

   return FD_SUCCESS;
}

static FD_RetCode accessJumpToNextByteBoundary( FD_StreamAccessPriv *streamAcc )
{
    FD_RetCode retCode;
    unsigned int data;

    while( (streamAcc->readMask != 0x00) && (streamAcc->readMask != 0x80) )
    {
        retCode = FD_StreamAccessGetBit( (FD_StreamAccess *)streamAcc, 1, &data );
        if( retCode != FD_SUCCESS )
           return retCode;
    }

    return FD_SUCCESS;
}

static FD_StreamPriv *streamAllocSize( unsigned int nbByte )
{
   FD_RetCode retCode;
   FD_StreamPriv *streamPriv;
   unsigned char *data;

   streamPriv = (FD_StreamPriv *)FD_Malloc( sizeof( FD_StreamPriv ) );
   if( !streamPriv )
      return (FD_StreamPriv *)NULL;

   data = (unsigned char *)FD_Malloc( nbByte );
   if( !data )
   {
      FD_Free(  streamPriv );
      return (FD_StreamPriv *)NULL;
   }

   retCode = streamPrivInit( streamPriv, data, nbByte, NULL, NULL );
   if( retCode != FD_SUCCESS )
   {
      FD_Free(  streamPriv );
      return (FD_StreamPriv *)NULL;
   }

   return streamPriv;
}

static FD_RetCode streamPrivInit( FD_StreamPriv *streamPriv,
                                  unsigned char *data,
                                  unsigned int size,
                                  FD_FreeFuncPtr freeFunc,
                                  void *opaqueData )
{
   /* Initialize all members of a FD_Stream. */

   /* Note: freeData and data will stay the same for most of the FD_Stream.
    *       'data' will differ from 'freeData' when a FD_Stream is "decapsulated"
    *       (with FD_StreamDecapsulate). At this moment, 'data' will point 
    *       after the encapsulation header.
    *       The end-user will not be aware that the header is still kept in the
    *       block...
    */
   streamPriv->data = data;
   streamPriv->freeData = data;

   /* Variables allowing to know how to free the data. */
   streamPriv->opaqueData = opaqueData;
   streamPriv->freeFunc = freeFunc; 

   /* Variables for keeping track on where the next bit is written. */
   streamPriv->data[0]      = 0;    /* Initialize first byte to zero.      */
   streamPriv->writePos     = 0;    /* Will write in the first byte.       */
   streamPriv->writeMask    = 0x80; /* Will write in the first bit (MSB).  */
   streamPriv->nbBitWritten = 0;    /* Nb of written bit.. zero of course. */

   streamPriv->allocSize = size; /* Nb of byte that can be written. */

   /* Will allow to link this block to others. */
   streamPriv->next      = NULL;
   streamPriv->lastBlock = streamPriv;

   /* Variable allowing to skip an header once a stream is decapsulated. */
   streamPriv->nbByteToSkip  = 0;

   /* Management variables... */
   streamPriv->magicNb   = FD_STREAM_MAGIC_NB;

   return FD_SUCCESS;
}

static FD_RetCode streamCompressBZIP2( const FD_StreamPriv *streamToCompress, FD_StreamPriv **retStream )
{
    FD_PROLOG
    bz_stream bzipStream;
    unsigned int returnCode, nbByteInThisBlock;
    unsigned int compressionCompleted;
    int action;

    const FD_StreamPriv *currentInputBlock;
    FD_Stream *outputStream;
    FD_StreamPriv *currentOutputBlock;

    FD_StreamPriv *streamToCompressPriv;

    #ifdef FD_DEBUG
       FILE *out;
    #endif

    if( !streamToCompress || !retStream )
       return FD_BAD_PARAM;

    *retStream = NULL;

    streamToCompressPriv = (FD_StreamPriv *)streamToCompress;

    if( streamToCompressPriv->magicNb != FD_STREAM_MAGIC_NB )
       return FD_BAD_OBJECT;

    FD_TRACE_BEGIN(  streamCompressBZIP2 );

    /* No particular alloc/free mechanism needed. The BZIP library
     * will directly used the standard malloc/free.
     */
    bzipStream.bzalloc = NULL;
    bzipStream.bzfree  = NULL;
    bzipStream.opaque  = NULL;

    /* Initialize the BZIP2 compression library. */
    returnCode = BZ2_bzCompressInit( &bzipStream, 5, 0, 0 );
    if( returnCode != BZ_OK )
    {
        FD_FATAL(  "BZIP2 cannot compress data", returnCode, 0 );
    }

    /* Now... compress block per block. */
    action = BZ_RUN;
    compressionCompleted = 0;

    /* Initialize output stream. */
    outputStream = FD_StreamAlloc();
    if( !outputStream )
    {
       FD_TRACE_RETURN( FD_ALLOC_ERR );
    }

    currentOutputBlock = (FD_StreamPriv *)outputStream;
    bzipStream.avail_out = currentOutputBlock->allocSize;
    bzipStream.next_out  = (char *)currentOutputBlock->data;

    /* Initialize input stream. */
    currentInputBlock = streamToCompress;
    bzipStream.next_in = (char *)currentInputBlock->data;
    nbByteInThisBlock = currentInputBlock->nbBitWritten>>3; /* Divid by 8. */
    if( currentInputBlock->nbBitWritten & 0x07 )
       nbByteInThisBlock++;
    bzipStream.avail_in = nbByteInThisBlock;

    do
    {
        /* Is new input data needed? */
        if( (action == BZ_RUN) && (bzipStream.avail_in == 0) )
        {
            /* Get the next block. */
            if( currentInputBlock->next )
            {
                currentInputBlock = currentInputBlock->next;
                bzipStream.next_in = (char *)currentInputBlock->data;
                nbByteInThisBlock = currentInputBlock->nbBitWritten>>3; /* Divid by 8. */
                if( currentInputBlock->nbBitWritten & 0x07 )
                    nbByteInThisBlock++;
                bzipStream.avail_in = nbByteInThisBlock;
            }
            else
            {
                /* no further data available. */
                action = BZ_FINISH;
            }
        }

        /* Is new output buffer needed? */
        if( bzipStream.avail_out == 0 )
        {
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamMerge( outputStream, (FD_Stream *)currentOutputBlock );
            currentOutputBlock = (FD_StreamPriv *)FD_StreamAlloc();
            bzipStream.avail_out = currentOutputBlock->allocSize;
            bzipStream.next_out  = (char *)currentOutputBlock->data;
        }

        /* Call the BZIP2 library to proceed with compression. */
        returnCode = BZ2_bzCompress( &bzipStream, action );

        /* Always adjust the output block for reflecting the byte added
         * by the BZIP2 library.
         */
        currentOutputBlock->writePos  = currentOutputBlock->allocSize-bzipStream.avail_out;
        currentOutputBlock->writeMask = 0x00;
        currentOutputBlock->nbBitWritten = currentOutputBlock->writePos << 3;

        switch( returnCode )
        {
        case BZ_RUN_OK:
        case BZ_FINISH_OK:
            /* Everything is fine. Keep working... */
            break;
        case BZ_STREAM_END:
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamMerge( outputStream, (FD_Stream *)currentOutputBlock );
            compressionCompleted = 1;
            break;
        default:
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamFree( (FD_Stream *)currentOutputBlock );
            FD_StreamFree( outputStream );
            FD_FATAL(  "BZIP2 cannot compress data", returnCode, 0 );
        }
    } while( !compressionCompleted );

    #ifdef FD_DEBUG
    out = FD_GetStdioFilePtr();
    if( out )
       fprintf( out, "Compression completed: Before: %d  After: %d\n",
                bzipStream.total_in_lo32, bzipStream.total_out_lo32 );
    #endif

    /* Free all ressources used by the BZIP2 library. */
    returnCode = BZ2_bzCompressEnd( &bzipStream );
    if( returnCode != BZ_OK )
    {
        FD_StreamFree( outputStream );
        FD_FATAL(  "BZIP2 cannot release ressources", returnCode, 0 );
    }

    *retStream = (FD_StreamPriv *)outputStream;

    FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode streamDecompressBZIP2( FD_StreamPriv *stream, FD_StreamAccessPriv *streamToDecompress )
{
    FD_PROLOG
    FD_RetCode retCode;
    bz_stream bzipStream;
    unsigned int returnCode, nbByteInThisBlock;
    unsigned int decompressionCompleted;

    FD_Stream *outputStream;
    FD_StreamPriv *currentOutputBlock;
    const FD_StreamPriv *currentInputBlock;

    if( !stream || !streamToDecompress )
       return FD_BAD_PARAM;

    if( (stream->magicNb != FD_STREAM_MAGIC_NB) ||
        (streamToDecompress->magicNb != FD_STREAM_ACCESS_MAGIC_NB ) )
       return FD_BAD_OBJECT;

    FD_TRACE_BEGIN(  streamDecompressBZIP2 );
        
    /* No particular alloc/free mechanism needed. The BZIP library
     * will directly used the standard malloc/free.
     */
    bzipStream.bzalloc = NULL;
    bzipStream.bzfree  = NULL;
    bzipStream.opaque  = NULL;

    /* Initialize the BZIP2 compression library. */
    returnCode = BZ2_bzDecompressInit( &bzipStream, 0, 0 );
    if( returnCode != BZ_OK )
    {
        FD_FATAL(  "BZIP2 cannot decompress data", returnCode, 0 );
    }

    /* Now... decompress block per block. */
    decompressionCompleted = 0;

    /* Initialize output stream. */
    outputStream = FD_StreamAlloc();
    if( !outputStream )
    {
       FD_TRACE_RETURN( FD_ALLOC_ERR );
    }

    currentOutputBlock = (FD_StreamPriv *)outputStream;
    bzipStream.avail_out = currentOutputBlock->allocSize;
    bzipStream.next_out  = (char *)currentOutputBlock->data;

    /* Initialize input stream. */
    retCode = accessJumpToNextByteBoundary( streamToDecompress );
    if( retCode != FD_SUCCESS )
       return FD_BAD_PARAM;

    currentInputBlock = streamToDecompress->currentBlock;
    bzipStream.next_in = (char *)&currentInputBlock->data[streamToDecompress->readPos];
    nbByteInThisBlock  = currentInputBlock->nbBitWritten>>3; /* Divid by 8. */
    if( currentInputBlock->nbBitWritten & 0x07 )
       nbByteInThisBlock++;
    bzipStream.avail_in = nbByteInThisBlock-streamToDecompress->readPos;

    do
    {
        /* Is new input data needed? */
        if( bzipStream.avail_in == 0 )
        {
            /* Get the next block. */
            if( !accessMoveToNextBlock( streamToDecompress ) )
                FD_FATAL(  "Decompression failed. No input byte left", 0, 0 );

            currentInputBlock = streamToDecompress->currentBlock;
            bzipStream.next_in = (char *)&currentInputBlock->data[0];
            nbByteInThisBlock  = currentInputBlock->nbBitWritten>>3; /* Divid by 8. */
            if( currentInputBlock->nbBitWritten & 0x07 )
                nbByteInThisBlock++;
            bzipStream.avail_in = nbByteInThisBlock;
        }

        /* Is new output buffer needed? */
        if( bzipStream.avail_out == 0 )
        {
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamMerge( outputStream, (FD_Stream *)currentOutputBlock );
            currentOutputBlock = (FD_StreamPriv *)FD_StreamAlloc();
            bzipStream.avail_out = currentOutputBlock->allocSize;
            bzipStream.next_out  = (char *)currentOutputBlock->data;
        }

        /* Call the BZIP2 library to proceed with compression. */
        returnCode = BZ2_bzDecompress( &bzipStream );

        /* Always adjust the output block for reflecting the byte added
         * by the BZIP2 library.
         */
        currentOutputBlock->writePos  = currentOutputBlock->allocSize-bzipStream.avail_out;
        currentOutputBlock->writeMask = 0x00;
        currentOutputBlock->nbBitWritten = currentOutputBlock->writePos << 3;

        switch( returnCode )
        {
        case BZ_OK:
            /* Everything is fine. Keep working... */
            break;
        case BZ_STREAM_END:
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamMerge( outputStream, (FD_Stream *)currentOutputBlock );
            decompressionCompleted = 1;
            break;
        default:
            if( (FD_StreamPriv *)outputStream != currentOutputBlock )
                FD_StreamFree( (FD_Stream *)currentOutputBlock );
            FD_StreamFree( outputStream );
            FD_FATAL(  "BZIP2 cannot decompress data", returnCode, 0 );
        }
    } while( !decompressionCompleted );

    /* Adjust the fd_stream_access to reflect the bytes consume
     * by the BZIP2 library.
     */
    if( bzipStream.avail_in == 0 )
    {
        accessMoveToNextBlock( streamToDecompress );
    }
    else
    {
        FD_StreamAccessBypass( (FD_Stream *)streamToDecompress, nbByteInThisBlock-bzipStream.avail_in );
    }
    /* Free all ressources used by the BZIP2 library. */
    returnCode = BZ2_bzDecompressEnd( &bzipStream );
    if( returnCode != BZ_OK )
    {
        FD_StreamFree( outputStream );
        FD_FATAL(  "BZIP2 cannot release ressources", returnCode, 0 );
    }

    retCode = FD_StreamMerge( (FD_Stream *)stream, outputStream );

    FD_TRACE_RETURN( retCode );
}

/* The following function is defined for handling internal errors
 * from the bzip library.
 */
void bz_internal_error ( int errCode )
{
    (void)errCode; /* To get ride of warning. */
    /* FD_FATAL( "BZIP internal error occured", errCode, 0 ); */
}

static void freeData( FD_StreamPriv *streamPriv )
{   
   if( streamPriv->freeData )
   {
      if( streamPriv->freeFunc )
         streamPriv->freeFunc(  streamPriv->freeData, streamPriv->opaqueData );
      else
         FD_Free(  streamPriv->freeData );
   }
}

static FD_RetCode markByteForSkip( FD_Stream *stream, unsigned int nbByteToSkip )
{
   FD_StreamPriv *streamPriv;
   unsigned int nbByteToSkipInThisBlock, nbByte;

   if( !stream || !nbByteToSkip )
      return FD_BAD_PARAM;

   streamPriv = (FD_StreamPriv *)stream;

   while( nbByteToSkip && streamPriv )
   {
      if( streamPriv->magicNb != FD_STREAM_MAGIC_NB )
         return FD_BAD_OBJECT;


      nbByte = streamPriv->nbBitWritten/8;
      if( streamPriv->nbBitWritten%8 )
        nbByte += 1;

      nbByteToSkipInThisBlock = min( nbByte, nbByteToSkip );

      streamPriv->data += nbByteToSkipInThisBlock;
      streamPriv->nbBitWritten -= nbByteToSkipInThisBlock*8;
      streamPriv->nbByteToSkip = nbByteToSkipInThisBlock;

      nbByteToSkip -= nbByteToSkipInThisBlock;
      streamPriv = streamPriv->next;
   }

   if( nbByteToSkip != 0 )
      return FD_INTERNAL_ERROR(10);

   return FD_SUCCESS;
}

static FD_RetCode calcCRC( FD_Stream *stream,
                           unsigned int start, /* First byte to include. Zero base. */
                           unsigned int stop,  /* Last byte to include. Zero base. */
                           unsigned int *crc32 )
{
   FD_RetCode retCode;
   FD_StreamAccess *access;
   unsigned int temp, i;
   unsigned char data, lastData;
   qbyte runningData;

   temp = 0; /* To get ride of warning. */

   if( !stream )
      return FD_BAD_PARAM;

   if( stop < start )
      return FD_BAD_PARAM;

   access = FD_StreamAccessAlloc( stream );
   if( !access )
      return FD_ALLOC_ERR;

   if( start != 0 )
   {
      retCode = FD_StreamAccessBypass( access, start );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamAccessFree( access );
         return retCode;
      }
   }

   /* The following can be speed optimized. Big time! */
   runningData = 0xFFFFFFFFL;
   for( i=0; i <= (stop-start); i++ )
   {
      retCode = FD_StreamAccessGetByte( access, &data );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamAccessFree( access );
         return retCode;
      }

      temp = calculate_running_crc( &runningData, &data, 1 );
      lastData = data;
   }

   FD_StreamAccessFree( access );

   *crc32 = temp;
   return FD_SUCCESS;   
}

static void accessPrivCopy( FD_StreamAccessPriv *src, FD_StreamAccessPriv *dst )
{
  /* Really simple... */
  *dst = *src;
}

static FD_RetCode streamGetHTMLTable( FD_StreamAccess *accessStart,
                                      unsigned int maxElementSize,
                                      char *buffer,
                                      char *hrefBuffer,
                                      FD_HTMLTableFuncPtr funcPtr,
                                      void *opaqueData )
{
   FD_RetCode retCode;
   FD_StreamAccessPriv accessPriv;
   FD_StreamAccess *access;
   unsigned int endOfTag, lineTag, columnTag, tableTag, skipTag;
   unsigned int line, column;
   unsigned int bufPos, again;
   unsigned char data;
   int tableLevel;
   int skipRestOfTable;

   accessPrivCopy( (FD_StreamAccessPriv *)accessStart,  &accessPriv );
 
   access = (FD_StreamAccess *)&accessPriv;

   line = column = bufPos = 0;
   
   *hrefBuffer = '\0';

   /* Find the start of the table. 
    * Position 'access' immediatly after 
    * the '>' of the <table ...> tag
    */
   retCode = FD_StreamAccessSearch( access, "<table" );
   if( retCode != FD_SUCCESS ) return retCode;
   do
   {
      retCode = FD_StreamAccessGetByte( access, &data );
      if( retCode != FD_SUCCESS ) return retCode;
   } while( data != '>' );

   /* Ok... not the best parsing approach on earth... but it
    * works.
    * Parse only HTML with good syntax (matching tags),
    * else an error is returned.
    */
   tableLevel = 1;
   again = 1;
   skipRestOfTable = 0;
   do
   {
      retCode = FD_StreamAccessGetByte( access, &data );
      if( retCode != FD_SUCCESS ) return retCode;

      /* Process tags. */
      endOfTag = 0;
      columnTag = 0;
      lineTag = 0;
      tableTag = 0;
      endOfTag = 0;
      skipTag = 0;

      if( data == '<' )
      {
         retCode = FD_StreamAccessGetByte( access, &data );
         if( retCode != FD_SUCCESS ) return retCode;

         /* Start or end of a tag? */
         if( data == '/' )
         {
            endOfTag = 1;
            retCode = FD_StreamAccessGetByte( access, &data );
            if( retCode != FD_SUCCESS ) return retCode;
         }
         else
            endOfTag = 0;

         /* Identify the tag. */                              
         switch( toupper(data) )
         {
         case 'T':
            retCode = FD_StreamAccessGetByte( access, &data );
            if( retCode != FD_SUCCESS ) return retCode;
            switch( toupper(data) )
            {
            case 'A':
               tableTag = 1;
               break;
            case 'D':
               columnTag = 1;
               break;
            case 'R':
               lineTag = 1;
               break;
            }
            break;
         case 'A':
            retCode = FD_StreamAccessGetByte( access, &data );
            if( retCode != FD_SUCCESS ) return retCode;
            if( isspace( toupper(data) ) )
            {
               /* Extract a "href=x>" where 'x' is returned in
                * hrefBuffer as a NULL terminated string.
                */
               retCode = streamGetHREF( access, hrefBuffer, maxElementSize );
               if( retCode != FD_SUCCESS )
                  return retCode;
               data = '>'; /* Because streamGetHREF eat the ending '>' */
            }
         }


         /* Confirm if yes or no this is a tableTag.
          * If not it will be skip.
          */
         if( tableTag )
         {
            tableTag = 0;
            retCode = FD_StreamAccessGetByte( access, &data );
            if( retCode != FD_SUCCESS ) return retCode;
            if( toupper(data) == 'B' )
            {
               retCode = FD_StreamAccessGetByte( access, &data );
               if( retCode != FD_SUCCESS ) return retCode;
               if( toupper(data) == 'L' )
               {
                  retCode = FD_StreamAccessGetByte( access, &data );
                  if( retCode != FD_SUCCESS ) return retCode;
                  if( toupper(data) == 'E' )
                     tableTag = 1; /* Confirmed. */
               }
            }
         }

            /* Handle the processing of the <TD>, </TD>, <TR>, </TR>,
             * <TABLE> and </TABLE> tag.
             */
            if( lineTag )
            {
               if( endOfTag )
               {  /* This is a new line. */
                  line++;
                  column = 0;
                  bufPos = 0;
                  *hrefBuffer = '\0';
               }
            }
            else if( tableTag )
            {
               if( !endOfTag )
               {
                  bufPos = 0; /* Begining of a table. */
                  *hrefBuffer = '\0';
                  tableLevel++;
               }
               else
               {
                  tableLevel--;
                  if( tableLevel <= 0 )
                     again = 0; /* End of table. Processing completed. */
               }
            }
            else if( columnTag )
            {
               if( endOfTag )
               {
                  /* Process one element of the table. */                 
                  if( !skipRestOfTable )
                  {
                     buffer[bufPos] = '\0';
                     retCode = funcPtr( line, column, buffer, hrefBuffer, opaqueData );
                     if( retCode == FD_FINISH_TABLE )
                        skipRestOfTable = 1;
                     else if( retCode != FD_SUCCESS )
                        return retCode;
                  }
                  column++;
                  bufPos = 0;
                  *hrefBuffer = '\0';
               }
            }

         /* Skip the rest of the tag. */
         while( data != '>' )
         {
            retCode = FD_StreamAccessGetByte( access, &data );
            if( retCode != FD_SUCCESS ) return retCode;
            if( data == '<' )
               return FD_BAD_HTML_SYNTAX;
         }
      }
      else
      {
         /* This is not within a tag... just accumulate the text. */
         if( bufPos < maxElementSize )
         {
            /* Do some replacement */
            if( isspace( data ) )
               data = ' ';

            buffer[bufPos] = data;
            bufPos++;
         }
      }

   } while( again );
   
   return FD_SUCCESS;
}

static FD_RetCode streamGetHREF( FD_StreamAccess *access,
                                 char *buffer, unsigned int bufferSize )
{
   FD_RetCode retCode;
   unsigned int i, again;
   unsigned char data;

   /* Extract a "href=x>" where 'x' is returned in
    * buffer as a NULL terminated string.
    * Remove potentialy double quotes surrounding
    * the x like this: "x"
    */
   retCode = FD_StreamAccessSearch( access, "href=" );
   if( retCode != FD_SUCCESS )
      return retCode;

   i = 0;
   again = 1;
   do
   { 
      retCode = FD_StreamAccessGetByte( access, &data );
      if( retCode != FD_SUCCESS )
      {
         *buffer = '\0';
         return retCode;
      }

      if( data != '"' )
      {   
         if( data == '>' )
            again = 0;
         else if( i < (bufferSize-1) )
            buffer[i++] = data;
      }
   } while( again );

   buffer[i] = '\0';
   
   return FD_SUCCESS;
}
