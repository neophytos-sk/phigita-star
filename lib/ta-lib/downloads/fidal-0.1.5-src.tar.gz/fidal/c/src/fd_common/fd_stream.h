#ifndef FD_STREAM_H
#define FD_STREAM_H

#ifndef FD_MEMORY_H
   #include "fd_memory.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

/* Important Note: This stream module is absolutly not protected for
 *                 multithread access. Make sure you use mutex around the 
 *                 access of a particular stream.
 *
 * Also, it is strongly suggested to keep everything on a BYTE boundary.
 *
 * Two reason for this:
 *   1) It is simply more efficient.
 *   2) Mixing non-boundary data with compressed/encapsulate stream
 *      can become quite complexe and error prone.
 *
 * So when using directly FD_StreamAddBit(), make sure you complete to 
 * a byte boundary eventually before mixing with other type of data. All
 * other FD_StreamAddXXXXX() functions can be used without worrying about
 * this.
 * If you are not sure if you are on a byte boundary, call
 * FD_StreamAdjustToBoundary() and the stream will be adjusted if needed.
 */
typedef unsigned int FD_Stream;
typedef unsigned int FD_StreamAccess;

/* Use to alloc/dealloc a stream. */
FD_Stream *FD_StreamAlloc( void );
FD_RetCode FD_StreamFree( FD_Stream *stream );

/* Alloc a FD_Stream from an existing buffer. 
 * On succcess, the buffer belongs to the FD_Stream and 
 * will be freed by the calller provided freeFunc when
 * the FD_StreamFree gets called.
 */
FD_Stream *FD_StreamAllocFromBuffer( unsigned char *data,
                                     unsigned int dataSize,
                                     FD_FreeFuncPtr funcPtr,
                                     void *opaqueData );


/* Use to append an element to the stream. */

/* Fundamental types. */
FD_RetCode FD_StreamAddBit  ( FD_Stream *stream, unsigned int   data );
FD_RetCode FD_StreamAddByte ( FD_Stream *stream, unsigned char  data );
FD_RetCode FD_StreamAddInt16( FD_Stream *stream, unsigned short data );
FD_RetCode FD_StreamAddInt32( FD_Stream *stream, unsigned int   data );

/* FIDAL types. */
FD_RetCode FD_StreamAddInteger  ( FD_Stream *stream, FD_Integer data );
FD_RetCode FD_StreamAddReal     ( FD_Stream *stream, FD_Real    data );
FD_RetCode FD_StreamAddString   ( FD_Stream *stream, const FD_String *string );
FD_RetCode FD_StreamAddTimestamp( FD_Stream *stream, const FD_Timestamp *timestamp );

/* Append the content of a file to the stream. */
FD_RetCode FD_StreamAddFile( FD_Stream *steam, FILE *in );

/* Append a buffer to the stream.
 * On success, the buffer belongs to the stream.
 * By default the data is freed by FD_Free unless
 * a FD_FreeFuncPtr is specified.
 */
FD_RetCode FD_StreamAddBuffer( FD_Stream *stream,
                               unsigned char *data,
                               unsigned int dataSize,
                               FD_FreeFuncPtr funcPtr,
                               void *opaqueData );

/* Bring the stream on a byte boundary. */
FD_RetCode FD_StreamAdjustToBoundary( FD_Stream *stream );

/* Use to read the stream sequentially.
 * The FD_StreamAccessGetXXXXX() functions return FD_END_OF_STREAM 
 * when there is no more data to read.
 *
 * A stream can safely be read by multiple FD_StreamAccess simultaneously.
 *
 * It is impossible to read backward in a stream (an alternative is
 * to re-allocate another FD_StreamAccess and start over!)
 */
FD_StreamAccess *FD_StreamAccessAlloc( const FD_Stream *stream );
FD_StreamAccess *FD_StreamAccessAllocCopy( const FD_StreamAccess *stream );

FD_RetCode FD_StreamAccessFree( FD_StreamAccess *streamAccess );

FD_RetCode FD_StreamAccessGetBit( FD_StreamAccess *streamAccess,
                                  unsigned int nbBit,
                                  unsigned int *data );

FD_RetCode FD_StreamAccessGetByte( FD_StreamAccess *streamAccess,
                                   unsigned char *data );

FD_RetCode FD_StreamAccessGetInt16( FD_StreamAccess *streamAccess,
                                    unsigned int  *data );

FD_RetCode FD_StreamAccessGetInt32( FD_StreamAccess *streamAccess,
                                    unsigned int  *data );

FD_RetCode FD_StreamAccessGetInteger( FD_StreamAccess *streamAccess,
                                      FD_Integer *data );

FD_RetCode FD_StreamAccessGetReal( FD_StreamAccess *streamAccess,
                                   FD_Real *data );

FD_RetCode FD_StreamAccessGetTimestamp( FD_StreamAccess *streamAccess,
                                        FD_Timestamp *data );


/* Get a string. This one is slightly different because
 * a FD_String will be allocated from this call. This is
 * why the address of a pointer is passed instead.
 */
FD_RetCode FD_StreamAccessGetString( FD_StreamAccess *streamAccess,
                                     FD_String **string );

/* Get the data chunk by chunk for speed efficiency.
 * Shall be used when it is known that the data is on
 * byte boundaries. MUST NOT be mix with any other
 * FD_StreamAccessGetXXXXXX() function.
 */
FD_RetCode FD_StreamAccessGetBuffer( FD_StreamAccess *streamAccess,
                                     const char   **theBuffer,
                                     unsigned int *theBufferSize );

/* Bypass the specified number of byte. */
FD_RetCode FD_StreamAccessBypass( FD_StreamAccess *streamAccess, unsigned int nbByteToBypass );

/* Search for a string.
 * On success, the stream will be positioned AFTER the requested string.
 * If the string does not exist, FD_END_OF_STREAM will be returned and the
 * FD_StreamAccess is NOT affected (in other word, on all failure, the position
 * in the source is preserved).
 */
FD_RetCode FD_StreamAccessSearch( FD_StreamAccess *source, const char *stringToFind );

/* Extract the next HTML table from the stream.
 * For each element of the table, the provided function is called.
 * All HTML tag are strip off from the element.
 *
 * The href is the first hyperlink within the cell. Additional href in the
 * same cell are ignored.
 *
 * If a table is embedded within a table, the whole elements are
 * returned as if they were belonging to the same global table.
 */
typedef FD_RetCode (*FD_HTMLTableFuncPtr)( unsigned int line,
                                           unsigned int column,
                                           const char *data,
                                           const char *href,
                                           void *opaqueData);

FD_RetCode FD_StreamAccessGetHTMLTable( FD_StreamAccess *streamAccess,
                                        unsigned int maxElementSize,
                                        FD_HTMLTableFuncPtr funcPtr,
                                        void *opaqueData );

/* Skip the next HTML Table.
 * (the streamAccess will point after the </table> tag)
 */
FD_RetCode FD_StreamAccessSkipHTMLTable( FD_StreamAccess *streamAccess );

/* Use to get the total size of byte/bit in the stream. */
unsigned int FD_StreamSizeInBit ( const FD_Stream *stream );
unsigned int FD_StreamSizeInByte( const FD_Stream *stream );

/* Use to write a stream to a file. */
FD_RetCode FD_StreamToFile( FD_Stream *stream, FILE *out );

/* Use to append a copy of a stream to another one.
 * The 'src' stream is copied at the end of the 'dest' stream.
 * The caller still have to properly free the 'dest' and 'src' FD_Stream.
 *
 * If the 'src' stream is not needed anymore by the caller, consider to use
 * instead the FD_StreamMerge function.
 */
FD_RetCode FD_StreamAppendCopy( FD_Stream *dest, const FD_Stream *src );

/* Take two streams and merge these into one stream.
 * The 'secondStream' will be concatenated to the firstStream.
 * On FD_SUCCESS, the caller must NEVER free the 'secondStream' (the
 * data will be freed when the firstStream will be freed).
 *
 * The FD_StreamMerge is a LOT more speed efficient than the
 * FD_StreamAppendCopy.
 */
FD_RetCode FD_StreamMerge( FD_Stream *firstStream, FD_Stream *secondStream );

/* A stream can contain compress or uncompress information.
 *
 * All the compression/decompression functionality is
 * encapsulated within this module.
 */

/* Compress a stream and append it to the 'stream'. */
FD_RetCode FD_StreamCompress( FD_Stream *stream, const FD_Stream *streamToCompress );

/* Un-compress a stream
 * On success, a new un-compress stream is returned.
 *
 * Following this call the 'streamToDecompress' access will be set
 * on the next bit to read from the stream. In other words, only the
 * bits needed by the compression algorithm are consumed.
 *
 * It is VERY IMPORTANT that the FD_StreamAccess is really pointing to a
 * position where the stream is compressed.
 */
FD_RetCode FD_StreamDecompress( FD_StreamAccess *streamToDecompress,
                                FD_Stream **newAllocatedStream );

/* Append CRC-32 information to the stream to allow to safely
 * rebuild it by a remote entity (or later re-read from a file).
 *
 * Following a call to FD_StreamEncapsulate, the stream is expected to
 * be written to a file or sent across a network. On reading/receiving
 * the data, a call to FD_StreamDecapsulate must be performed.
 *
 * On success, these two functions GUARANTEE the integrity of the
 * FD_Stream. In other word, FD_StreamDecapsulate will succeed ONLY
 * if the FD_Stream is successfully rebuild and IDENTICAL to the original.
 *
 * The caller can provide a timestamp and an identifier to be embedded
 * within the header of the encapsulated stream. If the caller does not
 * care, just pass dummy value for these. The exactitude of this timestamp
 * and integer is also guaranteed when FD_StreamDecapsulate succeed.
 *
 * Warning: Notice that FD_StreamEncapsulate may change the pointer on
 *          the 'stream'. Do not assume that the stream pointer
 *          did not changed. Free that stream as usual once you are done.
 */

FD_RetCode FD_StreamEncapsulate( FD_Stream    **stream, /* See Warning. */
                                 FD_Timestamp  *userTimestamp,
                                 FD_Integer     userIdentifier );

FD_RetCode FD_StreamDecapsulate( FD_Stream    *stream,
                                 FD_Timestamp *userTimestamp,
                                 FD_Integer   *userIdentifier ); 

/* Simply return the number of time a certain character exist within
 * the stream.
 * Check only on 8 bits boundary.
 *
 * Example: FD_StreamCountChar( stream, '\n' ) will return the
 *          number of lines in the stream.
 *     
 */
unsigned int FD_StreamCountChar( const FD_Stream *stream, char toCount );

#ifdef FD_DEBUG
FD_RetCode FD_StreamPrint( FD_Stream *stream );
#endif

#endif
