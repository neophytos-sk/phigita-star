/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY      Description
 *  -------------------------------------------------------------------
 *  110199 MF      First version.
 */

/**** Headers ****/
#include "fd_common.h"
#include "fd_list.h"
#include "kazlib/kaz_list.h"
#include "fd_memory.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/

/* The FD_List->flags can use the following boolean flags. */

/* The list come from FD_ListAlloc, else assume FD_ListInit */
#define FD_LIST_FLAGS_DYNAMIC      0x00000001 

/* Indicates if the user provides pre-allocated FD_ListNode or
 * a dynamic approach.
 * The distinction could be done only follwoing a FD_ListAddXXXXX() 
 * or FD_ListNodeAddXXXXX() functions.
 */
#define FD_LIST_FLAGS_PREALLOC_NODE 0x00000002
#define FD_LIST_FLAGS_DYNAMIC_NODE  0x00000004

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_List *FD_ListAlloc( void )
{
   FD_List *theList;

   /* Allocate the FD_List. */
   theList = (FD_List *)FD_Malloc( sizeof( FD_List ) );      
   if( !theList )
      return NULL;

   /* Initialize the content of the FD_List */
   FD_ListInit( theList );
   theList->flags = FD_LIST_FLAGS_DYNAMIC;

   return theList;
}

FD_RetCode FD_ListFree( FD_List *list )
{
   if( !list )
      return FD_SUCCESS; /* Assume already freed. */

   /* Destroy all the nodes if they were
    * dynamically allocated.
    */
   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      list_destroy_nodes( &list->d );

   /* Destroy the list if it was dynamically allocated. */
   if( list->flags & FD_LIST_FLAGS_DYNAMIC )
      FD_Free( list );

   return FD_SUCCESS;
}

/* Initialize a user pre-allocated FD_List.
 *
 * (Note: speed optimized, not as safe as FD_ListAlloc)
 *
 * Example:
 *      FD_List myList;
 *      FD_ListInit(  &myList );
 *      'myList' can be used from this point.
 */
void FD_ListInit( FD_List *list )
{
   list->node = NULL;
   list->flags = 0;

   list_init( &list->d, LISTCOUNT_T_MAX );
}

FD_RetCode FD_ListFreeAll( FD_List *list,
                           FD_RetCode (*freeFunc)( void *toBeFreed ))
{
   FD_PROLOG
   FD_RetCode retCode;
   void *node;

   FD_TRACE_BEGIN( FD_ListFreeAll );

   if( list != NULL )
   {
      while( (node = FD_ListRemoveTail( list )) != NULL )
      {
         retCode = freeFunc( node );
         if( retCode != FD_SUCCESS )
         {
            FD_FATAL( NULL, node, retCode );
         }
      }

      retCode = FD_ListFree( list );
      if( retCode != FD_SUCCESS )
      {
         FD_FATAL( NULL, list, retCode );
      }
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_ListAddTail( FD_List *list, void *newElement )
{
   lnode_t *node;

   if( list == NULL )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_PREALLOC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_DYNAMIC_NODE) )
      list->flags |= FD_LIST_FLAGS_DYNAMIC_NODE;

   /* Allocate node. */
   node = lnode_create( newElement );

   if( !node )
      return FD_ALLOC_ERR;

   list_append( &list->d, node );

   return FD_SUCCESS;
}

FD_RetCode FD_ListAddHead( FD_List *list, void *newElement )
{
   lnode_t *node;

   if( list == NULL )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_PREALLOC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_DYNAMIC_NODE) )
      list->flags |= FD_LIST_FLAGS_DYNAMIC_NODE;

   /* Allocate node. */
   node = lnode_create( newElement );

   if( !node )
      return FD_ALLOC_ERR;

   list_prepend( &list->d, node );

   return FD_SUCCESS;
}

FD_RetCode FD_ListAddBefore( FD_List *list, void *element, void *newElement )
{
   lnode_t *newNode;
   lnode_t *thisNode;

   if( list == NULL )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_PREALLOC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_DYNAMIC_NODE) )
      list->flags |= FD_LIST_FLAGS_DYNAMIC_NODE;

   /* Find 'element' node. */
   thisNode = list_find( &list->d, element, NULL );

   if( !thisNode )
      return FD_BAD_PARAM;

   /* Allocate node. */
   newNode = lnode_create( newElement );

   if( !newNode )
      return FD_ALLOC_ERR;

   list_ins_before( &list->d, newNode, thisNode );

   return FD_SUCCESS;
}

FD_RetCode FD_ListAddAfter( FD_List *list, void *element, void *newElement )
{
   lnode_t *newNode;
   lnode_t *thisNode;

   if( list == NULL )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_PREALLOC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_DYNAMIC_NODE) )
      list->flags |= FD_LIST_FLAGS_DYNAMIC_NODE;

   /* Find 'element' node. */
   thisNode = list_find( &list->d, element, NULL );

   if( !thisNode )
      return FD_BAD_PARAM;

   /* Allocate node. */
   newNode = lnode_create( newElement );

   if( !newNode )
      return FD_ALLOC_ERR;

   list_ins_after( &list->d, newNode, thisNode );

   return FD_SUCCESS;
}

FD_RetCode FD_ListNodeAddTail( FD_List *list, FD_ListNode *node, void *newElement )
{
   if( !list || !node )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_PREALLOC_NODE) )
      list->flags |= FD_LIST_FLAGS_PREALLOC_NODE;

   lnode_init( &node->node, newElement );

   list_append( &list->d, &node->node );

   return FD_SUCCESS;
}

FD_RetCode FD_ListNodeAddHead( FD_List *list, FD_ListNode *node, void *newElement )
{
   if( !list || !node )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_PREALLOC_NODE) )
      list->flags |= FD_LIST_FLAGS_PREALLOC_NODE;

   lnode_init( &node->node, newElement );

   list_prepend( &list->d, &node->node );

   return FD_SUCCESS;
}

FD_RetCode FD_ListNodeAddBefore( FD_List *list, FD_ListNode *node, void *element, void *newElement )
{
   lnode_t *newNode;
   lnode_t *thisNode;

   if( !list || !node )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_PREALLOC_NODE) )
      list->flags |= FD_LIST_FLAGS_PREALLOC_NODE;

   /* Find 'element' node. */
   thisNode = list_find( &list->d, element, NULL );

   if( !thisNode )
      return FD_BAD_PARAM;

   /* Initialize new node. */
   newNode = &node->node;
   lnode_init( newNode, newElement );

   list_ins_before( &list->d, newNode, thisNode );

   return FD_SUCCESS;
}

FD_RetCode FD_ListNodeAddAfter( FD_List *list, FD_ListNode *node, void *element, void *newElement )
{
   lnode_t *newNode;
   lnode_t *thisNode;

   if( !list || !node )
      return FD_BAD_PARAM;

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      return FD_INVALID_LIST_TYPE;

   if( !(list->flags & FD_LIST_FLAGS_PREALLOC_NODE) )
      list->flags |= FD_LIST_FLAGS_PREALLOC_NODE;

   /* Find 'element' node. */
   thisNode = list_find( &list->d, element, NULL );

   if( !thisNode )
      return FD_BAD_PARAM;

   /* Initialize new node. */
   newNode = &node->node;
   lnode_init( newNode, newElement );

   list_ins_after( &list->d, newNode, thisNode );

   return FD_SUCCESS;
}

void *FD_ListRemoveTail( FD_List *list )
{
   lnode_t *node;
   void *returnValue;

   if( (list == NULL)    ||
       list_isempty(&list->d) )
      return (void *)NULL;

   node = list_del_last( &list->d );

   returnValue = lnode_get( node );

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      lnode_destroy( node );

   return returnValue;
}

void *FD_ListRemoveHead( FD_List *list )
{
   lnode_t *node;
   void *returnValue;

   if( (list == NULL)    ||
       list_isempty(&list->d) )
      return (void *)NULL;

   node = list_del_first( &list->d );

   returnValue = lnode_get( node );

   if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
      lnode_destroy( node );

   return returnValue;
}

FD_RetCode FD_ListRemoveEntry( FD_List *list, void *elementToRemove )
{
   lnode_t *node;

   if( (list == NULL)    ||
       list_isempty(&list->d) )
      return FD_BAD_PARAM;

   node = list_first( &list->d );

   while( node !=  NULL )
   {
      if( lnode_get( node ) == elementToRemove )
      {
         list_delete( &list->d, node );
         if( list->flags & FD_LIST_FLAGS_DYNAMIC_NODE )
            lnode_destroy( node );
         return FD_SUCCESS;
      }

      node = list_next( &list->d, node );
   }

   return FD_BAD_PARAM;
}

unsigned int FD_ListSize( FD_List *list )
{

   if( list == NULL )
      return 0;

   return list_count( &list->d );
}

void *FD_ListAccessHead( FD_List *list )
{
   if( (list == NULL)    ||
       list_isempty(&list->d) )
      return NULL;

   list->node = list_first( &list->d );

   if( list->node == NULL )
      return NULL;
   else
      return lnode_get( list->node );
}

void *FD_ListAccessTail( FD_List *list )
{

   if( (list == NULL)    ||
       list_isempty(&list->d) )
      return NULL;

   list->node = list_last( &list->d );

   if( list->node == NULL )
      return NULL;
   else
      return lnode_get( list->node );
}

void *FD_ListAccessNext( FD_List *list )
{
   if( (list == NULL) || 
       (list->node == NULL) )
      return NULL;

   list->node = list_next( &list->d, list->node );

   if( list->node == NULL )
      return NULL;
   else
      return lnode_get( list->node );
}

void *FD_ListAccessPrev( FD_List *list )
{
   if( (list == NULL) || (list->node == NULL) )
      return NULL;

   list->node = list_prev( &list->d, list->node );

   if( list->node == NULL )
      return NULL;
   else
      return lnode_get( list->node );
}

void *FD_ListAccessCurrent( FD_List *list )
{
   if( (list == NULL) || (list->node == NULL) )
      return NULL;

   return lnode_get( list->node );
}

FD_RetCode FD_ListIterInit( FD_ListIter *iter, FD_List *list )
{
   if( (!iter) || (!list) )
      return FD_BAD_PARAM;

   iter->list = list;
   iter->currentNode = FD_ListIterHead( iter );

   return FD_SUCCESS;
}

void *FD_ListIterHead( FD_ListIter *iter )
{
   lnode_t *node;
   FD_List *theList;

   if( !iter )
      return NULL;

   theList = iter->list;

   if( (!theList) || list_isempty(&theList->d) )
      return NULL;

   node = list_first( &theList->d );

   iter->currentNode = (void *)node;
   if( node == NULL )
      return NULL;
   else
      return lnode_get( node );
}

void *FD_ListIterNext( FD_ListIter *iter )
{
   lnode_t *node;
   FD_List *theList;

   if( (!iter) || (!iter->currentNode) )
      return NULL;

   theList = iter->list;

   if( !theList )
      return NULL;

   node = list_next( &theList->d, (lnode_t *)iter->currentNode );

   iter->currentNode = (void *)node;
   if( node == NULL )
      return NULL;
   else
      return lnode_get( node );
}

void *FD_ListIterPrev( FD_ListIter *iter )
{
   lnode_t *node;
   FD_List *theList;

   if( (!iter) || (!iter->currentNode) )
      return NULL;

   theList = iter->list;

   if( !theList )
      return NULL;

   node = list_prev( &theList->d, (lnode_t *)iter->currentNode );

   iter->currentNode = (void *)node;
   if( node == NULL )
      return NULL;
   else
      return lnode_get( node );
}

void *FD_ListIterTail( FD_ListIter *iter )
{
   lnode_t *node;
   FD_List *theList;

   theList = iter->list;

   if( (!theList) || (!iter) || list_isempty(&theList->d) )
      return NULL;

   node = list_last( &theList->d );

   iter->currentNode = (void *)node;
   if( node == NULL )
      return NULL;
   else
      return lnode_get( node );
}

void *FD_ListIterCur( FD_ListIter *iter )
{
   lnode_t *node;

   if( (!iter) || (!iter->currentNode) )
      return NULL;

   node = (lnode_t *)iter->currentNode;
   
   return lnode_get( node );
}

FD_RetCode FD_ListIterSavePos( FD_ListIter *iter, FD_ListIterPos *iterPos )
{
   if( (!iter) || (!iterPos) || (!iter->currentNode) )
      return FD_BAD_PARAM;

   iterPos->iter = iter;
   iterPos->savedNode = iter->currentNode;
   return FD_SUCCESS;
}

void *FD_ListIterRestorePos( FD_ListIterPos *iterPos )
{
   void *tmp;

   if( (!iterPos) || (!iterPos->savedNode) )
      return NULL;

   tmp = iterPos->savedNode;
   if( !tmp )
      return NULL;

   iterPos->iter->currentNode = tmp;
   return lnode_get( (lnode_t *)tmp );
}


FD_RetCode FD_ListSort( FD_List *list, int compare(const void *, const void *) )
{
   if( list == NULL )
      return FD_BAD_PARAM;

   kazlist_sort( &list->d, compare );
   return FD_SUCCESS;
}

FD_RetCode FD_ListRemoveDuplicate( FD_List *list, 
                                   int equal(const void *, const void *),
                                   FD_RetCode (*freeFunc)( void *toBeFreed ) )
{
   FD_ListIter outerLoop;
   FD_ListIterPos savePos;
   void *a;
   void *b; 
   void *toBeRemove;
   FD_RetCode retCode;

   if( list == NULL )
      return FD_BAD_PARAM;

   if( FD_ListSize(list) < 2 )
      return FD_SUCCESS;

   FD_ListIterInit( &outerLoop, list );
   a = FD_ListIterHead( &outerLoop );
      
   do
   {     
      retCode = FD_ListIterSavePos( &outerLoop, &savePos);
      if( retCode != FD_SUCCESS )
         return retCode;
      b = FD_ListIterNext(&outerLoop);
      while(b) 
      {
         if( equal(a,b) )
         {
            toBeRemove = b;
            b = FD_ListIterNext(&outerLoop);
            retCode = FD_ListRemoveEntry(list,toBeRemove);
            if( retCode != FD_SUCCESS )
               return retCode;
            if( freeFunc )
               freeFunc(toBeRemove);
         }
         else
            b = FD_ListIterNext(&outerLoop);
      }

      FD_ListIterRestorePos(&savePos);
      a = FD_ListIterNext( &outerLoop );
   } while(a);

   return FD_SUCCESS;
}

/**** Local functions definitions.     ****/
/* None */

