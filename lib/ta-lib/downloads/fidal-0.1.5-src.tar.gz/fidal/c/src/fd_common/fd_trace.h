
#ifndef FD_TRACE_H
#define FD_TRACE_H

#ifndef FD_DICT_H
   #include "fd_dict.h"
#endif

#ifndef FD_DEFS_H
   #include "fd_defs.h"
#endif

/* This module allows to monitor and log internal error.
 * Most of the implementation is done through macro allowing
 * to enable/disable the feature.
 *
 * More loging and debugging is performed when FD_DEBUG is defined. 
 * FD_DEBUG shall never be defined in the final library.
 */

/* The following macros are used to return internal errors.
 * The Id can be from 1 to 999 and translate to the user 
 * as the return code 5000 to 5999.
 *
 * Everytime you wish to add a new fatal error code,
 * use the "NEXT AVAILABLE NUMBER" and increment the
 * number in this file.
 *
 * NEXT AVAILABLE NUMBER: 181
 */
#define FD_INTERNAL_ERROR(Id) (FD_INTERNAL_ERROR+Id)


/* Note: FIDAL is NEVER doing any console I/O (no putchar, printf etc...) unless
 *       it is specifically requested by the library user (like with the FD_FatalReport
 *       function).
 * 
 *       This is to make possible to integrate the FIDAL in any GUI without undesirable
 *       console output.
 */

/* FD_FILE_INFO must be placed at the top in the 'c' file, prior to 
 * using any of the tracing or assert macro.
 */
#ifndef FD_FILE_INFO
#define FD_FILE_INFO static const char *theFileNamePtr = __FILE__; \
                     static const char *theFileDatePtr = __DATE__; \
                     static const char *theFileTimePtr = __TIME__;
#endif

/* The FD_FATAL/FD_ASSERT macro are going to be ALWAYS enabled in the
 * final library.
 *
 * Upon failure, these macro will "return" from the function. There is no 
 * "exit" done to prevent to shutdown unappropriatly the application.
 *
 * On a fatal/assertion failure, FIDAL will record information. The user of
 * the library can retreive these recorded information by using FD_FatalReport
 * or FD_FatalReportToBuffer.
 *
 * An application can also monitor for fatal error by providing a callback
 * using FD_SetFatalErrorHandler.
 *
 * FD_ASSERT        : Must be in a function AFTER a FD_TRACE_BEGIN.
 * FD_ASSERT_RET    : Only for functions without a FD_PROLOG/FD_TRACE_BEGIN.
 * FD_ASSERT_NO_RET : Only for functions without a FD_PROLOG/FD_TRACE_BEGIN returning void.
 *
 * FD_FATAL         : Must be in a function AFTER a FD_TRACE_BEGIN.
 * FD_FATAL_RET     : Only for functions without a FD_PROLOG/FD_TRACE_BEGIN
 * FD_FATAL_NO_RET  : Only for functions without a FD_PROLOG/FD_TRACE_BEGIN returning void.
 *
 */
#define FD_ASSERT(b) {if(!(b)) {FD_PrivError(1,#b,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,0,0); FD_TRACE_RETURN(FD_FATAL_ERR);}}
#define FD_ASSERT_RET(b,ret) {if(!(b)) {FD_PrivError(1,#b,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,0,0); return ret;}}
#define FD_ASSERT_NO_RET(b) {if(!(b)) {FD_PrivError(1,#b,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,0,0); return;}}

#define FD_FATAL(str,param1,param2) {FD_PrivError(0,str,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,(unsigned long)param1,(unsigned long)param2); FD_TRACE_RETURN( FD_FATAL_ERR );}
#define FD_FATAL_RET(str,param1,param2,ret) {FD_PrivError(0,str,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,(unsigned long)param1,(unsigned long)param2); return ret;}
#define FD_FATAL_NO_RET(str,param1,param2) {FD_PrivError(0,str,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,(unsigned long)param1,(unsigned long)param2); return;}

/* When FD_DEBUG is defined, additional "paranoiac" testing can be performed
 * for checking the integrity of the software.
 *
 * This assert mechanism will NOT be enabled in the final library.
 *
 * FD_ASSERT_DEBUG : Must be in a function AFTER a FD_TRACE_BEGIN.
 */
#ifdef FD_DEBUG
   #define FD_ASSERT_DEBUG(b){if(!(b)){FD_PrivError(2,#b,theFileNamePtr,theFileDatePtr,theFileTimePtr,__LINE__,1,1); FD_TRACE_RETURN(FD_FATAL_ERR);}}
#else
   #define FD_ASSERT_DEBUG(b) {(void)theFileNamePtr;(void)theFileDatePtr;(void)theFileTimePtr;}
#endif

/* Tracing allows to fulfill the following needs:
 *     - Identify the context of execution when a
 *       fatal error is detected.
 *     - Allows to do an estimation of the code coverage
 *       while regression testing is performed.
 *
 * Tracing is for functions returning an integer (or FD_RetCode).
 *
 * This tracing has impact only when FD_DEBUG is defined.
 *
 * Tracing should be put in at least all path that reveals
 * the user actions, and at best in all functions.
 * 
 *   FD_PROLOG:
 *        Must be specified at the very top of all functions
 *        (before the local parameters).
 *
 *   FD_TRACE_BEGIN:
 *        Must be the first line executed in the function.
 *
 *   FD_TRACE_CHECKPOINT:
 *        Shall be put into the code block{} you wish to monitor
 *        for code coverage.
 *
 *   FD_TRACE_RETURN:
 *        Must be called at all exit point of the function.
 *
 * Example:
 *
 *    FD_FILE_INFO;
 *
 *    FD_RetCode myFunction( int param )
 *    {
 *       FD_PROLOG
 *       int i, j;  
 *
 *       FD_TRACE_BEGIN(myFunction);
 *
 *       if( param == 0 )
 *       {
 *          FD_TRACE_CHECKPOINT;
 *          FD_TRACE_RETURN( FD_BAD_PARAM );
 *       }
 *       else
 *       {
 *          FD_TRACE_CHECKPOINT;
 *
 *          for( i=0; i < 10; i++ )
 *             printf( "%d", i );
 *       }
 *
 *       FD_TRACE_RETURN( FD_SUCCESS );
 *    }
 *
 * FD_ASSERT and FD_ASSERT_DEBUG are safe to be used after a FD_TRACE_BEGIN,
 *
 */

#ifdef FD_DEBUG
   #define FD_PROLOG    const char *theTraceFuncName;
   #define FD_TRACE_BEGIN(name) { FD_PrivTraceBegin( #name, theFileNamePtr, __LINE__ ); \
                                  theTraceFuncName = #name; \
								}

   #define FD_TRACE_CHECKPOINT { FD_PrivTraceCheckpoint( theTraceFuncName, theFileNamePtr, __LINE__, 0 ); }

   #define FD_TRACE_RETURN(x) { return FD_PrivTraceReturn( theTraceFuncName, theFileNamePtr, __LINE__, x ); }
#else
   #define FD_PROLOG
   #define FD_TRACE_BEGIN(x)  {(void)theFileNamePtr;(void)theFileDatePtr;(void)theFileTimePtr;}
   #define FD_TRACE_CHECKPOINT
   #define FD_TRACE_RETURN(x) {return x;}
#endif


/* Never call directly the following functions. Always use the macro define above. */
void FD_PrivTraceCheckpoint( const char *funcname,
							 const char *filename,
						     unsigned int lineNb,
                             int value );
   
FD_RetCode FD_PrivTraceReturn( const char *funcname,
						       const char *filename,
						       unsigned int lineNb,
						       FD_RetCode retCode );

void FD_PrivTraceBegin( const char *funcname,
						const char *filename, 
						unsigned int lineNb );

void FD_PrivError( unsigned int type, const char *str,
                   const char *filename, const char *date,
                   const char *time, int lineNb,
                   unsigned long j, unsigned long k  );

#endif

