/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  AC       Angelo Ciceri
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  112400 MF   First version.
 *  082004 AC   Add FD_SetCandleSettings, FD_RestoreCandleDefaultSettings
 *              and call to FD_RestoreCandleDefaultSettings in FD_Initialize
 *
 */

/* Description:
 *   Provides initialization / shutdown functionality for all modules.
 *
 *   Since not all module are used/link in the application,
 *   the fd_common simply provides the mechanism for the module
 *   to optionnaly "register" its initialization/shutdown
 *   function.
 *
 *   This whole mechanism helps the initialization of "module globals"
 *   while actually not using true globals. The fact of not having "true"
 *   globals helps to make FIDAL re-entrant.
 *
 *   This also allows to clearly define the shutdown sequence.
 */

/**** Headers ****/
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fd_common.h"
#include "fd_magic_nb.h"
#include "fd_system.h"
#include "fd_global.h"
#include "fd_string.h"
#include "fd_memory.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
extern FD_RetCode FD_TraceInit( void );

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/

/* The entry point for all globals */
FD_LibcPriv theGlobals;
FD_LibcPriv *FD_Globals = &theGlobals;

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/
int FD_IsTraceEnabled( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */

   return FD_Globals->traceEnabled;
}

void FD_TraceEnable( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */
   FD_Globals->traceEnabled = 1;
}

void FD_TraceDisable( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */
   FD_Globals->traceEnabled = 0;
}

FD_StringCache *FD_GetGlobalStringCache( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */
   return FD_Globals->dfltCache;
}

FD_RetCode FD_Initialize( const FD_InitializeParam *param )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */
   FD_RetCode retCode;
   #if !defined( FD_SINGLE_THREAD )
   unsigned int again; /* Boolean */
   unsigned int i;
   #endif

   /* Initialize the "global variable" used to manage the global
    * variables of all other modules...
    */
   memset( FD_Globals, 0, sizeof( FD_LibcPriv ) );
   FD_Globals->magicNb = FD_LIBC_PRIV_MAGIC_NB;

   if( param )
   { 
      if( param->logOutput )
      {
         /* Override someone intention to use stdin!? */
         if( param->logOutput == stdin )
            FD_Globals->stdioFile = stdout;
         else
            FD_Globals->stdioFile = param->logOutput;

         FD_Globals->stdioEnabled = 1;      
      }

      if( param->userLocalDrive )
         FD_Globals->localCachePath = param->userLocalDrive;
   }

   #if !defined( FD_SINGLE_THREAD )
      /* For multithread, allocate all semaphores
       * protecting the module's globals.
       */
      again = 1;
      for( i=0; i < FD_NB_GLOBAL_ID && again; i++ )
      {
         retCode = FD_SemaInit( &(FD_Globals->moduleControl[i].sema), 1 );
         if( retCode != FD_SUCCESS )
            again = 0;
      }

      if( again == 0 )
      {
         /* Clean-up and exit. */
         for( i=0; i < FD_NB_GLOBAL_ID; i++ )
            FD_SemaDestroy( &(FD_Globals->moduleControl[i].sema) );

         memset( FD_Globals, 0, sizeof( FD_LibcPriv ) );

         return FD_INTERNAL_ERROR(4);
      }

   #endif
	  
   /* Force immediatly the initialization of the memory module. 
    * Note: No call to the tracing capability are allowed in FD_MemInit.
    */
   retCode = FD_MemInit( sizeof( FD_LibcPriv ) );

   /* Force immediatly the initialization of the tracing module. */
   if( retCode == FD_SUCCESS )
      retCode = FD_TraceInit();

   if( retCode != FD_SUCCESS )
   {
      /* Clean-up and exit. */
      #if !defined( FD_SINGLE_THREAD )
      for( i=0; i < FD_NB_GLOBAL_ID; i++ )
         FD_SemaDestroy( &(FD_Globals->moduleControl[i].sema) );
      #endif
      memset( FD_Globals, 0, sizeof( FD_LibcPriv ) );

      return FD_INTERNAL_ERROR(5);
   }

   /* Tracing can now be safely used by the memory module until
    * shutdown in FD_Shutdown.
    */
   FD_Globals->traceEnabled = 1;


   /*** At this point, FD_Shutdown can be called to clean-up. ***/


   /* Allocate the default string cache used throughout the library. */
   retCode = FD_StringCacheAlloc( &(FD_Globals->dfltCache) );

   if( retCode != FD_SUCCESS )
   {
      FD_Shutdown();
      return retCode;
   }

   /* Seeds random generator */
   srand( (unsigned)time( NULL ) );

   return FD_SUCCESS;
}

FD_RetCode FD_Shutdown( void )
{
   /* Note: Keep that function simple.
    *       No tracing and no assert.
    */
   const FD_GlobalControl *control;
   unsigned int i;
   FD_RetCode retCode, finalRetCode;

   if( FD_Globals->magicNb != FD_LIBC_PRIV_MAGIC_NB )
      return FD_LIB_NOT_INITIALIZE;

   /* Will change if an error occured at any point. */
   finalRetCode = FD_SUCCESS;

   /* Shutdown all the modules who were initialized.
    * Also destroy the corresponding semaphore.
    */
   for( i=0; i < FD_NB_GLOBAL_ID; i++ )
   {
	  /* Disable tracing when starting to shut down
	   * the tracing module. This is to avoid that
	   * the memory module starts do some tracing while we
	   * are shutting down the tracing itself!!!
	   */
	  if( i == FD_TRACE_GLOBAL_ID )
         FD_Globals->traceEnabled = 0;

      #if !defined( FD_SINGLE_THREAD )
      if( FD_Globals->moduleControl[i].sema.flags & FD_SEMA_INITIALIZED )
      {
         retCode = FD_SemaWait( &(FD_Globals->moduleControl[i].sema) );
         if( retCode != FD_SUCCESS )
            finalRetCode = retCode;
      #endif

         /* Just before shutting down the fd_memory module,
          * free the global string cache.
          */
         if( (i == FD_MEMORY_GLOBAL_ID) && (FD_Globals->dfltCache) )
         {
            retCode = FD_StringCacheFree( FD_Globals->dfltCache );
            if( retCode != FD_SUCCESS )
               finalRetCode = retCode;
         }

         if( FD_Globals->moduleControl[i].initialize )
         {
            control = FD_Globals->moduleControl[i].control;
            if( control && control->shutdown )
            {
               retCode = (*control->shutdown)( FD_Globals->moduleControl[i].global );
               if( retCode != FD_SUCCESS )
                  finalRetCode = retCode;
            }
            FD_Globals->moduleControl[i].initialize = 0;
         }

      #if !defined( FD_SINGLE_THREAD )
         retCode = FD_SemaDestroy( &(FD_Globals->moduleControl[i].sema) );
         if( retCode != FD_SUCCESS )
            finalRetCode = retCode;
      }
      #endif
   }

   /* Initialize to all zero to make sure we invalidate that object. */
   memset( FD_Globals, 0, sizeof( FD_LibcPriv ) );

   return finalRetCode;
}

/* This function return a pointer on the global variable for
 * a particular module.
 * If the global variables are NOT initialized, this function will
 * call the corresponding 'init' function for this module.
 */
FD_RetCode FD_GetGlobal( const FD_GlobalControl * const control,
                         void **global )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */

   FD_GlobalModuleId id;
   FD_RetCode retCode, finalRetCode;
   const FD_GlobalControl * const locControl = control;

   /* Validate parameters */
   if( !control || !global )
      return FD_FATAL_ERR;

   *global = NULL;

   id = control->id;
   if( id >= FD_NB_GLOBAL_ID )
      return FD_FATAL_ERR;

   if( FD_Globals->moduleControl[id].initialize )
   {
      /* This module is already initialized, just return the global. */
      *global = FD_Globals->moduleControl[id].global;
      return FD_SUCCESS;
   }

   /* This module did not yet get its global initialized. Let's do it. */

   /* Will change if anything goes wrong in the following critical section. */
   finalRetCode = FD_SUCCESS;

   #if !defined( FD_SINGLE_THREAD )
   if( !(FD_Globals->moduleControl[id].sema.flags&FD_SEMA_INITIALIZED) )
      return FD_FATAL_ERR;

   retCode = FD_SemaWait( &(FD_Globals->moduleControl[id].sema) );
   if( retCode != FD_SUCCESS )
      return FD_FATAL_ERR;

   /* Check again if initialize AFTER we got the semaphore. */
   if( !FD_Globals->moduleControl[id].initialize )
   {
   #endif

      /* The module needs to be initialized. Call the corresponding
       * 'init' function.
       */
      if( !FD_Globals->moduleControl[id].control )
         FD_Globals->moduleControl[id].control = locControl;         

      if( locControl->init )
      {
         retCode = (*locControl->init)( &(FD_Globals->moduleControl[id].global) );

         if( retCode != FD_SUCCESS )
            finalRetCode = retCode;
         else
            FD_Globals->moduleControl[id].initialize = 1;
      }

   #if !defined( FD_SINGLE_THREAD )
   }
   retCode = FD_SemaPost( &(FD_Globals->moduleControl[id].sema) );
   if( retCode != FD_SUCCESS )
      finalRetCode = FD_FATAL_ERR;
   #endif

   /* Verify if an error occured inside the critical section. */
   if( finalRetCode != FD_SUCCESS )
      return finalRetCode;

   if( FD_Globals->moduleControl[id].initialize )
   {
      /* Ok, everything is now alloc/initialized at this point, simply
       * return the pointer on the "global variable" for this module.
       */
      *global = FD_Globals->moduleControl[id].global;
   }
   else
      return FD_FATAL_ERR;

   return FD_SUCCESS;
}

FILE *FD_GetStdioFilePtr( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */

   if( FD_Globals->stdioEnabled )
      return FD_Globals->stdioFile;

   return NULL;
}

const char *FD_GetLocalCachePath( void )
{
   /* Note: Keep that function simple.
    *       No tracing, no stdio and no assert.
    */
   if( FD_Globals->localCachePath )
      return FD_Globals->localCachePath;

   return NULL;
}

/**** Local functions definitions.     ****/
/* None */


