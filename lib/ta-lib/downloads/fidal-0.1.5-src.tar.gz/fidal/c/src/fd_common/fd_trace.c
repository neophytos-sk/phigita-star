/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  112400 MF   First version.
 *  110803 MF   Implementation of FD_FatalReportToBuffer
 *  110903 MF   Add logging of return code, make sure logging
 *              occurs only when FD_DEBUG is defined, display
 *              compiler defines on fatal error.
 *  050104 MF   Add FD_RegressionTest.
 */

/* Description:
 *   Implements logging and tracing capability.
 *   See header file for details on how to use that module.
 */

/**** Headers ****/
#include <stdio.h>
#include <string.h>
#include "fd_global.h"
#include "fd_trace.h"
#include "fidal.h"
#include "fd_list.h"
#include "fd_dict.h"
#include "fd_memory.h"
#include "fd_system.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/

#if defined(FD_DEBUG)
   /* Size of circular buffer for code trace. */
   #define FD_CODE_TRACE_SIZE   15
#endif

typedef struct
{
    const char *funcname;
    const char *filename;
    unsigned int lineNb;
    unsigned int repetition; /* Keep count of consecutive passage at this position. */
    int value; /* Keep track of return code (when applicable) */
} FD_TracePosition;

typedef struct
{
   FD_TracePosition position;
   char *str;
   const char *date;
   const char *time;
   unsigned long param1;
   unsigned long param2;
   unsigned int type;
} FD_FatalErrorLog;

typedef struct
{
   #if !defined( FD_SINGLE_THREAD )
      /* If multithread, access to variables related to the
       * call stack and code trace are protected by callSema.
        */
      FD_Sema callSema;

      /* If multithread, access to variables related to the
       * logging of the fatal error is protected by fatalSema.
        */
      FD_Sema fatalSema;
   #endif

   #ifdef FD_DEBUG
      #if defined( FD_SINGLE_THREAD )     
          /* Maintain a call stack using FD_TRACE_BEGIN and FD_TRACE_RETURN.
           * This functionality makes no sense if multithread.
           */
          FD_List *callStack;
      #endif

       /* Maintain a complete dictionary of the function being called.
        * Used to evaluate the code coverage and do some profiling.
        * The element of the dictionary are FD_TracePosition.
        * The key of each entry are the merge of the line number merge with
        * the filename.
        */
       FD_Dict *functionCalled; 

       /* Maintain a code trace by using the FD_TRACE_BEGIN,
        * FD_TRACE_RETURN and FD_TRACE_CHECKPOINT.
        * Tracing is put in a circular buffer.
        */
       FD_TracePosition codeTrace[FD_CODE_TRACE_SIZE];
       unsigned int posForNextTrace;
   #endif

   /* Log the first occurence of a fatal error. */
   FD_FatalErrorLog fatalError;
   unsigned int fatalErrorRecorded;

    /* User of the library can install its own exception handler
     * to intercept the fatal error.
     * Will be NULL if no handler installed.
    */
   FD_FatalHandler userHandler;
} FD_TraceGlobal;


/**** Local functions declarations.    ****/
static void printFatalError( FD_FatalErrorLog *log, FD_PrintfVar *outp );
static void doFatalReport( FD_PrintfVar *outp );

#ifdef FD_DEBUG
static void internalCheckpoint( FD_TraceGlobal *global,
                                FD_String *key,
                                const char *funcname,
                                const char *filename,
                                unsigned int lineNb,
                                int value );

static void freeTracePosition( void *dataToBeFreed );
static FD_TracePosition *newTracePosition( const char *funcname, 
                                           const char *filename,
                                           unsigned int lineNb,
                                           int value );

static void printTracePosition( FD_TracePosition *tracePosition, FD_PrintfVar *outp );
#endif

static FD_RetCode FD_TraceGlobalShutdown( void *globalAllocated );
static FD_RetCode FD_TraceGlobalInit( void **globalToAlloc );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

const FD_GlobalControl FD_TraceGlobalControl =
{
   FD_TRACE_GLOBAL_ID,
   FD_TraceGlobalInit,
   FD_TraceGlobalShutdown
};

/**** Global functions definitions.   ****/
FD_RetCode FD_TraceInit( void )
{
   FD_RetCode retCode;
   FD_TraceGlobal *global;

   /* "Getting" the global will allocate/initialize the global for
    * this module. 
    * Note: All this will guarantee that FD_TraceGlobalShutdown
    *       will get called when FD_Shutdown is called by the
    *       library user.
    */
   retCode = FD_GetGlobal(  &FD_TraceGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

#ifdef FD_DEBUG
void FD_PrivTraceCheckpoint( const char *funcname,
                             const char *filename,
                             unsigned int lineNb,
                             int value )
{
   FD_TraceGlobal *global;
   FD_RetCode retCode;

   #if defined( FD_DEBUG )
      FD_String *key;
      FD_StringCache *stringCache;
   #endif

   /* Get access to the global. */
   retCode = FD_GetGlobal( &FD_TraceGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return;

   /* Build a unique string representing the position. */
   stringCache = FD_GetGlobalStringCache();
   key = FD_StringValueAlloc( stringCache, filename, lineNb );
   if( !key )
      return;

   internalCheckpoint( global, key, funcname, filename, lineNb, value );

   FD_StringFree( stringCache, key );
}
#endif

#ifdef FD_DEBUG
FD_RetCode FD_PrivTraceReturn( const char *funcname,
                               const char *filename,
                               unsigned int lineNb,
                               FD_RetCode retCode )
{
   #if defined( FD_SINGLE_THREAD )
   FD_TracePosition *tracePosition;
   FD_TraceGlobal *global;
   FD_RetCode localRetCode;
   #endif

   FD_PrivTraceCheckpoint( funcname, filename, lineNb, retCode );

   /* If debugging a single threaded, maintain a calling stack. */
   #if defined( FD_DEBUG ) && defined( FD_SINGLE_THREAD )
      if( !FD_IsTraceEnabled() )
      {
         /* Disable tracing within tracing! */
         FD_TraceDisable();

         /* Get access to the global. */
         localRetCode = FD_GetGlobal(  &FD_TraceGlobalControl, (void **)&global );
         if( localRetCode != FD_SUCCESS )
            return retCode;

         tracePosition = FD_ListRemoveTail( global->callStack );

         if( tracePosition )
         {
            --tracePosition->repetition;
            if( tracePosition->repetition == 0 )
               FD_Free( tracePosition );
            else
               FD_ListAddTail( global->callStack, tracePosition );
         }

         FD_TraceEnable();
      }
   #endif

   return retCode;
}
#endif

#ifdef FD_DEBUG
void FD_PrivTraceBegin( const char *funcname,
                        const char *filename, 
                        unsigned int lineNb )
{
   #if defined( FD_DEBUG) && defined( FD_SINGLE_THREAD )
   unsigned int newTracePositionNeeded; /* Boolean */
   FD_TracePosition *tracePosition;
   FD_TraceGlobal *global;
   FD_RetCode retCode;
   #endif

   /* Entry point of a function are "checkpoint" for code
    * coverage.
    */
   FD_PrivTraceCheckpoint( funcname, filename, lineNb, 0 );

   /* If debugging a single thread, maintain a call stack. */
   #if defined( FD_DEBUG ) && defined( FD_SINGLE_THREAD )
      if( FD_IsTraceEnabled() )
      {
         /* Disable tracing within tracing! */
         FD_TraceDisable();

         /* Get access to the global. */
         retCode = FD_GetGlobal( &FD_TraceGlobalControl, (void **)&global );
         if( retCode != FD_SUCCESS )
            return;

         tracePosition = FD_ListRemoveTail( global->callStack );
         newTracePositionNeeded = 1;
         if( tracePosition )
         {
             /* Check if last trace in the stack is the same function. */
             if( (tracePosition->filename == filename) &&
                 (tracePosition->funcname == funcname) )
            {
               /* Same function, so just increment the repetition. */
               tracePosition->repetition++;
               newTracePositionNeeded = 0;
            }
            else /* Not the same function, put back this trace. */
               FD_ListAddTail( global->callStack, tracePosition );
         }

         /* New function, so add the trace to the stack. */
         if( newTracePositionNeeded )
         {
            tracePosition = newTracePosition( funcname, filename, lineNb, 0 );
            if( tracePosition )      
               FD_ListAddTail( global->callStack, (void *)tracePosition );
         }

         /* Re-enable tracing. */
         FD_TraceDisable();
      }
   #endif
}
#endif

void FD_PrivError( unsigned int type, const char *str,
                   const char *filename, const char *date,
                   const char *time, int line,
                   unsigned long j, unsigned long k )
{
   FD_RetCode retCode;
   FD_TraceGlobal *global;
   unsigned int length;

   retCode = FD_GetGlobal( &FD_TraceGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return;

   /* If a fatal error already got handled, return
    * immediatly.
    */
   if( global->fatalErrorRecorded )
      return;

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaWait( &global->callSema );
      if( retCode != FD_SUCCESS )
         return;
   #endif

   /* Double-check inside the critical section. */
   if( global->fatalErrorRecorded )
   {
      #if !defined( FD_SINGLE_THREAD )
         FD_SemaPost( &global->callSema );
      #endif
      return;
   }

   global->fatalErrorRecorded = 1;

   /* Log the fatal error. */
   global->fatalError.position.filename = filename;
   global->fatalError.position.funcname = NULL;
   global->fatalError.position.lineNb = line;
   global->fatalError.position.repetition = 1;
   global->fatalError.position.value = 0;

   global->fatalError.str = NULL;
   if( str ) 
   {
      length = strlen( str ) + 1;
      if( length != 0 )
      {
         global->fatalError.str = (char *)FD_Malloc( length );
         memcpy( global->fatalError.str, str, length );
      }
   }

   global->fatalError.date = date;
   global->fatalError.time = time;
   global->fatalError.param1 = j;
   global->fatalError.param2 = k;
   global->fatalError.type = type;

   /* Call the user handler. */
   if( global->userHandler )
      global->userHandler();

   #if !defined( FD_SINGLE_THREAD )
   FD_SemaPost( &global->callSema );
   #endif
}

void FD_FatalReport( FILE *out )
{
   FD_PrintfVar outp;

   memset( &outp, 0, sizeof(outp) );
   outp.file = out;
   doFatalReport( &outp );
}


void FD_FatalReportToBuffer( char *buffer, unsigned int bufferSize )
{
   FD_PrintfVar outp;

   if( !buffer || bufferSize <= 0 )
      return;

   *buffer = '\0';

   memset( &outp, 0, sizeof(FD_PrintfVar) );
   outp.buffer = buffer;
   outp.size   = bufferSize;
   memset( outp.buffer, 0, outp.size );
   doFatalReport( &outp );
}

FD_RetCode FD_SetFatalErrorHandler( FD_FatalHandler handler )
{
   FD_TraceGlobal *global;
   FD_RetCode retCode;

   retCode = FD_GetGlobal(  &FD_TraceGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
       return retCode;

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaWait( &global->callSema );
      if( retCode != FD_SUCCESS )
         return retCode;
   #endif

   global->userHandler = handler;

   #if !defined( FD_SINGLE_THREAD )
      FD_SemaPost( &global->callSema );
   #endif

   return FD_SUCCESS;
}

FD_RetCode FD_RegressionTest( FD_RegressionTestId id )
{
   FD_PROLOG;

   FD_TRACE_BEGIN("FD_RegressionTest");

   /* Code for testing a FD_ASSERT.
    *
    * A failed assert trigs a fatal error, so the function
    * will return with FD_FATAL_ERR. The application is not
    * exited.
    *
    * If the user did provide an handler, it will get called.
    */
   FD_ASSERT( id != FD_REG_TEST_ASSERT_FAIL );

   /* Other tests... */
   switch( id )
   {
   case FD_REG_TEST_FATAL_ERROR:
      /* Force a fatal error. The function returns
       * with FD_FATAL_ERR. The application is not
       * exited.
       * If the user did provide an handler, it will get called.
       */ 
      FD_FATAL("Test",0x01234567,0x89ABCDEF);
      /* break; comment out to eliminate warning of un-reachable code */
   case FD_REG_TEST_ASSERT_FAIL:
      /* Should never happen since the assert above
       * should return from this function.
       */
      FD_FATAL("Should have return",FD_REG_TEST_ASSERT_FAIL,id);
      /* break; comment out to eliminate warning of un-reachable code */
   default:
      FD_TRACE_RETURN(FD_BAD_PARAM);
   }   
}

/**** Local functions definitions.     ****/
static void printFatalError( FD_FatalErrorLog *log, FD_PrintfVar *outp )
{
   unsigned int type;
   static char *errorType[] = { "Fatal", "Assert", "Debug Assert", "Warning", "Unknown" };
   const char *version;

   type = log->type;

   if( type >= (sizeof(errorType)/sizeof(char *)) )
      type = (sizeof(errorType)/sizeof(char *)) - 1;

   FD_Printf( outp, "*** Internal %s Error ***\n", errorType[type]);
   version = FD_GetVersionString();
   if( version )
      FD_Printf( outp, "Version:[%s]  ", version );

   /* Display compilation options */
   FD_Printf( outp, "[" );
   #ifdef FD_DEBUG
      FD_Printf( outp, " FD_DEBUG" );
   #endif
   #ifdef FD_SINGLE_THREAD
      FD_Printf( outp, " FD_SINGLE_THREAD" );
   #endif
   #ifdef WIN32
      FD_Printf( outp, " WIN32" );
   #endif
   FD_Printf( outp, " ]\n" );

   /* Display File desription, error position and compilation date.  */
   if( log->position.filename )
   {
       FD_Printf( outp, "File:[%s]\n", log->position.filename );
       FD_Printf( outp, "Line:[%d]    ", log->position.lineNb );
   }

   if( log->date && log->time )
       FD_Printf( outp, "Comp:[%s %s]\n", log->date, log->time );

   if( log->position.funcname )
       FD_Printf( outp, "Func:[%s]\n", log->position.funcname );
    
   if( log->str )
       FD_Printf( outp, "Desc:[%s]\n", log->str );

   /* Display information that was provided with this fatal error */
   FD_Printf( outp, "Info:[0x%08X,0x%08X]\n", log->param1, log->param2 );
}

static FD_RetCode FD_TraceGlobalInit( void **globalToAlloc )
{
   FD_TraceGlobal *global;
   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif

   if( !globalToAlloc )
      return FD_BAD_PARAM;

   *globalToAlloc = NULL;

   global = FD_Malloc( sizeof( FD_TraceGlobal ) );
   if( !global )
      return FD_ALLOC_ERR;

   memset( global, 0, sizeof( FD_TraceGlobal ) );

   #if !defined( FD_SINGLE_THREAD )
      /* Initialize the mutexes in a non-block state. */
      retCode = FD_SemaInit( &global->callSema, 1 );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(  global );
         return retCode;
      }
      retCode = FD_SemaInit( &global->fatalSema, 1 );
      if( retCode != FD_SUCCESS )
      {
         FD_SemaDestroy( &global->callSema );
         FD_Free(  global );
         return retCode;
      }
   #endif

   #ifdef FD_DEBUG   
      #if defined( FD_SINGLE_THREAD )
         /* When single threaded, maintain a calling stack. */      

         global->callStack = FD_ListAlloc();
         if( !global->callStack )
         {
            FD_Free(  global );
            return FD_ALLOC_ERR;
         }
      #endif

      /* All function call and checkpoint are maintained in a dictionary. */
      global->functionCalled = FD_DictAlloc( FD_DICT_KEY_ONE_STRING, freeTracePosition );
      if( !global->functionCalled )
      {
         #if !defined( FD_SINGLE_THREAD )
            FD_SemaDestroy( &global->callSema );
            FD_SemaDestroy( &global->fatalSema );      
         #else
            FD_ListFree( global->callStack );
         #endif      
         FD_Free(  global );
         return FD_ALLOC_ERR;
      }
   #endif

   /* Success, return the allocated memory to the caller. */
   *globalToAlloc = global;

   return FD_SUCCESS;
}

static FD_RetCode FD_TraceGlobalShutdown( void *globalAllocated )
{
   FD_TraceGlobal *global;
   FD_RetCode retCode = FD_SUCCESS;

   global = (FD_TraceGlobal *)globalAllocated;

   if( !global )
      return retCode;

   if( global->fatalError.str )
      FD_Free(  global->fatalError.str );

   #if !defined( FD_SINGLE_THREAD )      
      retCode = FD_SemaDestroy( &global->fatalSema );
      retCode = FD_SemaDestroy( &global->callSema );
   #endif

   #ifdef FD_DEBUG
      #if defined( FD_SINGLE_THREAD )
         if( global->callStack )
            FD_ListFree( global->callStack );
      #endif

      if( global->functionCalled )
         FD_DictFree( global->functionCalled );
   #endif

   FD_Free(  global );

   return retCode;
}

#ifdef FD_DEBUG
static void internalCheckpoint( FD_TraceGlobal *global,
                                FD_String  *key,
                                const char *funcname,
                                const char *filename,
                                unsigned int lineNb,
                                int value )
{
   #if !defined( FD_SINGLE_THREAD )      
   FD_RetCode retCode;
   #endif

   FD_TracePosition *tracePosition;

   /* Make sure there is no tracing while tracing!
    * In rare occasion, this may prevent to record
    * some tracing in a multithread environment.
    * We can live with that compromise.
    */   
   if( !FD_IsTraceEnabled() )
      return;

   #if !defined( FD_SINGLE_THREAD )                   
      retCode = FD_SemaWait( &global->callSema );
      if( retCode != FD_SUCCESS )
         return;   
   #endif

   /* If this position is already in the dictionary, just
    * increment the 'repetition' counter, else create
    * a new entry in the dictionary.
    */
   FD_TraceDisable();
   tracePosition = FD_DictGetValue_S( global->functionCalled, FD_StringToChar(key) );
   FD_TraceEnable();

   if( tracePosition && (tracePosition->value == value) )
      tracePosition->repetition++;
   else
   {
      tracePosition = newTracePosition( funcname, filename, lineNb, value );

      if( !tracePosition )
      {
         #if !defined( FD_SINGLE_THREAD )
            FD_SemaPost( &global->callSema );
         #endif
         return;
      }
      FD_TraceDisable();
      FD_DictAddPair_S( global->functionCalled, key, (void *)tracePosition );
      FD_TraceEnable();
   }
   /* Trace position are never deleted, until the library is shutdown.
    * Make a copy of it in the circular buffer.
    */
   global->codeTrace[global->posForNextTrace] = *tracePosition;

   /* Move to the next entry in the circular buffer. */
   global->posForNextTrace++;
   if( global->posForNextTrace >= FD_CODE_TRACE_SIZE )
      global->posForNextTrace = 0;

   #if !defined( FD_SINGLE_THREAD )
   FD_SemaPost( &global->callSema );
   #endif
}
#endif

#ifdef FD_DEBUG
static FD_TracePosition *newTracePosition( const char *funcname, 
                                           const char *filename,
                                           unsigned int lineNb,
                                           int value )
{
   FD_TracePosition *tracePosition;

   tracePosition = (FD_TracePosition *)FD_Malloc( sizeof(FD_TracePosition) );
   if( !tracePosition )
       return NULL;

   tracePosition->filename = filename;
   tracePosition->funcname = funcname;
   tracePosition->lineNb = lineNb;
   tracePosition->repetition = 1;
   tracePosition->value = value;

   return tracePosition;
}

static void freeTracePosition( void *dataToBeFreed )
{
   FD_Free( dataToBeFreed );
}

static void printTracePosition( FD_TracePosition *tracePosition, FD_PrintfVar *outp )
{
   const char *filename;
   int seperatorChar;

   if( !tracePosition )
      return;

   /* Strip off the path. */
   if( !tracePosition->filename )
      filename = NULL;
   else
   {
      seperatorChar = FD_SeparatorASCII();
      filename = strrchr( tracePosition->filename, seperatorChar );
      if( !filename )
         filename = tracePosition->filename;

      if( filename[0] == seperatorChar && seperatorChar != '\0' )
         filename++;
   }

   FD_Printf( outp, "(%03d)Line:[%04d][%s,%s]",
              tracePosition->repetition,
              tracePosition->lineNb,
              tracePosition->funcname?tracePosition->funcname:"(null)",
              filename?filename:"(null)" );

   if( tracePosition->value != 0 )
      FD_Printf( outp, " [0x%08X]\n", tracePosition->value );
   else
      FD_Printf( outp, "\n" );
}
#endif

static void doFatalReport( FD_PrintfVar *outp )
{
   FD_TraceGlobal *global;
   FD_RetCode retCode;
   #ifdef FD_DEBUG
   FD_TracePosition *tracePosition;
   unsigned int i, pos, outputTrace;
   #endif

   retCode = FD_GetGlobal(  &FD_TraceGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
       return;

   if( global->fatalErrorRecorded )
      printFatalError( &global->fatalError, outp );
   else
      FD_Printf( outp, "No fatal error" ); 

   /* Output the calling sequence. */
   #ifdef FD_DEBUG
      pos = global->posForNextTrace;
      outputTrace = 0;

      for( i=0; i < FD_CODE_TRACE_SIZE; i++ )
      {    
         tracePosition = &global->codeTrace[pos];
         if( tracePosition && tracePosition->repetition )
         {
            if( outputTrace++ == 0 )
               FD_Printf( outp, "Execution Sequence:\n" );

            printTracePosition( tracePosition, outp );
         }
         pos++;
         if( pos >= FD_CODE_TRACE_SIZE )
            pos = 0;
      }

      if( outputTrace != 0 )
         FD_Printf( outp, "End of Execution Sequence.\n" );
      else
         FD_Printf( outp, "Execution Sequence Empty.\n" );
   #else
      FD_Printf( outp, "Sequence Not Recorded in release build.\n" );
   #endif
}
