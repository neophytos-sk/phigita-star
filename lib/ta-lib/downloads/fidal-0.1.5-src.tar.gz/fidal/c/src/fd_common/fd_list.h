#ifndef FD_LIST_H
#define FD_LIST_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#include "kazlib/kaz_list.h"

/* This module implements an efficient list container.
 *
 * This implementation is just a list of opaque
 * pointers (void *). All value for the (void *) are
 * valid, except NULL.
 *
 * The list DOES NOT own its elements. So freeing the list
 * does not free the elements the (void *) are pointing to
 * (except if you use FD_ListFreeAll).
 *
 * The implementation is simplified by not having to manipulate 
 * 'node' structure for the elements in the list.
 *
 * This module offer the following operations:
 *        - Create/Destroy a list.
 *        - Append/Prepend a (void *) to the list.
 *        - Remove first/last (void *) in the list.
 *        - Remove a particular (void *) in the list.
 *        - Sequential access to the list.
 *        - Return the size of a list.
 *
 * Note: This module is not multithread safe, and the user must provide
 *       adequate protection in a multithread environment.
 *
 *
 * Speed Optimization with pre-allocated FD_List/FD_ListNode
 * ---------------------------------------------------------
 * It is possible for the caller to provide pre-allocated
 * FD_List and/or FD_ListNode.
 *
 * A FD_List can be pre-allocated, and the elements can be dynamic
 * (and vice-versa). The only limitation is if you start to use
 * pre-allocated FD_ListNode, all elements must be pre-allocated, 
 * else FD_INVALID_LIST_TYPE will be returned.
 * In the same way, as soon you add a dynamic element, no pre-allocated
 * element can be added to the same list from that point. All this can
 * be summarize by the following limitation rule:
 *   "For a given list, the FD_ListAddXXXX() and
 *    FD_ListNodeAddXXXX() functions cannot be mixed."
 *
 */
typedef struct
{
   /* Hidden implementation. Never touch these. Never. */
   list_t d;
   lnode_t *node;
   unsigned int flags;
} FD_List;

typedef struct
{
   /* FD_ListNode is useful only if you wish to prevent
    * the FD_List module to do any memory allocation.
    */

   /* Hidden implementation. Never touch these. Never. */
   lnode_t node;
} FD_ListNode;

/* Create an empty list.
 *
 * Return: An handle used to manipulate the list or NULL if
 *         there is an allocation error.
 */
FD_List *FD_ListAlloc( void );

/* Free a list.
 *
 * Basically, all internal ressource to maintain the
 * FD_List are freed. Remember that the list does not
 * own its element. To free the element, the function
 * FD_ListFreeAll can make it convenient for the user
 * by calling a user provided "free" function for all
 * the elements.
 *
 * This function will not attempt to free a pre-allocated
 * FD_List (as expected). The list will be emptied though.
 * 
 * This call on a FD_List using pre-allocated
 * FD_ListNode will correctly free the list, but
 * will leave the FD_ListNode untouch (as expected).
 *
 * At this point, you probably understand that if
 * you call FD_ListFree on a pre-allocated FD_List
 * using pre-allocated FD_ListNode, nothing will be
 * done (nothing needs to be freed!).
 *
 * Return: FD_SUCCESS or FD_BAD_PARAM.
 */
FD_RetCode FD_ListFree( FD_List *list );

/* Free all elements in the list and the list itself.
 *
 * The provided 'freeFunc' will be called for each element
 * before releasing all internal ressources.
 *
 * No need to call FD_ListFree after this call.
 *
 * In other word, this function will first ALWAYS call
 * the provided function with all the (void *) currenlty 
 * in the list and then do the equivalent of a FD_ListFree.
 *
 * Return: FD_SUCCESS or FD_BAD_PARAM.
 */
FD_RetCode FD_ListFreeAll( FD_List *list,
                           FD_RetCode (*freeFunc)(  void *toBeFreed ));

/* Initialize a pre-allocated list. 
 *
 * Example:
 *      FD_List myList;
 *      FD_ListInit(  &myList );
 *      'myList' can be used from this point.
 *
 * This function can replace the slower FD_ListAlloc if
 * the application has already a FD_List allocated.
 */
void FD_ListInit( FD_List *list );

/* Add a (void *) to the list.
 *
 * Return: FD_SUCCESS, FD_BAD_PARAM, FD_INVALID_LIST_TYPE or FD_ALLOC_ERR.
 *
 * Following this call, the FD_ListNodeAddXXXX() functions cannot be called.
 */
FD_RetCode FD_ListAddTail( FD_List *list, void *newElement );
FD_RetCode FD_ListAddHead( FD_List *list, void *newElement );

FD_RetCode FD_ListAddBefore( FD_List *list, void *element, void *newElement );
FD_RetCode FD_ListAddAfter ( FD_List *list, void *element, void *newElement );

/* Add a (void *) to the list.
 *
 * Return: FD_SUCCESS, FD_BAD_PARAM, FD_INVALID_LIST_TYPE or FD_ALLOC_ERR.
 *
 * Following this call, the FD_ListAddXXXX() functions cannot be called.
 */
FD_RetCode FD_ListNodeAddTail( FD_List *list, FD_ListNode *node, void *newElement );
FD_RetCode FD_ListNodeAddHead( FD_List *list, FD_ListNode *node, void *newElement );

#if 0
!!! Not yet implemented
FD_RetCode FD_ListNodeAddBefore( FD_List *list, FD_ListNode *node, void *element, void *newElement );
FD_RetCode FD_ListNodeAddAfter ( FD_List *list, FD_ListNode *node, void *element, void *newElement );
#endif

/* Remove a (void *) from the list.
 *
 * Return: The removed (void *) or NULL if empty list.
 */
void *FD_ListRemoveTail( FD_List *list );
void *FD_ListRemoveHead( FD_List *list );

/* Remove a particular (void *) from the list.
 *
 * Return: FD_SUCCESS or FD_BAD_PARAM.
 */
FD_RetCode FD_ListRemoveEntry( FD_List *list, void *elementToRemove );

/* Return the number of element in the list. */
unsigned int FD_ListSize( FD_List *list );

/* The built-in iterator
 *
 * This is a very simplified iterator for accessing sequentially (only)
 * a FD_List.
 *
 * Note: This is a speed efficient/simplified implementation of an iterator.
 *       Since this simplified iterator is embedded within the FD_List, it must
 *       be used only by one thread (context). For using multiple iterator
 *       on the same list, use the FD_ListIterXXXXX functions.
 *
 * Here is a code snippet printing all the content of 'list':
 * (Assuming the 'void *' in the 'list' are pointer to string).
 *
 * void printContent( FD_List *list )
 * {
 *    char *element;
 *
 *    element = FD_ListAccessHead( list );
 *
 *    if( element == NULL )
 *       printf( "List is empty!\n" );
 *    else
 *    {
 *       do
 *       {
 *          printf( "%s\n", (const char *)element );
 *          element = FD_ListAccessNext( list );
 *       } while( element );
 *    }
 * }
 */
void *FD_ListAccessHead( FD_List *list );
void *FD_ListAccessTail( FD_List *list );
void *FD_ListAccessNext( FD_List *list );
void *FD_ListAccessPrev( FD_List *list );

void *FD_ListAccessCurrent( FD_List *list );

/* Access the list using an independant iterator.
 *
 * This iterator allows sequential and random access to the list. Multiple
 * iterator can be used on the same FD_List.
 *
 * Random access can be achieved by keeping a copy of the actual position in
 * the list with the FD_ListIterSavePos, FD_ListIterRestorePos functions.
 * Multiple position can be indepedently saved. It is the responsibility of the
 * caller to make sure that the list is not modified while these saved position
 * are used! So keep in mind that these random access are working only with
 * un-modified FD_List.
 *
 * Note: The FD_ListIter functions can be used simultaneously and indepedently
 *       of the simpler FD_ListAccess functions.
 *
 * Example:
 * In this example, we print the content of a FD_List. For demo
 * purpose we re-print the first element by using the save/restore
 * capability (would be easier to simply call again FD_ListIterHead...).
 *
 * void printContent( FD_List *list )
 * {
 *    char *element;
 *    FD_ListIter iter;
 *    FD_ListIterPos iterPos;
 *
 *    FD_ListIterInit( &iter, list );
 *    element = FD_ListIterHead( &iter );
 *
 *    if( element == NULL )
 *       printf( "List is empty!\n" );
 *    else
 *    {
 *       FD_ListIterSavePos( &iter, &iterPos );
 *
 *       do
 *       {
 *          printf( "%s\n", element );
 *          element = FD_ListIterNext( &iter );
 *       } while( element );
 *
 *       element = FD_ListIterRestorePos( &iterPos );
 *       printf( "First element is %s", element );
 *    }
 * }
 */

typedef struct
{
  /* User should not access these fields directly. */
  FD_List *list;
  void *currentNode;
} FD_ListIter;

typedef struct
{
  /* User should not access these fields directly. */
  FD_ListIter *iter;
  void *savedNode;
} FD_ListIterPos;

FD_RetCode FD_ListIterInit( FD_ListIter *iter, FD_List *list );

void *FD_ListIterHead( FD_ListIter *iter );
void *FD_ListIterNext( FD_ListIter *iter );
void *FD_ListIterPrev( FD_ListIter *iter );
void *FD_ListIterTail( FD_ListIter *iter );
void *FD_ListIterCur ( FD_ListIter *iter );

FD_RetCode FD_ListIterSavePos   ( FD_ListIter *iter, FD_ListIterPos *iterPos );
void      *FD_ListIterRestorePos( FD_ListIterPos *iterPos );

/* Sort a list using the provided compare function:
 *    int compare(const void *, const void *)
 */
FD_RetCode FD_ListSort( FD_List *list, int compare(const void *, const void *) );

/* Remove duplicate from the list using the provided equal function:
 *     int equal(const void *, const void *)
 *
 * equal must return 1 when the two elements are considered duplicate, else
 * return 0.
 */
FD_RetCode FD_ListRemoveDuplicate( FD_List *list, 
                                   int equal(const void *, const void *),
                                   FD_RetCode (*freeFunc)( void *toBeFreed ) );
#endif
