#ifndef FD_STRING_H
#define FD_STRING_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

/* This is a very simple reference counting for small CONSTANT string.
 * This allows to manage efficiently "copies" of a large number of strings.
 * The string will be freed when the last reference to it is deleted.
 *
 * Here is an example of use:
 *  FD_String *s1, *s2;
 *  FD_StringCache *cache;
 *
 *  FD_StringCacheAlloc( &cache );
 *
 *  s1 = FD_StringAlloc( cache, "ABC" ); <- Copy of "ABC" is alloc here.
 *  s2 = FD_StringDup( cache, s1 );    <- Ref counter is incremented here.
 *
 *  printf( "This will print ABC=%s\n", FD_StringToChar( s2 ) );
 *
 *  FD_StringFree( cache, s1 ); <- The reference count is decremented by 1.
 *  FD_StringFree( cache, s2 ); <- Last reference freed.
 *
 *  FD_StringCacheFree( cache );
 *
 * The cache mechanism allows to optimize memory allocation.
 * 
 * The FD_String guarantee safe multithread copy/manipulation.
 */

/* Important: The FD_String must stay INVISIBLE to the user of the FIDAL.
 *            This "String Data Type" is tailored specifically for FIDAL
 *            and not for external use.
 */

typedef const char *FD_String;
typedef unsigned int FD_StringCache; /* hidden implementation. */

FD_RetCode FD_StringCacheAlloc( FD_StringCache **newStringCache );
FD_RetCode FD_StringCacheFree( FD_StringCache *stringCacheToFree );

/* Create a FD_String from a normal C 'string'. */
FD_String *FD_StringAlloc( FD_StringCache *stringCache,
                           const char *string );

/* Same as FD_StringAlloc, except FD_String will be all uppercase. */
FD_String *FD_StringAlloc_UC( FD_StringCache *stringCache,
                              const char *string );


/* Like FD_String but truncate after 'n' character. */
FD_String *FD_StringAllocN( FD_StringCache *stringCache,
                            const char *string,
                            unsigned int maxNbChar );

/* Same as FD_StringAllocN, except FD_String will be all uppercase. */
FD_String *FD_StringAllocN_UC( FD_StringCache *stringCache,
                               const char *string,
                               unsigned int maxNbChar );

/* Create a FD_String from a normal C 'string'. Remove whitespaces in the copy. */
FD_String *FD_StringAllocTrim( FD_StringCache *stringCache,
                               const char *string );

/* Create a FD_String by concatenating a normal C 'string' with an integer value. */
FD_String *FD_StringValueAlloc( FD_StringCache *stringCache,
                                const char *string,
                                unsigned int value );

/* Create a FD_String from an unsigned long integer. */
FD_String *FD_StringAlloc_ULong( FD_StringCache *stringCache,
                                 unsigned long value );

/* Allocate a "path string": and make the appropriate adaptation depending
 * of the platform.
 */
FD_String *FD_StringAlloc_Path( FD_StringCache *stringCache, const char *string );

/* Free this copy of the 'string'. */
void FD_StringFree( FD_StringCache *stringCache, FD_String *string );

/* Make a duplicate of a string.
 * (Do not assume that a reference counting occured, sometimes a re-allocation
 *  and copy could be needed if the counter reaches the maximum).
 */
FD_String *FD_StringDup( FD_StringCache *stringCache, FD_String *string );

/* Allows to use a FD_String like a normal 'const char *'.
 * Never override the "const" modifier.
 *
 * Also, this is not a "Copy" so you must stop to refer to that
 * pointer if FD_StringFree is called and there is no other reference
 * left on that string....
 */
#define FD_StringToChar(x) (((const char * const)(x))+1)

/* A very particular macro that should not be used if you do
 * not understand PERFECTLY the FD_String implementation.
 * This is provided for some speed optimization.
 *
 * Basicaly, that macro allows to re-identify the FD_String
 * correponding to a 'const char *'. Of course that 'const char *'
 * must come from a valid FD_String...
 */
#define FD_StringFromChar(x) ((FD_String *)((const char * const)(x)-1))

#endif

