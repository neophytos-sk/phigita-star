/* Simple application for accessing an SQL database using FIDAL. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "fidal.h"
#include "ta_mysql.h"

/*
#if defined (_MSC_VER)
#include <windows.h>
#endif
*/

typedef enum
{
   DISPLAY_SYMBOLS,
   DISPLAY_CATEGORIES,
   DISPLAY_HISTORIC_DATA
} Action;

void fatal_error_handler(void)
{
#if defined (_MSC_VER) && 0  /* disabled for now since FD_FatalReportToBuffer is missing */
   /* Update: FD_FatalReportToBuffer is now implemented - Mario */
   char buffer[FD_FATAL_ERROR_BUF_SIZE];
   FD_FatalReportToBuffer( buffer, FD_FATAL_ERROR_BUF_SIZE);
   OutputDebugString(buffer);
#else
   FD_FatalReport( stderr );
#endif
}

void print_usage( char *str ) 
{
   printf( "\n" );
   printf( "ta_mysql V%s - Query stock market data MySQL database\n", FD_GetVersionString() );
   printf( "\n" );
   printf( "Usage: fd_mysql -c <location> <user> <pass> <category (query)>\n" );
   printf( "       fd_mysql -s <location> <user> <pass> <category (query)> <given category> [<symbol (query)>]\n" );
   printf( "       fd_mysql -d <location> <user> <pass> <category> <symbol> <info>\n" );
   printf( "\n" );
   printf( "  -c  Display all supported categories\n" );
   printf( "  -s  Display all symbols for a given category\n" );
   printf( "  -d  Query and display quotes data\n" );
   printf( "  Add 'z' to use FD_REPLACE_ZERO_PRICE_BAR flag\n" );
   printf( "\n" );
   printf( "  Quotes output is \"Date,Open,High,Low,Close,Volume\"\n" );
   printf( "\n" );
   printf( "  Examples:\"\n" );
   printf( "    fd_mysql -c mysql://localhost/db guest \"\" \"SELECT * FROM cat\"\n" );
   printf( "    fd_mysql -s mysql://localhost/db guest \"\" \"SELECT * FROM cat\" NL.EURONEXT.STOCKS\n" );
   printf( "    fd_mysql -dz mysql://localhost/db guest \"\" \"SELECT * FROM cat\" MSFT \"SELECT ...\"\n" );
   printf( "\n" );
   printf( "  Online help: http://fidalsoft.org\n" );
   printf( "\n" );
   printf( "Error: [%s]\n", str );
}

void print_error( FD_RetCode retCode )
{
   FD_RetCodeInfo retCodeInfo;

   FD_SetRetCodeInfo( retCode, &retCodeInfo );
   printf( "\nError %d=%s:[%s]\n", retCode,
           retCodeInfo.enumStr,
           retCodeInfo.infoStr );
}

int print_data( FD_UDBase *udb,
                FD_AddDataSourceParam dsParam,
                FD_Period period )
{
   FD_RetCode retCode;
   FD_History *history = NULL;
   unsigned int i;

   retCode = FD_AddDataSource( udb, &dsParam );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   /* Get the historical data. */
   retCode = FD_HistoryAlloc( udb, 
                              dsParam.category, 
                              dsParam.symbol,
                              period, 0, 0, FD_FIELD_ALL,
                              &history );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   if( !history || history->nbBars == 0 )
   {
      printf( "No data available\n" );
   }
   else
   {
      for( i=0; i < history->nbBars; i++ )
      {
         printf( "%04u-%02u-%02u", FD_GetYear(&history->timestamp[i]),
                                   FD_GetMonth(&history->timestamp[i]),
                                   FD_GetDay(&history->timestamp[i]) );
         if( history->open )
            printf( ",%.2f", history->open[i] );
         if( history->high )
            printf( ",%.2f", history->high[i] );
         if( history->low )
            printf( ",%.2f", history->low[i] );
         if( history->close )
            printf( ",%.2f", history->close[i] );
         if( history->volume )
            printf( ",%d", history->volume[i] );
         printf( "\n" );
      }
   }

   /* Get rid of the historical data and return. */
   FD_HistoryFree( history );

   return 0;
}


int print_categories( FD_UDBase *udb,
                      FD_AddDataSourceParam dsParam)
{
   FD_RetCode retCode;
   unsigned int i;
   FD_StringTable *table;

   /* info not needed for getting just categories, but the driver insists on it */
   dsParam.info = "";  
   retCode = FD_AddDataSource( udb, &dsParam );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }
   
   retCode = FD_CategoryTableAlloc( udb, &table );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   } 

   for( i=0; i < table->size; i++ )
   {
      printf( "%s\n", table->string[i] );
   }

   FD_CategoryTableFree( table );

   return 0;
}


int print_symbols( FD_UDBase *udb,
                   FD_AddDataSourceParam dsParam,
                   const char *category,
                   const char *symbol)
{
   FD_RetCode retCode;
   unsigned int i;
   FD_StringTable *table = NULL;

   /* info not needed for getting just categories, but the driver insists on it */
   dsParam.info = "";  
   dsParam.symbol = symbol;
   retCode = FD_AddDataSource( udb, &dsParam );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   retCode = FD_SymbolTableAlloc( udb, category, &table );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   } 

   for( i=0; table && i < table->size; i++ )
   {
      printf( "%s\n", table->string[i] );
   }

   FD_SymbolTableFree( table );
  
   return 0;
}

int main( int argc, char *argv[] )
{
   Action theAction;
   FD_InitializeParam initParam;
   FD_UDBase *udb;
   FD_RetCode retCode;
   FD_Period period;
   FD_AddDataSourceParam dsParam;
   FD_SourceFlag flags;

   int retValue;

   /* Verify that there is the minimum required number 
    * of parameters.
    */
   if( argc < 6 )
   {
      print_usage( "Missing parameters" );
      return -1;
   }

   /* Verify that there are not too many parameters */
   if( argc > 8 )
   {
      print_usage( "Too Many parameters" );
      return -1;
   }

   /* Daily data by default. */
   period = FD_DAILY;
   flags = FD_NO_FLAGS;

   /* Check for the switch, and identify what needs to be done. */
   if ( strlen(argv[1]) > 1 && argv[1][strlen(argv[1])-1] == 'z') {
      flags |= FD_REPLACE_ZERO_PRICE_BAR;
   }
   if( strcmp( "-c", argv[1] ) == 0 )
      theAction = DISPLAY_CATEGORIES;
   else if( strcmp( "-s", argv[1] ) == 0 )
      theAction = DISPLAY_SYMBOLS;
   else if( strncmp( "-d", argv[1], 2 ) == 0 )
      theAction = DISPLAY_HISTORIC_DATA;
   else if( strncmp( "-dd", argv[1], 3 ) == 0 )
      theAction = DISPLAY_HISTORIC_DATA;
   else if( strncmp( "-dw", argv[1], 3 ) == 0 )
   {
      theAction = DISPLAY_HISTORIC_DATA;
      period = FD_WEEKLY;
   }
   else if( strncmp( "-dm", argv[1], 3 ) == 0 )
   {
      theAction = DISPLAY_HISTORIC_DATA;
      period = FD_MONTHLY;
   }
   else if( strncmp( "-dq", argv[1], 3 ) == 0 )
   {
      theAction = DISPLAY_HISTORIC_DATA;
      period = FD_QUARTERLY;
   }
   else if( strncmp( "-dy", argv[1], 3 ) == 0 )
   {
      theAction = DISPLAY_HISTORIC_DATA;
      period = FD_YEARLY;
   }
   else
   {
      print_usage( "Switch not recognized" );
      return -1;
   }

   /* Verify that there is at least a symbol and category 
    * on the command line (when applicable).
    */
   switch( theAction )
   {
   case DISPLAY_SYMBOLS:
      if( argc < 7 )
      {
         print_usage( "Symbol string missing" );
         return -1;
      }
      break;
   case DISPLAY_HISTORIC_DATA:
      if( argc < 8 )
      {
         print_usage( "Info string missing" );
         return -1;
      }
      break;
   case DISPLAY_CATEGORIES:
      /* Nothing to do. */
      break;
   }

   /* Initialize FIDAL and create an unified database. */
   memset( &initParam, 0, sizeof( FD_InitializeParam ) );
   initParam.userLocalDrive = ".";

   retCode = FD_Initialize( &initParam );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   retCode = FD_MYSQL_Initialize();
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   retCode = FD_SetFatalErrorHandler(fatal_error_handler);
   retCode = FD_UDBaseAlloc( &udb );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      FD_Shutdown();
      return -1;
   }

   memset( &dsParam, 0, sizeof( FD_AddDataSourceParam ) );
   dsParam.id = FD_SQL;

   dsParam.flags = flags;
   dsParam.location = argv[2];
   dsParam.username = argv[3];
   dsParam.password = argv[4];
   dsParam.category = argv[5];

   /* Do 'theAction' after making an uppercase copy
    * of the symbol and category.
    */
   switch( theAction )
   {
   case DISPLAY_HISTORIC_DATA:       
       dsParam.symbol = argv[6];
       dsParam.info = argv[7];
       retValue = print_data(udb, dsParam, period);
       break;

   case DISPLAY_SYMBOLS:
      retValue = print_symbols(udb, dsParam, argv[6], (argc>7? argv[7] : NULL));
       break;

   case DISPLAY_CATEGORIES:
       retValue = print_categories(udb, dsParam);
       break;

   default:
       retValue = -1;
       break;
   }

   /* Clean-up and exit. */
   FD_UDBaseFree( udb );
   FD_Shutdown();
   return retValue;
}
