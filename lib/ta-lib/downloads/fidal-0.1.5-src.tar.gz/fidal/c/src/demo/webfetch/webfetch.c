/* Simple command line utility for fetching a web site.
 *
 * The raw data is displayed and can be redirected to
 * a file.
 *
 * This application is just for giving a chance to
 * the fetch engine used within the FIDAL project
 * to be more widely used and tested.
 * 
 * Info: http://fidalsoft.org
 *
 */
#include <stdio.h>
#include "fidal.h"

/* Prototype */
static void print_usage( const char *str );
static void print_error( FD_RetCode retCode );

int main( int argc, char **argv )
{
   FD_RetCode retCode;
   int retValue;

   /* Verify the parameters. */
   if( argc != 2 )
   {
      print_usage( "Bad Parameter" );
      return -1;
   }

   /* Initialize FIDAL. */
   retCode = FD_Initialize( NULL );
   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      return -1;
   }

   /* Fetch and display the WebPage. */
   retCode = FD_WebFetch( argv[1], stdout );

   if( retCode != FD_SUCCESS )
   {
      print_error( retCode );
      retValue = -1;
   }
   else
      retValue = 0;
      
   /* Clean-up and exit. */
   FD_Shutdown();

   return retValue;
}

static void print_usage( const char *str ) 
{
   printf( "\n" );
   printf( "WebFetch V%s - Fetch data from a specified URL\n", FD_GetVersionString() );
   printf( "\n" );
   printf( "Usage: WebFetch URL\n" );
   printf( "\n" );
   printf( "   The text content of the URL is simply displayed\n" );
   printf( "   and can be redirected to a file.\n" );
   printf( "\n" );
   printf( "   Examples: WebFetch http://www.yahoo.com\n" );
   printf( "             WebFetch finance.yahoo.com/mt\n" );
   printf( "             WebFetch www.yahoo.com >myFile.html\n" );
   printf( "\n" );
   printf( "   On failure the first string displayed is\n" );
   printf( "   always \"WebFetch\".\n" );
   printf( "\n" );
   printf( "   Exit code is 0 on success.\n" );
   printf( "   Exit code is -1 on failure.\n" );
   printf( "\n" );
   printf( "   To uninstall, just delete WebFetch.exe\n" );
   printf( "\n" );
   printf( "   WebFetch.exe is open-source and is a small\n" );
   printf( "   component of a larger project called FIDAL.\n" );
   printf( "\n" );
   printf( "   More info at http://fidalsoft.org\n" );
   printf( "\n" );
   printf( "Error: [%s]\n", str );
}

static void print_error( FD_RetCode retCode )
{
   FD_RetCodeInfo retCodeInfo;

   /* Ask FIDAL to provide an error string
    * and the enum that can be used to find
    * the origin of the failure within the
    * source code.
    */
   FD_SetRetCodeInfo( retCode, &retCodeInfo );
   printf( "\nWebFetch Fail: %d=%s:[%s]\n",
           retCode,
           retCodeInfo.enumStr,
           retCodeInfo.infoStr );
}
