/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  PK       Pawel Konieczny
 *
 *
 * Change history:
 *
 *  MMDDYY BY      Description
 *  -------------------------------------------------------------------
 *  110199 MF      First version.
 *  011204 MF      Now use addDataSourceParamPriv and check for
 *                 new SPLIT/VALUE adjust flags.
 *  013104 MF      Add possibility to "name" data sources + add 
 *                 validation of start/end parameters.
 *  032004 MF      FD_END_OF_INDEX now use only to exit prematurely
 *                 while building the index. In normal operation, the 
 *                 data source driver should not have to return it.
 *  032704 MF      FD_AddDataSource location param will adapt to
 *                 platform when the driver set FD_LOCATION_IS_PATH.
 *  062105 PK      Added (partial) support for end-of-period
 *                 timestamp logic.
 *  070305 MF,PK   Fix #1229243 memory leak in some failure scenario.
 */

/* Decription:
 *    Provides all the user entry point for the "unified database".
 */

/**** Headers ****/
#include <string.h>
#include "fidal.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_data_udb.h"
#include "fd_global.h"
#include "fd_magic_nb.h"
#include "fd_history.h"
#include "fd_adddatasourceparam_priv.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/

/* The hidden data put in a FD_CategoryTable. */
typedef struct
{
   unsigned int magicNb;
   FD_UDBasePriv *privUDB;
} FD_CategoryTableHiddenData;

/* The hidden data put in a FD_SymbolTable. */
typedef struct
{
   unsigned int magicNb;
   FD_UDBasePriv *privUDB;
} FD_SymbolTableHiddenData;

typedef struct
{
   /* One instance of this struct exists for each added data source. */

   /* Keep a copy of the parameters who were used
    * to initialize this data source.
    */
   FD_AddDataSourceParamPriv *addDataSourceParamPriv;

   /* Initialize by the data source driver. */
   FD_DataSourceHandle *sourceHandle;

   /* This list is just a "container" for efficient allocation purpose. The
    * elements are used directly from the FD_DriverHandle->categoryHandle
    * pointer, but are owned here.
    */
   FD_List *listCategoryHandle;

   /* Allocation Strategy: This structure owns all its sub-elements. */
} FD_DataSource;

/* The following are for managing the global variables. */
static FD_RetCode FD_DataGlobalInit    ( void **globalToAlloc );
static FD_RetCode FD_DataGlobalShutdown( void *globalAllocated );

const FD_GlobalControl FD_DataGlobalControl =
{
   FD_DAFD_GLOBAL_ID,
   FD_DataGlobalInit,
   FD_DataGlobalShutdown
};

typedef struct
{
  /* Only one instance of this structure will exist. */

  #if !defined( FD_SINGLE_THREAD )
  FD_Sema sema; /* To protect this structure integrity. */
  #endif

  /* Keep track of which data source has been initialized. */
  unsigned char *dataSourceInitFlag;

  /* Keep track of the allocated unified database. */
  FD_List *listUDBase; /* List of FD_UDBasePriv. */
} FD_DataGlobal;

/**** Local functions declarations.    ****/
static FD_DataSource *allocDataSourceForGlobal( FD_UDBasePriv *privUDB,
                                                FD_AddDataSourceParamPriv *addDataSourceParamPriv,
                                                FD_DataSourceHandle *sourceHandle,
                                                FD_List *listCategoryHandle );

static FD_UDB_Category *addCategory( FD_UDBasePriv *privUDB, FD_String *string );
static FD_UDB_Symbol *addSymbol( FD_UDBasePriv *privUDB,
                                 FD_Dict *dictUDBSymbol,
                                 FD_UDB_Driver *driverHandle,
                                 FD_DataSourceHandle *sourceHandle,
                                 FD_CategoryHandle *categoryHandle,
                                 FD_SymbolHandle *symbolHandle );
static FD_RetCode stringTableFree( FD_StringTable *table, unsigned int freeInternalStringOnly );

static FD_RetCode closeAllDataSource( FD_UDBasePriv *privUDB );

static FD_RetCode closeAllUDBase( FD_DataGlobal *global );
static FD_RetCode shutdownAllSourceDriver( FD_DataGlobal *global );

static void freeSymbolData( void *toBeFreed );
static void freeCategoryData( void *toBeFreed );

static FD_RetCode processCategoryAndSymbols( FD_UDBasePriv *privUDB,
                                             const FD_DataSourceDriver *driver,
                                             const FD_AddDataSourceParamPriv *addDataSourceParamPriv,
                                             FD_DataSourceHandle *sourceHandle,
                                             FD_CategoryHandle   *categoryHandle );

/* Function to alloc/free a FD_AddDataSourceParamPriv. */
static FD_AddDataSourceParamPriv *FD_AddDataSourceParamPrivAlloc( const FD_AddDataSourceParam *param, FD_SourceFlag flags );
static FD_RetCode FD_AddDataSourceParamPrivFree( FD_AddDataSourceParamPriv *toBeFreed );

/* Mechanism for easily deleting lists. */
static FD_RetCode freeListAndElement( FD_List *list,
                                      FD_RetCode (*freeFunc)( void *toBeFreed ));

static FD_RetCode freeUDBDriverArray( void *toBeFreed );
static FD_RetCode freeCategoryHandle( void *toBeFreed );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_UDBaseAlloc( FD_UDBase **newUDBase )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_RetCode finalRetCode;
   FD_DataGlobal *global;
   FD_UDBasePriv *privUDB;
   FD_StringCache *stringCache;
   FD_String *string;

   FD_TRACE_BEGIN(FD_UDBaseAlloc);

   /* Verify parameters. */
   if( !newUDBase )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   *newUDBase = NULL;

   /* Get the pointer on the global variables. */
   retCode = FD_GetGlobal(  &FD_DataGlobalControl, (void *)&global );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Alloc the hidden implementation of a FD_UDBase */
   privUDB = (FD_UDBasePriv *) FD_Malloc( sizeof( FD_UDBasePriv ));

   if( !privUDB )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   memset( privUDB, 0, sizeof( FD_UDBasePriv ) );
   privUDB->magicNb   = FD_UDBASE_MAGIC_NB;

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaInit( &privUDB->sema, 1 );
   if( retCode != FD_SUCCESS )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   /* Initialize the list of data source.
    * Each time a data source is added with FD_AddDataSource, it
    * is added to this list.
    */
   privUDB->listDataSource = FD_ListAlloc();
   if( !privUDB->listDataSource )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Initialize the dictCategory. One entry in the dictionary
    * will exist for each category.
    */
   privUDB->dictCategory = FD_DictAlloc( FD_DICT_KEY_ONE_STRING, freeCategoryData );

   if( !privUDB->dictCategory )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Initialize the Default category structure. */
   stringCache = FD_GetGlobalStringCache();
   if( !stringCache )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   string = FD_StringAlloc( stringCache, FD_DEFAULT_CATEGORY );
   if( !string )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Add the default category to the dictionary. */
   privUDB->defaultCategory = addCategory( privUDB, string );
   FD_StringFree( stringCache, string );

   if( !privUDB->defaultCategory )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Add the UDBase to the global list. */
   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &global->sema );

   if( retCode != FD_SUCCESS )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   finalRetCode = FD_ListAddTail( global->listUDBase, (void *)privUDB );

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaPost( &global->sema );

   if( retCode != FD_SUCCESS )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   /* Check if an error occured within the critical section. */
   if( finalRetCode != FD_SUCCESS )
   {
      FD_UDBaseFree( (FD_UDBase *)privUDB );
      FD_TRACE_RETURN( finalRetCode );
   }

   /* Everything is fine, return the new unified database
    * to the caller.
    */
   *newUDBase = (FD_UDBase *)privUDB;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_UDBaseFree( FD_UDBase *toBeFreed )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_RetCode finalRetCode;
   FD_DataGlobal *global;
   FD_UDBasePriv *privUDB;

   /* Return immediately if apparently already freed. */
   privUDB = (FD_UDBasePriv *)toBeFreed;
   if( !privUDB )
      return FD_SUCCESS;

   /* Check integrity. */
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;

   retCode = FD_GetGlobal( &FD_DataGlobalControl, (void **)&global );
   if( retCode != FD_SUCCESS )
      return retCode;

   FD_TRACE_BEGIN( FD_UDBaseFree );

   /* Will change if an error happen. */
   finalRetCode = FD_SUCCESS;

   /* Remove from the global list. */
   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &global->sema );

   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   else
   {
   #endif

      retCode = FD_ListRemoveEntry( global->listUDBase, (void *)privUDB );

      if( retCode != FD_SUCCESS )
         finalRetCode = retCode;

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaPost( &global->sema );

      if( retCode != FD_SUCCESS )
         finalRetCode = retCode;
   }
   #endif

   #if !defined( FD_SINGLE_THREAD )
   /* No one else is suppose to access this data at this
    * point. But just in case... prevent the other to
    * be able to get the semaphore while we are shutting
    * down the unified database.
    */
   retCode = FD_SemaWait( &privUDB->sema );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   #endif

   retCode = closeAllDataSource( privUDB );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   
   retCode = FD_ListFree( privUDB->listDataSource );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;

   retCode = FD_DictFree( privUDB->dictCategory );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;

   #if !defined( FD_SINGLE_THREAD )
   /* Destroy the semaphore... too bad if someone was wrongly
    * waiting on it! That other thread will somehow be failed
    * or hang forever.
    */
   retCode = FD_SemaDestroy( &privUDB->sema );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   #endif

   FD_Free( privUDB );

   FD_TRACE_RETURN( finalRetCode );
}

FD_RetCode FD_AddDataSource( FD_UDBase *unifiedDatabase,
                             const FD_AddDataSourceParam *param )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_RetCode finalRetCode;
   FD_SourceId driverIndex;
   const FD_DataSourceDriver *driver;
   FD_List *tmpListCategory;
   FD_UDBasePriv *privUDB;

   FD_DataSource  *dataSource;

   FD_DataSourceHandle *sourceHandle;
   FD_CategoryHandle   *categoryHandle;

   FD_DataGlobal *global;

   FD_AddDataSourceParamPriv *addDataSourceParamPriv;

   unsigned int again; /* Boolean */

   unsigned int categoryIndex;

   FD_DataSourceParameters dataSourceParams;

   tmpListCategory = NULL;

   /* Check parameters. */
   if( unifiedDatabase == NULL )
      return FD_BAD_PARAM;

   privUDB = (FD_UDBasePriv *)unifiedDatabase;
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;

   if( param->id >= FD_NUM_OF_SOURCE_ID )
      return FD_BAD_PARAM;

   retCode = FD_GetGlobal( &FD_DataGlobalControl, (void *)&global );
   if( retCode != FD_SUCCESS )
      return retCode;

   FD_TRACE_BEGIN( FD_AddDataSource );

   /* It is assume there is a one-to-one correspondance
    * between the "FD_SourceId" and the index
    * in the FD_gDataSourceTable
    */
   driverIndex = param->id;
   driver = &FD_gDataSourceTable[driverIndex];

   /* Initialize the data source (if not already done). */
   finalRetCode = FD_SUCCESS;
   if( global->dataSourceInitFlag[driverIndex] == 0 )
   {
      #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaWait( &global->sema );

      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }

      /* Check again within the critical section. */
      if( global->dataSourceInitFlag[driverIndex] == 0 )
      {
      #endif
         if( driver->initializeSourceDriver )
         {
            retCode = driver->initializeSourceDriver();
            if( retCode != FD_SUCCESS )
               finalRetCode = retCode;
         }
         global->dataSourceInitFlag[driverIndex] = 1;
      #if !defined( FD_SINGLE_THREAD )
      }

      retCode = FD_SemaPost( &global->sema );

      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
      #endif
   }

   /* Check for error that could have happen in the critical section. */
   if( finalRetCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( finalRetCode );
   }

   /* Check that if a flag is set that the data source can
    * actually handle the requested functionality.
    */
   driver->getParameters( &dataSourceParams );
   if( (param->flags           & FD_REPLACE_ZERO_PRICE_BAR) && 
      !(dataSourceParams.flags & FD_REPLACE_ZERO_PRICE_BAR) )
   {
      FD_TRACE_RETURN( FD_UNSUPPORTED_REPLACE_ZERO_PRICE_BAR );
   }

   if( (param->flags           & FD_DO_NOT_SPLIT_ADJUST) && 
      !(dataSourceParams.flags & FD_DO_NOT_SPLIT_ADJUST) )
   {
      FD_TRACE_RETURN( FD_UNSUPPORTED_DO_NOT_SPLIT_ADJUST );
   }

   if( (param->flags           & FD_DO_NOT_VALUE_ADJUST) && 
      !(dataSourceParams.flags & FD_DO_NOT_VALUE_ADJUST) )
   {
      FD_TRACE_RETURN( FD_UNSUPPORTED_DO_NOT_VALUE_ADJUST );
   }

   /* Open the source. */
   
   /* Allocate a private copy of the parameters. This function
    * will also set the default values if not provided by the
    * caller. (particularly the category string).
    */
   addDataSourceParamPriv = FD_AddDataSourceParamPrivAlloc( param, dataSourceParams.flags );
   if( !addDataSourceParamPriv )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   retCode = driver->openSource( addDataSourceParamPriv, &sourceHandle );
   if( retCode != FD_SUCCESS )
   {
      FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
      FD_TRACE_RETURN( retCode );
   }

   /* Just check the handle to make sure. */
   if( sourceHandle == NULL )
   {
      FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Add entries to the Dict of Category.
    * Also, process symbols for each category.
    */
   if( sourceHandle->nbCategory != 0 )
   {
      /* Make sure the needed functions are provided by the driver. */
      if( !driver->getFirstCategoryHandle )
      {
         if( driver->closeSource )
            driver->closeSource( sourceHandle );
         FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(24) );
      }

      if( (sourceHandle->nbCategory > 1) && !driver->getNextCategoryHandle )
      {
         if( driver->closeSource )
            driver->closeSource( sourceHandle );
         FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(25) );
      }

      tmpListCategory = FD_ListAlloc();
      if( !tmpListCategory )
      {
         if( driver->closeSource )
            driver->closeSource( sourceHandle );
         FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      categoryIndex = 0;
      again = 1;
      while( again && (categoryIndex < sourceHandle->nbCategory) )
      {
         /* Allocate the categoryHandle. */
         categoryHandle = (FD_CategoryHandle *)FD_Malloc( sizeof(FD_CategoryHandle) );
         if( !categoryHandle )
         {
            freeListAndElement( tmpListCategory, freeCategoryHandle );
            if( driver->closeSource )
               driver->closeSource( sourceHandle );
            FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }

         /* Default values. */
         memset( categoryHandle, 0, sizeof( FD_CategoryHandle ) );

         /* Fill the categoryHandle information. */
         if( categoryIndex == 0 )
            retCode = driver->getFirstCategoryHandle( sourceHandle,
                                                      categoryHandle );
         else
            retCode = driver->getNextCategoryHandle( sourceHandle,
                                                     categoryHandle,
                                                     categoryIndex );

         categoryIndex++;
         if( retCode == FD_END_OF_INDEX )
         {
            FD_Free( categoryHandle );
            again = 0;
         }
         else if( retCode != FD_SUCCESS )
         {
            freeListAndElement( tmpListCategory, freeCategoryHandle );
            FD_Free(  categoryHandle );
            if( driver->closeSource )
               driver->closeSource( sourceHandle );
            FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
            FD_TRACE_RETURN( retCode );
         }
         else
         {
            retCode = processCategoryAndSymbols( privUDB,
                                                 driver, addDataSourceParamPriv,
                                                 sourceHandle,
                                                 categoryHandle );

            if( retCode != FD_SUCCESS )
            {
               freeListAndElement( tmpListCategory, freeCategoryHandle );
               FD_Free(  categoryHandle );
               if( driver->closeSource )
                  driver->closeSource( sourceHandle );
               FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
               FD_TRACE_RETURN( retCode );
            }

            /* Keep that category in a list. Will be assigned
             * for ownership to the FD_DataSource later.
             */
            retCode = FD_ListAddTail( tmpListCategory, categoryHandle );
            if( retCode != FD_SUCCESS )
            {
               freeListAndElement( tmpListCategory, freeCategoryHandle );
               FD_Free(  categoryHandle );
               if( driver->closeSource )
                  driver->closeSource( sourceHandle );
               FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
               FD_TRACE_RETURN( retCode );
            }
         }
      }
   }

   /* Keep track of that source in the listDataSource. */
   dataSource = allocDataSourceForGlobal( privUDB,
                                          addDataSourceParamPriv,
                                          sourceHandle,
                                          tmpListCategory );
   if( !dataSource )
   {
      freeListAndElement( tmpListCategory, freeCategoryHandle );
      if( driver->closeSource )
         driver->closeSource( sourceHandle );
      FD_AddDataSourceParamPrivFree( addDataSourceParamPriv );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CategoryTableAlloc( FD_UDBase *unifiedDatabase,
                                  FD_StringTable **table )
{
   FD_PROLOG
   FD_StringTable *stringTable;
   FD_UDBasePriv *privUDB;
   FD_StringCache *stringCache;
   unsigned int i;
   unsigned int again;
   FD_RetCode finalRetCode;
   FD_CategoryTableHiddenData *hiddenData;
   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif

   if( !unifiedDatabase || !table )
      return FD_BAD_PARAM;

   *table = NULL;

   privUDB = (FD_UDBasePriv *)unifiedDatabase;
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;

   FD_TRACE_BEGIN( FD_CategoryTableAlloc );

   stringTable = FD_Malloc( sizeof(FD_StringTable) );

   if( stringTable == NULL )
      FD_TRACE_RETURN( FD_ALLOC_ERR );

   stringTable->size = 0;
   stringTable->string = NULL;

   /* Handle special case where there is not even one data source added
    * (of course there is no category in that case).
    */
   if( privUDB->dictCategory == NULL )
   {
      *table = stringTable;
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   stringCache = FD_GetGlobalStringCache();

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &privUDB->sema );

   if( retCode != FD_SUCCESS )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   finalRetCode = FD_SUCCESS;

   /* Extract all 'category' from the category dictionary. */
   stringTable->size = FD_DictAccessFirst( privUDB->dictCategory );
   if( stringTable->size != 0 )
   {
      stringTable->string = (const char **)FD_Malloc( (stringTable->size) *
                                                      sizeof( const char *) );

      if( stringTable->string == NULL )
      {
         stringTableFree( stringTable, 0 );
         finalRetCode = FD_ALLOC_ERR;
      }
      else
      {
         memset( (void *)stringTable->string, 0, (stringTable->size) * sizeof( const char *) );

         again = 1;
         for( i=0; (i < stringTable->size) && again; i++ )
         {
            (stringTable->string)[i] = FD_StringToChar( FD_StringDup( stringCache, FD_DictAccessKey( privUDB->dictCategory ) ) );
            again = FD_DictAccessNext( privUDB->dictCategory );
         }
      }
   }

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaPost( &privUDB->sema );

   if( retCode != FD_SUCCESS )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   /* Check if an error occured in the critical section. */
   if( finalRetCode != FD_SUCCESS )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( finalRetCode );
   }

   /* Allocate and initialize the hidden data. */
   hiddenData = FD_Malloc( sizeof(FD_CategoryTableHiddenData) );
   if( !hiddenData )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   hiddenData->privUDB = privUDB;
   hiddenData->magicNb = FD_CATEGORY_TABLE_MAGIC_NB;
   stringTable->hiddenData = hiddenData;

   /* Return the table to the caller. */
   *table = stringTable;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CategoryTableFree( FD_StringTable *table )
{
   FD_PROLOG
   FD_UDBasePriv *privUDB;
   FD_CategoryTableHiddenData *hiddenData;
   FD_RetCode retCode;

   /* If it appears to be already freed, just return. */
   if( !table )
      return FD_SUCCESS;

   /* Make sure we are dealing with the right object */
   hiddenData = (FD_CategoryTableHiddenData *)table->hiddenData;
   if( !hiddenData )
      return FD_ALLOC_ERR;
   if( hiddenData->magicNb != FD_CATEGORY_TABLE_MAGIC_NB )
      return FD_BAD_OBJECT;
   privUDB = (FD_UDBasePriv *)hiddenData->privUDB;
   if( !privUDB )
      return FD_ALLOC_ERR;
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;

   FD_TRACE_BEGIN(  FD_CategoryTableFree );

   /* Free the hidden data. */
   memset( hiddenData, 0, sizeof( FD_CategoryTableHiddenData ) );
   FD_Free( hiddenData );
   
   /* Free the strings. */
   retCode = stringTableFree( table, 0 );

   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_SymbolTableAlloc( FD_UDBase *unifiedDatabase,
                                const char *categoryString,
                                FD_StringTable **table )
{
   FD_PROLOG
   FD_StringTable  *stringTable;
   FD_UDB_Category *categoryData;
   FD_Dict         *dictUDBSymbol;
   FD_UDBasePriv   *privUDB;
   FD_StringCache  *stringCache;
   unsigned int     i;
   unsigned int     again;
   FD_SymbolTableHiddenData *hiddenData;
   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode       retCode;
   #endif

   if( !table || !unifiedDatabase )
      return FD_BAD_PARAM;

   *table = NULL;

   privUDB = (FD_UDBasePriv *) unifiedDatabase;
   FD_TRACE_BEGIN(  FD_SymbolTableAlloc );

   stringTable = FD_Malloc( sizeof(FD_StringTable) );

   if( stringTable == NULL )
      FD_TRACE_RETURN( FD_ALLOC_ERR );

   stringTable->size = 0;
   stringTable->string = NULL;

   /* Handle special case where there is not even one data source added
    * (of course there is no symbol in that case).
    */
   if( privUDB->dictCategory == NULL )
   {
      *table = stringTable;
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   /* If categoy is NULL, use the default category. */
   if( !categoryString )
      categoryString = FD_DEFAULT_CATEGORY;

   stringCache = FD_GetGlobalStringCache();

   /* Find the symbol dictionary. */

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &privUDB->sema );

   if( retCode != FD_SUCCESS )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   categoryData = FD_DictGetValue_S( privUDB->dictCategory, categoryString );

   if( !categoryData || !(categoryData->dictUDBSymbol))
   {
      /* Category not found... */
      #if !defined( FD_SINGLE_THREAD )
         FD_SemaPost( &privUDB->sema );
      #endif
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( FD_CATEGORY_NOT_FOUND );
   }

   dictUDBSymbol = categoryData->dictUDBSymbol;

   /* Extract all 'symbols' from the symbol dictionary. */
   stringTable->size = FD_DictAccessFirst( dictUDBSymbol );
   if( stringTable->size != 0 )
   {
      stringTable->string = (const char **)FD_Malloc( (stringTable->size) *
                                                      sizeof( const char *) );

      if( stringTable->string == NULL )
      {
         #if !defined( FD_SINGLE_THREAD )
            FD_SemaPost( &privUDB->sema );
         #endif
         stringTableFree( stringTable, 0 );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      memset( (void *)stringTable->string, 0, (stringTable->size) * sizeof( const char *) );

      again = 1;
      for( i=0; (i < stringTable->size) && again; i++ )
      {
         (stringTable->string)[i] = FD_StringToChar( FD_StringDup( stringCache, FD_DictAccessKey( dictUDBSymbol ) ) );
         again = FD_DictAccessNext( dictUDBSymbol );
      }
   }

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaPost( &privUDB->sema );

   if( retCode != FD_SUCCESS )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   /* Allocate and initialize the hidden data. */
   hiddenData = FD_Malloc( sizeof(FD_SymbolTableHiddenData) );
   if( !hiddenData )
   {
      stringTableFree( stringTable, 0 );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   hiddenData->privUDB = privUDB;
   hiddenData->magicNb = FD_SYMBOL_TABLE_MAGIC_NB;
   stringTable->hiddenData = hiddenData;

   /* Return the table to the caller. */
   *table = stringTable;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SymbolTableFree( FD_StringTable *table )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_UDBasePriv *privUDB;
   FD_SymbolTableHiddenData *hiddenData;

   /* If it appears to be already freed, just return. */
   if( !table )
      return FD_SUCCESS;

   /* Make sure we are dealing with the right object */
   hiddenData = (FD_SymbolTableHiddenData *)table->hiddenData;
   if( !hiddenData )
      return FD_ALLOC_ERR;
   if( hiddenData->magicNb != FD_SYMBOL_TABLE_MAGIC_NB )
      return FD_BAD_OBJECT;
   privUDB = (FD_UDBasePriv *)hiddenData->privUDB;
   if( !privUDB )
      return FD_ALLOC_ERR;
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;
    
   FD_TRACE_BEGIN( FD_SymbolTableFree );

   /* Free the hidden data. */
   memset( hiddenData, 0, sizeof( FD_SymbolTableHiddenData ) );
   FD_Free(  hiddenData );

   retCode = stringTableFree( table, 0 );

   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_ForEachSymbol( FD_UDBase *unifiedDatabase,
                             FD_ForEachSymbolFunc functionToCall,
                             void *opaqueData )
{
   FD_PROLOG
   unsigned int i;
   unsigned int j;
   FD_StringTable *tableCategory;
   FD_StringTable *tableSymbol;
   FD_RetCode retCode;
   FD_UDBasePriv *privUDB;

   if( !unifiedDatabase || !functionToCall )
      return FD_BAD_PARAM;

   privUDB = (FD_UDBasePriv *)unifiedDatabase;
   if( privUDB->magicNb != FD_UDBASE_MAGIC_NB )
      return FD_BAD_OBJECT;

   FD_TRACE_BEGIN( FD_ForEachSymbol );

   /* Get all the category to iterate. */
   retCode = FD_CategoryTableAlloc( unifiedDatabase, &tableCategory );

   if( retCode == FD_SUCCESS )
   {
      for( i=0; i < tableCategory->size; i++ )
      {
         FD_ASSERT( tableCategory->string[i] != NULL );
         /* Get all the symbols to iterate for this category. */
         retCode = FD_SymbolTableAlloc( unifiedDatabase,
                                        tableCategory->string[i],
                                        &tableSymbol );

         if( retCode == FD_SUCCESS )
         {
            for( j=0; j < tableSymbol->size; j++ )
            {
               FD_ASSERT( tableSymbol->string[j] != NULL );
               (*functionToCall)( unifiedDatabase,
                                  tableCategory->string[i],
                                  tableSymbol->string[j],
                                  opaqueData );
            }

            FD_SymbolTableFree( tableSymbol );
         }
      }

      FD_CategoryTableFree( tableCategory );
   }
   else
      return FD_INTERNAL_ERROR(27);

   return FD_SUCCESS;
}

FD_RetCode FD_HistoryAlloc( FD_UDBase           *unifiedDatabase,
                            const FD_HistoryAllocParam *param,
                            FD_History         **history )
{
   FD_PROLOG
   FD_RetCode retCode;

   FD_UDB_Category *categoryData;
   FD_UDB_Symbol   *symbolData;
   FD_History      *newHistory;
   FD_Dict         *dictUDBSymbol;
   FD_UDBasePriv   *privUDB;
   FD_StringCache  *stringCache;

   const FD_Timestamp *startLocal;
   const FD_Timestamp *endLocal;
   const char *categoryLocal;

   privUDB = (FD_UDBasePriv *)unifiedDatabase;

   FD_TRACE_BEGIN( FD_HistoryAlloc );

   if( (history == NULL) || (param->symbol == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   if( (param->period == 0) || (param->period > FD_YEARLY) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   /* startLocal and endLocal must end up NULL if the
    * start and end are not specified.
    */
   startLocal = &param->start;
   endLocal   = &param->end;

   if( (startLocal->date == 0) && (startLocal->time == 0) )
      startLocal = (const FD_Timestamp *)0;
   if( (endLocal->date == 0) && (endLocal->time == 0) )
      endLocal = (const FD_Timestamp *)0;

   /* Verify validity of start/end */
   if( startLocal )
   {
      if( param->period >= FD_DAILY )
         retCode = FD_TimestampValidateYMD( startLocal );
      else
         retCode = FD_TimestampValidate( startLocal );
   
      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( FD_BAD_START_DATE );
   }

   if( endLocal )
   {
      if( param->period >= FD_DAILY )
         retCode = FD_TimestampValidateYMD( endLocal );
      else
         retCode = FD_TimestampValidate( endLocal );

      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( FD_BAD_END_DATE );
   }

   *history = NULL;

   /* Handle special case where there is not even one data source added. */
   if( privUDB->dictCategory == NULL )
   {
      FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
   }

   /* Look for the category. If no category provided, use the default. */
   categoryLocal = FD_DEFAULT_CATEGORY;
   if( param->category != NULL )
      categoryLocal = param->category;

   stringCache = FD_GetGlobalStringCache();

   categoryData = FD_DictGetValue_S( privUDB->dictCategory, categoryLocal );

   if( !categoryData )
   {
      FD_TRACE_RETURN( FD_CATEGORY_NOT_FOUND );
   }

   if( !categoryData->dictUDBSymbol )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(28) );
   }

   /* Look for the symbol in this category. */
   dictUDBSymbol = categoryData->dictUDBSymbol;

   symbolData = FD_DictGetValue_S( dictUDBSymbol, param->symbol );

   if( !symbolData )
   {
      FD_TRACE_RETURN( FD_SYMBOL_NOT_FOUND );
   }

   /* Leave it to the FD_History sub-module to do the rest. */
   retCode = FD_HistoryBuilder( privUDB, symbolData,
                                param->period, startLocal, endLocal,
                                param->field, param->flags, param->timeout, &newHistory );

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( newHistory != NULL );

   /* History has been allocated, return this information to the caller. */
   *history = newHistory;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_HistoryFree( FD_History *history )
{
   FD_PROLOG
   FD_HistoryHiddenData *hiddenData;

   FD_TRACE_BEGIN( FD_HistoryFree );

   if( !history )       
      FD_TRACE_RETURN(FD_BAD_PARAM);

   hiddenData = (FD_HistoryHiddenData *)history->hiddenData;
   if( !hiddenData || (hiddenData->magicNb != FD_HISTORY_MAGIC_NB) )
      FD_TRACE_RETURN(FD_BAD_OBJECT);

   /* Free all block of data. 
    *
    * The meaning of setting the hiddenData->"field"
    * is to transform the corresponding history->"field" 
    * into an internal pointer instead of a pointer where
    * the allocated memory starts.
    * 
    * When hiddenData->"field" is not set, the corresponding
    * public field in FD_History is the one that should
    * be look at for being freed.
    */
   #define FREE_FIELD(x) { \
      if( hiddenData->x ) \
      { \
         FD_Free((void *)hiddenData->x); \
         hiddenData->x = NULL; \
         history->x = NULL; \
      } \
      else \
      { \
         FREE_IF_NOT_NULL( history->x ); \
      } \
   }         
   FREE_FIELD( timestamp );
   FREE_FIELD( close );
   FREE_FIELD( open );
   FREE_FIELD( high );
   FREE_FIELD( low );
   FREE_FIELD( volume );
   FREE_FIELD( openInterest );
   #undef FREE_FIELD

   stringTableFree( &history->listOfSource, 1 );

   FD_Free( (void *)history );

   FD_TRACE_RETURN( FD_SUCCESS );
}

int FD_HistoryEqual( const FD_History *history1, const FD_History *history2 )
{
   unsigned int i;

   /* Return 1 if the content of both history is
    * identical or if both history pointer are NULL.
    */
   if( !history1 && !history2 )
      return 1;

   if( !history1 && history2 )
      return 0;

   if( history1 && !history2 )
      return 0;

   if( history1->period != history2->period )
      return 0;

   if( history1->nbBars != history2->nbBars )
      return 0;

   #define CHECK_MEMBER(param) \
   { \
      if( ( history1->param && !history2->param) || \
          (!history1->param &&  history2->param) ) \
         return 0; \
      if( history1->param ) \
      { \
         for( i=0; i < history1->nbBars; i++ ) \
         { \
            if( history1->param[i] != history2->param[i] ) \
               return 0; \
         } \
      } \
   }

   CHECK_MEMBER(open);
   CHECK_MEMBER(high);
   CHECK_MEMBER(low);
   CHECK_MEMBER(close);
   CHECK_MEMBER(volume);
   CHECK_MEMBER(openInterest);
   #undef CHECK_MEMBER

   if( ( history1->timestamp && !history2->timestamp) ||
       (!history1->timestamp &&  history2->timestamp) )
      return 0;
   if( history1->timestamp )
   {
      for( i=0; i < history1->nbBars; i++ )
      {
         if( !FD_TimestampEqual(&history1->timestamp[i],&history2->timestamp[i]) )
            return 0;
      }
   }

   return 1; /* Contents is equivalent. */
}

static FD_AddDataSourceParamPriv *FD_AddDataSourceParamPrivAlloc( const FD_AddDataSourceParam *param, FD_SourceFlag flag )
{
   /* Alloc an internal copy of the FD_AddDataSourceParam . */
   FD_AddDataSourceParamPriv *dst;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   dst = (FD_AddDataSourceParamPriv *)FD_Malloc( sizeof(FD_AddDataSourceParamPriv) );
   if( !dst )
      return NULL;

   memset( dst, 0, sizeof( FD_AddDataSourceParamPriv ) );

   /* At this point, FD_AddDataSourceParamPrivFree can be safely called. */

   #define DO(func,y) \
      { \
         if(param->y) \
         { \
            dst->y = func( stringCache, param->y ); \
            if( !dst->y ) \
            { \
               FD_AddDataSourceParamPrivFree( dst ); \
               return NULL; \
            } \
         } \
         else \
            dst->y = NULL; \
      } 

   /* Same as DO but provide a default if not specified by the user. */
   #define DO_DFLT(func,y,dflt) \
      { \
         if( param->y ) \
            dst->y = func( stringCache, param->y ); \
         else \
            dst->y = func( stringCache, dflt ); \
         if( !dst->y ) \
         { \
            FD_AddDataSourceParamPrivFree( dst ); \
            return NULL; \
         } \
      }

      if( flag & FD_LOCATION_IS_PATH )
      {
         DO( FD_StringAlloc_Path, location );
      }
      else
      {
         DO( FD_StringAlloc, location );
      }
         
      DO( FD_StringAlloc,     info     );
      DO( FD_StringAlloc,     username );
      DO( FD_StringAlloc,     password );
      DO( FD_StringAlloc,     symbol   );

      DO_DFLT( FD_StringAlloc, category,   FD_DEFAULT_CATEGORY          );
      DO_DFLT( FD_StringAlloc, country,    FD_DEFAULT_CATEGORY_COUNTRY  );
      DO_DFLT( FD_StringAlloc, exchange,   FD_DEFAULT_CATEGORY_EXCHANGE );
      DO_DFLT( FD_StringAlloc, type,       FD_DEFAULT_CATEGORY_TYPE     );
      DO_DFLT( FD_StringAlloc, sourceName, FD_gDataSourceTable[param->id].defaultName );
   #undef DO
   #undef DO_FLT

   /* Copy the rest. */
   dst->flags  = param->flags;
   dst->id     = param->id;
   dst->period = param->period;
   return dst;
}

static FD_RetCode FD_AddDataSourceParamPrivFree( FD_AddDataSourceParamPriv *toBeFreed )
{
   FD_StringCache *stringCache;

   if( toBeFreed )
   {
      stringCache = FD_GetGlobalStringCache();

      /* Free all the strings that are not NULL. */
      #define DO(y) { if(toBeFreed->y) FD_StringFree( stringCache, toBeFreed->y ); }
         DO( location   );
         DO( info       );
         DO( username   );
         DO( password   );
         DO( category   );
         DO( country    );
         DO( exchange   );
         DO( type       );
         DO( symbol     );
         DO( sourceName );
      #undef DO

      FD_Free( toBeFreed );
   }

   return FD_SUCCESS;
}

/**** Local functions definitions.     ****/

static FD_RetCode closeAllUDBase( FD_DataGlobal *global )
{
   FD_List *listUDB;
   FD_UDBase *udBase;

   /* Attempts to close all UDBase belonging to this library. */
   if( !global )
      return FD_INTERNAL_ERROR(30);

   listUDB = global->listUDBase;

   udBase = (FD_UDBase *)FD_ListRemoveTail( listUDB );
   while( udBase )
   {
      FD_UDBaseFree( udBase );
      udBase = (FD_UDBase *)FD_ListRemoveTail( listUDB );
   }

   return FD_SUCCESS;
}

static FD_RetCode closeAllDataSource( FD_UDBasePriv *privUDB )
{
   FD_PROLOG
   FD_DataSource       *dataSource;
   FD_StringCache      *stringCache;
   FD_List             *listDataSource;

   const FD_DataSourceDriver *driver;
   
   FD_TRACE_BEGIN( closeAllDataSource );
   stringCache = FD_GetGlobalStringCache();

   listDataSource = privUDB->listDataSource;

   dataSource = (FD_DataSource *)FD_ListRemoveTail( listDataSource );
   while( dataSource )
   {
      FD_ASSERT( dataSource->addDataSourceParamPriv->id < FD_NUM_OF_SOURCE_ID );

      driver = &FD_gDataSourceTable[dataSource->addDataSourceParamPriv->id];

      if( driver->closeSource )
      {
         if( dataSource->sourceHandle )
            driver->closeSource( dataSource->sourceHandle );
      }

      if( dataSource->addDataSourceParamPriv )
         FD_AddDataSourceParamPrivFree( dataSource->addDataSourceParamPriv );

      if( dataSource->listCategoryHandle )
         freeListAndElement( dataSource->listCategoryHandle, freeCategoryHandle );

      FD_Free( dataSource );

      dataSource = (FD_DataSource *)FD_ListRemoveTail( listDataSource );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode shutdownAllSourceDriver( FD_DataGlobal *global )
{
   unsigned int i;
   const FD_DataSourceDriver *driver;

   for( i=0; i < FD_gDataSourceTableSize; i++)
   {
      if( global->dataSourceInitFlag[i] )
      {
         driver = &FD_gDataSourceTable[i];
         if( driver->shutdownSourceDriver )
            driver->shutdownSourceDriver();
         global->dataSourceInitFlag[i] = 0;
      }
   }

   return FD_SUCCESS;
}

/* Add an entry in the dictCategory for the specified UDBase.
 * - If an entry is already existing, no entry are added and the existing
 *   entry is returned.
 * - If the entry does not exist, it is created and returned.
 *
 * On error, NULL is returned.
 */
static FD_UDB_Category *addCategory( FD_UDBasePriv *privUDB,
                                     FD_String *string )
{
   FD_UDB_Category *category;
   FD_RetCode retCode;
   FD_Dict *dictCategory;
   FD_StringCache *stringCache;

   if( !privUDB )
      return NULL;

   /* Validate parameters. */
   FD_ASSERT_RET( string != NULL, (FD_UDB_Category *)NULL );

   dictCategory = privUDB->dictCategory;
   FD_ASSERT_RET( dictCategory != NULL, (FD_UDB_Category *)NULL );

   /* Check if the string already exist in the dictionary.
    * If yes, do not add it, simply return it.
    */
   category = (FD_UDB_Category *)FD_DictGetValue_S( dictCategory, FD_StringToChar(string) );

   if( category )
      return category;

   /* The entry does not exist, create it and add it to the
    * dictCategory.
    */
   category = (FD_UDB_Category *)FD_Malloc( sizeof( FD_UDB_Category ) );

   if( category == NULL )
      return NULL;

   FD_ListInit(  &category->listUDBDriverArray );

   retCode = FD_DictAddPair_S( dictCategory, string, category );

   if( retCode != FD_SUCCESS )
   {
      FD_Free( category );
      return NULL;
   }

   /* Initialize the FD_UDB_Category fields. */
   category->dictUDBSymbol = FD_DictAlloc( FD_DICT_KEY_ONE_STRING, freeSymbolData );

   if( !category->dictUDBSymbol )
   {
      /* Can not create the symbol dict!? Clean-up and get out of here.... */
      FD_DictDeletePair_S( dictCategory, FD_StringToChar(string) );
      FD_Free( category );
      return NULL;
   }

   stringCache = FD_GetGlobalStringCache();
   category->string = FD_StringDup( stringCache, string );

   if( !category->string )
   {
      FD_DictFree( category->dictUDBSymbol );
      FD_DictDeletePair_S( dictCategory, FD_StringToChar(string) );
      FD_Free( category );
      return NULL;
   }

   return category;
}

static FD_UDB_Symbol *addSymbol( FD_UDBasePriv *privUDB,
                                 FD_Dict *dictUDBSymbol,
                                 FD_UDB_Driver *driverHandle,
                                 FD_DataSourceHandle *sourceHandle,
                                 FD_CategoryHandle *categoryHandle,
                                 FD_SymbolHandle *symbolHandle )
{
   FD_UDB_Symbol *data;   
   FD_RetCode retCode;
   FD_StringCache *stringCache;

   if( !privUDB )
      return NULL;

   /* Validate parameters. */
   FD_ASSERT_RET( dictUDBSymbol != NULL, (FD_UDB_Symbol *)NULL );
   FD_ASSERT_RET( sourceHandle != NULL, (FD_UDB_Symbol *)NULL );
   FD_ASSERT_RET( categoryHandle != NULL, (FD_UDB_Symbol *)NULL );
   FD_ASSERT_RET( symbolHandle != NULL, (FD_UDB_Symbol *)NULL );
   FD_ASSERT_RET( symbolHandle->string != NULL, (FD_UDB_Symbol *)NULL );

   stringCache = FD_GetGlobalStringCache();

   /* Check if the symbol is already in the dictionary.
    * If yes, use it, else create a new entry in the dictionary.
    */
   data = (FD_UDB_Symbol *)FD_DictGetValue_S( dictUDBSymbol, FD_StringToChar(symbolHandle->string) );

   if( data == NULL )
   {
      data = (FD_UDB_Symbol *)FD_Malloc( sizeof( FD_UDB_Symbol ) );

      if( data == NULL )
         return NULL;

      FD_ListInit( &data->listDriverHandle );

      retCode = FD_DictAddPair_S( dictUDBSymbol, symbolHandle->string, data );

      if( retCode != FD_SUCCESS )
      {
         FD_Free( data );
         return NULL;
      }

      /* Initialize the FD_UDB_Symbol fields. */
      data->string = FD_StringDup( stringCache, symbolHandle->string );

      if( data->string == NULL )
      {
         FD_DictDeletePair_S( dictUDBSymbol, FD_StringToChar(symbolHandle->string) );
         FD_Free( data );
         return NULL;
      }
   }

   /* Add the FD_UDB_Driver to the list for this symbol. */
   retCode = FD_ListNodeAddTail( &data->listDriverHandle, &driverHandle->node, driverHandle );
   if( retCode != FD_SUCCESS )
   {
      FD_DictDeletePair_S( dictUDBSymbol, FD_StringToChar(symbolHandle->string) );
      FD_StringFree( stringCache, data->string );
      FD_Free( data );
      FD_Free( driverHandle );
      return NULL;
   }

   return data;
}

static FD_RetCode stringTableFree( FD_StringTable *table, unsigned int freeInternalStringOnly )
{
   FD_PROLOG
   unsigned int size;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( stringTableFree );

   if( table == NULL )
   {
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   stringCache = FD_GetGlobalStringCache();

   if( table->string )
   {
      size = table->size;

      while( size > 0 )
      {
         if( (table->string)[size-1] )
            FD_StringFree( stringCache, FD_StringFromChar((table->string)[size-1]) );

         size--;
      }

      FD_Free( (void *)table->string );
   }

   if( !freeInternalStringOnly )
      FD_Free( table );

   FD_TRACE_RETURN( FD_SUCCESS );
}

/* On deletion of dictCategory, this function will get called
 * for each FD_UDB_Category member of the dictionary.
 */
static void freeCategoryData( void *toBeFreed )
{
   FD_UDB_Category *categoryData = (FD_UDB_Category *)toBeFreed;
   FD_StringCache *stringCache;

   if( categoryData->string )
   {
      stringCache = FD_GetGlobalStringCache();
      FD_StringFree( stringCache, categoryData->string );
   }

   /* Delete all symbols under that category. */
   if( categoryData->dictUDBSymbol )
      FD_DictFree( categoryData->dictUDBSymbol );

   /* Delete all the FD_UDB_Driver arrays. */
   freeListAndElement( &categoryData->listUDBDriverArray, freeUDBDriverArray );

   FD_Free( categoryData );
}

/* On deletion of a symbol dictionary, this function will get called
 * for each FD_UDB_Symbol member of the dictionary.
 */
static void freeSymbolData( void *toBeFreed )
{
   FD_UDB_Symbol *symbolData = (FD_UDB_Symbol *)toBeFreed;
   FD_StringCache *stringCache;

   /* Free the category/strings handles. */
   if( symbolData->string )
   {
      stringCache = FD_GetGlobalStringCache();
      FD_StringFree( stringCache, symbolData->string );
   }

   FD_Free(  symbolData );
}

static FD_RetCode processCategoryAndSymbols( FD_UDBasePriv *privUDB,
                                             const FD_DataSourceDriver *driver,
                                             const FD_AddDataSourceParamPriv *addDataSourceParamPriv,
                                             FD_DataSourceHandle *sourceHandle,
                                             FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_UDB_Category *categoryData;
   FD_UDB_Symbol   *symbolData;
   FD_UDB_Driver *theUDBDriverArray;
   FD_UDB_Driver *currentUDBDriver;

   FD_SymbolHandle *symbolHandle;
   unsigned int nbSymbol;
   unsigned int symbolIndex;

   if( !privUDB )
      return FD_INTERNAL_ERROR(31);

   FD_TRACE_BEGIN(  processCategoryAndSymbols );

   FD_ASSERT( driver != NULL );
   FD_ASSERT( sourceHandle != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( categoryHandle->string != NULL );

   categoryData = addCategory( privUDB, categoryHandle->string );

   if( (categoryData == NULL) || (categoryData->dictUDBSymbol == NULL) )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   nbSymbol = categoryHandle->nbSymbol;
   if( nbSymbol != 0 )
   {
      /* In one shot, allocate all the FD_UDB_Driver for all the symbols for
       * this category. This array will be owned by the corresponding FD_UDB_Category.
       */
      theUDBDriverArray = (FD_UDB_Driver *)FD_Malloc( sizeof( FD_UDB_Driver ) * nbSymbol );
      if( !theUDBDriverArray )
      {
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
      memset( theUDBDriverArray, 0, sizeof( FD_UDB_Driver ) * nbSymbol );

      retCode = FD_ListAddTail( &categoryData->listUDBDriverArray, theUDBDriverArray );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(  theUDBDriverArray );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      /* For the time being, for simplicity, nothing is removed from the
       * listUDBDriverArray, until the corresponding category is deleted.
       */
      for( symbolIndex=0; symbolIndex < nbSymbol; symbolIndex++ )
      {
         /* Initialize the FD_UDB_Driver for this symbol. */
         currentUDBDriver = &theUDBDriverArray[symbolIndex];
         currentUDBDriver->sourceHandle  = sourceHandle;
         currentUDBDriver->categoryHandle = categoryHandle;
         currentUDBDriver->addDataSourceParamPriv = addDataSourceParamPriv;

         /* Ask the driver to fill the symbolHandle information. */
         symbolHandle = &(currentUDBDriver->symbolHandle);
         if( symbolIndex == 0 )
            retCode = driver->getFirstSymbolHandle( sourceHandle,
                                                    categoryHandle,
                                                    symbolHandle );
         else
            retCode = driver->getNextSymbolHandle( sourceHandle,
                                                   categoryHandle,
                                                   symbolHandle,
                                                   symbolIndex );

         if( retCode != FD_SUCCESS )
         {
            FD_TRACE_RETURN( retCode );
         }
         else
         {
            /* Add the symbol to the unified database */            
            symbolData = addSymbol( privUDB, categoryData->dictUDBSymbol,
                                    currentUDBDriver,
                                    sourceHandle,
                                    categoryHandle,
                                    symbolHandle );
            if( symbolData == NULL )
            {
               FD_TRACE_RETURN( FD_ALLOC_ERR );
            }
         }
      }
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode freeListAndElement( FD_List *list,
                                      FD_RetCode (*freeFunc)( void *toBeFreed ))
{
   FD_PROLOG
   FD_RetCode retCode;
   void *node;

   FD_TRACE_BEGIN( freeListAndElement );

   if( list != NULL )
   {
      while( (node = FD_ListRemoveTail( list )) != NULL )
      {
         retCode = freeFunc(  node );
         if( retCode != FD_SUCCESS )
         {
            FD_FATAL(  NULL, node, retCode );
         }
      }

      retCode = FD_ListFree( list );
      if( retCode != FD_SUCCESS )
      {
         FD_FATAL(  NULL, list, retCode );
      }
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode freeUDBDriverArray( void *toBeFreed )
{
   /* Free all the FD_UDB_Driver of a certain category/datasource
    * combination in one shot (see FD_UDB_Category->listUDBDriverArray)
    */
   if( toBeFreed )
      FD_Free( toBeFreed );

   return FD_SUCCESS;
}

static FD_RetCode freeCategoryHandle( void *toBeFreed )
{
   if( toBeFreed )
      FD_Free( (FD_CategoryHandle *)toBeFreed );

   return FD_SUCCESS;
}

static FD_DataSource *allocDataSourceForGlobal( FD_UDBasePriv *privUDB,
                                                FD_AddDataSourceParamPriv *addDataSourceParamPriv,
                                                FD_DataSourceHandle *sourceHandle,
                                                FD_List *listCategoryHandle )
{
   FD_RetCode finalRetCode;
   FD_DataSource *dataSource;
   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif

   if( !privUDB )
      return NULL;

   dataSource = (FD_DataSource *)FD_Malloc( sizeof( FD_DataSource ) );

   memset( dataSource, 0, sizeof( FD_DataSource ) );

   dataSource->addDataSourceParamPriv = addDataSourceParamPriv;
   dataSource->sourceHandle = sourceHandle;
   dataSource->listCategoryHandle = listCategoryHandle;

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &privUDB->sema );
   if( retCode != FD_SUCCESS )
   {
      FD_Free(  dataSource );
      return NULL;
   }
   #endif

   finalRetCode = FD_ListAddTail( privUDB->listDataSource, dataSource );

   #if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaPost( &privUDB->sema );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   #endif

   if( finalRetCode != FD_SUCCESS )
   {
      FD_Free(  dataSource );
      return NULL;
   }

   return dataSource;
}

static FD_RetCode FD_DataGlobalShutdown( void *globalAllocated )
{
   FD_RetCode retCode;
   FD_RetCode finalRetCode;
   FD_DataGlobal *global;

   /* Will change if an error occured. */
   finalRetCode = FD_SUCCESS;

   if( !globalAllocated )
      return FD_BAD_PARAM;

   global = (FD_DataGlobal *)globalAllocated;

   /* Free all the UDBase. */
   retCode = closeAllUDBase( global );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;
   FD_ListFree( global->listUDBase );

   /* Shutdown all the source drivers. */
   retCode = shutdownAllSourceDriver( global );
   if( retCode != FD_SUCCESS )
      finalRetCode = retCode;

   FD_Free( global->dataSourceInitFlag );
   FD_Free( globalAllocated );

   return finalRetCode;
}

static FD_RetCode FD_DataGlobalInit( void **globalToAlloc )
{
   FD_PROLOG
   FD_DataGlobal *global;

   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif

   FD_TRACE_BEGIN( FD_DataGlobalInit );

   /* Make some "parano" runtime sanity check of the code. */
   FD_ASSERT( FD_gDataSourceTableSize == FD_NUM_OF_SOURCE_ID );

   *globalToAlloc = NULL;

   /* Allocate the global. */
   global = (FD_DataGlobal *)FD_Malloc( sizeof( FD_DataGlobal ) );
   if( !global )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Allocate and initialize flags use to keep track of which data source
    * driver have been initialized.
    */
   global->dataSourceInitFlag = (unsigned char *)FD_Malloc( FD_gDataSourceTableSize * sizeof( unsigned char) );
   if( !global->dataSourceInitFlag )
   {
      FD_Free( global );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   memset( global->dataSourceInitFlag, 0, FD_gDataSourceTableSize * sizeof( unsigned char) );

   /* Initialize the list keeping track of the UDBase. */
   global->listUDBase = FD_ListAlloc( );
   if( !global->listUDBase )
   {
      FD_Free( global->dataSourceInitFlag );
      FD_Free( global );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaInit( &global->sema, 1 );
      if( retCode != FD_SUCCESS )
      {
         FD_ListFree( global->listUDBase );
         FD_Free( global->dataSourceInitFlag );
         FD_Free( global );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
   #endif

   /* Success! Return the global to the caller. */
   *globalToAlloc = global;
   FD_TRACE_RETURN( FD_SUCCESS );
}


