#ifndef FD_TOKEN_H
#define FD_TOKEN_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

typedef enum
{
   FD_TOK_FIX,  /* A fixed string. */

   FD_TOK_YYYY, /* 4 digits Year string. */
   FD_TOK_YY,   /* 2 digits Year string. */
   FD_TOK_Y,    /* Year string (delimitated integer) */

   FD_TOK_M,    /* Month string (delimitated integer) */
   FD_TOK_MM,   /* 2 digits Month string  */
   FD_TOK_MMM,  /* 3 letters Month string */

   FD_TOK_D,    /* Day string (delimitated integer) */
   FD_TOK_DD,   /* 2 digits Day string. */

   FD_TOK_CAT,    /* Category String.  */
   FD_TOK_CATC,   /* Category Country  */
   FD_TOK_CATX,   /* Category Exchange */
   FD_TOK_CATT,   /* Category Type     */

   FD_TOK_SYM,    /* Symbol string (wild). */
   FD_TOK_SYMF,   /* Symbol string (fixed). */

   FD_TOK_SEP,  /* Seperator string (used in directory path). */

   FD_TOK_WILD,      /* Any value string. This is the '*' symbol. */
   FD_TOK_WILD_CHAR, /* Any value character. This is the '?' symbol. */

   FD_TOK_OPEN,
   FD_TOK_HIGH,
   FD_TOK_LOW,
   FD_TOK_CLOSE,
   FD_TOK_VOLUME,
   FD_TOK_OPENINTEREST,

   FD_TOK_HOUR,
   FD_TOK_MIN,
   FD_TOK_SEC,

   FD_TOK_HH, /* 2 digit hour string. */
   FD_TOK_MN, /* 2 digit minute string. */
   FD_TOK_SS, /* 2 digit second string. */

   FD_TOK_SKIP_N_REAL,
   FD_TOK_SKIP_N_INTEGER,
   FD_TOK_SKIP_N_CHAR,
   FD_TOK_SKIP_N_HEADER_LINE,

   FD_TOK_SKIP_NON_DIGIT_LINE,

   FD_TOK_END,  /* Indicates no more token available. */

   FD_NB_TOKEN_ID,

   FD_INVALID_TOKEN_ID = -1
} FD_TokenId;

/* The following will return the number of character a token
 * can take maximum. If this is an unlimited size, Zero is returned.
 */
unsigned int FD_TokenMaxSize( FD_TokenId id );

/* Return the string corresponding to the specified FD_TokenId.
 * That string is the one used within the '[' and ']'.
 */
const char *FD_TokenString( FD_TokenId id );

/* Return a string corresponding to a FD_TokenId.
 * That string can be used to display debug information.
 */
const char *FD_TokenDebugString( FD_TokenId id );

#endif
