/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  012504 MF   Add a few FD_ASSERT.
 */

/* Description:
 *    Allows to allocate/de-allocate FD_DataSourceHandle structure.
 */

/**** Headers ****/
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_ascii_handle.h"
#include "fd_fileindex.h"
#include "fd_token.h"
#include "fd_global.h"
#include "fd_readop.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/
static FD_PrivateAsciiHandle *allocPrivateHandle( void );
static FD_RetCode freePrivateHandle( FD_PrivateAsciiHandle *privateHandle );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

FD_DataSourceHandle *FD_ASCII_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param )
{
   FD_DataSourceHandle *handle;
   FD_PrivateAsciiHandle *privateHandle;

   FD_ASSERT_RET( param != NULL, (FD_DataSourceHandle *)NULL );
      
   handle = (FD_DataSourceHandle *)FD_Malloc(sizeof( FD_DataSourceHandle ));
   if( !handle )
      return (FD_DataSourceHandle *)NULL;

   /* Initialized fields. */
   handle->nbCategory = 0;

   /* Allocate the opaque data. */
   handle->opaqueData = allocPrivateHandle();
   if( !handle->opaqueData )
   {
      FD_ASCII_DataSourceHandleFree( handle );
      return (FD_DataSourceHandle *)NULL;
   }

   privateHandle = (FD_PrivateAsciiHandle *)handle->opaqueData;
   privateHandle->param = param;

   return handle;
}

FD_RetCode FD_ASCII_DataSourceHandleFree( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_PrivateAsciiHandle *privateHandle;

   FD_TRACE_BEGIN( FD_ASCII_DataSourceHandleFree );
   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateAsciiHandle *)handle->opaqueData;


   if( freePrivateHandle( (FD_PrivateAsciiHandle *)handle->opaqueData ) != FD_SUCCESS )
   {
      FD_FATAL(  NULL, handle, 0 );
   }

   FD_Free( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_BuildFileIndex( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileIndex *newIndex;
   FD_PrivateAsciiHandle *privateHandle;

   FD_TRACE_BEGIN( FD_ASCII_BuildFileIndex );

   FD_ASSERT( handle != NULL );
   privateHandle = (FD_PrivateAsciiHandle *)handle->opaqueData;

   FD_ASSERT( privateHandle != NULL );
   FD_ASSERT( privateHandle->param != NULL );
   FD_ASSERT( privateHandle->param->category != NULL );
   FD_ASSERT( privateHandle->param->location != NULL );

   /* De-allocate potentialy already existing file index. */
   if( privateHandle->theFileIndex != NULL )
   {
      retCode = FD_FileIndexFree( privateHandle->theFileIndex );
      privateHandle->theFileIndex = NULL;
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
   }

   /* Allocate new file index. */
   retCode = FD_FileIndexAlloc( privateHandle->param->location,
                                privateHandle->param->category,
                                privateHandle->param->country,
                                privateHandle->param->exchange,
                                privateHandle->param->type,
                                &newIndex );

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( newIndex != NULL );

   privateHandle->theFileIndex = newIndex;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_BuildReadOpInfo( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PrivateAsciiHandle *privateHandle;
   int readOpFlags;

   FD_TRACE_BEGIN( FD_ASCII_BuildFileIndex );
   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateAsciiHandle *)handle->opaqueData;


   FD_ASSERT( privateHandle != NULL );
   FD_ASSERT( privateHandle->param != NULL );
   FD_ASSERT( privateHandle->param->category != NULL );
   FD_ASSERT( privateHandle->param->location != NULL );

   readOpFlags = 0;
   if( privateHandle->param->flags & FD_REPLACE_ZERO_PRICE_BAR )
   {
      FD_SET_REPLACE_ZERO(readOpFlags);
   }

   retCode = FD_ReadOpInfoAlloc( FD_StringToChar(privateHandle->param->info),
                                 &privateHandle->readOpInfo, readOpFlags );

   FD_TRACE_RETURN( retCode );
}

/**** Local functions definitions.     ****/

static FD_PrivateAsciiHandle *allocPrivateHandle( void  )
{
   FD_PrivateAsciiHandle *privateHandle;

   privateHandle = (FD_PrivateAsciiHandle *)FD_Malloc( sizeof( FD_PrivateAsciiHandle ) );
   if( !privateHandle )
      return NULL;

   memset( privateHandle, 0, sizeof( FD_PrivateAsciiHandle ) );

   return privateHandle;
}

static FD_RetCode freePrivateHandle( FD_PrivateAsciiHandle *privateHandle )
{
   if( privateHandle )
   {
      if( privateHandle->theFileIndex )
         FD_FileIndexFree( privateHandle->theFileIndex );

      if( privateHandle->readOpInfo )
         FD_ReadOpInfoFree( privateHandle->readOpInfo );

      FD_Free(  privateHandle );
   }

   return FD_SUCCESS;
}
