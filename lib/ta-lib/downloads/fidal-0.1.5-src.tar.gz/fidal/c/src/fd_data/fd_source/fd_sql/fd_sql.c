/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  PK       Pawel Konieczny
 *  MF       Mario Fortier
 *  JS       Jon Sudul
 *
 * Change history:
 *
 *  MMDDYY BY     Description
 *  -------------------------------------------------------------------
 *  101703 PK     First version.
 *  110103 PK     Minidriver architecture
 *  012504 MF,JS  Fix some memory leaks and perform integer/double cast
 *                for columns that represents a number (Bug #881950)
 *  013104 MF     Revert the FD_TRACE_RETURN/RETURN_ON_ERROR change.
 *  112704 MF     Add handling of NULL for username and password.
 */

/* Description:
 *    This is the entry points of the data source driver for SQL database.
 *    It depend on the mysql++ library
 *
 *    It provides ALL the functions needed by the "FD_DataSourceDriver"
 *    structure (see fd_source.h).
 */

/**** Headers ****/
#include <ctype.h>
#include <string.h>
#include "fd_source.h"
#include "fd_common.h"
#include "fd_trace.h"
#include "fd_memory.h"
#include "fd_list.h"
#include "fd_global.h"
#include "fidal.h"
#include "fd_system.h"
#include "fd_sql.h"
#include "fd_sql_handle.h"
#include "fd_sql_local.h"

#if defined( WIN32 )
   #include "fd_sql_odbc.h"
#endif

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/

static FD_RetCode executeDataQuery( FD_PrivateSQLHandle *privateHandle, 
                                    const char          *queryStr, 
                                    FD_Period            period,
                                    FD_Field             fieldToAlloc,
                                    FD_ParamForAddData  *paramForAddData );

static const char *formatISODate(const FD_Timestamp *ts);
static const char *formatISOTime(const FD_Timestamp *ts);


/**** Local variables definitions.     ****/
FD_FILE_INFO;

#if !defined( FD_SINGLE_THREAD )
FD_Sema mod_sema;
#endif

/**** Global functions definitions.   ****/

FD_RetCode FD_SQL_InitializeSourceDriver( void )
{
   FD_PROLOG

   #if !defined( FD_SINGLE_THREAD ) || defined( WIN32 )
   FD_RetCode retCode;
   #endif

   FD_TRACE_BEGIN( FD_SQL_InitializeSourceDriver );

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaInit( &mod_sema, 1);
      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( retCode );
   #endif

   #if defined( WIN32 )
      /* ODBC driver is always enabled on WIN32 platform */
      retCode = FD_SQL_ODBC_Initialize();
      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( retCode );
   #endif

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_ShutdownSourceDriver( void )
{
   FD_PROLOG

   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif

   FD_TRACE_BEGIN( FD_SQL_ShutdownSourceDriver );

   FD_SQL_ShutdownMinidriver();

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaDestroy( &mod_sema );
      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( retCode );
   #endif

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_SQL_GetParameters );

   if( !param )
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(147) );

   memset( param, 0, sizeof( FD_DataSourceParameters ) );

   /* Parameters supported by FD_SQL */
   param->flags = FD_REPLACE_ZERO_PRICE_BAR;

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_OpenSource( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_DataSourceHandle *tmpHandle;
   FD_PrivateSQLHandle *privData;
   char *scheme, *host, *dbase;
   unsigned port;
   FD_RetCode retCode;

   FD_TRACE_BEGIN( FD_SQL_OpenSource );
   FD_ASSERT( handle != NULL );
   FD_ASSERT( param != NULL );

   *handle = NULL;

   /* 'info' and 'location' are mandatory. */
   if( (!param->info) || (!param->location) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   /* get parameters for SQL connection */
   scheme = (char*)FD_Malloc(strlen(FD_StringToChar(param->location)));
   if (scheme == NULL)
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   host = (char*)FD_Malloc(strlen(FD_StringToChar(param->location)));
   if (host == NULL)
   {
      FD_Free(scheme);
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   dbase = (char*)FD_Malloc(strlen(FD_StringToChar(param->location)));
   if (dbase == NULL)
   {
      FD_Free(scheme);
      FD_Free(host);
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   retCode = FD_SQL_ParseLocation(FD_StringToChar(param->location), scheme, host, &port, dbase);
   if( retCode != FD_SUCCESS )
   {
      FD_Free(scheme);
      FD_Free(host);
      FD_Free(dbase);
      FD_TRACE_RETURN( retCode );
   }

   /* Allocate and initialize the handle. This function will also allocate the
    * private handle (opaque data).
    */
   tmpHandle = FD_SQL_DataSourceHandleAlloc(param);

   if( tmpHandle == NULL )
   {
      FD_Free(scheme);
      FD_Free(host);
      FD_Free(dbase);
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   privData = (FD_PrivateSQLHandle *)(tmpHandle->opaqueData);

   /* Determine the minidriver to use */
   privData->minidriver = FD_SQL_GetMinidriver( scheme );

   /* Establish the connection with the SQL server */
   if(  privData->minidriver 
     && privData->minidriver->openConnection )
   {
      retCode = (*privData->minidriver->openConnection)(
         dbase, 
         host, 
         param->username?FD_StringToChar(param->username):NULL, 
         param->password?FD_StringToChar(param->password):NULL, 
         port,
         &privData->connection);
   }
   else
   {    /* minidriver not recognized */
      retCode = FD_INVALID_DATABASE_TYPE;
   }

   if( retCode != FD_SUCCESS )
   {
      FD_Free(scheme);
      FD_Free(host);
      FD_Free(dbase);
      FD_SQL_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Database name is a fallback symbol name when not available from parameters */
   privData->database = FD_StringAlloc(FD_GetGlobalStringCache(), dbase);
   FD_Free(scheme);
   FD_Free(host);
   FD_Free(dbase);
   if( !privData->database )
   {
      FD_SQL_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Now build the symbols index. */
   retCode = FD_SQL_BuildSymbolsIndex( tmpHandle );

   if( retCode != FD_SUCCESS )
   {
      FD_SQL_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Set the total number of distinct categories. */
   tmpHandle->nbCategory = FD_ListSize(privData->theCategoryIndex);

   *handle = tmpHandle;

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_SQL_CloseSource );

   /* Free all ressource used by this handle. */
   if( handle )
      FD_SQL_DataSourceHandleFree( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG
   FD_PrivateSQLHandle *privData;
   FD_List               *categoryIndex;
   FD_SQLCategoryNode  *categoryNode;

   FD_TRACE_BEGIN( FD_SQL_GetFirstCategoryHandle );

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateSQLHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(148) );
   }

   categoryIndex = privData->theCategoryIndex;

   if( !categoryIndex )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(149) );
   }

   /* Get the first category from the category index */
   categoryNode = (FD_SQLCategoryNode*)FD_ListAccessHead(categoryIndex);

   if( !categoryNode || !categoryNode->category )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(150) ); /* At least one category must exist. */
   }

   /* Set the categoryHandle. */
   categoryHandle->string = categoryNode->category;
   categoryHandle->nbSymbol = FD_ListSize(categoryNode->theSymbols);
   categoryHandle->opaqueData = categoryNode->theSymbols;

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_GetNextCategoryHandle( FD_DataSourceHandle *handle,
                                         FD_CategoryHandle   *categoryHandle,
                                         unsigned int         index )
{
   FD_PROLOG
   FD_PrivateSQLHandle *privData;
   FD_List               *categoryIndex;
   FD_SQLCategoryNode  *categoryNode;

   FD_TRACE_BEGIN(  FD_SQL_GetNextCategoryHandle );

   (void)index; /* Get rid of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateSQLHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(152) );
   }

   categoryIndex = privData->theCategoryIndex;

   if( !categoryIndex )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(153) );
   }

   /* Get the next category from the category index */
   categoryNode = (FD_SQLCategoryNode*)FD_ListAccessNext(categoryIndex);

   if( !categoryNode )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Set the categoryHandle. */
   categoryHandle->string = categoryNode->category;
   categoryHandle->nbSymbol = FD_ListSize(categoryNode->theSymbols);
   categoryHandle->opaqueData = categoryNode->theSymbols;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SQL_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle,
                                          FD_SymbolHandle     *symbolHandle )
{
   FD_PROLOG
   FD_PrivateSQLHandle *privData;
   FD_List               *symbolsIndex;
   FD_String             *symbol;

   FD_TRACE_BEGIN( FD_SQL_GetFirstSymbolHandle );

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateSQLHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(151) );
   }

   symbolsIndex = (FD_List*)categoryHandle->opaqueData;

   /* Get the first symbol in this category. */
   symbol = (FD_String*)FD_ListAccessHead(symbolsIndex);

   if( !symbol )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Set the symbolHandle. */
   symbolHandle->string = symbol;
   symbolHandle->opaqueData = NULL;  /* not needed */

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle   *categoryHandle,
                                       FD_SymbolHandle     *symbolHandle,
                                       unsigned int         index )
{
   FD_PROLOG
   FD_PrivateSQLHandle *privData;
   FD_List               *symbolsIndex;
   FD_String             *symbol;

   FD_TRACE_BEGIN( FD_SQL_GetNextSymbolHandle );

   (void)index; /* Get rid of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateSQLHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( (FD_RetCode)FD_INTERNAL_ERROR(154) );
   }

   symbolsIndex = (FD_List*)categoryHandle->opaqueData;

   /* Get the first symbol in this category. */
   symbol = (FD_String*)FD_ListAccessNext(symbolsIndex);

   if( !symbol )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Set the symbolHandle. */
   symbolHandle->string = symbol;
   symbolHandle->opaqueData = NULL;  /* not needed */

   FD_TRACE_RETURN( FD_SUCCESS );
}




FD_RetCode FD_SQL_GetHistoryData( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_RetCode retCode = FD_SUCCESS;
   FD_PrivateSQLHandle *privateHandle;
   char *queryStr, *tempStr;
   FD_Timestamp trueEnd;

   FD_TRACE_BEGIN( FD_SQL_GetHistoryData );

   FD_ASSERT( handle != NULL );

   if (  (start && FD_TimestampValidate(start) != FD_SUCCESS)
      || (end && FD_TimestampValidate(end) != FD_SUCCESS))
   {
       FD_TRACE_RETURN(FD_BAD_PARAM);
   }

   privateHandle = (FD_PrivateSQLHandle *)handle->opaqueData;
   FD_ASSERT( privateHandle != NULL );

   FD_ASSERT( paramForAddData != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   /* verify whether this source can deliver data usable for the requested period */
   if( privateHandle->param->period > 0)
   {
      /* this check can be done only when a period is known for this source */
      if( period < privateHandle->param->period )
      {
         FD_TRACE_RETURN(FD_SUCCESS);  /* no usable data, but also no error */
      }

      period = privateHandle->param->period;  /* to be passed to fd_history */
   }
   else
   {
      /* just assume that this source has usable data for the requested period */
   }
   
   /* we need a valid end timestamp for placeholder expansion;
    * if end not defined, take maximal value
    */
   if ( end )
   {
      trueEnd = *end;
   }
   else /* default value 0 means no upper bound */
   {
      FD_SetDate(9999,12,31,&trueEnd);  /* need some high value to substitute in SQL */
      FD_SetTime(23,59,59,&trueEnd);
   }

   /* Replace all relevant placeholders */
#if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaWait( &mod_sema );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN(retCode);
   }
#endif
   queryStr = FD_SQL_ExpandPlaceholders(FD_StringToChar(privateHandle->param->info),
                                        FD_SQL_CATEGORY_PLACEHOLDER,
                                        FD_StringToChar(categoryHandle->string));

   tempStr = queryStr;
   queryStr = FD_SQL_ExpandPlaceholders(tempStr,
                                        FD_SQL_SYMBOL_PLACEHOLDER,
                                        FD_StringToChar(symbolHandle->string));
   if ( tempStr)
      FD_Free( tempStr );

   tempStr = queryStr;
   queryStr = FD_SQL_ExpandPlaceholders(tempStr,
                                        FD_SQL_START_DATE_PLACEHOLDER,
                                        formatISODate(start));

   if ( tempStr)
      FD_Free( tempStr );
   tempStr = queryStr;
   queryStr = FD_SQL_ExpandPlaceholders(tempStr,
                                        FD_SQL_END_DATE_PLACEHOLDER,
                                        formatISODate(&trueEnd));

   if ( tempStr)
      FD_Free( tempStr );

   tempStr = queryStr;
   queryStr = FD_SQL_ExpandPlaceholders(tempStr,
                                        FD_SQL_START_TIME_PLACEHOLDER,
                                        formatISOTime(start));

   if ( tempStr)
      FD_Free( tempStr );

   tempStr = queryStr;
   queryStr = FD_SQL_ExpandPlaceholders(tempStr,
                                        FD_SQL_END_TIME_PLACEHOLDER,
                                        formatISOTime(&trueEnd));

   if ( tempStr)
      FD_Free( tempStr );

#if !defined( FD_SINGLE_THREAD )
   retCode = FD_SemaPost( &mod_sema );
   if( retCode != FD_SUCCESS )
   {
      if ( queryStr )
         FD_Free( queryStr );
      FD_TRACE_RETURN(retCode);
   }
#endif
   if( !queryStr )
   {
       FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Now the SQL query */
   retCode = executeDataQuery( privateHandle, queryStr, period, fieldToAlloc, paramForAddData );

   FD_Free( queryStr );

   FD_TRACE_RETURN( retCode );
}



/**** Local functions definitions.     ****/

static FD_RetCode executeDataQuery( FD_PrivateSQLHandle *privateHandle, 
                                    const char          *queryStr, 
                                    FD_Period            period,
                                    FD_Field             fieldToAlloc,
                                    FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_RetCode retCode;
   unsigned int timeRequired;

   /* result vectors */
   FD_Timestamp *timestampVec;
   FD_Real *openVec;
   FD_Real *highVec;
   FD_Real *lowVec;
   FD_Real *closeVec;
   FD_Integer *volumeVec;
   FD_Integer *oiVec;
   FD_Integer tempInteger;
   FD_Real    tempReal;

   /* recognized columns */
   int dateCol, timeCol, openCol, highCol, lowCol, closeCol, volumeCol, oiCol;

   void *queryResult;
   int resColumns, resRows;
   int colNum, rowNum, barNum;
   const char *strval;

   FD_TRACE_BEGIN( executeDataQuery );

   /* Initialize the variables. */
   retCode      = FD_SUCCESS;
   timeRequired = (period < FD_DAILY);      /* Boolean */
   timestampVec = NULL;
   openVec      = NULL;
   highVec      = NULL;
   lowVec       = NULL;
   closeVec     = NULL;
   volumeVec    = NULL;
   oiVec        = NULL;
   resColumns   = -1;
   resRows      = -1;
   strval       = NULL;

   /* Now the SQL query */
   retCode = (*privateHandle->minidriver->executeQuery)(
               privateHandle->connection,
               queryStr,
               &queryResult);
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }
   
   /* from now on: the query result has to be released upon premature return 
    * later, also allocated vectors have to be released
    */
   #define RETURN_ON_ERROR( rc )                            \
   {                                                        \
         if( rc != FD_SUCCESS )                             \
         {                                                  \
            retCode = rc;                                   \
            goto executeDataQuery_cleanup;                  \
         }                                                  \
   }

   #define RETURN_FUNC( rc )                                \
   {                                                        \
      retCode = rc;                                         \
      goto executeDataQuery_cleanup;                        \
   }

   /* find recognized columns */
   dateCol = timeCol = openCol = highCol = lowCol = closeCol = volumeCol = oiCol = -1;

   retCode = (*privateHandle->minidriver->getNumColumns)(
                  queryResult,
                  &resColumns );
   RETURN_ON_ERROR( retCode );

   retCode = (*privateHandle->minidriver->getNumRows)(
                  queryResult,
                  &resRows );
   if( retCode != FD_SUCCESS || resRows <= 0 )
   {
      /* not all minidrivers support reporting the number of rows in a query in advance
       * it is not a disaster, just less efficient
       * data will be collected in fixed size chunks
       */
      resRows = 500;
   }

   for( colNum = 0; colNum < resColumns; colNum++ ) 
   { 
      const char *name;
      retCode = (*privateHandle->minidriver->getColumnName)(
                           queryResult,
                           colNum,
                           &name );
      RETURN_ON_ERROR( retCode );

      if( stricmp(name, FD_SQL_DATE_COLUMN) == 0 )
         dateCol = colNum;
      else
      if( stricmp(name, FD_SQL_TIME_COLUMN) == 0 )
         timeCol = colNum;
      else
      if( stricmp(name, FD_SQL_OPEN_COLUMN) == 0 )
         openCol = colNum;
      else
      if( stricmp(name, FD_SQL_HIGH_COLUMN) == 0 )
         highCol = colNum;
      else
      if( stricmp(name, FD_SQL_LOW_COLUMN) == 0 )
         lowCol = colNum;
      else
      if( stricmp(name, FD_SQL_CLOSE_COLUMN) == 0 )
         closeCol = colNum;
      else
      if( stricmp(name, FD_SQL_VOLUME_COLUMN) == 0 )
         volumeCol = colNum;
      else
      if( stricmp(name, FD_SQL_OI_COLUMN) == 0 )
         oiCol = colNum;
   } 

   /* timestamp is always needed */
   if( fieldToAlloc != FD_FIELD_ALL )
      fieldToAlloc |= FD_FIELD_TIMESTAMP;   

   /* When the FD_REPLACE_ZERO_PRICE_BAR flag is set, we must
    * always process the close.
    */
   if( fieldToAlloc != FD_FIELD_ALL && privateHandle->param->flags & FD_REPLACE_ZERO_PRICE_BAR )
   {   
      fieldToAlloc |= FD_FIELD_CLOSE;
   }

   /* verify whether all required columns are present */
   if( timeRequired && timeCol < 0 )
   {
      /* we cannot deliver data for the requested period, thus exit gracefully */
      retCode = (*privateHandle->minidriver->releaseQuery)(queryResult);
      FD_TRACE_RETURN( retCode );
   }
   if(  dateCol < 0
     || (fieldToAlloc & FD_FIELD_OPEN   && openCol   < 0)
     || (fieldToAlloc & FD_FIELD_HIGH   && highCol   < 0)
     || (fieldToAlloc & FD_FIELD_LOW    && lowCol    < 0)
     || (fieldToAlloc & FD_FIELD_CLOSE  && closeCol  < 0)
     || (fieldToAlloc & FD_FIELD_VOLUME && volumeCol < 0)
     || (fieldToAlloc & FD_FIELD_OPENINTEREST && oiCol < 0) )
   {
      /* required column not found, so cannot deliver data */
      retCode = (*privateHandle->minidriver->releaseQuery)(queryResult);
      FD_TRACE_RETURN( retCode );
   }
      
   /* iterate through the result set */
   for( rowNum = 0, barNum = 0;  
        (retCode = 
            (*privateHandle->minidriver->getRowString)(
                              queryResult,
                              rowNum, 
                              dateCol,
                              &strval )
        ) != FD_END_OF_INDEX;
        rowNum++ ) 
   { 
      unsigned int u1, u2, u3;

      RETURN_ON_ERROR( retCode );  /* retCode from the for-condition */

      if( timestampVec == NULL )
      {
         /* Preallocate vectors memory */
         timestampVec = (FD_Timestamp*)FD_Malloc( resRows * sizeof(FD_Timestamp));
         if ( !timestampVec )
            RETURN_FUNC( FD_ALLOC_ERR );
         memset(timestampVec, 0, resRows * sizeof(FD_Timestamp));
         
         #define FD_SQL_ALLOC_VEC( col_num, field_flag, type, vec )           \
         {                                                                    \
               if( col_num >= 0                                               \
                  && (fieldToAlloc & field_flag || fieldToAlloc == FD_FIELD_ALL))   \
               {                                                              \
                  vec = (type*)FD_Malloc( resRows * sizeof(type) );           \
                  if( !vec )                                                  \
                  {                                                           \
                     RETURN_FUNC( FD_ALLOC_ERR );                             \
                  }                                                           \
              }                                                               \
         }

         FD_SQL_ALLOC_VEC( openCol,   FD_FIELD_OPEN,         FD_Real,    openVec   )
         FD_SQL_ALLOC_VEC( highCol,   FD_FIELD_HIGH,         FD_Real,    highVec   )
         FD_SQL_ALLOC_VEC( lowCol,    FD_FIELD_LOW,          FD_Real,    lowVec    )
         FD_SQL_ALLOC_VEC( closeCol,  FD_FIELD_CLOSE,        FD_Real,    closeVec  )
         FD_SQL_ALLOC_VEC( volumeCol, FD_FIELD_VOLUME,       FD_Integer, volumeVec )
         FD_SQL_ALLOC_VEC( oiCol,     FD_FIELD_OPENINTEREST, FD_Integer, oiVec     )
            
         #undef FD_SQL_ALLOC_VEC
            
      }

      /* date must be always present */
      if ( sscanf(strval, "%4u-%2u-%2u", &u1, &u2, &u3) != 3 )
      {
         RETURN_FUNC( FD_BAD_QUERY );  /* other error code? */
      }

      retCode = FD_SetDate(u1, u2, u3, &timestampVec[barNum]);
      RETURN_ON_ERROR( retCode );

      if (timeCol >= 0)
      {
         strval = NULL;
         retCode = (*privateHandle->minidriver->getRowString)(
                              queryResult,
                              rowNum, 
                              timeCol,
                              &strval );
         RETURN_ON_ERROR( retCode );
         
         if ( strval && *strval ) 
         {  
            if (sscanf(strval, "%2u:%2u:%2u", &u1, &u2, &u3) != 3 )
            {
               RETURN_FUNC( FD_BAD_QUERY );
            }

            retCode = FD_SetTime(u1, u2, u3, &timestampVec[barNum]);
            RETURN_ON_ERROR( retCode );
         }
         else /* ignore NULL fields */
            continue;
      }

      #define FD_SQL_STORE_VALUE( type1, type2, lc_field, uc_field, flag ) \
      {                                                                  \
         if (lc_field##Vec)                                              \
         {                                                               \
            retCode = (*privateHandle->minidriver->getRow##type1)(       \
                                 queryResult,                            \
                                 rowNum,                                 \
                                 lc_field##Col,                          \
                                 &lc_field##Vec[barNum] );               \
                                                                         \
            if( retCode == FD_UNEXPECTED_SQL_TYPE )                      \
            {                                                            \
               retCode = (*privateHandle->minidriver->getRow##type2)(    \
                                 queryResult,                            \
                                 rowNum,                                 \
                                 lc_field##Col,                          \
                                 &temp##type2);                          \
               lc_field##Vec[barNum] = (FD_##type1)temp##type2;          \
               if( retCode == FD_UNEXPECTED_SQL_TYPE )                   \
               {                                                         \
                  RETURN_FUNC( FD_UNEXPECTED_SQL_TYPE_FOR_##uc_field );  \
               }                                                         \
            }                                                            \
            RETURN_ON_ERROR( retCode );                                  \
                                                                         \
            if (lc_field##Vec[barNum] == 0 && (privateHandle->param->flags & flag) )          \
               lc_field##Vec[barNum] = (FD_##type1)( (barNum > 0)? closeVec[barNum-1] : 0 );  \
                                                                         \
            if (lc_field##Vec[barNum] == 0)                              \
               continue;                                                 \
         }                                                               \
      }
          
      FD_SQL_STORE_VALUE( Real,    Integer, open,   OPEN,   FD_REPLACE_ZERO_PRICE_BAR)
      FD_SQL_STORE_VALUE( Real,    Integer, high,   HIGH,   FD_REPLACE_ZERO_PRICE_BAR)
      FD_SQL_STORE_VALUE( Real,    Integer, low,    LOW,    FD_REPLACE_ZERO_PRICE_BAR)
      FD_SQL_STORE_VALUE( Real,    Integer, close,  CLOSE,  FD_REPLACE_ZERO_PRICE_BAR)
      FD_SQL_STORE_VALUE( Integer, Real,    volume, VOLUME, FD_NO_FLAGS)
      FD_SQL_STORE_VALUE( Integer, Real,    oi,     OI,     FD_NO_FLAGS)

      #undef FD_SQL_STORE_VALUE

      barNum++;  /* bar stored */

      if( barNum == resRows )   /* vectors filled up completely, pass to fd_history */
      {
         retCode = FD_HistoryAddData(  paramForAddData,
                                       barNum,
                                       period,
                                       timestampVec,
                                       openVec,
                                       highVec,
                                       lowVec,
                                       closeVec,
                                       volumeVec,
                                       oiVec );
         
         /* whatever happened, the vectors are not belonging to us anymore */
         timestampVec = NULL;
         openVec = highVec = lowVec = closeVec = NULL;
         volumeVec = oiVec = NULL;
         barNum = 0;
         
         if( retCode == FD_ENOUGH_DATA )
            break;

         RETURN_ON_ERROR( retCode );
      }
   }

   /* now pass remaining collected data to fd_history module */
   if( barNum > 0 )
   {
      retCode = FD_HistoryAddData(  paramForAddData,
                                    barNum,
                                    period,
                                    timestampVec,
                                    openVec,
                                    highVec,
                                    lowVec,
                                    closeVec,
                                    volumeVec,
                                    oiVec );
      
      /* whatever happened, the vectors are not belonging to us anymore */
      timestampVec = NULL;
      openVec = highVec = lowVec = closeVec = NULL;
      volumeVec = oiVec = NULL;
      
      if( retCode != FD_ENOUGH_DATA )
         RETURN_ON_ERROR( retCode );
   }

   if( retCode == FD_ENOUGH_DATA || retCode == FD_END_OF_INDEX )
      retCode = FD_SUCCESS;
   
   /* cleanup */
   #undef RETURN_ON_ERROR
   #undef RETURN_FUNC

executeDataQuery_cleanup:

   /* retCode is set to the exit reason, so do not overwrite it here */
   (*privateHandle->minidriver->releaseQuery)(queryResult);

   if ( timestampVec ) FD_Free( timestampVec );
   if ( openVec      ) FD_Free( openVec      );
   if ( highVec      ) FD_Free( highVec      );
   if ( lowVec       ) FD_Free( lowVec       );
   if ( closeVec     ) FD_Free( closeVec     );
   if ( volumeVec    ) FD_Free( volumeVec    );
   if ( oiVec        ) FD_Free( oiVec        );

   FD_TRACE_RETURN( retCode );
}



/* Format FD_Timestamp to ISO date as used by SQL
 * Not multithread-safe ;-)
 */
static const char *formatISODate(const FD_Timestamp *ts)
{
   static char str[11];  /* CCYY-MM-DD\0 */

   sprintf(str, "%04u-%02u-%02u", FD_GetYear(ts), FD_GetMonth(ts), FD_GetDay(ts));
   return str;
}

static const char *formatISOTime(const FD_Timestamp *ts)
{
   static char str[9];  /* hh:mm:ss\0 */

   sprintf(str, "%02u:%02u:%02u", FD_GetHour(ts), FD_GetMin(ts), FD_GetSec(ts));
   return str;
}
