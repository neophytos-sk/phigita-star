/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070800 MF   First version.
 *
 */

/* Description:
 *
 */

/**** Headers ****/
#include <stddef.h>
#include <string.h>
#include "fd_fileindex.h"
#include "fd_fileindex_priv.h"
#include "fd_trace.h"
#include "fidal.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_FileIndexAlloc( FD_String *path,
                              FD_String *initialCategory,
                              FD_String *initialCategoryCountry,
                              FD_String *initialCategoryExchange,
                              FD_String *initialCategoryType,
                              FD_FileIndex **newIndex )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileIndexPriv *fileIndexPriv;
   /*!!! FD_String *categoryToUse;*/
   /*!!! FD_StringCache *stringCache;*/

   FD_TRACE_BEGIN(  FD_FileIndexAlloc );
    
   FD_ASSERT( newIndex != NULL );
   FD_ASSERT( path != NULL );

   *newIndex = NULL;


   /* Make sure a default category and is provided.
    * Category component default must also be provided.
    */
   if( !initialCategory         || 
       !initialCategoryCountry  || 
       !initialCategoryExchange ||
       !initialCategoryType )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   /* Allocate the "FD_FileIndex" alias "FD_FileIndexPriv". */
   fileIndexPriv = FD_FileIndexPrivAlloc( 
                                          initialCategory,
                                          initialCategoryCountry,
                                          initialCategoryExchange,
                                          initialCategoryType );

   if( !fileIndexPriv )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   #if 0
   !!! Not needed!?
   stringCache = FD_GetGlobalStringCache(); 
   FD_ASSERT( stringCache != NULL );

   /* Add the default category. */
   retCode = FD_FileIndexAddCategoryData( fileIndexPriv,
                                          categoryToUse,
                                          (FD_FileIndexCategoryData **)NULL );

   if( initialCategory == NULL )
      FD_StringFree( stringCache, categoryToUse );

   if( retCode != FD_SUCCESS )
   {
      FD_FileIndexPrivFree( fileIndexPriv );
      FD_TRACE_RETURN( retCode );
   }
   #endif

   /* Parse the source pattern into FD_TokenId tokens. */
   retCode = FD_FileIndexParsePath( fileIndexPriv, path );
   if( retCode != FD_SUCCESS )
   {
      FD_FileIndexPrivFree( fileIndexPriv );
      FD_TRACE_RETURN( retCode );
   }

   /* Go through the directories to build the list of category/symbols. */
   retCode = FD_FileIndexBuildIndex( fileIndexPriv );

   if( retCode != FD_SUCCESS )
   {
      FD_FileIndexPrivFree( fileIndexPriv );
      FD_TRACE_RETURN( retCode );
   }

   /* Re-initialize some pointers used while building the index.
    * These pointers are not supposed to be used from now on.
    * Setting these to NULL may help to prevent "bad usage" of these.
    */
   fileIndexPriv->curToken = NULL;
   fileIndexPriv->nextToken = NULL;
   fileIndexPriv->prevToken = NULL;
   fileIndexPriv->currentSymbolString = NULL;
   fileIndexPriv->currentCategoryString = NULL;
   fileIndexPriv->currentCategoryCountryString = NULL;
   fileIndexPriv->currentCategoryExchangeString = NULL;
   fileIndexPriv->currentCategoryTypeString = NULL;

   /* File index completed! return the result to the caller. */
   *newIndex = (FD_FileIndex *)fileIndexPriv;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_FileIndexFree( FD_FileIndex *toBeFreed )
{
   FD_PROLOG
   FD_FileIndexPriv *fileIndexPriv;
   FD_RetCode retCode;

   if( !toBeFreed )
      return FD_SUCCESS;

   fileIndexPriv = (FD_FileIndexPriv *)toBeFreed;

   FD_TRACE_BEGIN(  FD_FileIndexFree );

   retCode = FD_FileIndexPrivFree( fileIndexPriv );

   FD_TRACE_RETURN( retCode ); 
}

FD_String *FD_FileIndexFirstCategory( FD_FileIndex *fileIndex )
{
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexPriv         *fileIndexPriv;
   FD_List                  *listCategory;

   if( !fileIndex )
      return NULL;

   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;

   FD_ASSERT_RET( listCategory != NULL, (FD_String *)NULL );
   categoryData  = (FD_FileIndexCategoryData *)FD_ListAccessHead( listCategory );

   if( !categoryData )
      return NULL;

   FD_ASSERT_RET( categoryData->string != NULL, (FD_String *)NULL );

   return categoryData->string;
}

FD_String *FD_FileIndexNextCategory ( FD_FileIndex *fileIndex )
{
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexPriv         *fileIndexPriv;
   FD_List                  *listCategory;

   if( fileIndex == NULL )
      return NULL;

   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;

   FD_ASSERT_RET( listCategory != NULL, (FD_String *)NULL );
   categoryData  = (FD_FileIndexCategoryData *)FD_ListAccessNext( listCategory );

   if( !categoryData )
      return NULL;

   FD_ASSERT_RET( categoryData->string != NULL, (FD_String *)NULL );

   return categoryData->string;
}

FD_RetCode FD_FileIndexSelectCategory( FD_FileIndex *fileIndex,
                                       FD_String *category )
{
   FD_PROLOG
   FD_FileIndexPriv *fileIndexPriv;
   FD_String        *currentCategoryString;
   FD_List          *listCategory;
   FD_FileIndexCategoryData *categoryData;

   if( !fileIndex )
      return FD_INTERNAL_ERROR(85);
        
   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   FD_TRACE_BEGIN(  FD_FileIndexSelectCategory );

   FD_ASSERT( category != NULL );

   listCategory = fileIndexPriv->listCategory;
   FD_ASSERT( listCategory != NULL );

   categoryData = (FD_FileIndexCategoryData *)FD_ListAccessCurrent( listCategory );

   if( categoryData == NULL )
   {
      currentCategoryString = FD_FileIndexFirstCategory( fileIndex );
      if( currentCategoryString == NULL )
      {
         FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
      }
   }
   else
      currentCategoryString = categoryData->string;

   /* Sanity check. */
   FD_ASSERT( currentCategoryString != NULL );

   /* Need to search for the category. */
   while( currentCategoryString )
   {
      /* Verify if we are positioned on the right category. if yes, return. */
      if( strcmp( FD_StringToChar( category ),
                  FD_StringToChar( currentCategoryString )) == 0 )
      {
         FD_TRACE_RETURN( FD_SUCCESS );
      }

      /* Go to next category string. */
      currentCategoryString = FD_FileIndexNextCategory( fileIndex );
   }

   FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
}

FD_FileInfo *FD_FileIndexFirstSymbol( FD_FileIndex *fileIndex )
{
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexSymbolData   *symbolData;
   FD_FileIndexPriv         *fileIndexPriv;
   FD_List                  *listCategory;
   FD_List                  *listSymbol;

   if( !fileIndex )
      return NULL;

   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;

   /* Make sure we are positioned on a valid category. */
   FD_ASSERT_RET( listCategory != NULL, (FD_FileInfo *)NULL );
   categoryData = (FD_FileIndexCategoryData *)FD_ListAccessCurrent( listCategory );

   if( !categoryData )
      return NULL;

   listSymbol = categoryData->listSymbol;

   FD_ASSERT_RET( listSymbol != NULL, (FD_FileInfo *)NULL );
   symbolData = (FD_FileIndexSymbolData *)FD_ListAccessHead( listSymbol );

   if( !symbolData )
      return (FD_FileInfo *)NULL;

   /* Parano sanity check: Verify that all the fields of the symbolData are ok.
    * This is a good place to verify sanity, since this is the last "exit point"
    * of the symbolData toward the user of the FD_FileIndex...
    */
   FD_ASSERT_RET( symbolData->parent == categoryData, (FD_FileInfo *)NULL );
   FD_ASSERT_RET( symbolData->string != NULL, (FD_FileInfo *)NULL );

   return (FD_FileInfo *)symbolData;
}

FD_FileInfo *FD_FileIndexNextSymbol( FD_FileIndex *fileIndex )
{
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexSymbolData   *symbolData;
   FD_FileIndexPriv         *fileIndexPriv;
   FD_List                  *listCategory;
   FD_List                  *listSymbol;

   if( !fileIndex )
      return NULL;

   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;

   /* Make sure we are positioned on a valid category. */
   FD_ASSERT_RET( listCategory != NULL, (FD_FileInfo *)NULL );
   categoryData = (FD_FileIndexCategoryData *)FD_ListAccessCurrent( listCategory );

   if( !categoryData )
      return NULL;

   listSymbol = categoryData->listSymbol;

   FD_ASSERT_RET( listSymbol != NULL, (FD_FileInfo *)NULL );
   symbolData = (FD_FileIndexSymbolData *)FD_ListAccessNext( listSymbol );

   if( !symbolData )
      return (FD_FileInfo *)NULL;

   /* Parano sanity check: Verify that all the fields of the symbolData are ok.
    * This is a good place to verify sanity, since this is the last "exit point"
    * of the symbolData toward the user of the FD_FileIndex...
    */
   FD_ASSERT_RET( symbolData->parent == categoryData, (FD_FileInfo *)NULL );
   FD_ASSERT_RET( symbolData->string != NULL, (FD_FileInfo *)NULL );

   return (FD_FileInfo *)symbolData;
}

/* Return the number of category. */
unsigned int FD_FileIndexNbCategory( FD_FileIndex *fileIndex )
{
   FD_FileIndexPriv *fileIndexPriv;
   FD_List          *listCategory;

   if( !fileIndex )
      return 0;

   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;
   FD_ASSERT_RET( listCategory != NULL, 0 );

   return FD_ListSize( listCategory );
}

/* Return the number of symbol for the current category. */
unsigned int FD_FileIndexNbSymbol( FD_FileIndex *fileIndex )
{
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexPriv         *fileIndexPriv;
   FD_List                  *listCategory;
   FD_List                  *listSymbol;

   if( !fileIndex )
       return 0;
   fileIndexPriv = (FD_FileIndexPriv *)fileIndex;
   listCategory = fileIndexPriv->listCategory;

   /* Make sure we are positioned on a valid category. */
   FD_ASSERT_RET( listCategory != NULL, 0 );
   categoryData = (FD_FileIndexCategoryData *)FD_ListAccessCurrent( listCategory );

   if( !categoryData )
      return 0;

   listSymbol = categoryData->listSymbol;

   FD_ASSERT_RET( listSymbol != NULL, 0 );

   return FD_ListSize( listSymbol );
}

/* Function to extract information from a FD_FileInfo. */
FD_String *FD_FileInfoSymbol( FD_FileInfo *fileInfo )
{
   FD_FileIndexSymbolData *symbolData;

   FD_ASSERT_RET( fileInfo != NULL, (FD_String *)NULL );
   symbolData = (FD_FileIndexSymbolData *)fileInfo;

   FD_ASSERT_RET( symbolData->string != NULL, (FD_String *)NULL );

   return symbolData->string;
}

FD_String *FD_FileInfoCategory( FD_FileInfo *fileInfo )
{
   FD_FileIndexSymbolData *symbolData;
   FD_FileIndexCategoryData *categoryData;

   FD_ASSERT_RET( fileInfo != NULL, (FD_String *)NULL );
   symbolData = (FD_FileIndexSymbolData *)fileInfo;

   categoryData = symbolData->parent;

   FD_ASSERT_RET( categoryData != NULL, (FD_String *)NULL );
   FD_ASSERT_RET( categoryData->string != NULL, (FD_String *)NULL );

   return categoryData->string;
}

const char *FD_FileInfoPath( FD_FileInfo *fileInfo )
{
   FD_RetCode retCode;
   FD_FileIndexSymbolData *symbolData;
   FD_FileIndexCategoryData *categoryData;
   FD_FileIndexPriv *fileIndex;
   char *scratchPad;

   /* Get the corresponding scratch pad. */
   FD_ASSERT_RET( fileInfo != NULL, (char *)NULL );
   symbolData = (FD_FileIndexSymbolData *)fileInfo;
   categoryData = symbolData->parent;

   FD_ASSERT_RET( categoryData != NULL, (char *)NULL );
   fileIndex = categoryData->parent;

   FD_ASSERT_RET( fileIndex != NULL, (char *)NULL );
   scratchPad = fileIndex->scratchPad;

   /* Build the path in the scratchPad. */
   FD_ASSERT_RET( scratchPad != NULL, (char *)NULL );
   FD_ASSERT_RET( symbolData->node != NULL, (char *)NULL );
   retCode = FD_FileIndexMakePathPattern( fileIndex,
                                          symbolData->node,
                                          scratchPad,
                                          FD_SOURCELOCATION_MAX_LENGTH );

   if( retCode != FD_SUCCESS )
      return (char *)NULL;

   return scratchPad;
}

/**** Local functions definitions.     ****/
/* None */

