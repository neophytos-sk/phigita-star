/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  102900 MF   First version.
 *
 */

/* Description:
 *    Provides private utility to the FD_FileIndex modules.
 */

/**** Headers ****/
#include <stddef.h>
#include "fd_fileindex_priv.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_FileIndexMoveToDepth( FD_FileIndexPriv *data, unsigned int depth )
{
   while( depth != data->curTokenDepth )
   {
      if( depth > data->curTokenDepth )
         FD_FileIndexMoveToNextToken( data );
      else
         FD_FileIndexMoveToPrevToken( data );
   }

   return FD_SUCCESS;
}

FD_RetCode FD_FileIndexMoveToNextToken( FD_FileIndexPriv *data )
{
   FD_PROLOG

   if( !data )
      return FD_INTERNAL_ERROR(86);

   FD_TRACE_BEGIN( FD_FileIndexMoveToNextToken );

   if( data->curToken == NULL )
   {
      /* First time this function get called for this 'data' */
      data->curTokenDepth = 0;
      data->curDirectionForward = 1;
      data->curToken = (FD_TokenInfo *)FD_ListAccessHead( data->listLocationToken );
      data->prevToken = NULL;
      data->nextToken = (FD_TokenInfo *)FD_ListAccessNext( data->listLocationToken );

      if( !data->curToken || !data->nextToken )
      {
         FD_FATAL( NULL, data->curToken, data->nextToken );
      }
   }
   else if( data->nextToken == NULL )
   {
      /* Can't go further, simply return. */
      FD_TRACE_RETURN( FD_SUCCESS );
   }
   else
   {
      if( data->curDirectionForward == 0 )
      {
         if( data->prevToken != NULL )
            FD_ListAccessNext( data->listLocationToken );
         else
            FD_ListAccessHead( data->listLocationToken );

         FD_ListAccessNext( data->listLocationToken );
         data->curDirectionForward = 1;
      }

      data->prevToken = data->curToken;
      data->curToken = data->nextToken;
      data->nextToken = (FD_TokenInfo *)FD_ListAccessNext( data->listLocationToken );

      /* Parano test: Should never happen since the code assume that
       * the 'listLocationToken' is always terminated by FD_END.
       */
      if( !data->curToken )
      {
         FD_FATAL( NULL, data->curToken->id, data->curTokenDepth );
      }
   }

   data->curTokenDepth++;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_FileIndexMoveToPrevToken( FD_FileIndexPriv *data )
{
   FD_PROLOG
   FD_RetCode retCode;

   if( !data )
      return FD_INTERNAL_ERROR(87);

   FD_TRACE_BEGIN( FD_FileIndexMoveToPrevToken );

   if( data->curToken == NULL )
   {
      /* Iterator variable not initialize. Simply position everything on the
       * first token.
       */
      retCode = FD_FileIndexMoveToNextToken( data );
      FD_TRACE_RETURN( retCode ); 
   }
   else if( data->prevToken == NULL )
   {
      /* Can't go further back. Simply return. */
      FD_TRACE_RETURN( FD_SUCCESS );
   }
   else
   {
      if( data->curDirectionForward == 1 )
      {
         if( data->nextToken != NULL )
            FD_ListAccessPrev( data->listLocationToken );
         else
            FD_ListAccessTail( data->listLocationToken );

         FD_ListAccessPrev( data->listLocationToken );
         data->curDirectionForward = 0;
      }

      data->nextToken = data->curToken;
      data->curToken = data->prevToken;
      data->prevToken = (FD_TokenInfo *)FD_ListAccessPrev( data->listLocationToken );

      /* Parano test: Should never happen since the code assume that
       * the 'listLocationToken' is always terminated by FD_END.
       */
      if( !data->curToken )
      {
         FD_FATAL( NULL, data->curToken->id, data->curTokenDepth );
      }
   }
   data->curTokenDepth--;

   FD_TRACE_RETURN( FD_SUCCESS );
}

unsigned int FD_FileIndexIdentifyFileDepth( FD_FileIndexPriv *data )
{
   FD_List *listLocationToken;
   FD_TokenInfo *info;
   unsigned int latestPathPortionDepth;
   unsigned int currentDepth;

   /* Identify the last portion of the path where
    * the directory path is all resolved.
    *
    * It is imperative that the last token be FD_TOK_END.
    */
   listLocationToken = data->listLocationToken;

   info = FD_ListAccessHead( listLocationToken );
   latestPathPortionDepth = 1;
   currentDepth = 0;
   while( info )
   {
      currentDepth++;

      if( info->id == FD_TOK_END )
         return latestPathPortionDepth;
      if( info->id == FD_TOK_SEP )
         latestPathPortionDepth = currentDepth;

      info = FD_ListAccessNext( listLocationToken );
   }

   /* Should never get here. */
   FD_FATAL_RET( NULL, currentDepth, latestPathPortionDepth, 0 );
}

/**** Local functions definitions.     ****/
/* None */



