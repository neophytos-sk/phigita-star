/* fd_sql_odbc.h
 * Call the following function to enable the ODBC minidriver on a WIN32 platform.
 */

#ifndef FD_SQL_ODBC_H
#define FD_SQL_ODBC_H

#ifdef WIN32
   FD_RetCode FD_SQL_ODBC_Initialize(void);
#endif

#endif
