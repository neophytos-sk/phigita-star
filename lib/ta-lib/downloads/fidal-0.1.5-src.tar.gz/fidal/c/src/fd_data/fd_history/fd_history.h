#ifndef FD_HISTORY_H
#define FD_HISTORY_H

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_DAFD_UDB_H
   #include "fd_data_udb.h"
#endif

/* Interface of the FD_History module.
 *
 * These functions are the only one that could be called from outside
 * the fd_history directory.
 *
 * This module provide functionality for:
 *   - building/allocating FD_History structures.
 *   - validating a FD_History integrity.
 */

/* FD_HistoryBuilder does all the job to interact with the data source
 * for building a FD_History.
 *
 * (function can be found in "fd_history_builder.c")
 */
FD_RetCode FD_HistoryBuilder( FD_UDBasePriv *privUDB,
                              FD_UDB_Symbol *symbolData,
                              FD_Period            period,
                              const FD_Timestamp  *start,
                              const FD_Timestamp  *end,
                              FD_Field             fieldToAlloc,
                              FD_HistoryFlag       flags,  
                              unsigned int         timeout,    
                              FD_History         **history ); 

/* Validate the integrity of a FD_History.
 *
 * This function attempts to be self-content as much as possible to avoid
 * dependency on the "rest of the code" that we wish to monitor.
 *
 * If FD_INCONSISTENT_PRICE_BAR is returned, an error has been found with
 * a price bar (like an open lower than the low etc...). The faulty price
 * bar and fields are returned into the pointed variables.
 *
 * If 'faultyIndex' is NULL, there is no validation performed on the
 * consistency of each price bar.
 *
 * (function can be found in "fd_historycheck.c")
 */
FD_RetCode FD_HistoryCheck( FD_Period           expectedPeriod,
                            const FD_Timestamp *expectedStart,
                            const FD_Timestamp *expectedEnd,
                            FD_Field            fieldToCheck,
                            const FD_History   *history,
                            FD_HistoryFlag      flags );

/* Allows to allocate an history with a different (longer) timeframe.
 * On success a new allocated history is returned through 'newHistory'.
 * The original history is never modified.
 *
 * If newPeriod is the same as history->period, the call result simply
 * as an allocation of an exact copy of the original FD_History.
 *
 * (function can be found in "fd_period.c")
 */
FD_RetCode FD_HistoryAllocCopyInternal( const FD_History *history,
                                        FD_History **newHistory,
                                        FD_Period newPeriod );


/* The hidden data put in a FD_History. */
typedef struct
{
   unsigned int magicNb;

   FD_UDBasePriv *privUDB;

   /* Ptr on the data that must be freed. */
   const void *open;
   const void *high;
   const void *low;
   const void *close;
   const void *volume;
   const void *openInterest;
   const void *timestamp;
} FD_HistoryHiddenData;

#endif

