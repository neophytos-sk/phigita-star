#ifndef FD_CSI_H
#define FD_CSI_H

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FD_DAFD_UDB_H
   #include "fd_data_udb.h"
#endif

/* See fd_source.h and fd_source.c for more information about these
 * functions.
 */
FD_RetCode FD_CSI_InitializeSourceDriver( void );

FD_RetCode FD_CSI_ShutdownSourceDriver( void );

FD_RetCode FD_CSI_GetParameters( FD_DataSourceParameters *param );

FD_RetCode FD_CSI_OpenSource( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle );

FD_RetCode FD_CSI_CloseSource( FD_DataSourceHandle *handle );


FD_RetCode FD_CSI_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle );

FD_RetCode FD_CSI_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle   *categoryHandle,
                                        FD_SymbolHandle     *symbolHandle );

FD_RetCode FD_CSI_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle   *categoryHandle,
                                       FD_SymbolHandle     *symbolHandle,
                                       unsigned int index );

FD_RetCode FD_CSI_GetHistoryData( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData );

FD_RetCode FD_CSIM_InitializeSourceDriver( void );

FD_RetCode FD_CSIM_ShutdownSourceDriver( void );

FD_RetCode FD_CSIM_GetParameters( FD_DataSourceParameters *param );

FD_RetCode FD_CSIM_OpenSource( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle );

FD_RetCode FD_CSIM_CloseSource( FD_DataSourceHandle *handle );


FD_RetCode FD_CSIM_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle );

FD_RetCode FD_CSIM_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle   *categoryHandle,
                                        FD_SymbolHandle     *symbolHandle );

FD_RetCode FD_CSIM_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle   *categoryHandle,
                                       FD_SymbolHandle     *symbolHandle,
                                       unsigned int index );

FD_RetCode FD_CSIM_GetHistoryData( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData );

#endif

