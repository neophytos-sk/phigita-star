/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY     Description
 *  -------------------------------------------------------------------
 *  112400 MF     First version.
 *  062803 MF     Make parsing to find exchange/type more adaptive to 
 *                potential changes from Yahoo! market page format.
 *  102103 MF     Now recognize American Mutual Fund ticker.
 *  020104 MF     Fix mem leaks related to FD_TRACE_BEGIN/FD_TRACE_RETURN.
 */

/* Description:
 *   Extract market data from Yahoo!
 */

/**** Headers ****/
#include "fd_common.h"
#include "fd_string.h"
#include "fd_yahoo_priv.h"
#include "fd_network.h"
#include "fd_system.h"
#include "fd_trace.h"
#include "fd_country_info.h"
#include "fd_global.h"
#include "fd_magic_nb.h"
#include "sfl.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   const char *extension;
   FD_CountryId countryId;
   const char *exchange;
   const char *type;
} FD_YahooExtension;

typedef struct
{   
   FD_YahooMarketPage      *marketPage;
   const FD_DecodingParam  *decodingParam;
} FD_MarketPageParseOpaqueData;

/**** Local functions declarations.    ****/
static FD_RetCode translateToYahooName( const FD_String *categoryName,
                                        const FD_String *symbolName,
                                        char *buffer,
                                        unsigned int maxBufferSize );

static FD_RetCode internalMarketPageAlloc( const FD_DecodingParam *decodingParam,
                                           const char *yahooName,
                                           const char *overideServerAddr,
                                           FD_YahooMarketPage **allocatedMarketPage );

static FD_RetCode internalMarketPageFree( FD_YahooMarketPage *marketPage );

static FD_RetCode parseMarketPage( FD_StreamAccess *streamAccess,
                                   FD_YahooMarketPage *marketPage );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

static FD_YahooExtension FD_YahooExtensionTable[] = 
{
   { "TO", FD_Country_ID_CA, "TSE",   "STOCK"  },  /* Toronto Stock Exchange */
   { "V",  FD_Country_ID_CA, "CDNX",  "STOCK"  },  /* Canadian Venture Exchange (Vancouver) */
   { "M",  FD_Country_ID_CA, "MSE",   "STOCK"  },  /* Montreal Stock Exchange */

   { "OB", FD_Country_ID_US, "OTCBB", "STOCK"  },  /* Over-the-counter, Bulletin Board */
   { "PK", FD_Country_ID_US, "OTC",   "STOCK"  },  /* Over-the-counter, Pink Sheet */

   { "L",  FD_Country_ID_UK, "LSE",   "STOCK"  },  /* London Stock Exchange */

   { "VI", FD_Country_ID_AT, "WBAG",  "STOCK"  },  /* Austria - Vienna Stock Exchange */

   { "CO", FD_Country_ID_DK, "XCSE",  "STOCK"  },  /* Copenhagen Stock Exchange */

   { "PA", FD_Country_ID_FR, "SBF",   "STOCK"  },  /* Bourse De Paris */
   { "P",  FD_Country_ID_FR, "SBF",   "STOCK"  },  /* Bourse De Paris */

   { "BE", FD_Country_ID_DE, "BSE",   "STOCK"  },  /* Berlin Stock Exchange */
   { "BM", FD_Country_ID_DE, "BWB",   "STOCK"  },  /* Bremen Stock Exchange */
   { "D",  FD_Country_ID_DE, "RWB",   "STOCK"  },  /* Dusseldorf Stock Exchange */
   { "F",  FD_Country_ID_DE, "FRA",   "STOCK"  },  /* Frankfurt Stock Exchange */
   { "DE", FD_Country_ID_DE, "XETRA", "STOCK"  },  /* XETRA Stock Exchange */
   { "H",  FD_Country_ID_DE, "HAM",   "STOCK"  },  /* Hamberg Stock Exchange */
   { "HA", FD_Country_ID_DE, "HAN",   "STOCK"  },  /* Hannover Stock Exchange */
   { "MU", FD_Country_ID_DE, "BBAG",  "STOCK"  },  /* Bavarian Stock Exchange (Munich) */
   { "SG", FD_Country_ID_DE, "BSAG",  "STOCK"  },  /* Stuttgart Stock Exchange */

   { "MI", FD_Country_ID_IT, "BI",    "STOCK"  },  /* Borsa Italia - Milan Stock Exchange */

   { "NL", FD_Country_ID_AT, "AEX",   "STOCK"  },  /* Amsterdam Stock Exchange */

   { "OL", FD_Country_ID_NO, "OSE",   "STOCK"  },  /* Oslo Stock Exchange */

   { "BC", FD_Country_ID_ES, "BSE",   "STOCK"  },  /* Barcelona Stock Exchange */
   { "BI", FD_Country_ID_ES, "BIL",   "STOCK"  },  /* Bilbao Stock Exchange */
   { "MF", FD_Country_ID_ES, "MEFF",  "FUTURE" },  /* Madrid Fixed Income and Derivative Market */
   { "MC", FD_Country_ID_ES, "MEFF",  "STOCK"  },  /* Madrid Fixed Income and Derivative Market */
   { "MA", FD_Country_ID_ES, "BDM",   "STOCK"  },  /* Madrid Stock Exchange */

   { "ST", FD_Country_ID_SE, "OMX",   "STOCK"  }   /* Stockholm Stock Exchange */
};

#define NB_YAHOO_EXCHANGE_EXTENSION (sizeof(FD_YahooExtensionTable)/sizeof(FD_YahooExtension))

/**** Global functions definitions.   ****/
FD_RetCode FD_AllocStringFromLibName( const FD_String *category,
                                      const FD_String *symbol,
                                      FD_String **allocatedYahooName )
{
   FD_PROLOG

   FD_RetCode retCode;
   FD_StringCache *stringCache;
   char buffer[200];

   FD_TRACE_BEGIN(  FD_AllocStringFromLibName );
   buffer[199] = '\0'; /* Just to be safe. */

   /* Translate the category/symbol into the yahoo! name. */
   retCode = translateToYahooName( category, symbol, &buffer[0], 199 );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   stringCache = FD_GetGlobalStringCache();
   *allocatedYahooName = FD_StringAlloc( stringCache, buffer );
   if( !*allocatedYahooName )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_AllocStringFromYahooName( FD_DecodingParam *marketDecodingParam,
                                        const char *yahooSymbol,
                                        FD_String **allocatedCategoryName,
                                        FD_String **allocatedSymbolName,
                                        unsigned int allowOnlineProcessing )
{
   FD_PROLOG

   FD_RetCode retCode;

   const char   *symbol;
   unsigned int symbolLength;
   const char   *ext;

   const char *countryAbbrev;
   const char *exchangeString;
   const char *typeString;

   unsigned int i;
   char *tempBuffer;
   FD_String *allocCategory;
   FD_String *allocSymbol;
   FD_StringCache *stringCache;
   FD_CountryId countryId;

   FD_YahooMarketPage *allocatedMarketPage;

   FD_TRACE_BEGIN( FD_AllocStringFromYahooName );

   /* Validate parameter */
   if( !marketDecodingParam || !yahooSymbol ||
       !allocatedCategoryName || !allocatedSymbolName )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   stringCache = FD_GetGlobalStringCache();

   /* Set a pointer on where the symbol start. */
   symbol = yahooSymbol;
  
   /* Size of the symbol. */
   symbolLength = getstrfldlen( symbol, 0, 0, "." );
   if( symbolLength < 2 )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }
   else
      symbolLength--;

   /* The 3 strings forming the final Category string. */
   countryAbbrev  = NULL;
   exchangeString = NULL;
   typeString     = NULL;

   /* Identify if there is an extension. */
   ext = strchr( symbol, '.' );
   if( ext )
   {
      ext++;
      if( *ext == '\0' )
         ext = NULL;
   }

   /* If ext != NULL, ext points on first char of the extension. */
   
   if( ext )
   {
      /* Identify known USA/CAN extension. */
      for( i=0; i < NB_YAHOO_EXCHANGE_EXTENSION; i++ )
      {
         if( lexcmp( FD_YahooExtensionTable[i].extension, ext ) == 0 )
         {
            countryId = FD_YahooExtensionTable[i].countryId;           
            countryAbbrev  = FD_CountryIdToAbbrev( countryId );
            exchangeString = FD_YahooExtensionTable[i].exchange;
            typeString     = FD_YahooExtensionTable[i].type;
            break; /* Exit the loop */
         }
      }

      /* Unknown extension, let's use the whole thing
       * as the symbol and keep going as if nothing
       * happened.
       */
      if( !countryAbbrev )
         ext = NULL; /* No known extension. */
   }

   /* Trap the american mutual fund who are always
    * 5 characters (with the last character being a 'X').
    */
   if( (strlen(yahooSymbol) == 5) && (yahooSymbol[4] == 'X') )
   {
      countryId      = FD_Country_ID_US;           
      countryAbbrev  = FD_CountryIdToAbbrev( countryId );
      exchangeString = "NASDAQ";
      typeString     = "FUND";
   }

   if( !exchangeString )
   {
      /* If online access is not allowed, and the 
       * symbol does not have a known extension, it
       * is not possible to identify the exchange.
       *
       * With online access, the exchange can be
       * found by doing further investigation on the
       * Yahoo! web sites.
       */
      if( !allowOnlineProcessing )
      {
         FD_TRACE_RETURN(FD_INVALID_SECURITY_EXCHANGE);
      }

      /* OK, we need to proceed by extracting the info
       * from Yahoo! web sites.
       */
      retCode = internalMarketPageAlloc( marketDecodingParam,
                                         yahooSymbol,
                                         NULL,
                                         &allocatedMarketPage );

      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN(retCode);
      }

      FD_ASSERT_DEBUG( allocatedMarketPage->exchange != NULL );
      FD_ASSERT_DEBUG( allocatedMarketPage->type != NULL );

      /* All these string pointer are globals. So the allocatedMarketPage
       * can be freed and the member-poitners are still valid.
       */
      countryAbbrev  = FD_CountryIdToAbbrev( allocatedMarketPage->countryId );
      exchangeString = allocatedMarketPage->exchange;
      typeString     = allocatedMarketPage->type;

      internalMarketPageFree( allocatedMarketPage );
   }   
   
   FD_ASSERT_DEBUG( typeString     != NULL );
   FD_ASSERT_DEBUG( exchangeString != NULL );
   FD_ASSERT_DEBUG( countryAbbrev  != NULL );

   /* Build the Category string into a buffer. */
   tempBuffer = FD_Malloc( strlen( countryAbbrev  )  +
                           strlen( exchangeString ) +
                           strlen( typeString )     + 3 );

   sprintf( tempBuffer, "%s.%s.%s", countryAbbrev, exchangeString, typeString );

   /* Allocate the Category string. */
   allocCategory = FD_StringAlloc_UC( stringCache, tempBuffer );

   FD_Free( tempBuffer );

   if( !allocCategory )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Allocate the symbol string. */
   allocSymbol = FD_StringAllocN_UC( stringCache, symbol, symbolLength );

   if( !allocSymbol )
   {
      FD_StringFree( stringCache, allocCategory );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Everything went fine, return the info to the caller. */
   *allocatedCategoryName = allocCategory;
   *allocatedSymbolName   = allocSymbol;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_YahooMarketPageAlloc( const FD_DecodingParam *decodingParam,
                                    const FD_String *categoryName,
                                    const FD_String *symbolName,
                                    const char *overideServerAddr,
                                    FD_YahooMarketPage **allocatedMarketPage )
{
   FD_RetCode retCode;
   char buffer[200];

   buffer[199] = '\0'; /* Just to be safe. */

   /* Translate the category/symbol into the yahoo! name. */
   retCode = translateToYahooName( categoryName, symbolName, &buffer[0], 199 );
   if( retCode != FD_SUCCESS )
      return retCode;

   return internalMarketPageAlloc( decodingParam,
                                   buffer,
                                   overideServerAddr,
                                   allocatedMarketPage );
}


FD_RetCode FD_YahooMarketPageFree( FD_YahooMarketPage *marketPage )
{
   return internalMarketPageFree( marketPage );
}

FD_RetCode FD_WebPageAllocFromYahooName( const FD_DecodingParam *decodingParam,
                                         const char *yahooName,
                                         const char *overideServerAddr,
                                         FD_WebPage **allocatedWebPage,
                                         FD_ParamForAddData *paramForAddData )
{
   FD_PROLOG
   FD_RetCode retCode;
   char webSitePage[300];
   unsigned int prefixLength, suffixLength, symbolLength, i, j;
   const char *webSiteAddr;
   const char *uirPrefix, *uirSuffix;
   FD_WebPage *webPage;

   FD_TRACE_BEGIN( FD_WebPageAllocFromYahooName );

   retCode = FD_INTERNAL_ERROR(117);

   if( !decodingParam || !yahooName || !allocatedWebPage )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   if( overideServerAddr )
      webSiteAddr = overideServerAddr;
   else
   {
      webSiteAddr  = decodingParam->webSiteServer;
      FD_ASSERT( webSiteAddr != NULL );
   }

   uirPrefix = decodingParam->uirPrefix;
   FD_ASSERT( uirPrefix != NULL );
   prefixLength = strlen( uirPrefix );

   uirSuffix = decodingParam->uirSuffix;
   FD_ASSERT( uirSuffix != NULL );
   suffixLength = strlen( uirSuffix );
   
   symbolLength = strlen( yahooName );
   if( (symbolLength + suffixLength + prefixLength) >= 299 )
   {
      FD_TRACE_RETURN( FD_INVALID_SECURITY_EXCHANGE );
   }

   sprintf( webSitePage, "%s%s%s", uirPrefix, yahooName, uirSuffix );

   /* Get the Web Page */   
   retCode = FD_SUCCESS;
   for( i=0; (i < 10) && (retCode != FD_DAFD_RETREIVE_TIMEOUT); i++ )
   {

      retCode = FD_WebPageAlloc( webSiteAddr,
                                 webSitePage,
                                 NULL, NULL, &webPage, 10, paramForAddData );

      if( retCode == FD_SUCCESS )
         break;
      else
      {         
         /* Yahoo! is may be slow, let's sleep 20 seconds. */
         if( !paramForAddData )
         {
            FD_Sleep(20);
         }
         else
         {
            retCode = FD_DriverShouldContinue(paramForAddData);
            j = 0;
            while( (retCode == FD_SUCCESS) && (j++ < 20) )
            {
               FD_Sleep( 1 ); 
               retCode = FD_DriverShouldContinue(paramForAddData);
            }
         }
      }
   }

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   *allocatedWebPage = webPage;
   FD_TRACE_RETURN( FD_SUCCESS );
}

/**** Local functions definitions.     ****/
static FD_RetCode translateToYahooName( const FD_String *categoryName,
                                        const FD_String *symbolName,
                                        char *buffer,
                                        unsigned int maxBufferSize )
{
   FD_CountryId countryId;
   unsigned int i, symbolLength, xchangeLength, extLength, typeLength;
   const char *symbol;
   const char *xchange;
   const char *type;
   const char *category;
   const char *ext;

   category = FD_StringToChar(categoryName);

   /* Identify the symbol and its length. */
   symbol = FD_StringToChar(symbolName);

   symbolLength = strlen( symbol );
   if( symbolLength >= maxBufferSize )
      return FD_INVALID_SECURITY_SYMBOL;

   strcpy( buffer, symbol );

   /* Trap special case where the symbol/category is for
    * one of the hard coded indice.
    */

   for( i=0; i < hardCodedIndiceSize; i++ )
   {
      if( (strcmp( hardCodedIndice[i].symbolLib, FD_StringToChar( symbolName ) ) == 0) &&
          (strcmp( hardCodedIndice[i].categoryLib, FD_StringToChar( categoryName ) ) == 0) )
      {
         strncpy( buffer, hardCodedIndice[i].symbolYahoo, maxBufferSize );
         return FD_SUCCESS;
      }
   }

   /* Identify if an extenstion must be appended
    * to the symbol.
    * At the same time, verify the country. 
    */
   countryId = FD_CountryAbbrevToId( FD_StringToChar(categoryName) );
   switch( countryId )
   {
   case FD_Country_ID_CA: /* Canada */
   case FD_Country_ID_US: /* United States */
   case FD_Country_ID_UK: /* United Kingdom */
   case FD_Country_ID_DE: /* Germany */
   case FD_Country_ID_DK: /* Denmark */
   case FD_Country_ID_ES: /* Spain */
   case FD_Country_ID_FR: /* France */
   case FD_Country_ID_IT: /* Italy */
   case FD_Country_ID_SE: /* Sweden */
   case FD_Country_ID_NO: /* Norway */
      /* Get the length of the second field of the category.
       * This field must exist, else an error is returned.
       */
      xchangeLength = getstrfldlen( category, 1, 0, "." ) -1;
      if( xchangeLength < 2 )
         return FD_INVALID_SECURITY_EXCHANGE;
      xchange = strchr( category, '.' );
      if( !xchange || (*xchange == '\0') )
         return FD_INVALID_SECURITY_EXCHANGE;
      xchange++;
      if( *xchange == '\0' )
         return FD_INVALID_SECURITY_EXCHANGE;

      /* Get the length of the third field of the category.
       * This field must exist, else an error is returned.
       */
      type = strchr( xchange, '.' );
      if( !type || (type == xchange) || (*type == '\0') )
         return FD_INVALID_SECURITY_TYPE;
      type++;
      if( *type == '\0' )
         return FD_INVALID_SECURITY_TYPE;
      typeLength = strlen( type );

      /* Look for the possible extension corresponding to
       * this exchange. If found, append it to the symbol.
       */
      for( i=0; i < NB_YAHOO_EXCHANGE_EXTENSION; i++ )
      {         
         if( (FD_YahooExtensionTable[i].countryId == countryId) &&
             (lexncmp( FD_YahooExtensionTable[i].exchange, xchange, xchangeLength ) == 0) &&
             (lexncmp( FD_YahooExtensionTable[i].type, type, typeLength ) == 0) )
         {
            ext = FD_YahooExtensionTable[i].extension;
            extLength = strlen( ext );
            if( extLength+symbolLength+1 > maxBufferSize-1 )
               return FD_INVALID_SECURITY_EXCHANGE;
            buffer[symbolLength] = '.';
            symbolLength++;
            strcpy( &buffer[symbolLength], ext );
            break; /* Exit the loop */
         }
      }
      break;
   default:
      return FD_INVALID_SECURITY_COUNTRY;
   }

   /* At this point, buffer contains the name as used by Yahoo! web site. */

   return FD_SUCCESS;
}

                                  
static FD_RetCode internalMarketPageAlloc( const FD_DecodingParam *decodingParam,
                                           const char *yahooName,
                                           const char *overideServerAddr,
                                           FD_YahooMarketPage **allocatedMarketPage )
{
   FD_RetCode retCode;
   FD_WebPage *webPage;
   FD_YahooMarketPage *marketPage;
   FD_StreamAccess *streamAccess;

   retCode = FD_WebPageAllocFromYahooName( decodingParam,
                                           yahooName,
                                           overideServerAddr,
                                           &webPage, NULL );
                                              
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Allocate the structure who will contained the extracted data */
   marketPage = (FD_YahooMarketPage *)FD_Malloc( sizeof( FD_YahooMarketPage ) );
   if( !marketPage )
   {
      FD_WebPageFree( webPage );
      return FD_ALLOC_ERR;
   }
   memset( marketPage, 0, sizeof( FD_YahooMarketPage ) );

   marketPage->magicNb = FD_MARKET_PAGE_MAGIC_NB;

   /* From this point, internalMarketPageFree can be safely called. */
    
   /* Extract the data by parsing the Web Page. */
   streamAccess = FD_StreamAccessAlloc( webPage->content );
   retCode = parseMarketPage( streamAccess, marketPage );

   if( retCode != FD_SUCCESS )
   {
      FD_StreamAccessFree( streamAccess );
      FD_WebPageFree( webPage );
      internalMarketPageFree( marketPage );
      return retCode;
   }

   retCode = FD_StreamAccessFree( streamAccess );
   if( retCode != FD_SUCCESS )
   {
      FD_WebPageFree( webPage );
      internalMarketPageFree( marketPage );
      return retCode;
   }

   retCode = FD_WebPageFree( webPage );
   if( retCode != FD_SUCCESS )
   {
      internalMarketPageFree( marketPage );
      return retCode;
   }
   
   /* Success. Return the result to the caller. */  
   *allocatedMarketPage = marketPage;

   return FD_SUCCESS;
}

static FD_RetCode internalMarketPageFree( FD_YahooMarketPage *marketPage )
{
   FD_StringCache *stringCache;

   if( marketPage )
   {
      if( marketPage->magicNb != FD_MARKET_PAGE_MAGIC_NB )
         return FD_BAD_OBJECT;

      if( marketPage->name )
      {
         stringCache = FD_GetGlobalStringCache();
         FD_StringFree( stringCache, marketPage->name );
      }

      FD_Free(  marketPage );
   }

   return FD_SUCCESS;
}

static FD_RetCode parseMarketPage( FD_StreamAccess *streamAccess,
                                   FD_YahooMarketPage *marketPage )
{
   FD_RetCode retCode;
   FD_StreamAccess *searchStartPoint;
   int i;
   #define NB_EXCHANGE_STRING 5
   static const char *exchangeString[NB_EXCHANGE_STRING][3] = 
   {
      {"(NASDAQNM", "NASDAQ", "STOCK"},
      {"(NASDAQSC", "NASDAQ", "FUND" },
      {"(NASDAQ",   "NASDAQ", "FUND" },
      {"(NYSE",     "NYSE",   "STOCK"},
      {"(AMEX",     "AMEX",   "STOCK"},
   };

   /* This parsing handle only US pages */
   marketPage->countryId = FD_Country_ID_US;

   /* Identify the exchange and type */
   searchStartPoint = FD_StreamAccessAllocCopy( streamAccess );
   for( i=0; i < NB_EXCHANGE_STRING; i++ )
   {
      retCode = FD_StreamAccessSearch( searchStartPoint, exchangeString[i][0] );
      if( retCode == FD_SUCCESS )
      { 
         marketPage->exchange  = exchangeString[i][1];
         marketPage->type      = exchangeString[i][2];
         break; /* Exchange identified... exit loop */
      }
   }
   FD_StreamAccessFree(searchStartPoint);

   if( i == NB_EXCHANGE_STRING )
   {
      /* Default unknown exchange */
      marketPage->exchange  = "OTHER";
      marketPage->type      = "OTHER";

      /* Detect case where the symbol is no longer valid. */
      searchStartPoint = FD_StreamAccessAllocCopy( streamAccess );
      retCode = FD_StreamAccessSearch( searchStartPoint, "is no longer valid" );
      FD_StreamAccessFree(searchStartPoint);
      if( retCode == FD_SUCCESS )
         return FD_OBSOLETED_SYMBOL;

      /* Detect case where the symbol is no longer valid. */
      searchStartPoint = FD_StreamAccessAllocCopy( streamAccess );
      retCode = FD_StreamAccessSearch( searchStartPoint, "Changed Ticker Symbol" );
      FD_StreamAccessFree(searchStartPoint);
      if( retCode == FD_SUCCESS )
         return FD_OBSOLETED_SYMBOL;

      /* Detect case where the symbol is no longer valid. */
      searchStartPoint = FD_StreamAccessAllocCopy( streamAccess );
      retCode = FD_StreamAccessSearch( searchStartPoint, "is not a valid ticker symbol" );
      FD_StreamAccessFree(searchStartPoint);
      if( retCode == FD_SUCCESS )
         return FD_OBSOLETED_SYMBOL;

      /* Detect case where the symbol is no longer valid. */
      searchStartPoint = FD_StreamAccessAllocCopy( streamAccess );
      retCode = FD_StreamAccessSearch( searchStartPoint, "Invalid Ticker Symbol" );
      FD_StreamAccessFree(searchStartPoint);
      if( retCode == FD_SUCCESS )
         return FD_OBSOLETED_SYMBOL;

      return FD_INVALID_SECURITY_EXCHANGE;
   }
   
   return FD_SUCCESS;
}

