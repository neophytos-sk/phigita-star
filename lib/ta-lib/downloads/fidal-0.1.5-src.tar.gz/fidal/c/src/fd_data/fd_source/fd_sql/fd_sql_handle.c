/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  PK       Pawel Konieczny
 *  MF       Mario Fortier
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  101703 PK   First version.
 *  110103 PK   Minidriver architecture
 *  012504 MF   Add some FD_ASSERT + minor changes to be more C vs C++.
 */

/* Description:
 *    Allows to allocate/de-allocate FD_DataSourceHandle structure.
 *    Executes SQL queries to build up the index of categories and symbols.
 */

/**** Headers ****/
#include <string.h>
#include <ctype.h>
#include <string.h>
#include "fd_trace.h"
#include "fd_memory.h"
#include "fd_global.h"
#include "fd_sql_handle.h"
#include "fd_sql_local.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/
static FD_PrivateSQLHandle *allocPrivateHandle( void );
static FD_RetCode freePrivateHandle( FD_PrivateSQLHandle *privateHandle );
static FD_RetCode freeCategoryIndex( void *toBeFreed );
static FD_RetCode freeSymbolsIndex( void *toBeFreed );
static FD_RetCode registerCategoryAndSymbol( FD_List *categoryIndex, FD_String *category, FD_String *symbol );
static FD_RetCode registerCategoryAndAllSymbols( FD_PrivateSQLHandle *privateHandle, FD_String *category);

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/


FD_DataSourceHandle *FD_SQL_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param )
{
   FD_DataSourceHandle *handle;

   FD_ASSERT_RET( param != NULL, (FD_DataSourceHandle *)NULL );
      
   handle = (FD_DataSourceHandle *)FD_Malloc(sizeof( FD_DataSourceHandle ));
   if( !handle )
      return NULL;

   /* Initialized fields. */
   handle->nbCategory = 0;

   /* Allocate the opaque data. */
   handle->opaqueData = allocPrivateHandle();
   if( !handle->opaqueData )
   {
      FD_SQL_DataSourceHandleFree( handle );
      return NULL;
   }

   ((FD_PrivateSQLHandle *)handle->opaqueData)->param = param;

   return handle;
}



FD_RetCode FD_SQL_DataSourceHandleFree( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_PrivateSQLHandle *privateHandle;

   FD_TRACE_BEGIN(  FD_SQL_DataSourceHandleFree );

   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateSQLHandle *)handle->opaqueData;

   if( handle )
   {
      if( freePrivateHandle( (FD_PrivateSQLHandle *)handle->opaqueData ) != FD_SUCCESS )
      {
         FD_FATAL(  NULL, handle, 0 );
      }

      FD_Free( handle );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}



FD_RetCode FD_SQL_BuildSymbolsIndex( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PrivateSQLHandle *privateHandle;
   FD_StringCache *stringCache;
   const char *strval;
   void *queryResult;
   int resColumns;
   int catCol, symCol;
   int rowNum;
   FD_String *cat_name;
   FD_String *sym_name;
   const char *name;

   FD_TRACE_BEGIN( FD_SQL_BuildSymbolsIndex );
  
   FD_ASSERT(handle != NULL );
   privateHandle = (FD_PrivateSQLHandle *)handle->opaqueData;

   FD_ASSERT( privateHandle != NULL );
   FD_ASSERT( privateHandle->param != NULL );
   FD_ASSERT( privateHandle->param->category != NULL );
   FD_ASSERT( privateHandle->param->location != NULL );
   FD_ASSERT( privateHandle->connection != NULL );
   FD_ASSERT( privateHandle->minidriver->executeQuery != NULL );

   /* Initialize variables. */
   retCode = FD_SUCCESS;
   stringCache = FD_GetGlobalStringCache();
   strval = NULL;

   /* De-allocate potentialy already existing category index. */
   if( privateHandle->theCategoryIndex != NULL )
   {
      retCode = FD_ListFreeAll(privateHandle->theCategoryIndex, freeCategoryIndex);
      privateHandle->theCategoryIndex = NULL;
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
   }

   /* Allocate new category index. */
   privateHandle->theCategoryIndex = FD_ListAlloc();
   if( !privateHandle->theCategoryIndex )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   if( strnicmp("SELECT ", FD_StringToChar(privateHandle->param->category), 7) == 0)
   {
      /* This is an SQL query; execute it to obtain the list of categories */

      retCode = (*privateHandle->minidriver->executeQuery)(
                  privateHandle->connection,
                  FD_StringToChar(privateHandle->param->category),
                  &queryResult);
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
      

      /* from now on: the query has to be released upon premature return */
      #define RETURN_ON_ERROR( rc )       \
      {                                   \
         if( rc != FD_SUCCESS )           \
         {                                \
            (*privateHandle->minidriver->releaseQuery)(queryResult); \
            FD_TRACE_RETURN( rc );        \
         }                                \
      }
      #define RETURN_FUNC( rc )           \
      {                                   \
         (*privateHandle->minidriver->releaseQuery)(queryResult); \
         FD_TRACE_RETURN( rc );        \
      }

      /* find the category column number, if present */
      retCode = (*privateHandle->minidriver->getNumColumns)(
                     queryResult,
                     &resColumns );
      RETURN_ON_ERROR( retCode );
      
      for ( catCol = 0; catCol < resColumns; catCol++) 
      { 
         retCode = (*privateHandle->minidriver->getColumnName)(
                              queryResult,
                              catCol,
                              &name );
         RETURN_ON_ERROR( retCode );
         if( stricmp(name, FD_SQL_CATEGORY_COLUMN) == 0 )
            break;
      } 
      if( catCol == resColumns )
      {
         RETURN_FUNC( FD_CATEGORY_NOT_FOUND );
      }

      /* find the symbol column number, if present */
      for ( symCol = 0; symCol < resColumns; symCol++) 
      { 
         retCode = (*privateHandle->minidriver->getColumnName)(
                              queryResult,
                              symCol,
                              &name );
         RETURN_ON_ERROR( retCode );
         if( stricmp(name, FD_SQL_SYMBOL_COLUMN) == 0 )
            break;
      }

      /* iterate through all rows */
      for( rowNum = 0;  
           (retCode = 
               (*privateHandle->minidriver->getRowString)(
                                 queryResult,
                                 rowNum, 
                                 catCol,
                                 &strval )
           ) != FD_END_OF_INDEX;
           rowNum++) 
      {
         cat_name = NULL;
         sym_name = NULL;

         RETURN_ON_ERROR( retCode );  /* retCode from the for-condition */

         if( strval && strval[0] != '\0' )  
         {
            cat_name = FD_StringAlloc( stringCache, strval );
         }
         else /* for NULL values fall back to default */
         {
            cat_name = FD_StringAlloc( stringCache, FD_DEFAULT_CATEGORY );
         }

         if( !cat_name )
         {
            RETURN_FUNC( FD_ALLOC_ERR );
         }

         if( symCol < resColumns )  /* we can collect symbols as well */
         {
            retCode = (*privateHandle->minidriver->getRowString)(
                                 queryResult,
                                 rowNum, 
                                 symCol,
                                 &strval );
            if ( retCode != FD_SUCCESS )
            {
               FD_StringFree(stringCache, cat_name);
               RETURN_ON_ERROR( retCode );
            }
       
            if( strval && strval[0] != '\0' )  /* not NULL value */
            {
                sym_name = FD_StringAlloc( stringCache, strval );

                if( !sym_name )
                {
                    RETURN_FUNC( FD_ALLOC_ERR );
                }
            }
         }

         if ( sym_name )
         {
            retCode = registerCategoryAndSymbol(privateHandle->theCategoryIndex, 
                                                cat_name,
                                                sym_name);
         }
         else
         {
            retCode = registerCategoryAndAllSymbols(privateHandle,
                                                    cat_name);
         }

         FD_StringFree(stringCache, cat_name);
         if( sym_name )
            FD_StringFree(stringCache, sym_name);

         if( retCode != FD_SUCCESS )
         {
            break;
         }
      } 

      if( retCode == FD_END_OF_INDEX )
      {
        retCode = FD_SUCCESS;
      }
   }
   else
   {
      /* Create one category, taking the category sting literally */
      retCode = registerCategoryAndAllSymbols(privateHandle, 
                                              privateHandle->param->category);
   }

#undef RETURN_ON_ERROR
#undef RETURN_FUNC
   
   FD_TRACE_RETURN( retCode );
}



/**** Local functions definitions.     ****/

static FD_PrivateSQLHandle *allocPrivateHandle( void  )
{
   FD_PrivateSQLHandle *privateHandle;

   privateHandle = (FD_PrivateSQLHandle *)FD_Malloc( sizeof( FD_PrivateSQLHandle ) );
   if( !privateHandle )
      return NULL;

   memset( privateHandle, 0, sizeof( FD_PrivateSQLHandle ) );

   return privateHandle;
}



static FD_RetCode freePrivateHandle( FD_PrivateSQLHandle *privateHandle )
{
   FD_RetCode retCode;
   FD_RetCode retCode2;

   retCode = FD_SUCCESS;
   if( privateHandle )
   {
      if( privateHandle->database )
      {
         FD_StringFree( FD_GetGlobalStringCache(), privateHandle->database );
      }

      if( privateHandle->theCategoryIndex )
      {
         retCode = FD_ListFreeAll(privateHandle->theCategoryIndex, freeCategoryIndex);
         privateHandle->theCategoryIndex = NULL;
      }

      if( privateHandle->connection )
      {
         if( privateHandle->minidriver->closeConnection )
         {
            retCode2 = (*privateHandle->minidriver->closeConnection)( privateHandle->connection );               
            if( retCode2 != FD_SUCCESS )
            {
               retCode = retCode2;
            }
         }
         else
         {
            retCode = FD_INTERNAL_ERR;
         }
         privateHandle->connection = NULL;
      }

      FD_Free( privateHandle );
   }

   return retCode;
}



static FD_RetCode freeCategoryIndex( void *toBeFreed )
{
   FD_SQLCategoryNode *node;
   FD_RetCode retCode;

   node = (FD_SQLCategoryNode*)toBeFreed;
   retCode = FD_SUCCESS;

   if( !node )
      return FD_SUCCESS;

   if( node->category && retCode == FD_SUCCESS )
   {
      FD_StringFree( FD_GetGlobalStringCache(), node->category );
      node->category = NULL;
   }

   if( node->theSymbols && retCode == FD_SUCCESS )
   {
      retCode = FD_ListFreeAll( node->theSymbols, freeSymbolsIndex);
      node->theSymbols = NULL;
   }
   
   if( retCode == FD_SUCCESS )
   {
      FD_Free(node);
   }

   return retCode;
}



static FD_RetCode freeSymbolsIndex( void *toBeFreed )
{
   FD_String *symbol;
   FD_RetCode retCode;

   symbol = (FD_String*)toBeFreed;
   retCode = FD_SUCCESS;

   if( symbol )
   {
      FD_StringFree( FD_GetGlobalStringCache(), symbol );
      symbol = NULL;
   }

   return retCode;
}



/* registerCategoryAndSymbol takes care of avoiding duplicates
 * The caller keeps ownership to passed parameters.
 * We will do dup here if needed.
 */
static FD_RetCode registerCategoryAndSymbol( FD_List *categoryIndex,
                                             FD_String *category, 
                                             FD_String *symbol )
{
   FD_String *known_symbol;
   FD_SQLCategoryNode *categoryNode;
   FD_RetCode retCode;

   if( !category )
      return FD_BAD_PARAM;

   /* Find out if the category is already registered */
   categoryNode = (FD_SQLCategoryNode*)FD_ListAccessHead(categoryIndex);
   while ( categoryNode 
        && strcmp(FD_StringToChar(categoryNode->category), FD_StringToChar(category)) != 0)
   {
      categoryNode = (FD_SQLCategoryNode*)FD_ListAccessNext(categoryIndex);
   }
 
   if( !categoryNode )
   {
      /* New category, allocate node for it */
      categoryNode = (FD_SQLCategoryNode*)FD_Malloc(sizeof( FD_SQLCategoryNode ));
      if( !categoryNode )
      {
         return FD_ALLOC_ERR;
      }
      memset(categoryNode, 0, sizeof( FD_SQLCategoryNode ));
      retCode = FD_ListAddTail( categoryIndex, categoryNode );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(categoryNode);
         return retCode;
      }
      categoryNode->category = FD_StringDup(FD_GetGlobalStringCache(), category);
   }

   /* Register symbol, if not yet registered */
   if( symbol )
   {
      /* Find out if the symbol is already registered */
      known_symbol = (FD_String*)FD_ListAccessHead(categoryNode->theSymbols);
      while ( known_symbol 
           && strcmp(FD_StringToChar(known_symbol), FD_StringToChar(symbol)) != 0)
      {
         known_symbol = (FD_String*)FD_ListAccessNext(categoryNode->theSymbols);
      }

      if( !known_symbol )
      {
         /* New symbol, add it to the list */
         if( !categoryNode->theSymbols )
         {
            categoryNode->theSymbols = FD_ListAlloc();
            if( !categoryNode->theSymbols )
               return FD_ALLOC_ERR;
         }

         retCode = FD_ListAddTail( categoryNode->theSymbols, 
                                    (void*)FD_StringDup(FD_GetGlobalStringCache(), symbol) );
         if( retCode != FD_SUCCESS )
         {
            return retCode;
         }
      }
   }

   return FD_SUCCESS;
}



/* registerCategoryAndAllSymbols executes SQL query for the symbol and
 * registers all symbols in the same category
 */
static FD_RetCode registerCategoryAndAllSymbols( FD_PrivateSQLHandle *privateHandle,
                                                 FD_String *category)
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_StringCache *stringCache;
   const char *strval;
   void *queryResult;
   int resColumns;
   int symCol;
   int rowNum;
   char *symQuery;
   FD_String *sym_name;
   const char *name;

   /* is trace allowed through static fuctions? */
   FD_TRACE_BEGIN( registerCategoryAndAllSymbols );

   stringCache = FD_GetGlobalStringCache();
   strval = NULL;

   if( !category )
   {
      FD_TRACE_RETURN(FD_BAD_PARAM);
   }

   if( privateHandle->param->symbol 
       && strnicmp("SELECT ", FD_StringToChar(privateHandle->param->symbol), 7) == 0)
   {
      /* This is an SQL query; execute it to obtain the list of symbols */
   
      /* Because the query may return no results, we must make sure that
       * at leas the category will be registered.
       */
      retCode = registerCategoryAndSymbol(privateHandle->theCategoryIndex, 
                                          category,
                                          NULL);
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN(retCode);
      }

      /* Now the SQL query */
      symQuery = FD_SQL_ExpandPlaceholders(FD_StringToChar(privateHandle->param->symbol),
                                            FD_SQL_CATEGORY_PLACEHOLDER,
                                            FD_StringToChar(category));
      if( !symQuery )
      {
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      retCode = (*privateHandle->minidriver->executeQuery)(
                  privateHandle->connection,
                  symQuery,
                  &queryResult);
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
      
      /* from now on: the query has to be released upon premature return */
      #define RETURN_ON_ERROR( rc )       \
      {                                   \
         if( rc != FD_SUCCESS )           \
         {                                \
            (*privateHandle->minidriver->releaseQuery)(queryResult); \
            FD_TRACE_RETURN( rc );        \
         } \
      }
      #define RETURN_FUNC( rc )           \
      {                                   \
         (*privateHandle->minidriver->releaseQuery)(queryResult); \
         FD_TRACE_RETURN( rc );        \
      }


      /* find the symbol column number, if present */
      retCode = (*privateHandle->minidriver->getNumColumns)(
                     queryResult,
                     &resColumns );
      RETURN_ON_ERROR( retCode );

      for ( symCol = 0; symCol < resColumns; symCol++) 
      { 
         name = NULL;

         retCode = (*privateHandle->minidriver->getColumnName)(
                              queryResult,
                              symCol,
                              &name );
         RETURN_ON_ERROR( retCode );

         if( (stricmp(name, FD_SQL_SYMBOL_COLUMN) == 0) )
         {
            break;
         }
      }
      if( symCol == resColumns )
      {
         RETURN_FUNC( FD_BAD_QUERY );
      }

      /* iterate through all rows */
      for( rowNum = 0;  
           (retCode = 
               (*privateHandle->minidriver->getRowString)(
                              queryResult,
                              rowNum, 
                              symCol,
                              &strval )
           ) != FD_END_OF_INDEX;
           rowNum++) 
      {
         sym_name = NULL;

         RETURN_ON_ERROR( retCode );  /* retCode from the for-condition */

         if( strval )
         {
            sym_name = FD_StringAlloc( stringCache, strval );
         }

         if( !sym_name )
         {
            RETURN_FUNC( FD_ALLOC_ERR );
         }

         if( strcmp(FD_StringToChar(sym_name), "") != 0 )  /* ignore NULL fields */
         {
            retCode = registerCategoryAndSymbol(privateHandle->theCategoryIndex, 
                                                category,
                                                sym_name);
         }
         FD_StringFree(stringCache, sym_name);

         if( retCode != FD_SUCCESS )
         {
            break;
         }
      }
      if( retCode == FD_END_OF_INDEX )
      {
         retCode = FD_SUCCESS;
      }

      FD_Free(symQuery);
   }
   else if ( privateHandle->param->symbol
             && *FD_StringToChar(privateHandle->param->symbol) != '\0' )
   {
      /* Create one symbol, taking the symbol sting literally */
      retCode = registerCategoryAndSymbol(privateHandle->theCategoryIndex, 
                                          category,
                                          privateHandle->param->symbol);
   }
   else
   {
      /* Create one symbol, falling back to the database name */
      retCode = registerCategoryAndSymbol(privateHandle->theCategoryIndex, 
                                          category,
                                          privateHandle->database);
   }

#undef RETURN_ON_ERROR
#undef RETURN_FUNC
      
   FD_TRACE_RETURN( retCode );   
}


