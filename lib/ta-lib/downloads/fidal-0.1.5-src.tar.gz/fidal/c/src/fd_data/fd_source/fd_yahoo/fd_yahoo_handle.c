/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  040304 MF   Fix #927808. Adapt code to a format change from Yahoo!
 */

/* Description:
 *    Allows to allocate/de-allocate FD_DataSourceHandle structure.
 */

/**** Headers ****/
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_yahoo_handle.h"
#include "fd_yahoo_idx.h"
#include "fd_fileindex.h"
#include "fd_token.h"
#include "fd_yahoo_priv.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/
static FD_PrivateYahooHandle *allocPrivateHandle( void );
static FD_RetCode freePrivateHandle( FD_PrivateYahooHandle *privateHandle );


/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

FD_DataSourceHandle *FD_YAHOO_DataSourceHandleAlloc( void )
{
   FD_DataSourceHandle *handle;
   FD_PrivateYahooHandle *privateHandle;

   handle = (FD_DataSourceHandle *)FD_Malloc(sizeof( FD_DataSourceHandle ));
   if( !handle )
      return NULL;

   memset( handle, 0, sizeof( FD_DataSourceHandle ) );

   /* Allocate the opaque data. */
   privateHandle = allocPrivateHandle();
   handle->opaqueData = privateHandle;
   if( !handle->opaqueData )
   {
      FD_Free( handle );
      return NULL;
   }
    
   handle->nbCategory = 0;
   
   return handle;
}

FD_RetCode FD_YAHOO_DataSourceHandleFree( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_PrivateYahooHandle *privateHandle;

   privateHandle = (FD_PrivateYahooHandle *)handle->opaqueData;

   FD_TRACE_BEGIN( FD_YAHOO_DataSourceHandleFree );

   if( handle )
   {
      if( freePrivateHandle( (FD_PrivateYahooHandle *)handle->opaqueData ) != FD_SUCCESS )
      {
         FD_FATAL( NULL, handle, 0 );
      }

      FD_Free( handle );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

/**** Local functions definitions.     ****/
static FD_PrivateYahooHandle *allocPrivateHandle( void )
{
   FD_PrivateYahooHandle *privateHandle;
   FD_RetCode retCode;

   privateHandle = (FD_PrivateYahooHandle *)FD_Malloc( sizeof( FD_PrivateYahooHandle ) );
   if( !privateHandle )
      return NULL;

   memset( privateHandle, 0, sizeof( FD_PrivateYahooHandle ) );

   /* freePrivateHandle can be safely called from this point. */

   retCode = FD_ReadOpInfoAlloc( "[D][MMM][YY][O][H][L][C][V][-NDL]",                               
                                 &privateHandle->readOp6Fields, 0 );
   if( retCode != FD_SUCCESS )
   {
      freePrivateHandle( privateHandle );
      return NULL;
   }

   retCode = FD_ReadOpInfoAlloc( "[D][MMM][YY][C][-NDL]",
                                 &privateHandle->readOp2Fields, 0 );
   if( retCode != FD_SUCCESS )
   {
      freePrivateHandle( privateHandle );
      return NULL;
   }

   retCode = FD_ReadOpInfoAlloc( "[D][MMM][YY][O][H][L][C][-NDL]",
                                 &privateHandle->readOp5Fields, 0 );
   if( retCode != FD_SUCCESS )
   {
      freePrivateHandle( privateHandle );
      return NULL;
   }

   return privateHandle;
}

static FD_RetCode freePrivateHandle( FD_PrivateYahooHandle *privateHandle )
{
   FD_StringCache *stringCache;

   if( privateHandle )
   {
      if( privateHandle->index )
         FD_YahooIdxFree( privateHandle->index );

      if( privateHandle->readOp6Fields )
         FD_ReadOpInfoFree( privateHandle->readOp6Fields );

      if( privateHandle->readOp5Fields )
         FD_ReadOpInfoFree( privateHandle->readOp5Fields );

      if( privateHandle->readOp2Fields )
         FD_ReadOpInfoFree( privateHandle->readOp2Fields );

      stringCache = FD_GetGlobalStringCache();
      if( privateHandle->webSiteSymbol )
         FD_StringFree( stringCache, privateHandle->webSiteSymbol );

      if( privateHandle->userSpecifiedServer )
         FD_StringFree( stringCache, privateHandle->userSpecifiedServer );

      FD_Free( privateHandle );
   }

   return FD_SUCCESS;
}
