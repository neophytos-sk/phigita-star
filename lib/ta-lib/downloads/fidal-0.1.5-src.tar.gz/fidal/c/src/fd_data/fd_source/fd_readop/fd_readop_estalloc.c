/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  JP       John Price <jp_talib@gcfl.net>
 *
 * Change history:
 *
 *  MMDDYY BY  Description
 *  -------------------------------------------------------------------
 *  120100 MF  First version.
 *  010503 MF  Fix #660248. Intra-day range problem submitted by JP.
 *             
 *
 */

/* Description:
 *    Provides function to estimate the minimum memory allocation space
 *    needed for a given ASCII file.
 *    Consider multiple factor, including the start/end range requested
 *    by the user.
 */

/**** Headers ****/
#include "fd_readop.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/

FD_RetCode FD_EstimateAllocInit( const FD_Timestamp *start,
                                 const FD_Timestamp *end,
                                 FD_Period period,
                                 unsigned int minimumSize,
                                 unsigned int maximumSize,
                                 FD_EstimateInfo *estimationInfo,
                                 unsigned int *nbElementToAllocate )
{
   unsigned int nbElement;

   #if 0
      /* Force extrems value for testing. */
      *nbElementToAllocate = 1;
      return FD_SUCCESS;
   #endif

   nbElement = minimumSize; /* Default */

   if( start && end )
   {
      switch( period )
      {
      case FD_DAILY:
         FD_TimestampDeltaDay( start, end, &nbElement );
         break;
      case FD_WEEKLY:
         FD_TimestampDeltaWeek( start, end, &nbElement );
         break;
      case FD_MONTHLY:
         FD_TimestampDeltaMonth( start, end, &nbElement );
         break;
      case FD_QUARTERLY:
         FD_TimestampDeltaQuarter( start, end, &nbElement );
         break;
      case FD_YEARLY:
         FD_TimestampDeltaYear( start, end, &nbElement );
         break;
      default:
         if( (period >= FD_1SEC) && (period <= FD_1HOUR) )
         {
            /* Estimate the number of day */
            if( (FD_GetDay  (start) != FD_GetDay  (end)) ||
                (FD_GetMonth(start) != FD_GetMonth(end)) ||
                (FD_GetYear (start) != FD_GetYear (end)) )
            {
               /* Estimate assuming market is open for 8 hours per day 
                * (it does not hurt to slightly under or over estimate)
                */
               FD_TimestampDeltaDay( start, end, &nbElement );
               nbElement *= (8*60*60);
               nbElement /= period;
            }
            else
            {
               nbElement = (8*60*60);
               nbElement /= period;
            }
         }
         break;
      }
      nbElement += 2;
   }

   /* Make the estimation fits within the max/min provided. */
   estimationInfo->maximumSize = maximumSize;
   estimationInfo->minimumSize = minimumSize;
   if( nbElement > maximumSize )
      nbElement = maximumSize;

   if( nbElement < minimumSize )
      nbElement = minimumSize;

   *nbElementToAllocate = nbElement;

   return FD_SUCCESS;
}

FD_RetCode FD_EstimateAllocNext( FD_EstimateInfo *estimationInfo,
                                 unsigned int *nbElementToAllocate )
{
   /* In the case that the initial estimation was not sufficient,
    * a re-estimation is requested for the remainder of the file.
    */
   (void)estimationInfo;

   #if 0
      /* Force extrems value for testing. */
      *nbElementToAllocate = 11;
      return FD_SUCCESS;
   #endif

   /* Let's keep it simple for the time being. Just add 
    * 200 price bar.
    */
   *nbElementToAllocate = 200;

   return FD_SUCCESS;
}



/**** Local functions definitions.     ****/
/* None */



