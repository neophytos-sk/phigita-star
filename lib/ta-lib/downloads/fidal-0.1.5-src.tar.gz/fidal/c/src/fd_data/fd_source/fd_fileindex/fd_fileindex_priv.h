#ifndef FD_FILEINDEX_PRIV_H
#define FD_FILEINDEX_PRIV_H

/* Contains prototypes/definitions that must be used only privately by the
 * FD_FileIndex module.
 */
#ifndef FD_FILEINDEX_H
   #include "fd_fileindex.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_TOKEN_H
   #include "fd_token.h"
#endif

typedef struct
{
   FD_String *value;
   FD_TokenId id;
} FD_TokenInfo;

typedef struct
{
   void *parent;
   FD_String *string;
   FD_List *child;
} FD_ValueTreeNode;

typedef struct
{
   FD_List *listCategory;     /* List of FD_FileIndexCategoryData */

   FD_List *listLocationToken;    /* FD_TokenInfo parsed from path. */

   FD_ValueTreeNode *root;    /* A tree containing the field value of some
                               * of the fields found in the listLocationToken.
                               */

   /* Copied at the creation of this struct. */
   FD_String *initialCategoryString; 
   FD_String *initialCategoryCountryString; 
   FD_String *initialCategoryExchangeString; 
   FD_String *initialCategoryTypeString; 

   /* Will point on constant strings used to access file systems with
    * wildcards. File system dependant.
    */
   FD_String *wildOneChar;
   FD_String *wildZeroOrMoreChar;
   FD_String *wildOneOrMoreChar;

   /* Large buffer used for temporary usage when processing
    * directories string.
    * Will be allocated with a size of FD_SOURCELOCATION_MAX_LENGTH.
    */
   char *scratchPad;

   /* Variables used to iterate within the 'listLocationToken'.
    * Only one iterator at the time.
    * These variables are mainly controled by:
    *   FD_FileIndexMoveToDepth
    *   FD_FileIndexMoveToNextToken
    *   FD_FileIndexMoveToPrevToken
    * This stuff is really not the best design in town...
    */
   unsigned int  curDirectionForward;
   unsigned int  curTokenDepth;
   FD_TokenInfo *curToken;
   FD_TokenInfo *nextToken;
   FD_TokenInfo *prevToken;

   /* Use to make our life easier while building the index.
    * Used also to iterate within the build index.
    */
   FD_String *currentSymbolString;

   /* The string for the FD_TOK_CAT token. */
   FD_String *currentCategoryString;

   /* The string for the FD_TOK_CATC,
    * FD_TOK_CATE, FD_TOK_CATT token.
    */
   FD_String *currentCategoryCountryString;
   FD_String *currentCategoryExchangeString;
   FD_String *currentCategoryTypeString;

   /* 'currentNode' identify where the next node can be added in the
    * value tree (Starting at root). Used only while building the index.
    */
   FD_ValueTreeNode *currentNode;
} FD_FileIndexPriv;

typedef struct
{
   FD_FileIndexPriv *parent;

   FD_String *string;    /* String for this category. Can be NULL. */
   FD_List *listSymbol;  /* List of FD_FileIndexSymbolData */
} FD_FileIndexCategoryData;

typedef struct
{
   FD_FileIndexCategoryData *parent;

   FD_String *string;

   /* Point to the last node in the "value tree" defining the fields for
    * correctly retreiving this symbol.
    * These fields are used in particular for:
    *  - re-building the path to access the file.
    *  - When applicable, do some sanity check for the symbol and
    *    category values.
    *
    * Note: the node belongs to the "value tree", consequently this pointer
    *       should not be used to free the node...
    */
   FD_ValueTreeNode *node;
} FD_FileIndexSymbolData;


/* Allocate/de-allocate FD_FileIndexPriv. */
FD_FileIndexPriv *FD_FileIndexPrivAlloc( FD_String *initialCategory,
                                         FD_String *initialCategoryCountry,
                                         FD_String *initialCategoryExchange,
                                         FD_String *initialCategoryType );

FD_RetCode FD_FileIndexPrivFree( FD_FileIndexPriv *toBeFreed );

/* The following allows to add elements to
 * the handle->opaqueData (this is the FD_PrivateHandle)
 *
 * Notice that there is no way to "remove" these elements
 * individually. If something wrong happen, 'freeHandle'
 * shall be called and all the related memory is freed!
 *
 * It is based on the principle that creating a new handle either
 * totaly succeed or totaly fail.
 */

FD_RetCode FD_FileIndexAddCategoryData( FD_FileIndexPriv *data,
                                        FD_String *stringCategory,
                                        FD_FileIndexCategoryData **added );

FD_RetCode FD_FileIndexAddTokenInfo(  FD_FileIndexPriv *data,
                                      FD_TokenId id,
                                      FD_String *value,
                                      FD_TokenInfo *optBefore );

FD_RetCode FD_FileIndexAddSymbolData( FD_FileIndexCategoryData *categoryData,
                                      FD_String *stringSymbol,
                                      FD_ValueTreeNode *treeNodeValue,
                                      FD_FileIndexSymbolData **added );

/* The following served to build the "value tree". The best way to destroy
 * this tree is by deleting the whole FD_FileIndexPriv...
 * On the other side, a utility function FD_FileIndexFreeValueTree is provided
 * for detroying part of the tree starting to specific node (used specifically
 * while processing the directories and a directory is found empty... all
 * correponding fields value needs to be deleted in the "value tree").
 */
FD_RetCode FD_FileIndexAddTreeValue( FD_FileIndexPriv *data,
                                     FD_String *string,
                                     FD_ValueTreeNode **added );

FD_RetCode FD_FileIndexFreeValueTree( FD_ValueTreeNode *fromNode );

/* All the time that the "Value tree" exist in the FD_FileIndexPriv, there
 * is one node designated as the currentNode.
 * Value added by FD_FileIndexAddTreeValue are added as child of the current node.
 * The newly added value become the new current node.
 *
 * The function FD_FileIndexSetCurrentTreeValueNode allows to change the current
 * node. By default, the current node start as the root of the "value tree".
 */
FD_RetCode FD_FileIndexSetCurrentTreeValueNode( FD_FileIndexPriv *data,
                                                FD_ValueTreeNode *node );

FD_ValueTreeNode *FD_FileIndexGetCurrentTreeValueNode( FD_FileIndexPriv *data );

/* Two very limited function for walking up/dowm the tree.
 * FD_FileIndexGoDownTreeValue use the first child for going down.
 * The "current node" is adjusted as we go up/down.
 */
FD_ValueTreeNode *FD_FileIndexGoDownTreeValue( FD_FileIndexPriv *data );
FD_ValueTreeNode *FD_FileIndexGoUpTreeValue( FD_FileIndexPriv *data );

/* Change the value of a particular FD_ValueTreeNode */
FD_RetCode FD_FileIndexChangeValueTreeNodeValue( FD_ValueTreeNode *nodeToChange,
                                                 FD_String *newValue );

/* Note: When FD_FileIndexAddSymbolData or FD_FileIndexAddCategoryData are
 *       called with an already existing symbol or category, the existing entity
 *       is returned.
 */

/* Utility functions. */
FD_RetCode FD_FileIndexMoveToDepth( FD_FileIndexPriv *data, unsigned int depth );
FD_RetCode FD_FileIndexMoveToNextToken( FD_FileIndexPriv *data );
FD_RetCode FD_FileIndexMoveToPrevToken( FD_FileIndexPriv *data );
unsigned int FD_FileIndexIdentifyFileDepth( FD_FileIndexPriv *data );

/* This function will transform into tokens the pattern path.
 * The tokens are put in the FD_FileIndexPriv->listLocationToken
 */
FD_RetCode FD_FileIndexParsePath( FD_FileIndexPriv *fileIndexPriv,
                                  FD_String *path );

/* Build (or re-build) the complete index of exchange and symbol by using the
 * FD_FileIndexPriv->listLocationToken.
 */
FD_RetCode FD_FileIndexBuildIndex( FD_FileIndexPriv *fileIndexPriv );

/* Re-build the path to access the file correponding to the last
 * value of a branch (leaf) in the value tree.
 */
FD_RetCode FD_FileIndexMakePathPattern( FD_FileIndexPriv *fileIndexPriv,
                                        FD_ValueTreeNode *node,
                                        char *bufferToUse,
                                        int maxBufferSize );


#endif

