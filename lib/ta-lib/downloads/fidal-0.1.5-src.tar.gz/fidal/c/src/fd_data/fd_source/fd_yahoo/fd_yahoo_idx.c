/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  SD       Scott Deerwester
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  061201 MF   First version.
 *  062803 MF   Add printf when failed to add the symbol to index.
 *  031604 SD   Fix #917085 - Unprotected fclose was causing segfault.
 *  061304 MF   Replace chart.yahoo.com with ichart.yahoo.com
 *  040205 MF   Make it easy to add decoding for other Yahoo! web site.
 */

/* Description:
 *    Allows to build the index representing all securities provided
 *    by Yahoo!
 */

/**** Headers ****/
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "fd_yahoo_idx.h"

#include "fd_dict.h"
#include "fd_list.h"
#include "fd_trace.h"
#include "fd_memory.h"
#include "fd_global.h"
#include "fd_magic_nb.h"
#include "fd_network.h"
#include "fd_yahoo_priv.h"
#include "fd_system.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
FD_HardCodedIndice hardCodedIndice[] = 
{
  { FD_Country_ID_US, "^DJI",   "DJI", "US.CBOT.INDEX" }, 
  { FD_Country_ID_US, "^DJT",   "DJT", "US.CBOT.INDEX" }, 
  { FD_Country_ID_US, "^DJU",   "DJU", "US.CBOT.INDEX" }, 
  { FD_Country_ID_US, "^DJA",   "DJC", "US.CBOT.INDEX" },

  { FD_Country_ID_US, "^NYA",   "NYA", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^NFA",   "NFA", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^NDA",   "NDA", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^NNA",   "NNA", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^NNA",   "NHB", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^STI.N", "TRIN", "US.NYSE.INDEX" },
  { FD_Country_ID_US, "^TIC.N", "TICK", "US.NYSE.INDEX" },

  { FD_Country_ID_US, "^IXIC",  "IXIC",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXQ",   "IXQ",   "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^NDX",   "IXNDX", "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXBQ",  "IXBQ",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXFN",  "IXFN",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXF",   "IXF",   "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXID",  "IXID",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXIS",  "IXIS",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXK",   "IXK",   "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXTR",  "IXTR",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^IXUT",  "IXUT",  "US.NASDAQ.INDEX" },
  { FD_Country_ID_US, "^NBI",   "NBI",   "US.NASDAQ.INDEX" },

  { FD_Country_ID_US, "^GSPC",  "SP500", "US.OTHER.INDEX" },
  { FD_Country_ID_US, "^OEX",   "SP100", "US.OTHER.INDEX" },
  { FD_Country_ID_US, "^MID",   "SP400", "US.OTHER.INDEX" },
  { FD_Country_ID_US, "^SML",   "SP600", "US.OTHER.INDEX" },

  { FD_Country_ID_US, "^RUI",   "RUI", "US.OTHER.INDEX" },
  { FD_Country_ID_US, "^RUT",   "RUT", "US.OTHER.INDEX" },
  { FD_Country_ID_US, "^RUA",   "RUA", "US.OTHER.INDEX" },

  { FD_Country_ID_US, "^XAX",   "XAX", "US.AMEX.INDEX" },
  { FD_Country_ID_US, "^IIX",   "IIX", "US.AMEX.INDEX" },
  { FD_Country_ID_US, "^NWX",   "NWX", "US.AMEX.INDEX" },
  { FD_Country_ID_US, "^NDI",   "NDI", "US.AMEX.INDEX" },
  { FD_Country_ID_US, "^XMI",   "XMI", "US.AMEX.INDEX" },
  { FD_Country_ID_US, "^TMW",   "TMW", "US.AMEX.INDEX" },

  { FD_Country_ID_US, "^VLIC",  "VLIC", "US.KCBT.INDEX" },

  { FD_Country_ID_US, "^DOT",   "DOT", "US.PHLX.INDEX" },
  { FD_Country_ID_US, "^XAU",   "XAU", "US.PHLX.INDEX" },
  { FD_Country_ID_US, "^SOXX",  "SOX", "US.PHLX.INDEX" },
  { FD_Country_ID_US, "^BKX",   "BKX", "US.PHLX.INDEX" },

  { FD_Country_ID_US, "^PSE",   "PSE", "US.PSE.INDEX" },

  { FD_Country_ID_US, "^YHOh227", "YHOh227", "US.YAHOO.INDEX" },
  { FD_Country_ID_US, "^YHOh240", "YHOh240", "US.YAHOO.INDEX" },
  { FD_Country_ID_US, "^YHOh301", "YHOh301", "US.YAHOO.INDEX" },  

  { FD_Country_ID_CA, "^TSE",   "TSE300", "CA.TSE.INDEX" }
};

const unsigned int hardCodedIndiceSize = sizeof(hardCodedIndice)/sizeof(FD_HardCodedIndice);

/**** Local declarations.              ****/

/* Hidden data within a FD_YahooCategory. */
typedef struct
{
   /* Variable used only while building the 
    * idx. Put here for convenience of 
    * freeing everything when an error occured.
    */
   FD_Dict *symDict; /* Dict of FD_String representing symbols. */
} FD_YahooCategoryHidden;

/* Hidden data within a FD_YahooIdx. */
typedef struct
{
   FD_Timestamp timestamp;

   /* Variable used only while building the 
    * idx. Put here for convenience of 
    * freeing everything when an error occured.
    */
   FD_Dict *catDict; /* Dict of FD_YahooCategory. */

   FD_YahooDecodingParam decodingParam;

} FD_YahooIdxHidden;


/* Opaque data pass to the functions doing the 
 * parsing of the HTML tables.
 */
typedef struct
{
   FD_YahooIdx *idx;
   FD_CountryId countryId;
   const char *serverName;
   const char *topIndex;
   FD_YahooIdx *idx_remote;
} FD_TableParseOpaqueData;

/**** Local functions declarations.    ****/
static void freeYahooCategory( void *toBeFreed );
static FD_RetCode addYahooSymbol( FD_YahooIdx *idx, 
                                  FD_String *catString,
                                  FD_String *symString );

static FD_RetCode buildIndexFromStream( FD_YahooIdx *idx, 
                                        FD_Stream *stream,
                                        FD_Timestamp *cacheTimeout );

static FD_RetCode buildIndexFromLocalCache( FD_YahooIdx *idx,
                                            FD_Timestamp *cacheTimeout );

static FD_RetCode buildIndexFromRemoteCache( FD_YahooIdx *idx,
                                             FD_Timestamp *cacheTimeout );

static FD_RetCode buildIndexFromYahooWebSite( FD_YahooIdx *idx );

static FD_RetCode convertDictToTables( FD_YahooIdx *idx );
static FD_RetCode convertStreamToTables( FD_YahooIdx *idx, FD_StreamAccess *stream );
static FD_RetCode buildIdxStream( const FD_YahooIdx *idx, FD_Stream *stream );

static FD_RetCode buildDictFromWebSite( FD_YahooIdx *yahooIdx, 
                                        FD_CountryId countryId );

/* Write the equivalent of a FD_DecodingParam to a stream. */
static FD_RetCode writeDecodingParam( FD_Stream *stream,
                                      FD_DecodingParam *param );

/* Alloc a FD_DecodingParam from a stream. */
static FD_RetCode allocDecodingParam( FD_StreamAccess *streamAccess,
                                      FD_DecodingParam **paramAllocated );

/* Free a FD_DecodingParam */
static FD_RetCode freeDecodingParam( FD_DecodingParam *param );

/* Function where the symbols are extracted from the Yahoo! index page. */
static FD_RetCode addSymbolsFromWebPage( FD_WebPage *webPage,
                                         void *opaqueData );

/* Function for parsing HTML tables. */
static FD_RetCode processTopIndex( unsigned int line,
                                   unsigned int column,
                                   const char *data,
                                   const char *href,
                                   void *opaqueData);

static FD_RetCode processIndex( unsigned int line,
                                unsigned int column,
                                const char *data,
                                const char *href,
                                void *opaqueData);

static FD_RetCode addTheSymbolFromWebPage( unsigned int line,
                                           unsigned int column,
                                           const char *data,
                                           const char *href,
                                           void *opaqueData);

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/* American and Canadian decoding info. */
static FD_DecodingParam defaultHistoricalDecoding =
{
   "ichart.yahoo.com",
   "/table.csv?s=",
   "&a=1&b=1&c=1950&d=1&e=1&f=3000&g=d&q=q&y=0&z=file&x=.csv",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

static FD_DecodingParam defaultMarketDecoding =
{
   "finance.yahoo.com",
   "/q?s=",
   "&d=t",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

static FD_DecodingParam defaultInfoDecoding =
{
   "finance.yahoo.com",
   "/d/quotes.csv?s=",
   "&f=sl1d1t1c1ohgv&e=.csv",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

static FD_DecodingParam defaultAdjustDecoding =
{
   "finance.yahoo.com",
   "/q/hp?s=",
   "&a=1&b=1&c=1950&d=1&e=1&f=3000&g=m",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

/* European Web Site decoding info.
 *
 * Just use the UK site for all european
 * data.
 */
static FD_DecodingParam euHistoricalDecoding =
{
   "uk.table.finance.yahoo.com",
   "/table.csv?s=",
   "&a=1&b=1&c=1950&d=1&e=1&f=3000&g=d&q=q&y=0&z=file&x=.csv",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

static FD_DecodingParam euMarketDecoding =
{
   "finance.yahoo.com",
   "/q?s=",
   "&d=t",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};

static FD_DecodingParam euInfoDecoding =
{
   "finance.yahoo.com",
   "/d/quotes.csv?s=",
   "&f=sl1d1t1c1ohgv&e=.csv",
   0x00000000,0x00,0x00,0x00,0x00,0x0000,0x0000
};


/**** Global functions definitions.   ****/

FD_RetCode FD_YahooIdxDataDecoding( FD_CountryId id, FD_DecodeType type, FD_DecodingParam *param )
{
   unsigned int i;

   memset( param, 0, sizeof( FD_DecodingParam ) );

   for( i=0; i < tableDirectYahooDecodingSize; i++ )
   {
      if( id == tableDirectYahooDecoding[i].countryId )
      {
         switch( type )
         {
         case FD_YAHOOIDX_CSV_PAGE:
            param->uirPrefix = tableDirectYahooDecoding[i].dataPrefix;
            param->uirSuffix = tableDirectYahooDecoding[i].dataSuffix;
            param->webSiteServer = tableDirectYahooDecoding[i].dataServer;
            break;

         case FD_YAHOOIDX_ADJUSTMENT:
            param->uirPrefix = tableDirectYahooDecoding[i].adjustmentPrefix;
            param->uirSuffix = tableDirectYahooDecoding[i].adjustmentSuffix;
            param->webSiteServer = tableDirectYahooDecoding[i].adjustmentServer;
            break;

         default:
            /* Do nothing */
            break;
         }

         return FD_SUCCESS; /* The country was found. */
      }
   }

   return FD_UNSUPPORTED_COUNTRY;
}

FD_DecodingParam *FD_YahooIdxDecodingParam( FD_YahooIdx *idx, FD_DecodeType type )
{
   FD_YahooIdxHidden *idxHidden;

   if( idx == NULL )
   {
      /* When no index (from .dat file) is provided, we
       * use by default the US web-site for now.
       */
      switch( type )
      {
      case FD_YAHOOIDX_CSV_PAGE:
         return &defaultHistoricalDecoding;

      case FD_YAHOOIDX_MARKET_PAGE:
         return &defaultMarketDecoding;

      case FD_YAHOOIDX_INFO:
         return &defaultInfoDecoding;

      case FD_YAHOOIDX_ADJUSTMENT:
         return &defaultAdjustDecoding;

      default:
         return NULL;
      }
   }

   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;
   if( !idxHidden )
      return NULL;

   switch( type )
   {
   case FD_YAHOOIDX_CSV_PAGE:
      return idxHidden->decodingParam.historical;

   case FD_YAHOOIDX_MARKET_PAGE:
      return idxHidden->decodingParam.market;

   case FD_YAHOOIDX_INFO:
      return idxHidden->decodingParam.info;

   case FD_YAHOOIDX_ADJUSTMENT:
      return idxHidden->decodingParam.adjustment;

   default:
      return NULL;
   }
}

FD_RetCode FD_YahooIdxAlloc( FD_CountryId           countryId,
                             FD_YahooIdx          **yahooIdxAllocated,
                             FD_YahooIdxStrategy    strategy,
                             FD_Stream             *stream,
                             FD_Timestamp          *localCacheTimeout,
                             FD_Timestamp          *remoteCacheTimeout )
{
   FD_PROLOG
   FD_YahooIdx *idx;
   FD_RetCode retCode;
   FD_YahooIdxHidden *idxHidden;
   unsigned int idxDone, i;
   const char *tempPtr;

   if( !yahooIdxAllocated )
      return FD_BAD_PARAM;

   (void)theFileDatePtr;
   (void)theFileTimePtr;

   *yahooIdxAllocated = NULL;

   FD_TRACE_BEGIN( FD_YahooIdxAlloc );

   /* Allocate the basic infrastructure for building the index. */
   idx = (FD_YahooIdx *)FD_Malloc( sizeof( FD_YahooIdx ) );
   if( !idx )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   memset( idx, 0, sizeof( FD_YahooIdx ) );
   
   idxHidden = (FD_YahooIdxHidden *)FD_Malloc( sizeof( FD_YahooIdxHidden ) );
   if( !idxHidden )
   {
      FD_Free(  idx );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( idxHidden, 0, sizeof( FD_YahooIdxHidden ) );

   idx->hiddenData = (void *)idxHidden;

   /* From this point FD_YahooIdxFree can be safely called. */

   /* Set default creation date. */
   FD_SetDefault( &idx->creationDate );

   /* Validate the countryId. */
   tempPtr = FD_CountryIdToAbbrev(countryId);
   if( !tempPtr )
   {
      FD_YahooIdxFree( idx );
      FD_TRACE_RETURN( FD_UNSUPPORTED_COUNTRY );
   }
   idx->countryId = countryId;
   idx->countryAbbrev[0] = tempPtr[0];
   idx->countryAbbrev[1] = tempPtr[1];
   idx->countryAbbrev[2] = '\0';

   idxDone = 0;
   /* Start to build using the proposed strategy. */
   if( stream )
   {
      retCode = buildIndexFromStream( idx, stream, NULL );
      if( retCode != FD_SUCCESS )
      {
         FD_YahooIdxFree( idx );
         FD_TRACE_RETURN( retCode );
      }

      idxDone = 1; /* idx is now build. */
   }
   else
   {

      if( !idxDone && (strategy & FD_USE_LOCAL_CACHE) )
      {
         retCode = buildIndexFromLocalCache( idx, localCacheTimeout );

         if( retCode == FD_SUCCESS )
            idxDone = 1; /* idx is now build. */
         else if( !(strategy & (FD_USE_REMOTE_CACHE|FD_USE_YAHOO_SITE|FD_USE_YAHOO_AND_REMOTE_MERGE)) )
         {
            /* No other alternative offer, so return with failure. */
            FD_YahooIdxFree( idx );
            FD_TRACE_RETURN( FD_YAHOO_IDX_UNAVAILABLE_1 );
         }
      }

      if( !idxDone && (strategy & FD_USE_REMOTE_CACHE) )
      {
         /* Try to retreive the index from the 
          * remote cache.
          */
         retCode = FD_YAHOO_IDX_UNAVAILABLE_2;
         for( i=0; (i < 3) && (retCode != FD_SUCCESS); i++ )
            retCode = buildIndexFromRemoteCache( idx, remoteCacheTimeout );

         if( retCode == FD_SUCCESS )
            idxDone = 1; /* idx is now build. */
         else
         { 
            if( !(strategy & (FD_USE_YAHOO_SITE|FD_USE_YAHOO_AND_REMOTE_MERGE)) )
            {
               /* No other alternative offer, so return with failure. */
               FD_YahooIdxFree( idx );
               FD_TRACE_RETURN( FD_YAHOO_IDX_UNAVAILABLE_2 );
            }
         }
      }
   
      if( !idxDone && (strategy & FD_USE_YAHOO_SITE) )
      {
         retCode = buildIndexFromYahooWebSite( idx );
         if( retCode == FD_SUCCESS )
            idxDone = 1; /* idx is now build. */
         else
         { 
            if( !(strategy & (FD_USE_YAHOO_AND_REMOTE_MERGE)) )
            {
               /* No other alternative offer, so return with failure. */
               FD_YahooIdxFree( idx );
               FD_TRACE_RETURN( FD_YAHOO_IDX_UNAVAILABLE_4 );
            }
         }  
      }

      if( !idxDone && (strategy & FD_USE_YAHOO_AND_REMOTE_MERGE) )
      {
         retCode = buildIndexFromYahooWebSite( idx );
         if( retCode == FD_SUCCESS )
            idxDone = 1; /* idx is now build. */
      }
   }

   if( !idxDone )
   {
      FD_YahooIdxFree( idx );
      if( strategy & (FD_USE_YAHOO_SITE|FD_USE_REMOTE_CACHE|FD_USE_YAHOO_AND_REMOTE_MERGE) )
      {
         FD_TRACE_RETURN( FD_YAHOO_IDX_UNAVAILABLE_3 );
      }
      else
      {
         FD_TRACE_RETURN( FD_YAHOO_IDX_FAILED );
      }
   }

   /* Success! Return the index to the caller. */
   *yahooIdxAllocated = idx;

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_YahooIdxFree( FD_YahooIdx *idxToBeFreed )
{
   FD_YahooIdxHidden *idxHidden;
   unsigned int i;
   FD_StringCache *stringCache;
   FD_YahooCategory *category;
   unsigned int catBelongToDict;

   if( idxToBeFreed )
   {
      /* Get pointers used to free the rest... */
      idxHidden = (FD_YahooIdxHidden *)idxToBeFreed->hiddenData;
      if( !idxHidden )
         return FD_INTERNAL_ERROR(105);

      stringCache = FD_GetGlobalStringCache();
      if( !stringCache )
         return FD_INTERNAL_ERROR(106);

      /* Identify who owns the category, consequently
       * who should free these (when a dictionary exist
       * the pointers in 'categories' are just alias).
       */
      if( idxHidden->catDict )
         catBelongToDict = 1;
      else
         catBelongToDict = 0;
      
      /* Free public data. */      
      if( idxToBeFreed->categories )
      {         
         /* Free categories if not own by catDict. */
         if( !catBelongToDict )
         {
            for( i=0; i < idxToBeFreed->nbCategory; i++ )
            {
               category = idxToBeFreed->categories[i];
               if( category )
                  freeYahooCategory( category );
            }
         }

         FD_Free( idxToBeFreed->categories );
      }

      /* Free hidden data. */
      if( idxHidden->catDict )
         FD_DictFree( idxHidden->catDict );
      if( idxHidden->decodingParam.historical )
         freeDecodingParam( idxHidden->decodingParam.historical );
      if( idxHidden->decodingParam.market )
         freeDecodingParam( idxHidden->decodingParam.market );
      if( idxHidden->decodingParam.info )
         freeDecodingParam( idxHidden->decodingParam.info );
      /* Note: idxHidden->decodingParam.adjustment is hard coded. */

      FD_Free( idxHidden );

      /* Finally, free the FD_YahooIdx itself. */
      FD_Free( idxToBeFreed );
   }

   return FD_SUCCESS;
}

FD_RetCode FD_YahooIdxStream( const FD_YahooIdx *idx, FD_Stream **streamAllocated )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_YahooIdxHidden *idxHidden;
   FD_Stream *stream;
   FD_Stream *compressedStream;
   FD_Timestamp now;
   FD_Integer identifier;

   unsigned int beforeSize, afterSize;
   #ifdef FD_DEBUG
   FILE *out;
   #endif

   if( !idx || !streamAllocated )
      return FD_BAD_PARAM;

   idxHidden = idx->hiddenData;

   *streamAllocated = NULL;

   FD_TRACE_BEGIN(  FD_YahooIdxStream );

   #ifdef FD_DEBUG
      out = FD_GetStdioFilePtr();
   #endif

   stream = FD_StreamAlloc();
   if( !stream )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Build the stream. */
   retCode = buildIdxStream( idx, stream );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( stream );
      FD_TRACE_RETURN( retCode );
   }

   /* Compress the stream. */
   compressedStream = FD_StreamAlloc();
   if( !compressedStream )
   {
      FD_StreamFree( stream );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   retCode = FD_StreamCompress( compressedStream, stream );
   beforeSize = FD_StreamSizeInBit( stream );

   #if 0
      #ifdef FD_DEBUG
      /* Useful when very low-level debugging is needed. */
      if( out )
      {
         fprintf( out, "ORIG: " );
         FD_StreamPrint( stream );
         fprintf( out, "COMP: " );
         FD_StreamPrint( compressedStream );
      }
      #endif
   #endif
    
   FD_StreamFree( stream ); /* The uncompress one not needed anymore. */

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }
   afterSize = FD_StreamSizeInBit( compressedStream );

   /* Encapsulate the stream. */
   FD_SetDateNow( &now );
   FD_SetTimeNow( &now );
   identifier = 0;
   retCode = FD_StreamEncapsulate( &compressedStream, &now, identifier );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( stream );
      FD_TRACE_RETURN( retCode );
   }

   #if 0
      #ifdef FD_DEBUG
      /* Useful when very low-level debugging is needed. */
      if( out )
      {
         fprintf( out, "ENCP: " );
         FD_StreamPrint( compressedStream );
         fprintf( out, "Yahoo! index final Size = %d\n", FD_StreamSizeInByte(compressedStream) );
      }
      #endif
   #endif

   /* All done! Return the stream to the caller. */
   *streamAllocated = compressedStream;
   FD_TRACE_RETURN( FD_SUCCESS );
}

/**** Local functions definitions.     ****/

/* The string are duplicated and added to the dictionaries. */
static FD_RetCode addYahooSymbol( FD_YahooIdx *idx, 
                                  FD_String  *catString,
                                  FD_String  *symString )
{
   FD_RetCode retCode;
   FD_YahooCategory *category;
   FD_YahooCategoryHidden *categoryHidden;
   FD_StringCache *stringCache;
   FD_YahooIdxHidden *idxHidden;

   /* Check parameters. */
   if( !idx || !catString || !symString )
      return FD_BAD_PARAM;

   if( !strlen(FD_StringToChar(catString)) || !strlen(FD_StringToChar(symString)) )
      return FD_BAD_PARAM;

   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;
   if( !idxHidden )
      return FD_INTERNAL_ERROR(107);

   stringCache = FD_GetGlobalStringCache();
   if( !stringCache )
      return FD_INTERNAL_ERROR(109);

   /* Add the symbol/category to the dictionnary. */
   category = FD_DictGetValue_S( idxHidden->catDict, FD_StringToChar(catString) );

   if( category )
   {
      /* The category is already in the dictionnary. */
      categoryHidden = (FD_YahooCategoryHidden *)category->hiddenData;
      if( !categoryHidden )
         return FD_INTERNAL_ERROR(110);
   }
   else
   {
      /* The category is NOT in the dictionary.
       * Allocate a new category.
       */
      category = (FD_YahooCategory *)FD_Malloc( sizeof( FD_YahooCategory ) );
      if( !category )
         return FD_ALLOC_ERR;

      memset( category, 0, sizeof( FD_YahooCategory ) );
      
      /* From this point, freeYahooCategory can be safely called. */

      category->name = FD_StringDup( stringCache, catString );
      if( !category->name )
      {
         freeYahooCategory( category );
         return FD_ALLOC_ERR;
      }

      category->hiddenData = (FD_YahooCategoryHidden *)FD_Malloc( sizeof( FD_YahooCategoryHidden ) );
      if( !category->hiddenData )
      {
         freeYahooCategory( category );
         return FD_ALLOC_ERR;
      }

      categoryHidden = category->hiddenData;
      categoryHidden->symDict = FD_DictAlloc( FD_DICT_KEY_ONE_STRING, NULL );
      if( !categoryHidden->symDict )
      {
         freeYahooCategory( category );
         return FD_ALLOC_ERR;
      }

      retCode = FD_DictAddPair_S( idxHidden->catDict, category->name, category );
      if( retCode != FD_SUCCESS )
      {
         freeYahooCategory( category );
         return retCode;
      }

      /* If something goes wrong from this point, the category will
       * be free by FD_YahooIdxFree because it is now part of the
       * dictionary.
       */
   }

   /* Add symbol to the dictionary of this category. 
    * The value is not important, only the key is significant.
    * This is why the value is a dummy '1'.
    */
   retCode = FD_DictAddPair_S( categoryHidden->symDict, symString, (void *)1 );
   if( retCode != FD_SUCCESS )
      return FD_ALLOC_ERR;
   
   /* Everything went well. */
   return FD_SUCCESS;
}

static void freeYahooCategory( void *toBefreed )
{
   FD_YahooCategory *category;
   unsigned int i;
   FD_StringCache *stringCache;
   FD_YahooCategoryHidden *hiddenData;
   FD_String *stringPtr;

   category = (FD_YahooCategory *)toBefreed;
   stringCache = FD_GetGlobalStringCache();

   if( category )
   {
      if( category->name )
         FD_StringFree( stringCache, category->name );
 
      if( category->symbols != 0 )
      {
         for( i=0; i < category->nbSymbol; i++ )
         {
            stringPtr = category->symbols[i];
            if( stringPtr )
               FD_StringFree( stringCache, stringPtr );
         }

         FD_Free(  (void *)category->symbols );
      }

      hiddenData = category->hiddenData;
      if( hiddenData )
      {
         if( hiddenData->symDict )
            FD_DictFree( hiddenData->symDict );
         FD_Free(  (void *)hiddenData );
      } 

      FD_Free(  (void *)category );
   }
}

static FD_RetCode buildIndexFromStream( FD_YahooIdx *idx, 
                                        FD_Stream *stream,
                                        FD_Timestamp *timeoutDate )
{
   FD_RetCode retCode;
   FD_Stream *finalStream;
   FD_StreamAccess *streamAccess;
   FD_Timestamp streamTimestamp;
   FD_Integer streamIdentifier;

   #ifdef FD_DEBUG
   FILE *out;
   #endif
      
   #ifdef FD_DEBUG
      out = FD_GetStdioFilePtr();
   #endif

   /* Build the public tables from the stream. */

   /* Decapsulate the stream. */
   #ifdef FD_DEBUG
      #if 0
      /* Useful when very low-level debugging is needed. */
      if( out )
      {
         fprintf( out, "ENCP: " );
         FD_StreamPrint( stream );
      }
      #endif
   #endif

   retCode = FD_StreamDecapsulate( stream, &streamTimestamp, &streamIdentifier );
   if( retCode != FD_SUCCESS )
      return retCode;

   #ifdef FD_DEBUG
      #if 0
      if( out )
      {
         fprintf( out, "COMP: " );
         FD_StreamPrint( stream );
      }
      #endif
   #endif

   retCode = FD_TimestampValidate( &streamTimestamp );
   if( retCode != FD_SUCCESS )
      return retCode;

   FD_TimestampCopy( &idx->creationDate, &streamTimestamp );

   /* Check for timeout, if the caller cares. */
   if( timeoutDate )
   {
      if( FD_TimestampLess( &streamTimestamp, timeoutDate ) )
         return FD_YAHOO_IDX_EXPIRED;
   }

   /* Decompress the stream. */
   streamAccess = FD_StreamAccessAlloc( stream );
   if( !streamAccess )
      return FD_ALLOC_ERR;

   retCode = FD_StreamDecompress( streamAccess, &finalStream );
   FD_StreamAccessFree( streamAccess );

   if( retCode != FD_SUCCESS )
      return retCode;

   #ifdef FD_DEBUG
      #if 0
      /* Useful when very low-level debugging is needed. */
      if( out )
      {
         fprintf( out, "ORIG: " );
         FD_StreamPrint( finalStream );
      }
      #endif
   #endif

   /* Convert the stream to the public interface. 
    * Needs a streamAccess on the finalStream.
    */
   streamAccess = FD_StreamAccessAlloc( finalStream );
   if( !streamAccess )
   {
      FD_StreamFree( finalStream );
      return FD_ALLOC_ERR;
   }
   retCode = convertStreamToTables( idx, streamAccess );
   FD_StreamAccessFree( streamAccess );
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( finalStream );
      return retCode;
   }

   /* All done, get ride of the stream. */
   retCode = FD_StreamFree( finalStream );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

static FD_RetCode buildIndexFromRemoteCache( FD_YahooIdx *idx, FD_Timestamp *cacheTimeout )
{
   FD_RetCode retCode;
   FD_WebPage *webPage;
   FD_Stream  *stream;
   FD_YahooIdxHidden *idxHidden;
   const char *cachePath;
   char *pathBuffer;
   FILE *out;
   int pathLength;

   char buffer[100];

   if( !idx )
      return FD_BAD_PARAM;

   idxHidden= idx->hiddenData;
   if( !idxHidden )
      return FD_BAD_PARAM;

   /* Get the cache online. */
   if( strlen( (const char *)&idx->countryAbbrev[0] ) != 2 )
      return FD_INTERNAL_ERROR(111);

   sprintf( buffer, "/rdata/y_%c%c.dat",
            tolower(idx->countryAbbrev[0]),
            tolower(idx->countryAbbrev[1]) );
   retCode = FD_WebPageAlloc( "fidalsoft.org",
                              buffer,
                              NULL, NULL,
                              &webPage, 2, NULL );

   if( retCode != FD_SUCCESS )
      return retCode;

   stream = webPage->content;
   if( !stream )
   {
      FD_WebPageFree( webPage );
      return FD_ALLOC_ERR;
   }

   /* From this point, the webPage will be freed when the stream will
    * be freed.
    */

   /* Save the remote cache locally. */
   cachePath = FD_GetLocalCachePath();

   if( cachePath )
   {
      /* Create the local file */
      pathLength = strlen( cachePath );
      pathBuffer = FD_Malloc( pathLength + 11 );
      if( pathLength )
      {
         sprintf( pathBuffer, "%s%cy_%c%c.dat",
                  cachePath,
                  FD_SeparatorASCII(),
                  tolower(idx->countryAbbrev[0]),
                  tolower(idx->countryAbbrev[1]) );
      }
      else
      {
         sprintf( pathBuffer, "y_%c%c.dat",
                  tolower(idx->countryAbbrev[0]),
                  tolower(idx->countryAbbrev[1]) );
      }

      out = fopen( pathBuffer, "wb" );
      if( out )
      {
         /* printf( "Saving local [%s]\n", pathBuffer ); */
         FD_StreamToFile( stream, out );
         fclose(out);
      }
      FD_Free( pathBuffer );
   }

   /* Call buildIndexFromStream to build the tables. */
   retCode = buildIndexFromStream( idx, stream, cacheTimeout );
   if( retCode != FD_SUCCESS )
   {
      FD_WebPageFree( webPage );
      return retCode;
   }
      
   retCode = FD_WebPageFree( webPage );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

static FD_RetCode buildIndexFromYahooWebSite( FD_YahooIdx *idx )
{
   FD_RetCode retCode;
   FD_YahooIdxHidden *idxHidden;

   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;

   /* Allocate a dictionary to make it easier to build the whole index. */
   idxHidden->catDict = (void *)FD_DictAlloc( FD_DICT_KEY_ONE_STRING, freeYahooCategory );
   if( !idxHidden->catDict )
   {
      return FD_ALLOC_ERR;
   }

   retCode = buildDictFromWebSite( idx, idx->countryId );
   if( retCode != FD_SUCCESS )
   {
      return retCode;
   }

   /* Convert the dictionaries into the public tables. */
   retCode = convertDictToTables( idx );
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

static FD_RetCode convertDictToTables( FD_YahooIdx *idx )
{
   FD_YahooIdxHidden *idxHidden;
   FD_StringCache *stringCache;
   FD_YahooCategoryHidden *categoryHidden;
   FD_YahooCategory *category;
   int i, j, nbCategory, nbSymbol;
   int again1, again2; /* boolean */
   FD_Dict *symDict;

   /* Check parameters. */
   if( !idx | (idx->categories != NULL) )
      return FD_BAD_PARAM;
   
   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;
   stringCache = FD_GetGlobalStringCache();

   nbCategory = FD_DictAccessFirst( idxHidden->catDict );
   if( nbCategory == 0 )
      idx->categories = NULL;
   else
   {
      idx->categories = (FD_YahooCategory **)FD_Malloc( sizeof( FD_YahooCategory * ) * nbCategory );
      memset( idx->categories, 0, sizeof( FD_YahooCategory * ) * nbCategory );
      if( !idx->categories )
         return FD_ALLOC_ERR;
      idx->nbCategory = nbCategory;

      /* Iterate through the category. */
      again1 = 1;
      for( i=0; again1 && (i < nbCategory); i++ )
      {
        category = (FD_YahooCategory *)FD_DictAccessValue( idxHidden->catDict );
        if( !category )
           return FD_INTERNAL_ERROR(112);

        categoryHidden = category->hiddenData;
        if( !categoryHidden )
           return FD_INTERNAL_ERROR(113);

        /* Iterate through the symbols. */
        symDict = categoryHidden->symDict;
        nbSymbol = FD_DictAccessFirst( symDict );
        if( nbSymbol == 0 )
           return FD_INTERNAL_ERROR(114);
        else
        {
           category->symbols = (FD_String **)FD_Malloc( sizeof( FD_String *) * nbSymbol );
           if( !category->symbols )
              return FD_ALLOC_ERR;
           category->nbSymbol = nbSymbol;
           again2 = 1;
           for( j=0; again2 && (j < nbSymbol); j++ )
           {
              category->symbols[j] = FD_StringDup( stringCache, FD_DictAccessKey( symDict ) );
              again2 = FD_DictAccessNext( symDict );
           }

           FD_DictFree( symDict );
           categoryHidden->symDict = NULL;
        }           

        /* Alias the category in the public interface.
         * The free function will free the dictionary and not
         * the alias in the public interface (when the catDict != NULL
         * of course, else the alias are considered the original element).
         */
        idx->categories[i] = (FD_YahooCategory *)FD_DictAccessValue( idxHidden->catDict );        
        again1 = FD_DictAccessNext( idxHidden->catDict );
      }
   }

   return FD_SUCCESS;
}

/* The stream is defined as follow:
 *
 *   Write the header:
 *    (32 bits)   FD_YAHOO_IDX_MAGIC_NB
 *    ( 8 bits)   Version of this encoding
 *
 *    ( 8 bits)   Country Abbreviation letter 1
 *    ( 8 bits)   Country Abbreviation letter 2
 *
 *    (FD_Timestamp) Creation date/time of this index.
 *
 *   Write the FD_DecodingParam for historical data:
 *    (FD_String) Web Site Server
 *    (FD_String) UIR Prefix
 *    (FD_String) UIR Suffix
 *    (32 bits)   Decoding Flow Flags
 *    ( 8 bits)   Decoding Param8_1
 *    ( 8 bits)   Decoding Param8_2
 *    ( 8 bits)   Decoding Param8_3
 *    ( 8 bits)   Decoding Param8_4
 *    (16 bits)   Decoding Param16_1
 *    (16 bits)   Decoding Param16_2
 *
 *   Write the FD_DecodingParam for market info:
 *    (FD_String) Web Site Server
 *    (FD_String) UIR Prefix
 *    (FD_String) UIR Suffix
 *    (32 bits)   Decoding Flow Flags
 *    ( 8 bits)   Decoding Param8_1
 *    ( 8 bits)   Decoding Param8_2
 *    ( 8 bits)   Decoding Param8_3
 *    ( 8 bits)   Decoding Param8_4
 *    (16 bits)   Decoding Param16_1
 *    (16 bits)   Decoding Param16_2
 *
 *   Write the FD_DecodingParam for security info:
 *    (FD_String) Web Site Server
 *    (FD_String) UIR Prefix
 *    (FD_String) UIR Suffix
 *    (32 bits)   Decoding Flow Flags
 *    ( 8 bits)   Decoding Param8_1
 *    ( 8 bits)   Decoding Param8_2
 *    ( 8 bits)   Decoding Param8_3
 *    ( 8 bits)   Decoding Param8_4
 *    (16 bits)   Decoding Param16_1
 *    (16 bits)   Decoding Param16_2
 *
 *    (16 bits)   Nb Of Category
 *
 *   For each category:
 *        (8 bits)        A sanity indicator (0xAF)
 *        (FD_String)     The name of the category.
 *        (32 bits)       The Nb Of Symbol.
 *        (8 bits)        A sanity indicator (0xEB)
 *        n x (FD_String) A string for each symbols.
 *        (8 bits)        A sanity indicator (0xF2)
 *   End for each category.
 *
 */    
static FD_RetCode buildIdxStream( const FD_YahooIdx *idx, FD_Stream *stream )
{
   FD_RetCode retCode;
   FD_YahooCategory *category;
   unsigned int i, j;
   FD_Timestamp timestamp;

   retCode = FD_StreamAddInt32( stream, FD_YAHOO_IDX_MAGIC_NB );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAddByte( stream, 0x02 ); /* Version 0.2 */
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Add timestamp. */
   retCode = FD_SetDateNow( &timestamp );
   if( retCode != FD_SUCCESS )
      return retCode;
   retCode = FD_SetTimeNow( &timestamp );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAddTimestamp( stream, &timestamp );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Write the last known valid decoding
    * parameters for this country.
    */
   for( i=0; i < 2; i++ )
   {
      retCode = FD_StreamAddByte( stream, idx->countryAbbrev[i] );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   switch( idx->countryId )
   {
   case FD_Country_ID_US:
   case FD_Country_ID_CA:
       /* Write historical decoding data. */
       retCode = writeDecodingParam( stream,
                                     &defaultHistoricalDecoding );

       /* Write market decoding data. */
       if( retCode == FD_SUCCESS )
          retCode = writeDecodingParam( stream,
                                        &defaultMarketDecoding );

       /* Write info decoding data. */
       if( retCode == FD_SUCCESS )
          retCode = writeDecodingParam( stream,
                                        &defaultInfoDecoding );
       break;

   case FD_Country_ID_UK: /* United Kingdom */
   case FD_Country_ID_DE: /* Germany */
   case FD_Country_ID_DK: /* Denmark */
   case FD_Country_ID_ES: /* Spain */
   case FD_Country_ID_FR: /* France */
   case FD_Country_ID_IT: /* Italy */
   case FD_Country_ID_SE: /* Sweden */
   case FD_Country_ID_NO: /* Norway */
       /* Write historical decoding data. */
       retCode = writeDecodingParam( stream,
                                     &euHistoricalDecoding );

       /* Write market decoding data. */
       if( retCode == FD_SUCCESS )
          retCode = writeDecodingParam( stream,
                                        &euMarketDecoding );

       /* Write info decoding data. */
       if( retCode == FD_SUCCESS )
          retCode = writeDecodingParam( stream,
                                        &euInfoDecoding );       
       break;

   default:
      return FD_UNSUPPORTED_COUNTRY;
   }
      
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Add the number of category. */   
   retCode = FD_StreamAddInt16( stream, (unsigned short)idx->nbCategory );
   if( retCode != FD_SUCCESS )
      return retCode;
   
   /* Add the data of each category. */
   for( i=0; i < idx->nbCategory; i++ )
   {
      retCode = FD_StreamAddByte( stream, 0xAF );
      if( retCode != FD_SUCCESS )
         return retCode;

      category = idx->categories[i];
      if( !category )
         return FD_INTERNAL_ERROR(115);

      retCode = FD_StreamAddString( stream, category->name );
      if( retCode != FD_SUCCESS )
         return retCode;

      retCode = FD_StreamAddInt32( stream, category->nbSymbol );
      if( retCode != FD_SUCCESS )
         return retCode;

      retCode = FD_StreamAddByte( stream, 0xEB );
      if( retCode != FD_SUCCESS )
         return retCode;

      for( j=0; j < category->nbSymbol; j++ )
      {
         retCode = FD_StreamAddString( stream, category->symbols[j] );
         if( retCode != FD_SUCCESS )
            return retCode;         
      }

      retCode = FD_StreamAddByte( stream, 0xF2 );
      if( retCode != FD_SUCCESS )
         return retCode;
   }

   /* The stream representing the index is completed! */

   return FD_SUCCESS;
}


static FD_RetCode convertStreamToTables( FD_YahooIdx *idx, FD_StreamAccess *streamAccess )
{
   FD_RetCode retCode;
   unsigned int i, j, intData, tempInt;
   unsigned int nbCategory, nbSymbol;
   unsigned char data;
   unsigned char version;
   FD_YahooIdxHidden *idxHidden;
   FD_YahooCategory *category;
   unsigned char countryAbbrev[3];

   if( !idx || !streamAccess )
      return FD_BAD_PARAM;

   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;
   if( !idxHidden )
      return FD_INTERNAL_ERROR(116);

   retCode = FD_StreamAccessGetInt32( streamAccess, &intData );
   if( retCode != FD_SUCCESS )
      return retCode;

   if( intData != FD_YAHOO_IDX_MAGIC_NB )
      return FD_BAD_YAHOO_IDX_HDR;

   /* Get the version. */    
   retCode = FD_StreamAccessGetByte( streamAccess, &version );
   if( retCode != FD_SUCCESS )
      return retCode;
   
   /* This code supports only Version 0.2 for now. */
   if( version != 0x02 )
      return FD_UNSUPORTED_YAHOO_IDX_VERSION;

   /* Get the timestamp. This is unused here. */
   retCode = FD_StreamAccessGetTimestamp( streamAccess, &idxHidden->timestamp );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Get and validate the country info. */
   countryAbbrev[2] = '\0';
   for( i=0; i < 2; i++ )
   {
      retCode = FD_StreamAccessGetByte( streamAccess, &countryAbbrev[i] );
      if( retCode != FD_SUCCESS )
         return retCode;
   }
   if( FD_CountryAbbrevToId( (const char *)&countryAbbrev[0] ) != idx->countryId )
      return FD_UNSUPPORTED_COUNTRY;

   /* Read the web page decoding parameters. */
   retCode = allocDecodingParam( streamAccess, &idxHidden->decodingParam.historical );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = allocDecodingParam( streamAccess, &idxHidden->decodingParam.market );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = allocDecodingParam( streamAccess, &idxHidden->decodingParam.info );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* "Adjustment" decoding info is hard coded for now. */ 
   idxHidden->decodingParam.adjustment = &defaultAdjustDecoding;

   /* Get the number of category and allocate the needed space. */
   retCode = FD_StreamAccessGetInt16( streamAccess, &nbCategory );
   if( retCode != FD_SUCCESS )
      return retCode;
   tempInt = sizeof( FD_YahooCategory *) * nbCategory;
   idx->categories = FD_Malloc( tempInt );
   if( !idx->categories )
      return FD_ALLOC_ERR;
   idx->nbCategory = 0; /* Will get incremented as the category are allocated. */

   /* Allocate each category. */
   for( i=0; i < nbCategory; i++ )
   {
      /* Verify the sanity indicator (0xAF) */
      retCode = FD_StreamAccessGetByte( streamAccess, &data );
      if( retCode != FD_SUCCESS )
         return retCode;
      if( data != 0xAF )
         return FD_BAD_YAHOO_IDX_INDICATOR_AF;

      /* Allocate directly the category in the public interface.
       * No need for catDict.
       */
      category = FD_Malloc( sizeof( FD_YahooCategory ) );
      if( !category )
         return FD_ALLOC_ERR;
      memset( category, 0, sizeof( FD_YahooCategory ) );
      idx->categories[i] = category;      
      idx->nbCategory++;
      retCode = FD_StreamAccessGetString( streamAccess, &category->name );
      if( retCode != FD_SUCCESS )
         return retCode;

      /* Get the number of symbol for this category. */
      retCode = FD_StreamAccessGetInt32( streamAccess, &nbSymbol );
      if( retCode != FD_SUCCESS )
         return retCode;

      /* Verify the sanity indicator (0xEB) */
      retCode = FD_StreamAccessGetByte( streamAccess, &data );
      if( retCode != FD_SUCCESS )
         return retCode;
      if( data != 0xEB )
         return FD_BAD_YAHOO_IDX_INDICATOR_EB;

      /* Allocate the space needed for the symbols. */
      tempInt = sizeof( FD_String *) * nbSymbol;
      category->symbols = (FD_String **)FD_Malloc( tempInt );
      if( !category->symbols )
         return FD_ALLOC_ERR;

      /* Get the string for each symbol in this category. */
      retCode = FD_SUCCESS;
      for( j=0; (retCode == FD_SUCCESS) && (j < nbSymbol); j++ )
      {
         retCode = FD_StreamAccessGetString( streamAccess, &category->symbols[j] );
         if( retCode != FD_SUCCESS )
            return retCode;
         category->nbSymbol++;
      }

      /* Verify the sanity indicator (0xF2) */
      retCode = FD_StreamAccessGetByte( streamAccess, &data );
      if( retCode != FD_SUCCESS )
         return retCode;
      if( data != 0xF2 )
         return FD_BAD_YAHOO_IDX_INDICATOR_F2;
   }

   return FD_SUCCESS;
}

static FD_RetCode writeDecodingParam( FD_Stream *stream,
                                      FD_DecodingParam *param )
{
   FD_RetCode retCode;
   FD_String *tempString;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   /* Add webSiteServer. */
   tempString= FD_StringAlloc( stringCache, param->webSiteServer );
   if( !tempString )
      return FD_ALLOC_ERR;
   retCode = FD_StreamAddString( stream, tempString );
   FD_StringFree( stringCache, tempString );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Add uirPrefix */
   tempString= FD_StringAlloc( stringCache, param->uirPrefix );
   if( !tempString )
      return FD_ALLOC_ERR;
   retCode = FD_StreamAddString( stream, tempString );
   FD_StringFree( stringCache, tempString );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Add uirSuffix */
   tempString= FD_StringAlloc( stringCache, param->uirSuffix );
   if( !tempString )
      return FD_ALLOC_ERR;
   retCode = FD_StreamAddString( stream, tempString );
   FD_StringFree( stringCache, tempString );
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAddInt32( stream, param->flags );
   if( retCode != FD_SUCCESS )
      return retCode;

   /* Add the rest... */
   retCode = FD_StreamAddByte( stream, param->param8_1);
   if( retCode != FD_SUCCESS )
      return retCode;
   retCode = FD_StreamAddByte( stream, param->param8_2);
   if( retCode != FD_SUCCESS )
      return retCode;
   retCode = FD_StreamAddByte( stream, param->param8_3);
   if( retCode != FD_SUCCESS )
      return retCode;
   retCode = FD_StreamAddByte( stream, param->param8_4);
   if( retCode != FD_SUCCESS )
      return retCode;

   retCode = FD_StreamAddInt16( stream, (unsigned short)param->param16_1);
   if( retCode != FD_SUCCESS )
      return retCode;
   retCode = FD_StreamAddInt16( stream, (unsigned short)param->param16_2);
   if( retCode != FD_SUCCESS )
      return retCode;

   return FD_SUCCESS;
}

static FD_RetCode allocDecodingParam( FD_StreamAccess *streamAccess,
                                      FD_DecodingParam **paramAllocated )
{
   FD_DecodingParam *param;
   FD_RetCode retCode;
   FD_String *tempString;

   if( !streamAccess || !paramAllocated )
      return FD_BAD_PARAM;

   *paramAllocated = NULL;

   retCode = FD_SUCCESS;

   param = (FD_DecodingParam *)FD_Malloc( sizeof( FD_DecodingParam ) );
   if( !param )
      return FD_ALLOC_ERR;

   memset( param, 0, sizeof( FD_DecodingParam ) );

   /* freeDecodingParam can be safely called from this point. */

   retCode = FD_StreamAccessGetString( streamAccess, &tempString );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   param->webSiteServer = FD_StringToChar( tempString );

   retCode = FD_StreamAccessGetString( streamAccess, &tempString );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   param->uirPrefix = FD_StringToChar( tempString );

   retCode = FD_StreamAccessGetString( streamAccess, &tempString );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   param->uirSuffix = FD_StringToChar( tempString );

   retCode = FD_StreamAccessGetInt32( streamAccess, (unsigned int *)&param->flags );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetByte( streamAccess, &param->param8_1 );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetByte( streamAccess, &param->param8_2 );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetByte( streamAccess, &param->param8_3 );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetByte( streamAccess, &param->param8_4 );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetInt16( streamAccess, &param->param16_1 );
   if( retCode != FD_SUCCESS )
      goto Exit_allocDecodingParam;

   retCode = FD_StreamAccessGetInt16( streamAccess, &param->param16_2 );

Exit_allocDecodingParam:
   if( retCode != FD_SUCCESS )
      freeDecodingParam( param );
   else
      *paramAllocated = param;

   return retCode;
}

/* Free a FD_DecodingParam */
static FD_RetCode freeDecodingParam( FD_DecodingParam *param )
{
   FD_StringCache *stringCache;

   if( param )
   {
      stringCache = FD_GetGlobalStringCache();

      if( param->webSiteServer )
         FD_StringFree( stringCache, FD_StringFromChar(param->webSiteServer) );

      if( param->uirPrefix )
         FD_StringFree( stringCache, FD_StringFromChar(param->uirPrefix) );

      if( param->uirSuffix )
         FD_StringFree( stringCache, FD_StringFromChar(param->uirSuffix) );

      FD_Free(  param );
   } 

   return FD_SUCCESS;
}

static FD_RetCode buildDictFromWebSite( FD_YahooIdx *idx, FD_CountryId countryId )
{
   FD_RetCode retCode;
   FD_WebPage *webPage;
   FD_StreamAccess *access;
   unsigned int i, nbTableToSkip;

   FD_String *catString;
   FD_String *symString;
   FD_StringCache *stringCache;

   FD_TableParseOpaqueData opaqueData;

   access = NULL;

   stringCache = FD_GetGlobalStringCache();
   catString = NULL;
   symString = NULL;

   opaqueData.countryId = countryId;
   opaqueData.idx = idx;
   opaqueData.idx_remote = NULL;

   /* Identify the server. */
   switch( countryId )
   {
   case FD_Country_ID_US:
   case FD_Country_ID_CA:
      opaqueData.serverName = "biz.yahoo.com";
      nbTableToSkip = 2;
      break;
   default:
      /* All european index are integrated together, so just
       * use the UK server.
       */
      opaqueData.serverName = "uk.biz.yahoo.com";
      nbTableToSkip = 4;
      break;
   }

   /* Identify the top page. */
   switch( countryId )
   {
   case FD_Country_ID_US:
   case FD_Country_ID_CA:
      opaqueData.topIndex = "/i/";
      break;
   case FD_Country_ID_UK:
      opaqueData.topIndex = "/p/uk/cpi/index.html";
      break;
   case FD_Country_ID_DE: /* Germany */
      opaqueData.topIndex = "/p/de/cpi/index.html";
      break;
   case FD_Country_ID_DK: /* Denmark */
      opaqueData.topIndex = "/p/dk/cpi/index.html";
      break;
   case FD_Country_ID_ES: /* Spain */
      opaqueData.topIndex = "/p/es/cpi/index.html";
      break;
   case FD_Country_ID_FR: /* France */
      opaqueData.topIndex = "/p/fr/cpi/index.html";
      break;
   case FD_Country_ID_IT: /* Italy */
      opaqueData.topIndex = "/p/it/cpi/index.html";
      break;
   case FD_Country_ID_SE: /* Sweden */
      opaqueData.topIndex = "/p/se/cpi/index.html";
      break;
   case FD_Country_ID_NO: /* Norway */
      opaqueData.topIndex = "/p/no/cpi/index.html";
      break;
   default:
      opaqueData.topIndex = "/i/";
      break;
   }

   retCode = FD_WebPageAlloc( opaqueData.serverName,
                              opaqueData.topIndex,
                              NULL, NULL,
                              &webPage, 2, NULL );

   if( retCode != FD_SUCCESS )
      return retCode;

   /* From now on, should exit the function by jumping
    * at the end.
    */

   /* Watch-out... this is indirectly a recursive call, but it
    * will be fine as long this remains FD_USE_REMOTE_CACHE only.
    * The remote US index is used for speed optimization to find
    * category when working to build the US/CA index.
    */
   switch( countryId )
   {
   case FD_Country_ID_US:
   case FD_Country_ID_CA:
      retCode = FD_YahooIdxAlloc( FD_Country_ID_US,
                                  &opaqueData.idx_remote,
                                  FD_USE_REMOTE_CACHE,
                                  NULL, NULL, NULL );

      if( retCode != FD_SUCCESS )
         goto Exit_buildPageList;
   default:
      break;
   }

   /* Find the table at the top representing the 
    * top index.
    */
   access = FD_StreamAccessAlloc( webPage->content );

   /* Skip first the non-meaningful tables. */
   for( i=0; i < nbTableToSkip; i++ )
   {
      retCode = FD_StreamAccessSkipHTMLTable( access );
      if( retCode != FD_SUCCESS )
         goto Exit_buildPageList;
   }

   /* Now go for the table we are looking for. */   
   retCode = FD_StreamAccessGetHTMLTable( access, 100, processTopIndex, &opaqueData );
   if( retCode != FD_SUCCESS )
      goto Exit_buildPageList;

   /* Add hard-coded index. */  
   for( i=0; i < hardCodedIndiceSize; i++ )
   {
      if( hardCodedIndice[i].countryId == countryId )
      {
         symString = FD_StringAlloc( stringCache, hardCodedIndice[i].symbolLib   );

         if( !symString )
         {
            retCode = FD_ALLOC_ERR;
            goto Exit_buildPageList;
         }
                      
         catString = FD_StringAlloc( stringCache, hardCodedIndice[i].categoryLib );

         if( !catString )
         {
            retCode = FD_ALLOC_ERR;
            goto Exit_buildPageList;
         }

         retCode = addYahooSymbol( idx, catString, symString );
         if( retCode != FD_SUCCESS )
            goto Exit_buildPageList;

         if( symString )   
         {
            FD_StringFree( stringCache, symString );
            symString = NULL;
         }

         if( catString )
         {
            FD_StringFree( stringCache, catString );
            catString = NULL;
         }
      }
   }

Exit_buildPageList:

   if( symString )   
      FD_StringFree( stringCache, symString );

   if( catString )
      FD_StringFree( stringCache, catString );

   FD_StreamAccessFree( access );
   FD_WebPageFree( webPage );
   
   if( opaqueData.idx_remote )       
      FD_YahooIdxFree( opaqueData.idx_remote );

   return retCode;
}

static FD_RetCode processTopIndex( unsigned int line,
                                   unsigned int column,
                                   const char *data,
                                   const char *href,
                                   void *opaqueData)
{
   FD_TableParseOpaqueData *tableParseInfo;
   FD_RetCode retCode;
   FD_WebPage *webPage;
   FD_StreamAccess *access;
   unsigned int i, nbTableToSkip;

   (void)data; /* Get ride of compiler warning. */
   (void)column; /* Get ride of compiler warning. */
   (void)line; /* Get ride of compiler warning. */

   webPage = NULL;
   access = NULL;

   retCode = FD_SUCCESS;

   if( *href != '\0' )
   {
      tableParseInfo = (FD_TableParseOpaqueData *)opaqueData;

      printf( "************* Processing Top Index [%s]\n", href );
      retCode = FD_WebPageAlloc( tableParseInfo->serverName,
                                 href,
                                 NULL, NULL,
                                 &webPage, 2, NULL );

      if( retCode != FD_SUCCESS )
         goto Exit_processTopIndex;

      retCode = addSymbolsFromWebPage( webPage, opaqueData );

      /* retCode = FD_FINISH_TABLE; */

      if( retCode != FD_SUCCESS )
         goto Exit_processTopIndex;

      /* Now process all the "sub index" pages */
      access = FD_StreamAccessAlloc( webPage->content );
      if( retCode != FD_SUCCESS )
         goto Exit_processTopIndex;

      /* Skip first the non-meaningful tables. */
      switch( tableParseInfo->countryId )
      {
      case FD_Country_ID_US:
      case FD_Country_ID_CA:
         nbTableToSkip = 3;
         break;
      default:
         nbTableToSkip = 8;
         break;
      }

      for( i=0; i < nbTableToSkip; i++ )
      {
         retCode = FD_StreamAccessSkipHTMLTable( access );
         if( retCode != FD_SUCCESS )
            goto Exit_processTopIndex;
      }

      /* Now go for the table we are looking for. */
      retCode = FD_StreamAccessGetHTMLTable( access, 100, processIndex, opaqueData );
      if( retCode == FD_END_OF_STREAM )
      {
         /* Do not consider as an error as it may
          * happen on certain index page.
          */
         retCode = FD_SUCCESS; 
      }

      if( retCode != FD_SUCCESS )
         goto Exit_processTopIndex;
   }

Exit_processTopIndex:
   if( access )
      FD_StreamAccessFree( access );

   if( webPage )   
      FD_WebPageFree( webPage );

   return retCode;
}

static FD_RetCode processIndex( unsigned int line,
                                unsigned int column,
                                const char *data,
                                const char *href,
                                void *opaqueData)
{
   FD_TableParseOpaqueData *tableParseInfo;
   FD_RetCode retCode;
   FD_WebPage *webPage;

   (void)data; /* Get ride of compiler warning. */
   (void)column; /* Get ride of compiler warning. */
   (void)line; /* Get ride of compiler warning. */

   webPage = NULL;

   retCode = FD_SUCCESS;

   if( *href != '\0' )
   {
      tableParseInfo = (FD_TableParseOpaqueData *)opaqueData;

      /* Trap the case where the table does not appear to be right.
       * This may happen if there is no additional index
       * index on this page (Typically the page Y,Z)
       */
      switch( tableParseInfo->countryId )
      {
      case FD_Country_ID_US:
      case FD_Country_ID_CA:
         if( strncmp( "/i/", href, 3 ) != 0 )
         {
            retCode = FD_FINISH_TABLE;
            goto Exit_processIndex;
         }
         break;
      default:         
         if( (strncmp( "/p/", href, 3 ) != 0) || (strncmp( "uk/cpi/cpi", &href[3], 10) != 0) )
         {
            retCode = FD_FINISH_TABLE;
            goto Exit_processIndex;
         }
         break;
      }

      #if 0
      /* Temporary just to debug */
      if( *(&href[3]) != 'i' )
         goto Exit_processIndex;
      #endif

      printf( "Processing web page [%s]                                 \n", &href[3] );

      retCode = FD_WebPageAlloc( tableParseInfo->serverName,
                                 href,
                                 NULL, NULL,
                                 &webPage, 2, NULL );

      if( retCode != FD_SUCCESS )
         goto Exit_processIndex;

      retCode = addSymbolsFromWebPage( webPage, opaqueData );
      if( retCode != FD_SUCCESS )
         goto Exit_processIndex;
   }

Exit_processIndex:
   if( webPage )
      FD_WebPageFree( webPage );

   return retCode;
}

static FD_RetCode addSymbolsFromWebPage( FD_WebPage *webPage, void *opaqueData )
{
   FD_RetCode retCode;
   unsigned int i;

   FD_TableParseOpaqueData *tableParseInfo;
   FD_StreamAccess *access;

   if( !webPage )
      return FD_BAD_PARAM;

   access = FD_StreamAccessAlloc( webPage->content );
   if( !access )
      return FD_ALLOC_ERR;

   /* Position on the table containing all the symbols. */
   tableParseInfo = (FD_TableParseOpaqueData *)opaqueData;
   switch( tableParseInfo->countryId )
   {
   case FD_Country_ID_US:
   case FD_Country_ID_CA:
      retCode = FD_StreamAccessSearch( access, "value=search" );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamAccessFree( access );
         return retCode;
      }
      break;

   default:
      for( i=0; i < 7; i++ )
      {
         retCode = FD_StreamAccessSkipHTMLTable( access );
         if( retCode != FD_SUCCESS )
         {
            FD_StreamAccessFree( access );
            return retCode;
         }
      }

      for( i=0; i < 2; i++ )
      {
         retCode = FD_StreamAccessSearch( access, "<p>" );
         if( retCode != FD_SUCCESS )
         {
            FD_StreamAccessFree( access );
            return retCode;
         }
      }
      break;
   }

   /* Now parse the symbol table. */
   retCode = FD_StreamAccessGetHTMLTable( access, 100, addTheSymbolFromWebPage, opaqueData );

   FD_StreamAccessFree( access );
   return retCode;
}

static FD_RetCode addTheSymbolFromWebPage( unsigned int line,
                                           unsigned int column,
                                           const char *data,
                                           const char *href,
                                           void *opaqueData)
{
   FD_TableParseOpaqueData *tableParseInfo;
   FD_RetCode retCode;
   FD_String *category;
   FD_String *symbol;
   FD_StringCache *stringCache;
   const char *abbrev;
   int allowOnlineProcessing;

   (void)line; /* Get ride of compiler warning. */
   (void)href;

   if( column == 1 )
   {
      if( data )
      {
         tableParseInfo = (FD_TableParseOpaqueData *)opaqueData;

         /* Convert from Yahoo! classification to the FIDAL classification. */
         category = NULL;
         symbol = NULL;

         /* Go online only when processing US/CA stocks. All other
          * country have extension allowing to identify the
          * exchange so there is no need to do additional online
          * processing to identify the exchange.
          */ 
         switch( tableParseInfo->countryId )
         {
         case FD_Country_ID_US:
         case FD_Country_ID_CA:
            allowOnlineProcessing = 1;
            break;
         default:
            allowOnlineProcessing = 0;
         }

         #if 0

         This optimization has been removed in 0.1.2 because problematic
         with symbols that were changing of category.

         /* When online allowed and the remote index is available,
          * cache the US index to quickly identify the category.          
          * For audit purpose, still go online for randomly selected
          * symbols. We try to not go online for ALL symbols for
          * performance reason.
          */       
         if( allowOnlineProcessing && (tableParseInfo->idx_remote != NULL) && ((rand()%100)>5) )
         {
            retCode = findStringFromCacheUsingYahooName( tableParseInfo->idx_remote,
                                                         data, &category, &symbol );
         }
         else
            retCode = FD_INVALID_SECURITY_SYMBOL;
         
         if( retCode != FD_SUCCESS )
         {
         #endif

         retCode = FD_AllocStringFromYahooName( &defaultMarketDecoding,
                                                data, &category, &symbol,
                                                allowOnlineProcessing );

         if( retCode == FD_OBSOLETED_SYMBOL )
         {
            /* Symbol is obsolete, just ignore it with no fatal error. */
            printf( "Warning: This symbol is no longuer in use [%s]\n", data );
            return FD_SUCCESS;
         }

         if( retCode != FD_SUCCESS )
         {
            /* Just a warning for now... */
            printf( "Warning. Does not recognize exchange for [%s] (%d)\n", data, retCode );
            return FD_SUCCESS;
         }

         stringCache = FD_GetGlobalStringCache();

         /* Add only if of the requested country. */
         abbrev = FD_CountryIdToAbbrev(tableParseInfo->countryId);
         if( strncmp( abbrev, FD_StringToChar(category), 2 ) == 0 )
         {
            printf( "[%s][%s]                              \r",
                    FD_StringToChar(category),
                    FD_StringToChar(symbol) );
            retCode = addYahooSymbol( tableParseInfo->idx, 
                                      category, symbol );
         }

         FD_StringFree( stringCache, category );
         FD_StringFree( stringCache, symbol );

         if( retCode != FD_SUCCESS )
         {
            printf( "Warning: Failed to add symbol [%s]\n", data );
            return retCode;
         }
      }
   }

   return FD_SUCCESS;
}

static FD_RetCode buildIndexFromLocalCache( FD_YahooIdx *idx,
                                            FD_Timestamp *cacheTimeout )
{
   const char *cachePath;
   FD_YahooIdxHidden *idxHidden;
   char *buffer;
   FD_Stream *stream;
   FILE *in;
   FD_RetCode retCode;
   int pathLength;

   idxHidden = (FD_YahooIdxHidden *)idx->hiddenData;

   cachePath = FD_GetLocalCachePath();

   if( !cachePath )
      return FD_YAHOO_IDX_EXPIRED;
   
   /* Open the file */
   pathLength = strlen( cachePath );
   buffer = FD_Malloc( pathLength + 11 );
   if( pathLength )
   {
      sprintf( buffer, "%s%cy_%c%c.dat",
               cachePath,
               FD_SeparatorASCII(),
               tolower(idx->countryAbbrev[0]),
               tolower(idx->countryAbbrev[1]) );
   }
   else
   {
      sprintf( buffer, "y_%c%c.dat",
               tolower(idx->countryAbbrev[0]),
               tolower(idx->countryAbbrev[1]) );
   }

   /* printf( "Trying to open local [%s]\n", buffer ); */

   in = fopen( buffer, "rb" );
   FD_Free(  buffer );
   if( !in )
      return FD_YAHOO_IDX_EXPIRED;

   /* Create a stream from the file. */
   stream = FD_StreamAlloc();
   if( !stream )
      return FD_YAHOO_IDX_EXPIRED;
   retCode = FD_StreamAddFile( stream, in );
   fclose(in);
   if( retCode != FD_SUCCESS )
   {
      FD_StreamFree( stream );
      return FD_YAHOO_IDX_EXPIRED;
   }

   /* Call buildIndexFromStream to build the tables. */
   retCode = buildIndexFromStream( idx, stream, cacheTimeout );
   FD_StreamFree( stream );
   if( retCode != FD_SUCCESS )
      return FD_YAHOO_IDX_EXPIRED;

   /* printf( "Using local cache for [%s]\n", idx->countryAbbrev ); */

   return FD_SUCCESS;
}

#if 0
static FD_RetCode findStringFromCacheUsingYahooName( FD_YahooIdx *idx,
                                                     const char *data,                                           
                                                     FD_String **category,
                                                     FD_String **symbol )
{
    FD_StringCache *stringCache;
    FD_YahooCategory *yahooCategory;
    unsigned int i, j;

    if( !idx || !data || !category || !symbol )
       return FD_BAD_PARAM;
    
    /* Do nothing if the Yahoo! string contains a dot.
     * In that case, there is better way to figure out the
     * category.
     */
    if( strchr( data, '.' ) != NULL )
       return FD_INVALID_SECURITY_SYMBOL;
    
    for( i=0; i < idx->nbCategory; i++ )
    {
       yahooCategory = idx->categories[i];
       for( j=0; j < yahooCategory->nbSymbol; j++ )
       {
          if( strcmp(data, FD_StringToChar(yahooCategory->symbols[j])) == 0 )
          {
             stringCache = FD_GetGlobalStringCache();
             if( !stringCache )
                return FD_INTERNAL_ERROR(140);;

             *category = FD_StringDup( stringCache, yahooCategory->name );
             *symbol   = FD_StringDup( stringCache, yahooCategory->symbols[j] );
             return FD_SUCCESS;
          }
       }
    }

    return FD_INVALID_SECURITY_SYMBOL;
    
}
#endif
