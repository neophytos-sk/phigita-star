/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070701 MF   First version.
 *  061104 MF   Add FD_YAHOO_ONE_SYMBOL.
 *  062104 MF   Server can now be override using the 'location' param.
 */

/* Description:
 *    This is the entry points of the data source driver for
 *    the Yahoo! web site.
 *
 *    It provides ALL the functions needed by the "FD_DataSourceDriver"
 *    structure (see fd_source.h).
 */

/**** Headers ****/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "fd_source.h"
#include "fd_yahoo.h"
#include "fd_common.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_list.h"
#include "fidal.h"
#include "fd_system.h"
#include "fd_yahoo_idx.h"
#include "fd_yahoo_handle.h"
#include "fd_yahoo_priv.h"
#include "fd_global.h"
#include "fd_country_info.h"
#include "sfl.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/

/* String used to specify an alternate "server" in the location parameter. */
#define FD_SERVER_STR "server="

/**** Local functions declarations.    ****/
static FD_RetCode initCategoryHandle( FD_DataSourceHandle *handle,
                                      FD_CategoryHandle   *categoryHandle,
                                      unsigned int index );

static FD_RetCode initSymbolHandle( FD_DataSourceHandle *handle,
                                    FD_CategoryHandle   *categoryHandle,
                                    FD_SymbolHandle     *symbolHandle,
                                    unsigned int index );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_YAHOO_InitializeSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_YAHOO_InitializeSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_YAHOO_ShutdownSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_YAHOO_ShutdownSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_YAHOO_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_YAHOO_GetParameters );

   memset( param, 0, sizeof( FD_DataSourceParameters ) );

   /* Internet access is considered slow. */
   param->flags = FD_SLOW_ACCESS;

   /* Indicate the support for split/value adjustment. */
   param->flags |= FD_DO_NOT_SPLIT_ADJUST;
   param->flags |= FD_DO_NOT_VALUE_ADJUST;

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_YAHOO_OpenSource( const FD_AddDataSourceParamPriv *param,
                                FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_DataSourceHandle *tmpHandle;
   FD_PrivateYahooHandle *privData;
   FD_RetCode retCode;
   FD_StringCache *stringCache;
   FD_CountryId countryId;
   FD_CountryId countryIdTemp;
   FD_Timestamp now;
   const char *locationPtr;
   char locationBuffer[3];
   int timeout_set; /* boolean */
   int i, again;
   unsigned int strLength, strServerLength;
   const char *strTemp;

   *handle = NULL;

   FD_TRACE_BEGIN( FD_YAHOO_OpenSource );

   stringCache = FD_GetGlobalStringCache();

   /* Verify that the requested functionality is supported or not. */
   if( param->flags & FD_REPLACE_ZERO_PRICE_BAR )
   {
      FD_TRACE_RETURN( FD_NOT_SUPPORTED );
   }

   /* Allocate and initialize the handle. This function will also allocate the
    * private handle (opaque data).
    */
   tmpHandle = FD_YAHOO_DataSourceHandleAlloc();

   if( tmpHandle == NULL )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   privData = (FD_PrivateYahooHandle *)(tmpHandle->opaqueData);

   /* Copy some parameters in the private handle. */
   privData->param = param;
   
   /* Indentify the country and replace with the default as needed.
    * At the same time, identify optional "server=" modifier.
    */
   countryId = FD_Country_ID_INVALID;
   if( privData->param->location )
   {
      locationPtr = FD_StringToChar(privData->param->location);

      /* Split into token (seperator is ';'). Check for a 2 character country 
       * string and the optional "server=" modifier.
       */
      i = -1; 
      strTemp = &locationPtr[0];
      strLength = 0;
      strServerLength = strlen(FD_SERVER_STR);
      again = 1;
      while( (++i < 1024) && again )
      {
         if( strLength == 0 )
            strTemp = &locationPtr[i];

         if( locationPtr[i] == '\0' )
            again = 0;         

         if( locationPtr[i] == ';' || !again )
         {
            if( strLength == 2 )
            {
               locationBuffer[0] = locationPtr[i-2];
               locationBuffer[1] = locationPtr[i-1];
               locationBuffer[2] = '\0';
               countryIdTemp = FD_CountryAbbrevToId(locationBuffer);
               if( countryIdTemp == FD_Country_ID_INVALID )
                  FD_TRACE_RETURN( FD_UNSUPPORTED_COUNTRY );
               if( countryId != FD_Country_ID_INVALID )
                  FD_TRACE_RETURN( FD_LIMIT_OF_ONE_COUNTRY_ID_EXCEEDED );
               countryId = countryIdTemp;         
            }
            else if( strLength>strServerLength && (strncmp(strTemp,FD_SERVER_STR,strServerLength)==0) )
            {              
               if( privData->userSpecifiedServer )
                  FD_TRACE_RETURN( FD_LIMIT_OF_ONE_SERVER_EXCEEDED );
               privData->userSpecifiedServer = FD_StringAllocN( stringCache, 
                                                                &strTemp[strServerLength],
                                                                strLength-strServerLength );
               FD_ASSERT( privData->userSpecifiedServer != NULL );
            }
            else
               FD_TRACE_RETURN( FD_LOCATION_PARAM_INVALID );

            strLength = 0;           
         }
         else
            strLength++;
      }
   }

   if( countryId == FD_Country_ID_INVALID )
   {
      /* Default is United States. */
      countryId = FD_Country_ID_US;
   }

   if( privData->param->id == FD_YAHOO_ONE_SYMBOL )
   {
      privData->index = NULL;
      privData->webSiteCountry = countryId;
      privData->webSiteSymbol  = FD_StringDup(stringCache,privData->param->info);
      tmpHandle->nbCategory = 1;
   }
   else
   {
      /* Build the index using .dat files */
      switch( countryId )
      {
      case FD_Country_ID_US: /* United States */
      case FD_Country_ID_CA: /* Canada */
      case FD_Country_ID_UK: /* United Kingdom */
      case FD_Country_ID_DE: /* Germany */
      case FD_Country_ID_DK: /* Denmark */
      case FD_Country_ID_ES: /* Spain */
      case FD_Country_ID_FR: /* France */
      case FD_Country_ID_IT: /* Italy */
      case FD_Country_ID_SE: /* Sweden */
      case FD_Country_ID_NO: /* Norway */
         /* These country are currently supported. */
         break;
      default:
         FD_YAHOO_DataSourceHandleFree( tmpHandle );
         FD_TRACE_RETURN( FD_UNSUPPORTED_COUNTRY );
      }

      /* Establish the timeout for local cache of the index.
       * Let's make it 4 business days.
       */
      timeout_set = 0;
      FD_SetDefault( &now );
      retCode = FD_SetDateNow( &now );
      for( i=0; (i < 4) && (retCode == FD_SUCCESS); i++ )
         retCode = FD_PrevWeekday( &now );
      if( (i == 4) && (retCode == FD_SUCCESS) )
         timeout_set = 1;
      
      /* At this point, we got all the information we
       * need in the handle.
       * Now build the FD_YahooIdx.
       */
      retCode = FD_YahooIdxAlloc( countryId,
                                  &privData->index,
                                  FD_USE_LOCAL_CACHE|FD_USE_REMOTE_CACHE,
                                  NULL, timeout_set?&now:NULL, NULL );

      if( retCode != FD_SUCCESS )
      {
         FD_YAHOO_DataSourceHandleFree( tmpHandle );
         FD_TRACE_RETURN( retCode );
      }

      /* Set the total number of distinct category. */
      tmpHandle->nbCategory = privData->index->nbCategory;
   }

   *handle = tmpHandle;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_YAHOO_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_YAHOO_CloseSource );

   /* Free all ressource used by this handle. */
   if( handle )
      FD_YAHOO_DataSourceHandleFree( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_YAHOO_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                            FD_CategoryHandle   *categoryHandle )
{
   FD_PrivateYahooHandle *privData;

   privData = (FD_PrivateYahooHandle *)(handle->opaqueData);

   if( privData->param->id == FD_YAHOO_ONE_SYMBOL )
   {
      categoryHandle->nbSymbol = 1;
      categoryHandle->string = privData->param->category;
      return FD_SUCCESS;
   }

   return initCategoryHandle( handle, categoryHandle, 0 );
}

FD_RetCode FD_YAHOO_GetNextCategoryHandle( FD_DataSourceHandle *handle,
                                           FD_CategoryHandle   *categoryHandle,
                                           unsigned int index )
{
   FD_PrivateYahooHandle *privData;
   privData = (FD_PrivateYahooHandle *)(handle->opaqueData);

   if( privData->param->id == FD_YAHOO_ONE_SYMBOL )
      return FD_END_OF_INDEX;

   return initCategoryHandle( handle, categoryHandle, index );                              
}

FD_RetCode FD_YAHOO_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle,
                                          FD_SymbolHandle     *symbolHandle )
{
   FD_PrivateYahooHandle *privData;
   FD_String *symbol;
   FD_String *info;

   privData = (FD_PrivateYahooHandle *)(handle->opaqueData);

   if( privData->param->id == FD_YAHOO_ONE_SYMBOL )
   {
      info = privData->param->info;
      symbol = privData->param->symbol;
      if( !symbol )      
         symbol = info;
      symbolHandle->string = symbol;
      return FD_SUCCESS;
   }

   return initSymbolHandle( handle, categoryHandle, symbolHandle, 0 );
}


FD_RetCode FD_YAHOO_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                         FD_CategoryHandle   *categoryHandle,
                                         FD_SymbolHandle     *symbolHandle,
                                         unsigned int index )
{
    FD_PrivateYahooHandle *privData;
    privData = (FD_PrivateYahooHandle *)(handle->opaqueData);

    if( privData->param->id == FD_YAHOO_ONE_SYMBOL )
       return FD_END_OF_INDEX;

    return initSymbolHandle( handle, categoryHandle,                             
                             symbolHandle, index );
                             
}

FD_RetCode FD_YAHOO_GetHistoryData( FD_DataSourceHandle *handle,
                                    FD_CategoryHandle   *categoryHandle,
                                    FD_SymbolHandle     *symbolHandle,
                                    FD_Period            period,
                                    const FD_Timestamp  *start,
                                    const FD_Timestamp  *end,
                                    FD_Field             fieldToAlloc,
                                    FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_RetCode tempRetCode, retCode;
   FD_PrivateYahooHandle *yahooHandle;
   int again, j;

   FD_TRACE_BEGIN( FD_YAHOO_GetHistoryData );

   FD_ASSERT( handle != NULL );
   FD_ASSERT( paramForAddData != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   yahooHandle = (FD_PrivateYahooHandle *)handle->opaqueData;
   FD_ASSERT( yahooHandle != NULL );

   /* If the requested period is too precise for the
    * period that can be provided by this data source,
    * simply return without error.
    * Since no data has been added, the FIDAL will ignore
    * this data source.
    */
   if( period < FD_DAILY )
   {
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   /* Get the data from the WEB.
    *
    * Yahoo! sometimes have "gaps" in its data (like one
    * week missing), when this is being detected, we throw
    * away all the data up to now and start over (up to
    * 5 times before giving up).
    */
   again = 5;
   do
   {
      retCode = FD_GetHistoryDataFromWeb( handle,                                       
                                          categoryHandle, symbolHandle,
                                          FD_DAILY, start, end,                                            
                                          fieldToAlloc, paramForAddData );
      if( retCode == FD_DATA_GAP )
      {
         retCode = FD_HistoryAddDataReset( paramForAddData );
         if( retCode != FD_SUCCESS )
            again = 0; /* Give up */
         else
         {
            --again; /* Try again */

            /* Sometimes giving Yahoo! a break helps. */
            tempRetCode = FD_DriverShouldContinue(paramForAddData);
            j = 0;
            while( (j++ < 5) && (tempRetCode != FD_DAFD_RETREIVE_TIMEOUT) )
            {
               FD_Sleep(1);
               tempRetCode = FD_DriverShouldContinue(paramForAddData);
            }
            if( tempRetCode == FD_DAFD_RETREIVE_TIMEOUT )
            {
               retCode = tempRetCode;
               again = 0;            
            }
         }
      }
      else
      {
         again = 0; /* Exit the loop */
      }
   } while( again > 0 );


   FD_TRACE_RETURN( retCode );   
}

/**** Local functions definitions.     ****/
static FD_RetCode initCategoryHandle( FD_DataSourceHandle *handle,
                                      FD_CategoryHandle   *categoryHandle,
                                      unsigned int index )
{
   FD_PROLOG
   FD_PrivateYahooHandle *privData;
   FD_YahooIdx *yahooIndex;
   FD_String   *string;

   FD_TRACE_BEGIN( FD_YAHOO_GetFirstCategoryHandle );

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateYahooHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(99) );
   }

   yahooIndex = privData->index;

   if( !yahooIndex )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(100) );
   }

   if( index >= yahooIndex->nbCategory )
      return FD_END_OF_INDEX;

   string = yahooIndex->categories[index]->name;

   if( !string )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(101) ); /* At least one category must exist. */
   }

   /* Set the categoryHandle. */
   categoryHandle->string = string;
   categoryHandle->nbSymbol = yahooIndex->categories[index]->nbSymbol;
   categoryHandle->opaqueData = yahooIndex->categories[index];

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode initSymbolHandle( FD_DataSourceHandle *handle,
                                    FD_CategoryHandle   *categoryHandle,
                                    FD_SymbolHandle     *symbolHandle,
                                    unsigned int index )
{
   FD_PROLOG
   FD_YahooCategory *category;

   FD_TRACE_BEGIN( FD_YAHOO_GetFirstSymbolHandle );

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   category = (FD_YahooCategory *)categoryHandle->opaqueData;

   if( index >= category->nbSymbol )
      return FD_END_OF_INDEX;

   /* Set the symbolHandle. */
   symbolHandle->string = category->symbols[index];
   symbolHandle->opaqueData = NULL;

   FD_TRACE_RETURN( FD_SUCCESS );
}
