#ifndef FD_YAHOO_PRIV_H
#define FD_YAHOO_PRIV_H

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_COUNTRY_INFO_H
   #include "fd_country_info.h"
#endif

#ifndef FD_NETWORK_H
   #include "fd_network.h"
#endif

#ifndef FD_GLOBAL_H
   #include "fd_global.h"
#endif

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

/* There is an attempts to make the decoding
 * a little more solid against change to
 * the format of the page providing the data.
 *
 * Some parametric information is stored in 
 * the index. Assuming the user is using an index
 * created with the latest software (like when read
 * from fidalsoft.org, the user may be able to continue
 * to interpret the web page without updating its
 * software.
 *
 * Example: If Yahoo! decide to change the URL to access
 *          the data, 'webSiteServer' can reflect the
 *          change.
 */
typedef enum
{
  FD_NO_FLAG = 0x00
} FD_DecodeFlag;

typedef struct
{
   const char *webSiteServer;
   const char *uirPrefix;
   const char *uirSuffix;
   FD_DecodeFlag  flags;

   unsigned char  param8_1;
   unsigned char  param8_2;
   unsigned char  param8_3;
   unsigned char  param8_4;

   unsigned int param16_1; /* Only first 16 bits used. */
   unsigned int param16_2; /* Only first 16 bits used. */
} FD_DecodingParam;

typedef struct
{
   /* Basic parameters for extracting historical data. */
   FD_DecodingParam *historical;

   /* Basic parameters for extracting current market data. */
   FD_DecodingParam *market;

   /* Basic parameters for extracting security info. */
   FD_DecodingParam *info;

   /* Basic parameters for extracting adjustment info */
   FD_DecodingParam *adjustment;
} FD_YahooDecodingParam;

/* Reflect the information that can be extracted from the
 * Quote page from Yahoo.
 * Contains mainly the Market data + some.
 *
 * This function is in "fd_yahoo_market.c"
 */
typedef struct
{
   unsigned int magicNb;

   FD_Real lastTrade;
   FD_Real bid;
   FD_Real ask;

   FD_Real open;
   FD_Real dayLow;
   FD_Real dayHigh;

   FD_Real previousClose; 

   FD_Integer volume;

   FD_String *name; /* Company name (long version). */
   FD_CountryId countryId;
   const char *exchange;
   const char *type;
} FD_YahooMarketPage;

FD_RetCode FD_YahooMarketPageAlloc( const FD_DecodingParam *marketDecodingParam,
                                    const FD_String *categoryName,
                                    const FD_String *symbolName,
                                    const char *overideServerAddr,
                                    FD_YahooMarketPage **allocatedMarketPage );

FD_RetCode FD_YahooMarketPageFree( FD_YahooMarketPage *quotePage );

/* Allocate strings used by FIDAL to classify each stock.
 *
 * On success, both strings must be freed with FD_StringFree.
 * On failure, no string are allocated.
 *
 * When the Yahoo! symbol is a known extension, this call
 * is quite fast, but in the case that there is no extension
 * further online investigation is required (fetching of webPage).
 *
 * Because this online investigation can be quite costly,
 * in terms of time, the parameter allowOnlineProcessing
 * must be true for allowing such investigation. 
 *
 * In practice, only US symbols needs further investigation
 * because many do not have an extension (by default I guess).
 *
 * On success, the allocated strings must be eventually freed
 * with FD_StringFree.
 *
 * These allocated strings are the one that must be used
 * when calling FD_YahooQuotePageAlloc.
 *
 * Example 1:
 *     if yahooSymbolString is "NT.TO", the allocated strings
 *     will be:
 *           *allocatedCategoryName = "CAN.TSE.STOCK"
 *           *allocatedSymbolName   = "NT"
 *
 *     CAN is the official abbreviation for Canada.
 *     TSE is the official abbreviation for the Toronto Stock Exchange.
 *     STOCK is the security type.
 *     NT  is the symbol representing Nortel.
 *
 *     More information on how categoy works can be found
 *     in the "Category Guideline" document.
 *
 * See "fd_yahoo_market.c"
 */
FD_RetCode FD_AllocStringFromYahooName( FD_DecodingParam *info,
                                        const char *yahooSymbol,
                                        FD_String **allocatedCategoryName,
                                        FD_String **allocatedSymbolName,
                                        unsigned int allowOnlineProcessing );


/* Providing a Category and Symbol name, the Yahoo! Symbol is rebuild. 
 * FD_AllocStringFromLibName() is the complement of the function 
 * FD_AllocStringFromYahooName(). Rebuilding from the FIDAL Name is
 * speed efficient.
 *
 * See "fd_yahoo_market.c"
 */
FD_RetCode FD_AllocStringFromLibName( const FD_String *category,
                                      const FD_String *symbol,
                                      FD_String **allocatedYahooName );

/* Retreive a web page corresponding to the provided symbol.
 *
 * See "fd_yahoo_market.c"
 */
FD_RetCode FD_WebPageAllocFromYahooName( const FD_DecodingParam *info,
                                         const char *yahooName,
                                         const char *overideServerAddr,
                                         FD_WebPage **allocatedWebPage,
                                         FD_ParamForAddData *paramForAddData );


/* Retreive the historical data corresponding to a 
 * categoryHandle, symbolHandle.
 * This is the functions that return back the data
 * to FD_LIB by calling FD_HistoryAddData.
 *
 * See "fd_yahoo_historical.c"
 */
FD_RetCode FD_GetHistoryDataFromWeb( FD_DataSourceHandle *handle,
                                     FD_CategoryHandle   *categoryHandle,
                                     FD_SymbolHandle     *symbolHandle,
                                     FD_Period            period,
                                     const FD_Timestamp  *start,
                                     const FD_Timestamp  *end,
                                     FD_Field             fieldToAlloc,
                                     FD_ParamForAddData  *paramForAddData );

/* Table of Hard coded indices for Yahoo! 
 * The table allows to translate from FIDAL category/symbol to the
 * strng used by Yahoo! (and vice versa).
 */
typedef struct
{
   FD_CountryId countryId;
   const char *symbolYahoo;
   const char *symbolLib;
   const char *categoryLib;
} FD_HardCodedIndice;

extern FD_HardCodedIndice hardCodedIndice[];
extern const unsigned int hardCodedIndiceSize;

/* Facilitate specification of URL to access Yahoo! web sites. */
typedef struct 
{
   FD_CountryId countryId;
   const char *dataServer;
   const char *dataPrefix;
   const char *dataSuffix;

   const char *adjustmentServer;
   const char *adjustmentPrefix;
   const char *adjustmentSuffix;
} FD_DirectYahooDecoding;

extern FD_DirectYahooDecoding tableDirectYahooDecoding[];

extern unsigned int tableDirectYahooDecodingSize;

#endif
