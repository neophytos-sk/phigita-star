/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  MS       Marcel Schaible <marcel@schaible-consulting.de>
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  010503 MF   Fix #644512. Problem with [-I] submitted by MS.
 *  040304 MF   Add support for FD_TOK_SKIP_NON_DIGIT_LINE
 */

/* Description:
 *    Allows to allocate/de-allocate FD_DataSourceHandle structure.
 */

/**** Headers ****/
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_fileindex.h"
#include "fd_token.h"
#include "fd_global.h"
#include "fd_readop.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/
static FD_RetCode findTokenId( const char *str,
                               FD_TokenId *id,
                               FD_Integer *optionalParam );

static FD_RetCode buildReadOp( FD_ReadOpInfo *readOpInfo,
                               const char *localBuf,
                               FD_ReadOp *readOp,
                               FD_TokenId *tokenId,
                               unsigned int *intraDayIncrementInSecond );

static FD_RetCode findTokenIdWithParam( const char *str,
                                        FD_TokenId *tokenId,
                                        unsigned int *extractedParam );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

FD_RetCode FD_ReadOpInfoFree( FD_ReadOpInfo *readOpInfoToBeFreed )
{
   if( readOpInfoToBeFreed )
   {
      if( readOpInfoToBeFreed->arrayReadOp )
         FD_Free( readOpInfoToBeFreed->arrayReadOp );

      FD_Free( readOpInfoToBeFreed );
   }

   return FD_SUCCESS;
}

FD_RetCode FD_ReadOpInfoAlloc( const char *sourceInfo,
                               FD_ReadOpInfo **allocatedInfo,
                               unsigned int readOpFlags )
{
   FD_PROLOG
   FD_RetCode retCode;

   FD_ReadOp readOp;
   FD_ReadOp *arrayReadOp;
   FD_ReadOpInfo *newReadOpInfo;
   FD_Field fieldMask, fieldProvided;
   unsigned int timeframeIdx;
   unsigned int intraDayIncPeriod;
   FD_TokenId   intraDayIncToken;
   FD_TokenId   tempToken;
   unsigned int tempInt;
   unsigned int period;
   unsigned int errorOccurred;

   const char *pos;
   unsigned int inField;
   unsigned int nbField;
   unsigned int nbCharInField;
   unsigned int skipNonDigitLine;
   const char *ptrFirstCarInField;

   unsigned char localBuf[10];
   unsigned int bufIdx, opIdx, i;

   register unsigned int flagSet;
   register FD_ReadOp *ptrReadOp;
   
   FD_TRACE_BEGIN(  FD_BuildArrayReadOp );

   newReadOpInfo = (FD_ReadOpInfo *)FD_Malloc( sizeof( FD_ReadOpInfo ) );

   /* These variables are resolved within this function. */
   memset( newReadOpInfo, 0, sizeof( FD_ReadOpInfo ) );

   /* At this point, FD_ReadOpInfoFree can be safely called. */

   /* Keep track of some user provided parameter. */
   newReadOpInfo->sourceInfo = sourceInfo;
   newReadOpInfo->readOpFlags = readOpFlags;

   /* Initialize some defaults. */
   newReadOpInfo->openInterestMult = 100;
   newReadOpInfo->volumeMult       = 100;

   nbField = 0;
   intraDayIncPeriod = 0;
   intraDayIncToken = FD_TOK_END;

   pos = newReadOpInfo->sourceInfo;
   if( !pos || (*pos == '\0') )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_MISSING_FIELD );
   }

   /* Find how many fields are defined and check some syntax
    * at the same time.
    */
   if( *pos != '[' )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_INVALID_FIELD );
   }

   inField = 0;
   nbCharInField = 0;
   skipNonDigitLine = 0;
   ptrFirstCarInField = NULL;
   while( *pos != '\0' )
   {
      switch( *pos )
      {
      case '[':
         if( inField )
         {
            FD_ReadOpInfoFree( newReadOpInfo );
            FD_TRACE_RETURN( FD_INVALID_FIELD );
         }
         inField = 1;
         break;
      case ']':
         if( (!inField) || (nbCharInField == 0) )
         {
            FD_ReadOpInfoFree( newReadOpInfo );
            FD_TRACE_RETURN( FD_INVALID_FIELD );
         }

         nbField++;

         /* Exclude fields not generating a FD_ReadOp.
          * For the time being that means only the -H and -NDL field.
          */
         if( nbCharInField >= 2 )
         {
            FD_ASSERT( ptrFirstCarInField != NULL );
            if( ptrFirstCarInField[0] == '-' ) 
            {
               if( toupper(ptrFirstCarInField[1]) == 'H' )
                  nbField--;
               else if( (toupper(ptrFirstCarInField[1]) == 'N') &&
                        (toupper(ptrFirstCarInField[2]) == 'D') &&
                        (toupper(ptrFirstCarInField[3]) == 'L') )
               {
                  skipNonDigitLine = 1;
                  nbField--;
               }               
             }
         }

         inField = 0;
         nbCharInField = 0;
         ptrFirstCarInField = NULL;
         break;
      default:
         if( !inField )
         {
            FD_ReadOpInfoFree( newReadOpInfo );
            FD_TRACE_RETURN( FD_INVALID_FIELD );
         }

         if( nbCharInField == 0 )
            ptrFirstCarInField = pos;
         nbCharInField++;
         break;
      }

      pos++;
   }

   if( inField || *(pos-1) != ']' )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_INVALID_FIELD );
   }

   /* Build the FD_ReadOp array */
   arrayReadOp = (FD_ReadOp *)FD_Malloc( sizeof( FD_ReadOp ) * nbField );

   if( !arrayReadOp )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   newReadOpInfo->arrayReadOp = arrayReadOp;

   pos = FD_StringToChar(newReadOpInfo->sourceInfo);

   bufIdx = 0;
   opIdx = 0;
   while( *pos != '\0' && (opIdx < nbField) )
   {
      switch( *pos )
      {
      case '[':
        break;

      case ']':
        localBuf[bufIdx] ='\0';
        bufIdx = 0;

        /* Identify the field and build the FD_ReadOp. */
        tempInt = 0;
        retCode = buildReadOp( newReadOpInfo,
                               (const char *)&localBuf[0],
                               &arrayReadOp[opIdx],
                               &tempToken, &tempInt );
        if( retCode != FD_SUCCESS )
        {
           FD_ReadOpInfoFree( newReadOpInfo );
           FD_TRACE_RETURN( retCode );
        }

        if( arrayReadOp[opIdx] != 0 )
        {
           /* Set the replace zero flag as needed */
           if( FD_IS_REPLACE_ZERO(readOpFlags) && FD_IS_REAL_CMD(arrayReadOp[opIdx]) )
           {
              FD_SET_REPLACE_ZERO(arrayReadOp[opIdx]);
           }

           /* Set the skipNonDigitLine flag as needed. */
           if( skipNonDigitLine == 1 )
           {
              FD_SET_SKIP_NDL_FLAG(arrayReadOp[opIdx]);
           }

           /* Ooof... this readOp is now all build! */
           opIdx++;
        }

        /* If this is a time token, make sure this
         * is not in contradiction with an already
         * specified increment.
         */
        if( intraDayIncPeriod )
        {
           errorOccurred = 0;
           switch( tempToken )
           {
           case FD_TOK_SEC:
           case FD_TOK_SS:
              if( (intraDayIncToken == FD_TOK_MIN) ||
                  (intraDayIncToken == FD_TOK_MN) )
                 errorOccurred = 1;
              /* no break */
           case FD_TOK_MIN:
           case FD_TOK_MN:
              if( (intraDayIncToken == FD_TOK_HOUR) ||
                  (intraDayIncToken == FD_TOK_HH) )
                 errorOccurred = 1;
              break;
           case FD_TOK_HOUR:
           case FD_TOK_HH:
              errorOccurred = 1;
              break;
           default:
              /* Do nothing */
              break;
           }

           if( errorOccurred )
           {
              FD_ReadOpInfoFree( newReadOpInfo );
              FD_TRACE_RETURN( FD_INVALID_FIELD );
           }
        }

        /* Check if a period increment is specified. */
        if( (tempInt != 0) && (tempInt != 1) )
        {
           if( intraDayIncPeriod != 0 )
           {
              FD_ReadOpInfoFree( newReadOpInfo );
              FD_TRACE_RETURN( FD_INVALID_FIELD );
           }

           intraDayIncPeriod = tempInt;
           intraDayIncToken  = tempToken;
        }
        break;

      default:
        if( bufIdx >= sizeof(localBuf)-1 )
        {
           FD_ReadOpInfoFree( newReadOpInfo );
           FD_TRACE_RETURN( FD_INVALID_FIELD );
        }

        localBuf[bufIdx++] = *pos;
        break;
      }

      pos++;
   }

   if( opIdx != nbField )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(89) );
   }

   arrayReadOp[opIdx-1] |= FD_CMD_LAST_FLAG;

   /* Build the mask representing the fields provided. */
   fieldProvided = 0;
   timeframeIdx = FD_INTEGER_ARRAY_SIZE;

   for( opIdx=0; opIdx < nbField; opIdx++ )
   {
      readOp = arrayReadOp[opIdx];

      FD_ASSERT( readOp != 0 ); /* Parano test */

      if( !FD_IS_PERMANENT_SKIP_SET(readOp) )
      {
         /* Make sure this field was not specified twice. */
         for( i=opIdx+1; i < nbField; i++ )
         {
            if( (FD_IS_REAL_CMD(readOp) && FD_IS_REAL_CMD(arrayReadOp[i])) ||
                (FD_IS_INTEGER_CMD(readOp) && FD_IS_INTEGER_CMD(arrayReadOp[i])) )
            {
               if( (FD_GET_IDX(readOp) == FD_GET_IDX(arrayReadOp[i])) &&
                   !FD_IS_PERMANENT_SKIP_SET(arrayReadOp[i]) )
               {
                  FD_ReadOpInfoFree( newReadOpInfo );
                  FD_TRACE_RETURN( FD_REDUNDANT_FIELD );
               }
            }
         }

         /* Parano test: Double-check redundant field in a different way. */
         fieldMask = FD_ReadOpToField( readOp );
         FD_ASSERT( fieldMask != 0 );
         if( !(fieldMask & FD_FIELD_TIMESTAMP) && (fieldProvided & fieldMask) )
         {
            FD_ReadOpInfoFree( newReadOpInfo );
            FD_TRACE_RETURN( FD_REDUNDANT_FIELD );
         }

         /* Set the field. */
         fieldProvided |= fieldMask;

         /* Keep track of the smallest granularity of the timestamp. */
         if( fieldMask & FD_FIELD_TIMESTAMP )
         {
            if( (timeframeIdx == FD_INTEGER_ARRAY_SIZE) ||
                (FD_GET_IDX(readOp) < timeframeIdx) )
               timeframeIdx = FD_GET_IDX(readOp);
         }
      }
   }


   /* No date/time reference provided!? This is considered an error
    * in the current implementation.
    */
   if( timeframeIdx == FD_INTEGER_ARRAY_SIZE )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_MISSING_DATE_OR_TIME_FIELD );
   }

   /* Determine at which point the timestamp is completed. */
   flagSet = 0;
   for( opIdx=nbField; opIdx > 0; opIdx-- )
   {
      ptrReadOp = &arrayReadOp[opIdx-1];
      readOp = *ptrReadOp;

      if( !flagSet                          && 
          FD_IS_INTEGER_CMD(readOp)         && 
          (FD_GET_IDX(readOp)<=FD_YEAR_IDX) && 
          !FD_IS_PERMANENT_SKIP_SET(readOp) )
      {
         FD_SET_TIMESTAMP_COMPLETE(*ptrReadOp);
         flagSet = 1;
      }
      else
      {
         FD_CLR_TIMESTAMP_COMPLETE(*ptrReadOp);
      }
   }

   /* Validate and identify the period. */
   period = 0;
   if( intraDayIncPeriod )
   {
      errorOccurred = 0;
      switch( timeframeIdx )
      {
      case FD_YEAR_IDX:
      case FD_MONTH_IDX:
      case FD_DAY_IDX:
         errorOccurred = 1;
         break;
      case FD_HOUR_IDX:
         if( (intraDayIncPeriod < FD_1HOUR) || (intraDayIncPeriod >= FD_DAILY) )
            errorOccurred = 1;
         break;
      case FD_MIN_IDX:
         if( (intraDayIncPeriod < FD_1MIN) || (intraDayIncPeriod >= FD_1HOUR) )
            errorOccurred = 1;
         break;
      case FD_SEC_IDX:
         if( (intraDayIncPeriod < FD_1SEC) || (intraDayIncPeriod >= FD_1MIN) )
            errorOccurred = 1;
         break;
      default:
         FD_ReadOpInfoFree( newReadOpInfo );
         FD_FATAL(  NULL, timeframeIdx, fieldProvided );
      }

      if( errorOccurred )
      {
         FD_ReadOpInfoFree( newReadOpInfo );
         FD_TRACE_RETURN( FD_INVALID_FIELD );
      }
            
      period = intraDayIncPeriod;
   }
   else
   {
      switch( timeframeIdx )
      {
      case FD_YEAR_IDX:
         period = FD_YEARLY;
         break;
      case FD_MONTH_IDX:
         period = FD_MONTHLY;
         break;
      case FD_DAY_IDX:
         period = FD_DAILY;
         break;
      case FD_HOUR_IDX:
         period = FD_1HOUR;
         break;
      case FD_MIN_IDX:
         period = FD_1MIN;
         break;
      case FD_SEC_IDX:
         period = FD_1SEC;
         break;
      default:
         FD_FATAL(  NULL, timeframeIdx, fieldProvided );
      }
   }

   /* A last check... */
   if( period == 0 )
   {
      FD_ReadOpInfoFree( newReadOpInfo );
      FD_TRACE_RETURN( FD_INVALID_FIELD );
   }
         
   /* Everything is fine, let's return the information. */
   newReadOpInfo->arrayReadOp = arrayReadOp;
   newReadOpInfo->fieldProvided = fieldProvided;
   newReadOpInfo->nbReadOp = nbField;
   newReadOpInfo->period = period;

   *allocatedInfo = newReadOpInfo;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ReadOpInfoClone( FD_ReadOpInfo **allocatedInfo, FD_ReadOpInfo *src )
{
   /* Could be speed optimized, keep it simple for now. */
   return FD_ReadOpInfoAlloc( src->sourceInfo,
                              allocatedInfo,
                              src->readOpFlags );
   
}

unsigned int FD_ReadOpToField( FD_ReadOp readOp )
{
  if( FD_IS_REAL_CMD(readOp) )
  {
     switch( FD_GET_IDX(readOp) )
     {
     case FD_FIELD_CLOSE_IDX:
        return FD_FIELD_CLOSE;
     case FD_FIELD_OPEN_IDX:
        return FD_FIELD_OPEN;
     case FD_FIELD_HIGH_IDX:
        return FD_FIELD_HIGH;
     case FD_FIELD_LOW_IDX:
        return FD_FIELD_LOW;
     }
  }
  else if( FD_IS_INTEGER_CMD(readOp) )
  {
     switch( FD_GET_IDX(readOp) )
     {
     case FD_FIELD_VOLUME_IDX:
        return FD_FIELD_VOLUME;
     case FD_FIELD_OPENINTEREST_IDX:
        return FD_FIELD_OPENINTEREST;
     default:
        return FD_FIELD_TIMESTAMP;
     }
  }

  FD_FATAL_RET( NULL, readOp, 0, FD_FIELD_ALL );

  /* Unreachable code:
   * return FD_FIELD_ALL;
   */
}

/**** Local functions definitions.     ****/

static FD_RetCode buildReadOp( FD_ReadOpInfo *readOpInfo,
                               const char *localBuf,
                               FD_ReadOp *readOp,
                               FD_TokenId *tokenId,
                               unsigned int *intraDayIncrementInSeconds )
{
   FD_PROLOG
   FD_TokenId id;
   FD_ReadOp tmpReadOp;
   FD_RetCode retCode;
   FD_Integer optionalParam;
   unsigned int mult, intraDayIncrement;

   FD_TRACE_BEGIN(  buildReadOp );

   if( !readOp || !intraDayIncrementInSeconds || !tokenId )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(9) );
   }

   *intraDayIncrementInSeconds = 0;
   *readOp = 0;
   *tokenId = 0;

   retCode = findTokenId( localBuf, &id, &optionalParam );

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( id != FD_TOK_END );

   /* Trap special token not generating a FD_ReadOp. */
   if( id == FD_TOK_SKIP_N_HEADER_LINE )
   {
      if( optionalParam == 0 )
      {
         FD_TRACE_RETURN( FD_INVALID_FIELD );
      }
      readOpInfo->nbHeaderLineToSkip = optionalParam;
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   if( id == FD_TOK_SKIP_NON_DIGIT_LINE )
   {
      if( optionalParam != 1 )
      {
         FD_TRACE_RETURN( FD_INVALID_FIELD );
      }
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   /* Integer or Real operation? */
   switch( id )
   {
   case FD_TOK_OPEN:
   case FD_TOK_HIGH:
   case FD_TOK_LOW:
   case FD_TOK_CLOSE:
   case FD_TOK_SKIP_N_REAL:
      tmpReadOp = FD_CMD_READ_REAL;
      break;
   case FD_TOK_YYYY:
   case FD_TOK_YY:
   case FD_TOK_Y:
   case FD_TOK_M:
   case FD_TOK_MM:
   case FD_TOK_MMM:
   case FD_TOK_D:
   case FD_TOK_DD:
   case FD_TOK_VOLUME:
   case FD_TOK_OPENINTEREST:
   case FD_TOK_HOUR:
   case FD_TOK_MIN:
   case FD_TOK_SEC:
   case FD_TOK_HH:
   case FD_TOK_MN:
   case FD_TOK_SS:
   case FD_TOK_SKIP_N_INTEGER:
      tmpReadOp = FD_CMD_READ_INTEGER;
      break;
   case FD_TOK_SKIP_N_CHAR:
   case FD_TOK_SKIP_NON_DIGIT_LINE:
      tmpReadOp = 0;
      break;
   default:
      FD_TRACE_RETURN( FD_INVALID_FIELD );
   }

   /* Is this a permanent skip operation? */
   switch( id )
   {
   case FD_TOK_SKIP_N_CHAR:
   case FD_TOK_SKIP_N_INTEGER:
   case FD_TOK_SKIP_N_REAL:
      FD_SET_PERMANENT_SKIP_FLAG( tmpReadOp );
      FD_SET_SKIP_FLAG( tmpReadOp );
      break;
   default:
      FD_CLR_PERMANENT_SKIP_FLAG( tmpReadOp );
      FD_CLR_SKIP_FLAG( tmpReadOp );
   }

   /* Set the "numeric" parameter */
   switch( id )
   {
   case FD_TOK_SKIP_N_INTEGER:
   case FD_TOK_SKIP_N_REAL:
   case FD_TOK_SKIP_N_CHAR:
      FD_SET_NB_NUMERIC( tmpReadOp, optionalParam );
      break;
   case FD_TOK_OPENINTEREST:
      readOpInfo->openInterestMult = optionalParam;
      FD_SET_NB_NUMERIC( tmpReadOp, 0 );
      break;
   case FD_TOK_VOLUME:
      readOpInfo->volumeMult = optionalParam;
      FD_SET_NB_NUMERIC( tmpReadOp, 0 );
      break;
   default:
      FD_SET_NB_NUMERIC( tmpReadOp, FD_TokenMaxSize(id) );
      break;
   }

   /* Set the index information. */
   switch( id )
   {
   case FD_TOK_YYYY:
   case FD_TOK_YY:
   case FD_TOK_Y:
      FD_SET_IDX( tmpReadOp, FD_YEAR_IDX );
      break;
   case FD_TOK_M:
   case FD_TOK_MM:
   case FD_TOK_MMM:
      FD_SET_IDX( tmpReadOp, FD_MONTH_IDX );
      break;
   case FD_TOK_D:
   case FD_TOK_DD:
      FD_SET_IDX( tmpReadOp, FD_DAY_IDX );
      break;
   case FD_TOK_OPEN:
      FD_SET_IDX( tmpReadOp, FD_FIELD_OPEN_IDX );
      break;
   case FD_TOK_HIGH:
      FD_SET_IDX( tmpReadOp, FD_FIELD_HIGH_IDX );
      break;
   case FD_TOK_LOW:
      FD_SET_IDX( tmpReadOp, FD_FIELD_LOW_IDX );
      break;
   case FD_TOK_CLOSE:
      FD_SET_IDX( tmpReadOp, FD_FIELD_CLOSE_IDX );
      break;
   case FD_TOK_VOLUME:
      FD_SET_IDX( tmpReadOp, FD_FIELD_VOLUME_IDX );
      break;
   case FD_TOK_OPENINTEREST:
      FD_SET_IDX( tmpReadOp, FD_FIELD_OPENINTEREST_IDX );
      break;
   case FD_TOK_HOUR:
   case FD_TOK_HH:
      FD_SET_IDX( tmpReadOp, FD_HOUR_IDX );
      break;
   case FD_TOK_MIN:
   case FD_TOK_MN:
      FD_SET_IDX( tmpReadOp, FD_MIN_IDX );
      break;
   case FD_TOK_SEC:
   case FD_TOK_SS:
      FD_SET_IDX( tmpReadOp, FD_SEC_IDX );
      break;
   default:
      /* Do nothing. */
      break;
   }

   /* Set a special flag for the FD_TOK_MMM because
    * it must do chat to integer processing.
    */
   if( id == FD_TOK_MMM )
      tmpReadOp |= FD_CMD_READ_MONTH_CHAR;

   /* Identify the time increments. */
   mult = 1;
   intraDayIncrement = 0;

   switch( id )
   {
   case FD_TOK_HOUR:
   case FD_TOK_HH:
      mult *= 60;
   case FD_TOK_MIN:
   case FD_TOK_MN:
      mult *= 60;
   case FD_TOK_SEC:
   case FD_TOK_SS:
      if( optionalParam < 1 )
      {
         /* Shall be at least '1'... */
         FD_TRACE_RETURN( FD_INVALID_FIELD );
      }
      else if( optionalParam > 1 )
      {
         /* When the default '1' is specified, do
          * not return the increment to the caller.
          */
         intraDayIncrement = optionalParam * mult;
      }
      break;
   default:
      /* Do nothing */
      break;
   }

   /* Everything is fine, return the info to the caller. */
   *readOp = tmpReadOp;
   *intraDayIncrementInSeconds = intraDayIncrement;
   *tokenId = id;

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode findTokenId( const char *str,
                               FD_TokenId *id,
                               FD_Integer *optionalParam )
{
   FD_PROLOG
   unsigned int i;
   const char *cmp_str;
   FD_TokenId tokenId;
   unsigned int extractedParam;
   FD_RetCode retCode;

   FD_TRACE_BEGIN(  findTokenId );

   *id = FD_TOK_END;
   *optionalParam = 0;

   tokenId = FD_TOK_END;
   extractedParam = 0;

   /* First check for token directly mapping to a simple string. */
   for( i=0; (i < FD_NB_TOKEN_ID) && (tokenId == FD_TOK_END); i++ )
   {
      cmp_str = FD_TokenString( (FD_TokenId)i );

      if( cmp_str )
      {
          #if defined( WIN32 )
          if( stricmp( str, cmp_str ) == 0 )
          #else
          if( strcasecmp( str, cmp_str ) == 0 )
          #endif
          {
             tokenId = (FD_TokenId)i;
             extractedParam = 1;
          }
      }
   }

   /* If not found, look for more advanced token taking
    * optional "=n" parameters.
    */
   if( tokenId == FD_TOK_END )
   {
      retCode = findTokenIdWithParam( &str[0], &tokenId, &extractedParam );

      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
   }

   /* Make sure it is a valid field for a file description. */
   switch( tokenId )
   {
   case FD_TOK_YYYY:
   case FD_TOK_YY:
   case FD_TOK_Y:
   case FD_TOK_M:
   case FD_TOK_MM:
   case FD_TOK_MMM:
   case FD_TOK_D:
   case FD_TOK_DD:
   case FD_TOK_OPEN:
   case FD_TOK_HIGH:
   case FD_TOK_LOW:
   case FD_TOK_CLOSE:
   case FD_TOK_VOLUME:
   case FD_TOK_OPENINTEREST:
   case FD_TOK_HOUR:
   case FD_TOK_MIN:
   case FD_TOK_SEC:
   case FD_TOK_HH:
   case FD_TOK_MN:
   case FD_TOK_SS:
   case FD_TOK_SKIP_N_CHAR:
   case FD_TOK_SKIP_N_HEADER_LINE:
   case FD_TOK_SKIP_N_REAL:
   case FD_TOK_SKIP_N_INTEGER:
   case FD_TOK_SKIP_NON_DIGIT_LINE:
      break;
   default:
      FD_TRACE_RETURN( FD_INVALID_FIELD );
   }

   /* Everything is fine, return the information. */
   *id = tokenId;
   *optionalParam = extractedParam;

   FD_TRACE_RETURN( FD_SUCCESS );
}


static FD_RetCode findTokenIdWithParam( const char *str,
                                        FD_TokenId *tokenId,
                                        unsigned int *extractedParam )
{
   unsigned int i, length;
   const char *cmp_str;

   *tokenId = FD_TOK_END;
   length = 0;

   /* Identify the token.  */
   for( i=0; (i < FD_NB_TOKEN_ID) && (*tokenId == FD_TOK_END); i++ )
   {
      cmp_str = FD_TokenString( (FD_TokenId)i );

      if( cmp_str )
      {
          length = strlen(cmp_str);

          #if defined( WIN32 )
          if( strnicmp( str, cmp_str, length ) == 0 )
          #else
          if( strncasecmp( str, cmp_str, length ) == 0 )
          #endif
          {
             if( (str[length] == '=') && isdigit(str[length+1])) 
             {
                *tokenId = (FD_TokenId)i;
             }
         }
      }
   }

   /* Make sure this is a field that can have a parameter. */
   switch( *tokenId )
   {
   case FD_TOK_HOUR:
   case FD_TOK_MIN:
   case FD_TOK_SEC:
   case FD_TOK_HH:
   case FD_TOK_MN:
   case FD_TOK_SS:
   case FD_TOK_SKIP_N_CHAR:
   case FD_TOK_SKIP_N_REAL:
   case FD_TOK_SKIP_N_INTEGER:
   case FD_TOK_SKIP_N_HEADER_LINE:
   case FD_TOK_VOLUME:
   case FD_TOK_OPENINTEREST:
      break;
   default:
      return FD_INVALID_FIELD;
   }

   /* Make sure the "= n" is specified. */
   if( (str[length] != '=') ||
       (!isdigit( str[length+1] )) ) 
      return FD_INVALID_FIELD;

   *extractedParam = atoi( &str[length+1] );

   /* Validate some ranges. */
   switch( *tokenId )
   {
   case FD_TOK_HOUR:
   case FD_TOK_HH:
      switch( *extractedParam )
      {
      case 1: case 2: case 3: case 4: case 12:
         /* All these are valid values. */
         break;
      default:
         return FD_INVALID_FIELD;
      }
      break;
   case FD_TOK_MN:
   case FD_TOK_SS:
   case FD_TOK_MIN:
   case FD_TOK_SEC:
      switch( *extractedParam )
      {
      case  1: case  2: case  3: case  4: case  5:
      case  6: case 10: case 12: case 15: case 20:
      case 30:
         /* All these are valid values. */
         break;
      default:
         return FD_INVALID_FIELD;
      }
      break;
   case FD_TOK_VOLUME:
   case FD_TOK_OPENINTEREST:
      switch( *extractedParam )
      {
      case     1:
      case    10:
      case   100: 
      case  1000:
      case 10000:
         /* All these are valid values. */
         break;
      default:
         return FD_INVALID_FIELD;
      }
   default:
      /* Do nothing */
      break;
   }

   return FD_SUCCESS;
}
