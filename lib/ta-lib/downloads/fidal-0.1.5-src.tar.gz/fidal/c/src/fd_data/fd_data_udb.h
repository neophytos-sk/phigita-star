#ifndef FD_DAFD_UDB_H
#define FD_DAFD_UDB_H

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_DICT_H
   #include "fd_dict.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SYSTEM_H
   #include "fd_system.h"
#endif

/* Declarations used only within the FD_DATA module. Should never
 * be accessible by the library end-user.
 */

/* The unified database is represented in memory by using mainly
 * the following structures:
 *
 *   FD_UDB_Category
 *      One exist for each distinct category in the unified database.
 *
 *   FD_UDB_Symbol
 *      One exist for each distinct symbol in a given category in the
 *      unified database.
 *
 *   FD_UDB_Driver
 *      One or more exist for a given symbol in the unified database.
 *      That structure point to all the information needed for retreiving
 *      the data from a particular data source.
 */
typedef struct
{
   FD_String *string;
   FD_Dict *dictUDBSymbol; /* Dictionary of FD_UDB_Symbol for that category. */

   FD_List listUDBDriverArray; /* List of array of FD_UDB_Driver. An array
                                * will exist for each data source added who
                                * contributes some symbol to this category.
                                */

   /* Allocation Strategy: This structure owns all its sub-elements. */
} FD_UDB_Category;

typedef struct
{
   FD_String *string;
   FD_List listDriverHandle; /* List of FD_DriverHandle for this symbol. */

   /* Allocation Strategy: This structure owns all its sub-elements. */
} FD_UDB_Symbol;

typedef struct
{
   /* This structure keep tracks of everything needed to retreive
    * a symbol from a particular data source drivers.
    */
   FD_DataSourceHandle *sourceHandle;
   FD_CategoryHandle   *categoryHandle;
   FD_SymbolHandle      symbolHandle;

   /* Pre-allocated list node used allowing to easily include 
    * this structure into the listDriverHandle in the FD_UDB_Symbol.
    */
   FD_ListNode node;

   /* Parameters that were used when FD_AddDataSource was done. */
   const FD_AddDataSourceParamPriv *addDataSourceParamPriv;

   /* Allocation Strategy: This structure does not owns the pointed elements. */
} FD_UDB_Driver;

/* The hidden implementation of an "unified database".
 * From the user point of view, this is a FD_UDBase.
 */
typedef struct
{
  unsigned int magicNb;

  #if !defined( FD_SINGLE_THREAD )
  FD_Sema sema; /* To protect this structure integrity. */
  #endif
  FD_List *listDataSource; /* List of FD_DataSource   */
  FD_Dict *dictCategory;   /* Dict of FD_UDB_Category */

  /* Keep a pointer on the default category. */
  FD_UDB_Category *defaultCategory;

} FD_UDBasePriv;

#endif

