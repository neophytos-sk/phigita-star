/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *
 */

/* Description:
 *    This is the entry points of the data source driver for the ASCII format.
 *
 *    It provides ALL the functions needed by the "FD_DataSourceDriver"
 *    structure (see fd_source.h).
 */

/**** Headers ****/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "fd_source.h"
#include "fd_ascii.h"
#include "fd_common.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_list.h"
#include "fidal.h"
#include "fd_system.h"
#include "fd_ascii_handle.h"
#include "fd_fileindex.h"
#include "fd_readop.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_ASCII_InitializeSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN(  FD_ASCII_InitializeSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_ShutdownSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN(  FD_ASCII_ShutdownSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_ASCII_GetParameters );

   memset( param, 0, sizeof( FD_DataSourceParameters ) );

   param->flags = FD_REPLACE_ZERO_PRICE_BAR;

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_ASCII_OpenSource( const FD_AddDataSourceParamPriv *param,
                                FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_DataSourceHandle *tmpHandle;
   FD_PrivateAsciiHandle *privData;
   FD_RetCode retCode;
   FD_StringCache *stringCache;

   *handle = NULL;

   FD_TRACE_BEGIN( FD_ASCII_OpenSource );

   stringCache = FD_GetGlobalStringCache();

   /* 'info' and 'location' are mandatory. */
   if( (!param->info) || (!param->location) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   /* Allocate and initialize the handle. This function will also allocate the
    * private handle (opaque data).
    */
   tmpHandle = FD_ASCII_DataSourceHandleAlloc(param);

   if( tmpHandle == NULL )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   privData = (FD_PrivateAsciiHandle *)(tmpHandle->opaqueData);

   /* Keep a pointer on the FD_AddDataSourcePriv parameters.
    * This pointer (and its content) is guaranteed to be good
    * until CloseSource gets called.
    */
   privData->param = param;

   /* Now build the FD_FileIndex. */
   retCode = FD_ASCII_BuildFileIndex( tmpHandle );

   if( retCode != FD_SUCCESS )
   {
      FD_ASCII_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Set the total number of distinct category. */
   tmpHandle->nbCategory = FD_FileIndexNbCategory( privData->theFileIndex );

   /* Build the array of operation to perform for reading the
    * ASCII file.
    */
   retCode = FD_ASCII_BuildReadOpInfo( tmpHandle );
   if( retCode != FD_SUCCESS )
   {
      FD_ASCII_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Verify that a close field is provided when the flag
    * to replace zero price bar is set.
    */
   if(  (param->flags & FD_REPLACE_ZERO_PRICE_BAR) &&       
       !(privData->readOpInfo->fieldProvided & FD_FIELD_CLOSE) )
   {
      FD_ASCII_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( FD_MISSING_CLOSE_PRICE_FIELD );
   }

   *handle = tmpHandle;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG

   FD_TRACE_BEGIN(  FD_ASCII_CloseSource );

   /* Free all ressource used by this handle. */
   if( handle )
      FD_ASCII_DataSourceHandleFree( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                            FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG
   FD_PrivateAsciiHandle *privData;
   FD_FileIndex     *fileIndex;
   FD_String        *string;

   FD_TRACE_BEGIN(  FD_ASCII_GetFirstCategoryHandle );

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateAsciiHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(49) );
   }

   fileIndex = privData->theFileIndex;

   if( !fileIndex )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(50) );
   }

   string = FD_FileIndexFirstCategory( fileIndex );

   if( !string )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(51) ); /* At least one category must exist. */
   }

   /* Set the categoryHandle. */
   categoryHandle->string = string;
   categoryHandle->nbSymbol = FD_FileIndexNbSymbol( fileIndex );
   categoryHandle->opaqueData = categoryHandle;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetNextCategoryHandle( FD_DataSourceHandle *handle,
                                           FD_CategoryHandle   *categoryHandle,
                                           unsigned int index )
{
   FD_PROLOG

   FD_PrivateAsciiHandle *privData;
   FD_FileIndex     *fileIndex;
   FD_String        *string;

   FD_TRACE_BEGIN(  FD_ASCII_GetNextCategoryHandle );

   (void)index; /* Get ride of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateAsciiHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(52) );
   }

   fileIndex = privData->theFileIndex;

   if( !fileIndex )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(53) );
   }

   /* Get the next category from the fileIdnex. */
   string = FD_FileIndexNextCategory( fileIndex );

   if( !string )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Set the categoryHandle. */
   categoryHandle->string = string;
   categoryHandle->nbSymbol = FD_FileIndexNbSymbol( fileIndex );
   categoryHandle->opaqueData = NULL; /* Not needed... */

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle,
                                          FD_SymbolHandle     *symbolHandle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PrivateAsciiHandle *privData;
   FD_FileIndex *fileIndex;
   FD_FileInfo *sourceInfo;

   FD_TRACE_BEGIN(  FD_ASCII_GetFirstSymbolHandle );

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateAsciiHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(54) );
   }

   fileIndex = privData->theFileIndex;

   if( !fileIndex || !categoryHandle->string )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(55) );
   }

   /* Make sure the current category is the one requested. */
   retCode = FD_FileIndexSelectCategory( fileIndex, categoryHandle->string );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(56) );
   }

   /* Get the first symbol in this category. */
   sourceInfo = FD_FileIndexFirstSymbol( fileIndex );

   if( !sourceInfo )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Parano sanity check: the string of the requested categoryHandle should
    * correspond to the string of this sourceInfo.
    */
   if( strcmp( FD_StringToChar( FD_FileInfoCategory( sourceInfo ) ),
               FD_StringToChar( categoryHandle->string ) ) != 0 )
   {
      FD_FATAL(  NULL, 0, 0 );
   }

   /* Set the symbolHandle. */
   symbolHandle->string = FD_FileInfoSymbol( sourceInfo );
   symbolHandle->opaqueData = sourceInfo;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                         FD_CategoryHandle   *categoryHandle,
                                         FD_SymbolHandle     *symbolHandle,
                                         unsigned int index )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PrivateAsciiHandle *privData;
   FD_FileIndex *fileIndex;
   FD_FileInfo *sourceInfo;

   FD_TRACE_BEGIN(  FD_ASCII_GetNextSymbolHandle );

   (void)index; /* Get ride of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateAsciiHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(57) );
   }

   fileIndex = privData->theFileIndex;

   if( !fileIndex || !categoryHandle->string )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(58) );
   }

   /* Make sure the current category is the one requested. */
   retCode = FD_FileIndexSelectCategory( fileIndex, categoryHandle->string );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(59) );
   }

   /* Get the next symbol in this category. */
   sourceInfo = FD_FileIndexNextSymbol( fileIndex );

   if( !sourceInfo )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Parano sanity check: the string of the requested categoryHandle should
    * correspond to the string of this sourceInfo.
    */
   if( strcmp( FD_StringToChar( FD_FileInfoCategory( sourceInfo ) ),
               FD_StringToChar( categoryHandle->string ) ) != 0 )
   {
      FD_FATAL(  NULL, 0, 0 );
   }

   /* Set the symbolHandle. */
   symbolHandle->string = FD_FileInfoSymbol( sourceInfo );
   symbolHandle->opaqueData = sourceInfo;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_ASCII_GetHistoryData( FD_DataSourceHandle *handle,
                                    FD_CategoryHandle   *categoryHandle,
                                    FD_SymbolHandle     *symbolHandle,
                                    FD_Period            period,
                                    const FD_Timestamp  *start,
                                    const FD_Timestamp  *end,
                                    FD_Field             fieldToAlloc,
                                    FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   const char *path;
   FD_FileInfo *sourceInfo;
   FD_FileHandle *fileHandle;
   FD_RetCode retCode;
   FD_PrivateAsciiHandle *privateHandle;

   FD_TRACE_BEGIN(  FD_ASCII_GetHistoryData );

   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateAsciiHandle *)handle->opaqueData;
   FD_ASSERT( privateHandle != NULL );

   FD_ASSERT( paramForAddData != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   sourceInfo = (FD_FileInfo *)symbolHandle->opaqueData;

   FD_ASSERT( sourceInfo != NULL );

   /* If the requested period is too precise for the
    * period that can be provided by this data source,
    * simply return without error.
    * Since no data has been added, the FIDAL will ignore
    * this data source.
    */
   if( period < privateHandle->readOpInfo->period )
   {
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   /* If all fields are requested, provides all the fields
    * that were specified when this data source was added.
    */
   if( fieldToAlloc == FD_FIELD_ALL )
      fieldToAlloc = privateHandle->readOpInfo->fieldProvided;

   /* When the FD_REPLACE_ZERO_PRICE_BAR flag is set, we must
    * always process the close.
    */
   if( !(fieldToAlloc & FD_FIELD_CLOSE) &&
        (privateHandle->param->flags & FD_REPLACE_ZERO_PRICE_BAR) )
   {   
      fieldToAlloc |= FD_FIELD_CLOSE;
   }

   /* Get the path of the file. */
   path = FD_FileInfoPath( sourceInfo );

   if( !path )
   {
      FD_FATAL(  "Building path failed", 0, 0 );
   }

   /* Open the file for sequential read only (optimized read) */
   retCode = FD_FileSeqOpen( path, &fileHandle );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Optimize the readOp according to the requested field. */
   retCode = FD_ReadOp_Optimize( privateHandle->readOpInfo,
                                 privateHandle->readOpInfo->period,
                                 fieldToAlloc );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Read all the price bar. */
   retCode = FD_ReadOp_Do( fileHandle,                           
                           privateHandle->readOpInfo,
                           privateHandle->readOpInfo->period,
                           start, end, 200,
                           fieldToAlloc, paramForAddData, NULL );

   if( retCode != FD_SUCCESS )
   {
      FD_FileSeqClose( fileHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Read completed... clean-up and return. */
   retCode = FD_FileSeqClose( fileHandle );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

/**** Local functions definitions.     ****/
/* None */

