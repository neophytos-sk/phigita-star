#ifndef FD_HISTORY_PRIV_H
#define FD_HISTORY_PRIV_H

/* Contains declarations/prototypes private to the FD_History module. */

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FD_HISTORY_H
   #include "fd_history.h"
#endif

typedef struct
{
   FD_Real *open;
   FD_Real *high;
   FD_Real *low;
   FD_Real *close;
   FD_Integer *volume;
   FD_Integer *openInterest;
   FD_Timestamp *timestamp;

   FD_Integer nbBars;
   FD_Period  period;

   FD_Field   fieldProvided;
} FD_DataBlock;

typedef struct
{
  /* All the data allocated while the processing of building
   * the FD_History will be refer one way or the other from here.
   * (except for the data possibly internally allocated by the
   * driver of course). This will allow to easily clean-up everything
   * when something wrong happen.
   */
  FD_List *listOfSupportForDataSource; /* List of FD_SupportForDataSource. */

  FD_List *listOfMergeOp;  /* List of FD_MergeOp */
  unsigned int nbPriceBar; /* Final number of price bar. */

  /* When FD_FIELD_ALL is requested, we keep track of the set of common
   * field provided among all the data source.
   */
  FD_Field commonFieldProvided;

  /* Indicates if an error has been detected at ANY point while building
   * the FD_History.
   */
  FD_RetCode retCode;

} FD_BuilderSupport;


typedef struct
{
   /* Describe a 'copy' operation that must be performed when merging.
    * Many instances of this structure will usually exist to complete
    * a merging.
    */
   FD_DataBlock *srcDataBlock;
   unsigned int srcIndexForCopy;
   unsigned int nbElementToCopy;
} FD_MergeOp;

/* Structure to store split/value adjustments.
 *
 * A split adjustement affects both the price and
 * the volume in the same proportion.
 *
 * A value  adjustment affects only the price. Examples
 * are dividend, disbursment etc...
 */
typedef struct
{
   FD_Timestamp timestamp;
   double factor;
} FD_SplitAdjust;

typedef struct
{
   FD_Timestamp timestamp;
   double amount;
} FD_ValueAdjust;


/* This structure is the private version for the FD_ParamForAddData type. */
typedef struct
{
  /* An instance of this structure will exist for each data source involve
   * when a FD_HistoryAlloc call is done.
   */

  /* Parameters needed to be passed to the data source driver. */
  FD_BuilderSupport   *parent;
  FD_DataSourceHandle *sourceHandle;
  FD_CategoryHandle   *categoryHandle;
  FD_SymbolHandle     *symbolHandle;
  FD_Period            period;
  const FD_Timestamp  *start;
  const FD_Timestamp  *end;
  FD_Field             fieldToAlloc;

  /* Setting this variable to one will force the driver to stop
   * processing as soon as possible the addition of data.
   * Basically, it is a way for the caller of the driver to say... I got
   * enough data from you!
   */
  volatile unsigned int enoughValidDataProvided;

  /* This variable will get set to one when the driver return from
   * the GetHistoryData function.
   */
  volatile unsigned int finishIndication;

  /* Indicates the fields provided. Can be different than
   * fieldToAlloc if the driver:
   * 1) provides more field than requested.
   * 2) When fieldToAlloc is FD_FIELD_ALL.
   *
   * Of course, fieldProvided cannot be FD_FIELD_ALL, it must be specific
   * about WHICH fields are provided by this driver.
   *
   * It is assumed (and verified) that all data block (in listOfDataBlock)
   * provides the same fields.
   */
  FD_Field fieldProvided;

  /* The driver have the liberty to provide the data in a timeframe
   * smaller than requested by 'period' (see above).
   * It is verified that all data added by the same driver (in listOfDataBlock)
   * have the same period though.
   */
  FD_Period periodProvided;

  /* The latest return code of the GetHistoryData function. */
  volatile FD_RetCode retCode;

  FD_List *listOfDataBlock; /* Lists of FD_DataBlock. */


  /* We keep track of the extremes in the listOfDataBlock. */
  const FD_Timestamp *lowestTimestamp;
  const FD_Timestamp *highestTimestamp;

  /* The following values are reset everytime the data
   * source driver calls FD_GetInfoFromAddedData
   */
  unsigned int barAddedSinceLastCall; /* boolean */
  const FD_Timestamp *lowestTimestampAddedSinceLastCall;
  const FD_Timestamp *highestTimestampAddedSinceLastCall; 

  /* Provides information about which feature the
   * datasource can support.
   */
  FD_DataSourceParameters supportedParameter;

  /* Parameter that were used when this data
   * source was added.
   */
  const FD_AddDataSourceParamPriv *addDataSourceParamPriv;

  /* List of FD_SplitAdjust structures. */
  FD_List *listOfSplitAdjust;

  /* List of FD_ValueAdjust structures. */
  FD_List *listOfValueAdjust;

  /* The following variables are used only while doing the merging with
   * the other data sources. They allow to keep track of the next
   * price bar to be processed for this particular data source.
   */
  unsigned int allDataConsumed;
  unsigned int curIndex;
  const FD_Timestamp *curTimestamp;
  const FD_Timestamp *curLastTimestamp;
  FD_DataBlock       *curDataBlock;

  /* Indicates if that data source has data part of the
   * final data returned to the caller of FD_HistoryAlloc.
   */
  unsigned int contributingDataSource;

  /* Moment from which the data source should give up and
   * return with a FD_DAFD_RETREIVE_TIMEOUT error.
   * When all zero, the driver do a best-effort before
   * giving up.
   */
  FD_Timestamp timeLimit;

} FD_SupportForDataSource;

/********** Prototype for function in fd_period.c *********/

/* Will make all list of datablock use the same period logic. 
 * That is all datablocks using begin-of-period or end-of-period
 * timestamps.
 */
FD_RetCode FD_PeriodLogicAdjust( FD_BuilderSupport *builderSupport, FD_HistoryFlag flag );

/* Will make all list of datablock use the same period. The datablock
 * with the longest period will determine the period.
 *
 * Example: if a data source provides the data in 15 minutes increment
 *          and another in daily price bar, all data block will be normalize
 *          to daily period.
 */
FD_RetCode FD_PeriodNormalize( FD_BuilderSupport *builderSupport );


/* Allocate data in a different timeframe from
 * an existing history.
 *
 * When the parameter doAllocateNew is != 0, the history 
 * is transformed and the "Allocate new" pointers
 * will be all NULL.
 *
 * When the parameter doAllocateNew == 0, the "history"
 * is left untouch, and all the new data are returned
 * through the "Allocate new" pointers. FD_Free must be 
 * called on these pointers when not needed anymore.
 *
 * In both case, you will need to free "history" as usual.
 */
FD_RetCode FD_PeriodTransform( FD_History *history,       /* The original history. */
                               FD_Period newPeriod,       /* The new desired period. */
                               FD_HistoryFlag flags,
                               int doAllocateNew,         /* When true, following ptrs are used. */
                               FD_Integer *nbBars,        /* Return the number of price bar */
                               FD_Timestamp **timestamp,  /* Allocate new timestamp. */
                               FD_Real **open,            /* Allocate new open. */
                               FD_Real **high,            /* Allocate new high. */
                               FD_Real **low,             /* Allocate new low. */
                               FD_Real **close,           /* Allocate new close. */
                               FD_Integer **volume,       /* Allocate new volume. */
                               FD_Integer **openInterest  /* Allocate new openInterest. */ );

#endif
