#ifndef FD_CSI_HANDLE_H
#define FD_CSI_HANDLE_H

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FD_CSI_FILES_H
   #include "fd_csi_files.h"
#endif


typedef struct
{  
   /* Keep a ptr on the user FD_AddDataSource parameters. */
   const FD_AddDataSourceParamPriv *param;

   /* Index extracted from the files. */
   struct MasterListRecordType *index;
   int indexSize;

   /* A FD_String for each MasterListRecordType */
   FD_String **indexString;

   /* A FD_String for the CSI_ID_CATEGORY_NAME */
   FD_String *category;

} FD_PrivateCSIHandle;

#define CSI_ID_CATEGORY_NAME "CSI_ID"

/* Alloc/Free for the FD_DataSourceHandle.
 *
 * Takes care also to alloc/initialize/free the FD_PrivateCSIHandle
 * which is the 'opaque' part of the FD_DataSourceHandle.
 */
FD_DataSourceHandle *FD_CSI_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param );
FD_RetCode FD_CSI_DataSourceHandleFree( FD_DataSourceHandle *handle );

/* Build (or re-build) the index for this handle. */
FD_RetCode FD_CSI_BuildIndex( FD_DataSourceHandle *handle );

#endif
