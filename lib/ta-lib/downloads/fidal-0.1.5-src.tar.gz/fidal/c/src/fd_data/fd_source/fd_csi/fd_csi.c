/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  031904 MF   First version.
 *
 */

/* Description:
 *    This is the entry points of the data source driver for the CSI format.
 *
 *    It provides ALL the functions needed by the "FD_DataSourceDriver"
 *    structure (see fd_source.h).
 */

/**** Headers ****/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "fd_source.h"
#include "fd_common.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_list.h"
#include "fidal.h"
#include "fd_system.h"
#include "fd_csi_handle.h"
#include "fd_global.h"

#include "fd_csi.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_CSI_InitializeSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_CSI_InitializeSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_ShutdownSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_CSI_ShutdownSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_CSI_GetParameters );

   memset( param, 0, sizeof( FD_DataSourceParameters ) );

   param->flags = FD_LOCATION_IS_PATH;

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_CSI_OpenSource( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_DataSourceHandle *tmpHandle;
   FD_PrivateCSIHandle *privData;
   FD_RetCode retCode;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_CSI_OpenSource );

   FD_ASSERT( handle != NULL );
   FD_ASSERT( param != NULL );

   *handle = NULL;

   stringCache = FD_GetGlobalStringCache();

   /* Allocate and initialize the handle. This function will also allocate the
    * private handle (opaque data).
    */
   tmpHandle = FD_CSI_DataSourceHandleAlloc(param);

   if( tmpHandle == NULL )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   privData = (FD_PrivateCSIHandle *)(tmpHandle->opaqueData);

   privData->param = param;

   /* Now build the index. */  
   retCode = FD_CSI_BuildIndex( tmpHandle );

   if( retCode != FD_SUCCESS )
   {
      FD_CSI_DataSourceHandleFree( tmpHandle );
      FD_TRACE_RETURN( retCode );
   }

   /* Set the total number of distinct category. */
   tmpHandle->nbCategory = 1;

   /* All fine, return result to caller. */
   *handle = tmpHandle;
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG

   FD_TRACE_BEGIN( FD_CSI_CloseSource );

   /* Free all ressource used by this handle. */
   if( handle )
      FD_CSI_DataSourceHandleFree( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG
   FD_PrivateCSIHandle *privData;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_CSI_GetFirstCategoryHandle );

   FD_ASSERT( handle != NULL );

   stringCache = FD_GetGlobalStringCache();

   privData = (FD_PrivateCSIHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(161) );
   }

   /* Set the categoryHandle. */
   categoryHandle->string = privData->category;
   categoryHandle->nbSymbol = privData->indexSize;
   categoryHandle->opaqueData = NULL;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle   *categoryHandle,
                                        FD_SymbolHandle     *symbolHandle )
{
   FD_PROLOG
   FD_PrivateCSIHandle *privData;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_CSI_GetFirstSymbolHandle );

   FD_ASSERT( handle != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   stringCache = FD_GetGlobalStringCache();
   privData = (FD_PrivateCSIHandle *)(handle->opaqueData);

   FD_ASSERT( privData != NULL );
   FD_ASSERT( privData->index != NULL );
   FD_ASSERT( privData->indexSize >= 1 );

   /* Set the symbolHandle. */
   symbolHandle->string = privData->indexString[0];
   symbolHandle->opaqueData = &privData->index[0];

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle   *categoryHandle,
                                       FD_SymbolHandle     *symbolHandle,
                                       unsigned int index )
{
   FD_PROLOG
   FD_PrivateCSIHandle *privData;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_CSI_GetNextSymbolHandle );

   (void)index; /* Get ride of compiler warnings. */

   FD_ASSERT( handle != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   stringCache = FD_GetGlobalStringCache();
   privData = (FD_PrivateCSIHandle *)(handle->opaqueData);

   FD_ASSERT( privData != NULL );
   FD_ASSERT( privData->index != NULL );
   FD_ASSERT( privData->indexString != NULL );
   FD_ASSERT( privData->indexString[index] != NULL );
   FD_ASSERT( privData->indexSize >= 1 );

   /* Set the symbolHandle. */
   symbolHandle->string = privData->indexString[index];
   symbolHandle->opaqueData = &privData->index[index];

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_GetHistoryData( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PrivateCSIHandle *privateHandle;
   MasterListRecord *record;

   SingleContractDataDayCore *dataList;
   int nbData;
   int i, index;
   int year,month,day,date,tmpInt;

   FD_Timestamp *timestamp;
   FD_Real *open, *high, *low, *close;
   FD_Integer *vol, *oi;
   
   FD_TRACE_BEGIN( FD_CSI_GetHistoryData );

   (void)start;
   (void)end;

   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateCSIHandle *)handle->opaqueData;
   FD_ASSERT( privateHandle != NULL );

   FD_ASSERT( paramForAddData != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   record = (MasterListRecord *)symbolHandle->opaqueData;

   FD_ASSERT( record != NULL );

   open = high = low = close = NULL;
   vol = oi = NULL;

   /* If the requested period is too precise for the
    * period that can be provided by this data source,
    * simply return without error.
    * Since no data has been added, the FIDAL will ignore
    * this data source.
    */
   if( period < record->Period )
   {
      FD_TRACE_RETURN( FD_SUCCESS );
   }

   /* Calculate the "offset" of the record in the main index. 
    * This is the "fileNumber" that CSI use.
    */
   index = ((const char *)record - (const char *)privateHandle->index)/sizeof(MasterListRecord);
   
   /* Get the data from the file. */
   dataList = NULL;
   switch( privateHandle->param->id )
   {
   case FD_CSI:
      retCode = ReadCSIData( FD_StringToChar(privateHandle->param->location), index, -1, &dataList, &nbData );
      break;
   case FD_CSIM:
      retCode = ReadCSIMData( FD_StringToChar(privateHandle->param->location), index, -1, &dataList, &nbData );
      break;
   default:
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(164) );
   }

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( dataList != NULL );

   /* Convert each field of data into arrays. */
   timestamp = (FD_Timestamp *)FD_Malloc(sizeof(FD_Timestamp)*nbData);
   if( !timestamp )
   {
      FD_Free( dataList );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   for( i=0; i < nbData; i++ )
   {
      FD_SetTime( 0, 0, 0, &timestamp[i] );
      date   = dataList[i].date;
      day    = date%100;
      tmpInt = date%10000;
      year   = (date - tmpInt)/10000;
      month  = (tmpInt - day)/100;
      FD_SetDate( year, month, day, &timestamp[i] );
   }

   #define PROCESS_ARRAY(type,uc,lc) \
   { \
      if( (fieldToAlloc == FD_FIELD_ALL) || (fieldToAlloc & FD_FIELD_##uc) ) \
      { \
         lc = (type *)FD_Malloc(sizeof(type)*nbData); \
         if( !lc ) \
         { \
            FREE_IF_NOT_NULL( timestamp ); \
            FREE_IF_NOT_NULL( open ); \
            FREE_IF_NOT_NULL( high ); \
            FREE_IF_NOT_NULL( low ); \
            FREE_IF_NOT_NULL( close ); \
            FREE_IF_NOT_NULL( vol ); \
            FREE_IF_NOT_NULL( oi ); \
            FD_Free( dataList ); \
            FD_TRACE_RETURN( FD_ALLOC_ERR ); \
         } \
         for( i=0; i < nbData; i++ ) \
            lc[i] = dataList[i].lc; \
      } \
   }

   PROCESS_ARRAY( FD_Real, OPEN,  open  );
   PROCESS_ARRAY( FD_Real, HIGH,  high  );
   PROCESS_ARRAY( FD_Real, LOW,   low   );
   PROCESS_ARRAY( FD_Real, CLOSE, close );

   PROCESS_ARRAY( FD_Integer, VOLUME, vol );
   PROCESS_ARRAY( FD_Integer, OPENINTEREST, oi );

   FD_Free( dataList );

   retCode = FD_HistoryAddData( paramForAddData, nbData,
                                record->Period, timestamp,
                                open, high, low, close,
                                vol, oi );

   FD_TRACE_RETURN( retCode );
}

/* The code for CSIM format is practically the same as for CSI.
 * The _CSI_ functions will handle the difference by looking
 * at the "id" FD_CSI vs FD_CSIM.
 */
FD_RetCode FD_CSIM_InitializeSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_CSIM_InitializeSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSIM_ShutdownSourceDriver( void )
{
   FD_PROLOG
   FD_TRACE_BEGIN( FD_CSIM_ShutdownSourceDriver );

    /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSIM_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_GetParameters );

   retCode = FD_CSI_GetParameters( param );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_OpenSource( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_OpenSource );

   retCode = FD_CSI_OpenSource( param, handle );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_CloseSource );

   retCode = FD_CSI_CloseSource( handle );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_GetFirstCategoryHandle );

   retCode = FD_CSI_GetFirstCategoryHandle( handle, categoryHandle );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle   *categoryHandle,
                                        FD_SymbolHandle     *symbolHandle )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_GetFirstSymbolHandle );

   retCode = FD_CSI_GetFirstSymbolHandle( handle, categoryHandle, symbolHandle );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle   *categoryHandle,
                                       FD_SymbolHandle     *symbolHandle,
                                       unsigned int index )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_GetNextSymbolHandle );

   retCode = FD_CSI_GetNextSymbolHandle( handle, categoryHandle, symbolHandle, index );
   FD_TRACE_RETURN( retCode );
}

FD_RetCode FD_CSIM_GetHistoryData( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TRACE_BEGIN( FD_CSIM_GetHistoryData );

   retCode = FD_CSI_GetHistoryData( handle, categoryHandle, symbolHandle,
                                    period, start, end, fieldToAlloc, paramForAddData );
   FD_TRACE_RETURN( retCode );                                 
}

/**** Local functions definitions.     ****/
/* None */

