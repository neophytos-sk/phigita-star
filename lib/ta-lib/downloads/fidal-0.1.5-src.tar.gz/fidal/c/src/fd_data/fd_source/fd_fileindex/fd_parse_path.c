/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *
 */

/* Description:
 *    Parse a path into tokens. This parsing includes recognition
 *    of special fields.
 */

/**** Headers ****/
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "fd_system.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_fileindex_priv.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
#define SEARCH_FORWARD  1 /* For searchIdInLastLeg() direction parameter */
#define SEARCH_BACKWARD 0 /* For searchIdInLastLeg() direction parameter */

/**** Local functions declarations.    ****/
static FD_RetCode flushFixPart( FD_FileIndexPriv *fileIndexPriv,
                                const char *currentTokenStart,
                                char *pos );
static FD_RetCode addToken( FD_FileIndexPriv *fileIndexPriv,
                            FD_TokenId id, const char *value );

static FD_RetCode findTokenId( const char *str,
                               FD_TokenId *id );

static FD_RetCode checkForRedundantToken( FD_FileIndexPriv *fileIndexPriv );

static FD_RetCode checkForConsecutiveToken( FD_FileIndexPriv *fileIndexPriv );

static int isContainingSymbolField( FD_FileIndexPriv *fileIndexPriv );
static FD_RetCode processSymbolFieldSubstitution( FD_FileIndexPriv *fileIndexPriv );

#if 0
static void displayTokens( FD_FileIndexPriv *fileIndexPriv );
#endif

static const char *findDot( const char *str, unsigned int *returnFoundOffset );

static FD_TokenInfo *searchIdInLastLeg( int direction,
                                        FD_FileIndexPriv *fileIndexPriv,
                                        FD_TokenId id );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_FileIndexParsePath( FD_FileIndexPriv *fileIndexPriv, FD_String *path )
{
   typedef enum { INIT_PROCESSING,
                  FIX_PROCESSING,
                  FIELD_PROCESSING,
                  WILD_PROCESSING,
                  SEP_PROCESSING } State;

   FD_PROLOG
   State currentState;
   const char *currentTokenStart;
   unsigned int length;
   char *str;
   char *pos;
   char sepTmp[2];
   FD_RetCode retCode;
   unsigned int tokenSize;
   FD_TokenId tokenId;
   const char *sourcePattern;

   FD_TRACE_BEGIN(  FD_FileIndexParsePath );

   FD_ASSERT( path != NULL );

   sepTmp[1] = '\0';
   sourcePattern = FD_StringToChar( path );

   /* The following macro should help for the readability of the parsing logic.
    * These macro are used only inside this function.
    */
   #define RETURN(y) {FD_Free(str); FD_TRACE_RETURN( y );}
   #define REJECT_STATE(x,y) { if(currentState==x)RETURN(y);  }
   #define CHANGE_STATE(x) {currentState=x; currentTokenStart=pos+1;}

   #define ADD_TOKEN(id,value) \
   { \
      retCode = addToken(fileIndexPriv,id,value); \
      if( retCode != FD_SUCCESS) RETURN(retCode); \
   }

   #define FLUSH_FIX() \
   { \
      retCode = flushFixPart(fileIndexPriv,currentTokenStart,pos); \
      if( retCode != FD_SUCCESS ) RETURN(retCode); \
   }

   /* This function build a list representing the tokens
    * of the sourcePattern.
    *
    * Example:  "C:\a\*AZD?\[S]\data.txt" becomes
    *
    *            TokenId      Value
    *            FD_TOK_FIX       "C:"
    *            FD_TOK_SEP       "\"
    *            FD_TOK_FIX       "a"
    *            FD_TOK_SEP       "\"
    *            FD_TOK_WILD      "*"
    *            FD_TOK_FIX       "AZD"
    *            FD_TOK_WILD_CHAR "?"
    *            FD_TOK_SEP       "\"
    *            FD_TOK_S         "?*"
    *            FD_TOK_SEP       "\"
    *            FD_TOK_FIX       "data.txt"
    *            FD_TOK_END       (null)
    *
    *        In the values, the '?' and '*' character represent MS-DOS kind
    *        of wildcards:
    *             '?' is any character (but only one).
    *             '*' zero or more of any character
    */
   if( sourcePattern == NULL )
      return FD_INVALID_PATH;

   length = strlen( sourcePattern ) + 1;

   if( (length <= 1) || (length > 2048) )
      return FD_INVALID_PATH;

   str = (char *)FD_Malloc( length );
   strcpy( str, sourcePattern );

   pos = str;
   currentState = INIT_PROCESSING;
   currentTokenStart = pos;

   while( *pos != '\0' )
   {

      if( (*pos == '\\') || (*pos == '/') )
      {
         /* Handle directories separator character. */
         REJECT_STATE( FIELD_PROCESSING, FD_INVALID_FIELD );
         REJECT_STATE( SEP_PROCESSING, FD_INVALID_PATH );

         FLUSH_FIX();

#if 0
!!! Needed?
         /* Check that the string prior to the separator
          * does not terminate with a dot '.'
          */
         if( currentState != INIT_PROCESSING )
         {
            if( *(pos-1) == '.' )
               RETURN( FD_INVALID_PATH );
         }
#endif
         /* Transform into the directory delimiter
          * used on the host file system.
          */
         sepTmp[0] = (char)FD_SeparatorASCII();
         ADD_TOKEN( FD_TOK_SEP, sepTmp );

         CHANGE_STATE( SEP_PROCESSING );
      }
      else switch( *pos )
      {
      case '*':
         /* Cannot have a wildcard in a field! */
         REJECT_STATE( FIELD_PROCESSING, FD_INVALID_FIELD );

         FLUSH_FIX();

         /* Add the wild card token. */
         ADD_TOKEN( FD_TOK_WILD, NULL );

         /* Keep track that we just processed a wild card token. */
         CHANGE_STATE( WILD_PROCESSING );
         break;

      case '[':
         /* Cannot have a field inside another field! */
         REJECT_STATE( FIELD_PROCESSING, FD_INVALID_FIELD );
         FLUSH_FIX();
         CHANGE_STATE( FIELD_PROCESSING );
         break;

      case ']':
         /* Cannot close a field when not processing a field! */
         REJECT_STATE( WILD_PROCESSING, FD_INVALID_FIELD );
         REJECT_STATE( INIT_PROCESSING, FD_INVALID_FIELD );
         REJECT_STATE( FIX_PROCESSING, FD_INVALID_FIELD );
         REJECT_STATE( SEP_PROCESSING, FD_INVALID_FIELD );

         /* Return an error if the field is an empty string. */
         if( currentTokenStart == pos )
            RETURN( FD_INVALID_FIELD );

         /* Identify/store the field.
          * Will return an error if this is a non-valid field.
          */
         *pos = '\0';
         if( findTokenId( currentTokenStart, &tokenId ) != FD_SUCCESS )
            RETURN( FD_INVALID_FIELD );

         /* At this point the field has been identified and validated. */
         ADD_TOKEN( tokenId, NULL );

         tokenSize = FD_TokenMaxSize( tokenId );

         if( tokenSize == 0 )
         {
            /* Everything is fine, now indicates that we
             * just met a wild string...
             */
            CHANGE_STATE( WILD_PROCESSING );
         }
         else
            CHANGE_STATE( FIX_PROCESSING );
         break;

      case '?':
         REJECT_STATE( FIELD_PROCESSING, FD_INVALID_FIELD );

         FLUSH_FIX();

         ADD_TOKEN( FD_TOK_WILD_CHAR, NULL );

         CHANGE_STATE( FIX_PROCESSING );
         break;

#if 0
!!! Needed?
      case '.':
         /* These other characters are correct within
          * a fix section, but strictly forbidden
          * within a field (possibly for future use).
          */
         REJECT_STATE( FIELD_PROCESSING, FD_INVALID_FIELD );
         currentState = FIX_PROCESSING;
         break;
#endif

      default:
         /* Skip the character, and start doing FIX processing
          * except if we are actually handling a field.
          */
         if( currentState != FIELD_PROCESSING )
            currentState = FIX_PROCESSING;
      }

      pos++;
   }

   /* Detect not terminated field. */
   if( currentState == FIELD_PROCESSING )
      RETURN( FD_INVALID_FIELD );

   /* We did end up with a path without any character!?
    * This should never happen.
    */
   if( currentState == INIT_PROCESSING )
   {
      FD_FATAL(  NULL, pos, currentTokenStart );
      /* unreachable code:
       * RETURN( FD_INVALID_PATH );
       */
   }

   FLUSH_FIX();

   #if 0
      displayTokens( fileIndexPriv );
   #endif

   /* When terminated with a separator, assume the caller
    * want to include all files within the specified directory.
    * Consequently, by default, append a "[S]" or "*".
    */
   if( currentState == SEP_PROCESSING )
   {
      if( isContainingSymbolField( fileIndexPriv ) )
      {
         ADD_TOKEN( FD_TOK_WILD, NULL );
      }
      else
      {
         ADD_TOKEN( FD_TOK_SYM, NULL );     
      }

      #if 0
         displayTokens( fileIndexPriv );
      #endif
   }

   /* If NO [S] field is specified, perform some "intuitive" substitution
    * for the caller.
    */
   if( isContainingSymbolField( fileIndexPriv ) == 0 )
   {
      processSymbolFieldSubstitution( fileIndexPriv );
      #if 0
         displayTokens( fileIndexPriv );
      #endif
   }

   ADD_TOKEN( FD_TOK_END, NULL );

   /* At this point the list of tokens is determined
    * and should not changed.
    */
   #if 0
      displayTokens( fileIndexPriv );
   #endif

   /* Parano test: Verify again that a [S] symbol field is present. */
   if( isContainingSymbolField( fileIndexPriv ) == 0 )
      RETURN( FD_INVALID_PATH );

   /* Should not have more than one occurence of some of the
    * fields (like [S],[YYYY] etc...)
    */
   retCode = checkForRedundantToken( fileIndexPriv );

   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   /* Validate that no two identical token
    * are consecutive (except for FD_TOK_WILD_CHAR).
    */
   retCode = checkForConsecutiveToken( fileIndexPriv );

   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   /* Succesfully return. */
   RETURN( FD_SUCCESS );

   #undef RETURN
   #undef REJECT_STATE
   #undef ADD_TOKEN
   #undef CHANGE_STATE
   #undef FLUSH_FIX
}

/**** Local functions definitions.     ****/
static FD_RetCode flushFixPart( FD_FileIndexPriv *fileIndexPriv,
                                const char *currentTokenStart,
                                char *pos )
{
   FD_RetCode retCode;
   char tmp;

   if( currentTokenStart != pos )
   {
      /* Add this FIX string to the list if size is
       * different of zero.
       */
      tmp = *pos;
      *pos = '\0';
      retCode = addToken( fileIndexPriv, FD_TOK_FIX, currentTokenStart );
      *pos = tmp;
      return retCode;
   }

   return FD_SUCCESS;
}

static FD_RetCode addToken( FD_FileIndexPriv *fileIndexPriv,
                            FD_TokenId id, const char *value )
{
   FD_String *str = NULL;
   FD_RetCode retCode;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   if( value )
   {
      str = FD_StringAlloc(stringCache,value);

      if( str == NULL )
         return FD_ALLOC_ERR;
   }
   else
   {
      /* Some token use pre-defined values. */
      switch( id )
      {
      case FD_TOK_WILD:
         str = FD_StringDup( stringCache,fileIndexPriv->wildZeroOrMoreChar );
         if( !str )
            return FD_ALLOC_ERR;
         break;
      case FD_TOK_WILD_CHAR:
         str = FD_StringDup( stringCache,fileIndexPriv->wildOneChar );
         if( !str )
            return FD_ALLOC_ERR;
         break;
      case FD_TOK_SYM:
      case FD_TOK_CAT:
      case FD_TOK_CATC:
      case FD_TOK_CATX:
      case FD_TOK_CATT:
         str = FD_StringDup( stringCache,fileIndexPriv->wildOneOrMoreChar );
         if( !str )
            return FD_ALLOC_ERR;
         break;
      default:
         /* Do nothing */
         break;
      }
   }

   retCode = FD_FileIndexAddTokenInfo( fileIndexPriv, id, str, NULL );

   /* FD_FileIndexAddTokenInfo keeps its own duplicate of the string, so
    * simply free this local copy.
    */
   if( str )
      FD_StringFree( stringCache, str);

   return retCode;
}

static FD_RetCode findTokenId( const char *str, FD_TokenId *id )
{
   unsigned int i;
   const char *cmp_str;

   *id = (FD_TokenId)NULL;

   for( i=0; i < FD_NB_TOKEN_ID; i++ )
   {
      cmp_str = FD_TokenString( (FD_TokenId)i );

      if( cmp_str )
      {
	  #if defined( WIN32 )
          if( stricmp( str, cmp_str ) == 0 )
          #else
          if( strcasecmp( str, cmp_str ) == 0 )
          #endif
          {
             /* Make sure it is a valid field that can be found
              * in a path.
              */
             switch( i )
             {
             /* !!! For the time being, we do not accept date
              * within the path
             case FD_YYYY:
             case FD_MM:
             case FD_DD:
             */
             case FD_TOK_SYM:
             case FD_TOK_CAT:
             case FD_TOK_CATC:
             case FD_TOK_CATX:
             case FD_TOK_CATT:
                *id = (FD_TokenId)i;
                return FD_SUCCESS;
             default:
                return FD_INVALID_FIELD;
             }
          }
      }
   }

   return FD_INVALID_FIELD;
}

static FD_RetCode checkForRedundantToken( FD_FileIndexPriv *fileIndexPriv )
{
   int i;
   int tokenSeenOnce;
   FD_TokenInfo *token;

   FD_List *list = fileIndexPriv->listLocationToken;

   for( i=0; i < FD_NB_TOKEN_ID; i++ )
   {
      if( (i != FD_TOK_FIX) &&
          (i != FD_TOK_SEP) &&
          (i != FD_TOK_WILD_CHAR) &&
          (i != FD_TOK_WILD) )
      {
         token = (FD_TokenInfo *)FD_ListAccessHead( list );

         if( token == NULL )
            return FD_INVALID_PATH; /* Empty list!? */
         else
         {
            tokenSeenOnce = 0;
            do
            {
               if( i == token->id )
               {
                  if( tokenSeenOnce )
                     return FD_INVALID_FIELD;
                  tokenSeenOnce++;
               }

               token = (FD_TokenInfo *)FD_ListAccessNext( list );
            } while( token );
         }
      }
   }

   return FD_SUCCESS;
}

static FD_RetCode checkForConsecutiveToken( FD_FileIndexPriv *fileIndexPriv )
{
   FD_TokenInfo *token;
   FD_TokenInfo *prevToken;

   FD_List *list = fileIndexPriv->listLocationToken;

   token = (FD_TokenInfo *)FD_ListAccessHead( list );

   if( token == NULL )
      return FD_INVALID_PATH; /* Empty list!? */
   else
   {
      prevToken = NULL;
      do
      {
         if( prevToken )
         {
            if( (prevToken->id == token->id) &&
                (token->id != FD_TOK_WILD_CHAR) &&
                (token->id != FD_TOK_WILD) )
               return FD_INVALID_PATH;
         }

         prevToken = token;
         token = (FD_TokenInfo *)FD_ListAccessNext( list );
      }while( token );
   }

   return FD_SUCCESS;
}

static int isContainingSymbolField( FD_FileIndexPriv *fileIndexPriv )
{
   FD_TokenInfo *token;
   FD_List *list = fileIndexPriv->listLocationToken;

   token = (FD_TokenInfo *)FD_ListAccessHead( list );

   if( token == NULL )
      return FD_INVALID_PATH; /* Empty list!? */
   else
   {
      do
      {
         if( (token->id == FD_TOK_SYM) || (token->id == FD_TOK_SYMF) )
            return 1;
         token = (FD_TokenInfo *)FD_ListAccessNext( list );
      }while( token );
   }

   return 0;
}

static FD_TokenInfo *searchIdInLastLeg( int direction,
                                        FD_FileIndexPriv *fileIndexPriv,
                                        FD_TokenId id )
{
   FD_TokenInfo *token;
   FD_List *list;
   FD_TokenInfo *lastTokenSeen;

   /* if 'direction' is SEARCH_FORWARD, the left most occurence of id is returned.
    * if 'direction' is SEARCH_BACKWARD, the last occurence of id is returned.
    */

   lastTokenSeen = NULL;

   list = fileIndexPriv->listLocationToken;
   token = (FD_TokenInfo *)FD_ListAccessTail( list );

   while( token )
   {
      if( token->id == FD_TOK_SEP )
      {
         /* Got at the beginning of the last leg. */
         if( direction == SEARCH_FORWARD )
            return lastTokenSeen;
         else
            return NULL;
      }

      /* Look for 'id' while going backward. */
      if( token->id == id )
      {
         /* We found the first occurence while going backward... just return it! */
         if( direction == SEARCH_BACKWARD )
            return token;

         lastTokenSeen = token;
      }

      token = (FD_TokenInfo *)FD_ListAccessPrev( list );
   }

   return lastTokenSeen;
}

/* Find leftmost dot in the str. Return NULL if not found. */
static const char *findDot( const char *str, unsigned int *returnFoundOffset )
{
   unsigned int i = 0;

   while( *str )
   {
     if( *str == '.' )
     {
        *returnFoundOffset = i;
        return str;
     }
     str++;
     i++;
   }

   return NULL;
}

static FD_RetCode processSymbolFieldSubstitution( FD_FileIndexPriv *fileIndexPriv )
{
   FD_PROLOG
   FD_String *tmpPtr;
   FD_TokenInfo *token;
   char *str;
   FD_RetCode retCode;
   FD_StringCache *stringCache;
   unsigned int dotPos;

   FD_TRACE_BEGIN(  processSymbolFieldSubstitution );

   stringCache = FD_GetGlobalStringCache();

   /* For the time being, when there is no symbol defined,
    * it is not allowed to use the '?' wildcard in the last
    * leg of the path.
    */
   token = searchIdInLastLeg( SEARCH_BACKWARD, fileIndexPriv, FD_TOK_WILD_CHAR );
   if( token )
   {
      FD_TRACE_RETURN( FD_INVALID_PATH );
   }

   /* Perform the following default substitution:
    * - when last leg contains at least one [FD_TOK_WILD]:
    *      Replace the first [FD_TOK_WILD] with a [FD_TOK_S].
    *
    * - when last leg finish with a [FD_TOK_FIX] without any [FD_TOK_WILD]:
    *      Split the [FD_TOK_FIX] into [FD_TOK_SF][FD_TOK_FIX] if the original
    *      [FD_TOK_FIX] contains at least one dot '.' The dot determine
    *      where the split occur.
    *      If there is no dot, replace [FD_TOK_FIX] with [FD_TOK_SF].
    *
    */
   token = searchIdInLastLeg( SEARCH_FORWARD, fileIndexPriv, FD_TOK_WILD );
   if( token )
   {
      FD_ASSERT( token->id == FD_TOK_WILD );
      FD_ASSERT( token->value != NULL );

      /* Substitute the FD_TOK_WILD with FD_TOK_SYM. */
      token->id = FD_TOK_SYM;
      FD_StringFree( stringCache, token->value );
      token->value = FD_StringDup( stringCache, fileIndexPriv->wildOneOrMoreChar );
   }
   else
   {
      token = searchIdInLastLeg( SEARCH_BACKWARD, fileIndexPriv, FD_TOK_FIX );

      if( token )
      {
         FD_ASSERT( token->id == FD_TOK_FIX );
         FD_ASSERT( token->value != NULL );

         /* str will point on the leftmost dot if one is found.
          * 'dotPos' will indicate offset of the dot in the string (zero base).
          */
         str = (char *)findDot( FD_StringToChar( token->value ), &dotPos );

         if( str )
         {
            /* !!! needed?
            FD_ASSERT( dotPos != 0 ); */
             
            /* Some validity check (parano).
             * Check that there is something before and after the dot...
             */
            if( (*(str+1) == '\0') || (str == FD_StringToChar( token->value )) )
            {
               FD_TRACE_RETURN( FD_INVALID_PATH );
            }

            /* Create a new FD_TOK_SF field using the character before the dot. */
            tmpPtr = FD_StringAllocN( stringCache, FD_StringToChar( token->value ), dotPos );
            if( !tmpPtr )
            {
               FD_TRACE_RETURN( FD_ALLOC_ERR );
            }

            retCode = FD_FileIndexAddTokenInfo( fileIndexPriv, FD_TOK_SYMF, tmpPtr, token );
            FD_StringFree( stringCache, tmpPtr );
            if( retCode != FD_SUCCESS )
            {
               FD_TRACE_RETURN( retCode );
            }

            /* Adjust the FD_TOK_FIX by keeping only the characters after the dot. */
            tmpPtr = FD_StringAlloc( stringCache, str );
            if( !tmpPtr )
            {
               FD_TRACE_RETURN( FD_ALLOC_ERR );
            }

            FD_StringFree( stringCache, token->value );
            token->value = tmpPtr;
         }
         else
         {
             /* There is no dot... the FD_TOK_FIX becomes a FD_TOK_SF. */
             token->id = FD_TOK_SYMF;
         }
      }
   }

   FD_TRACE_RETURN( FD_INVALID_PATH );
}

#if 0
static void displayTokens( FD_FileIndexPriv *fileIndexPriv )
{
   FD_TokenInfo *token;
   FD_List *list = fileIndexPriv->listLocationToken;
   const char *str;

   printf( "Token List: " );

   token = (FD_TokenInfo *)FD_ListAccessHead( list );

   if( token == NULL )
      printf( "empty!\n" );
   else
   {
      do
      {
         str = FD_TokenDebugString( token->id );

         if( !str )
            printf( "[(null)] " );
         else
         {
            if( token->id == FD_TOK_SEP )
               printf( "%s", FD_StringToChar( token->value ) );
            else if( token->id == FD_TOK_FIX )
               printf( "%s", FD_StringToChar( token->value ) );
            else if( token->value )
               printf( "[%s=%s]", str, FD_StringToChar( token->value ) );
            else
               printf( "[%s]", str );
         }

         token = (FD_TokenInfo *)FD_ListAccessNext( list );
      }while( token );

      printf( "\n" );
   }
}

#endif
