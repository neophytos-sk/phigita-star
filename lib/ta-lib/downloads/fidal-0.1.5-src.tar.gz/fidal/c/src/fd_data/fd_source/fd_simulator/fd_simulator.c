/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  062105 PK   Simulator can produce end-of-period timestamped data.
 *
 */

/* Description:
 *    This is the entry points of the data source driver for FD_Simulator.
 *
 *    It provides ALL the functions needed by the "FD_DataSourceDriver"
 *    structure (see fd_source.h).
 */

/**** Headers ****/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "fd_source.h"
#include "fd_simulator.h"
#include "fd_common.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_list.h"
#include "fidal.h"
#include "fd_system.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
#define FD_REF_DAILY_NB_BARS 252 /* from fd_daily_ref_0.c */
extern FD_Timestamp FD_SREF_timestamp_daily_ref_0_PRIV [FD_REF_DAILY_NB_BARS];
extern FD_Real      FD_SREF_open_daily_ref_0_PRIV      [FD_REF_DAILY_NB_BARS];
extern FD_Real      FD_SREF_high_daily_ref_0_PRIV      [FD_REF_DAILY_NB_BARS];
extern FD_Real      FD_SREF_low_daily_ref_0_PRIV       [FD_REF_DAILY_NB_BARS];
extern FD_Real      FD_SREF_close_daily_ref_0_PRIV     [FD_REF_DAILY_NB_BARS];
extern FD_Integer   FD_SREF_volume_daily_ref_0_PRIV    [FD_REF_DAILY_NB_BARS];

#define FD_REF_INTRA_NB_BARS 33 /* from fd_intra_ref_0.c */
extern FD_Timestamp FD_SREF_timestamp_intra_ref_0_PRIV [FD_REF_INTRA_NB_BARS];
extern FD_Real      FD_SREF_open_intra_ref_0_PRIV      [FD_REF_INTRA_NB_BARS];
extern FD_Real      FD_SREF_high_intra_ref_0_PRIV      [FD_REF_INTRA_NB_BARS];
extern FD_Real      FD_SREF_low_intra_ref_0_PRIV       [FD_REF_INTRA_NB_BARS];
extern FD_Real      FD_SREF_close_intra_ref_0_PRIV     [FD_REF_INTRA_NB_BARS];

extern const char FD_MRG_0_DAFD_PRIV[1000]; /* from fd_mrg_0.c */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   /* Put everything in the Data source handle.
    * This is slightly a kludge approach... 
    * but it will do since there a fix and limited
    * amount of category and symbol to handle for
    * this data source.
    */
   unsigned int categoryIter;
   unsigned int catRefIter;
   unsigned int catMrgIter;
   FD_String *ta_sim_ref_cat;
   FD_String *ta_sim_mrg_cat;
   FD_String *daily_ref_0;
   FD_String *intra_ref_0;
   FD_String *mrg_0;

   unsigned int mrgAllocated; /* boolean */
   unsigned int mrgInstance;  /* 1,2,3,4 */
   FD_History   mrgHistory;
   FD_SourceFlag flags;

} FD_PrivateHandle;

/**** Local functions declarations.    ****/
static void freePrivateHandle( FD_PrivateHandle *privData );
static FD_RetCode addSimMrgData( FD_PrivateHandle *privData,
                                 FD_ParamForAddData  *paramForAddData );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_SIMULATOR_InitializeSourceDriver( void )
{
   FD_PROLOG

   FD_TRACE_BEGIN(  FD_SIMULATOR_InitializeSourceDriver );

   /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_ShutdownSourceDriver( void )
{
   FD_PROLOG

   FD_TRACE_BEGIN(  FD_SIMULATOR_ShutdownSourceDriver );

   /* Nothing to do for the time being. */
   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetParameters( FD_DataSourceParameters *param )
{
   FD_PROLOG

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetParameters );
   memset( param, 0, sizeof( FD_DataSourceParameters ) );

   /* All parameters are zero */
   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_SIMULATOR_OpenSource( const FD_AddDataSourceParamPriv *param,
                                    FD_DataSourceHandle **handle )
{
   FD_PROLOG
   FD_DataSourceHandle *tmpHandle;
   FD_PrivateHandle *privData;
   FD_StringCache *stringCache;

   *handle = NULL;

   FD_TRACE_BEGIN(  FD_SIMULATOR_OpenSource );

   stringCache = FD_GetGlobalStringCache();

   if( !stringCache )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(91) );
   }

   /* Allocate and initialize the handle. This function will also allocate the
    * private handle (opaque data).
    */
   tmpHandle = (FD_DataSourceHandle *)FD_Malloc( sizeof( FD_DataSourceHandle ) );

   if( tmpHandle == NULL )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( tmpHandle, 0, sizeof( FD_DataSourceHandle ) );

   privData = (FD_PrivateHandle *)FD_Malloc( sizeof( FD_PrivateHandle ) );
   if( !privData )
   {
      FD_Free(  tmpHandle );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( privData, 0, sizeof( FD_PrivateHandle ) );

   tmpHandle->opaqueData = privData;

   /* Copy some parameters in the private handle. */
   privData->categoryIter = 0;   
   privData->catRefIter   = 0;
   privData->catMrgIter   = 0;

   if( param->info == NULL )
   {
      privData->mrgInstance = 0;
      tmpHandle->nbCategory = 1;
   }
   else
   {
      privData->mrgInstance = atoi( FD_StringToChar( param->info ) );

      if( (privData->mrgInstance < 1) || (privData->mrgInstance > 4) )
      {
         FD_Free(  tmpHandle );
         FD_Free(  privData );
         FD_TRACE_RETURN( FD_BAD_PARAM );
      }

      tmpHandle->nbCategory = 2;

      /* Allocate the data. */
      
   }

   /* Pre-allocate all the string used in this data source. */
   privData->ta_sim_ref_cat = FD_StringAlloc(stringCache, "FD_SIM_REF");
   privData->ta_sim_mrg_cat = FD_StringAlloc(stringCache, "FD_SIM_MRG");
   privData->daily_ref_0    = FD_StringAlloc(stringCache, "DAILY_REF_0");
   privData->intra_ref_0    = FD_StringAlloc(stringCache, "INTRA_REF_0");
   privData->mrg_0          = FD_StringAlloc(stringCache, "MRG_0");

   if( !privData->ta_sim_ref_cat ||
       !privData->ta_sim_mrg_cat ||
       !privData->daily_ref_0 ||
       !privData->intra_ref_0 ||
       !privData->mrg_0 )
   {
      freePrivateHandle( privData );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   privData->flags = param->flags;

   /* Everything is fine, return the handle to the caller. */
   *handle = tmpHandle;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_CloseSource( FD_DataSourceHandle *handle )
{
   FD_PROLOG

   FD_PrivateHandle *privData;

   FD_TRACE_BEGIN(  FD_SIMULATOR_CloseSource );

   /* Free all ressource used by this handle. */
   if( handle )
   {
      privData = (FD_PrivateHandle *)handle->opaqueData;

      if( privData )
         freePrivateHandle( privData );

      FD_Free(  handle );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                                FD_CategoryHandle   *categoryHandle )
{
   FD_PROLOG

   FD_PrivateHandle *privData;

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetFirstCategoryHandle );

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(92) );
   }

   categoryHandle->nbSymbol = 2;
   categoryHandle->string = privData->ta_sim_ref_cat;
   categoryHandle->opaqueData = 0;

   privData->categoryIter = 1;   

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetNextCategoryHandle( FD_DataSourceHandle *handle,
                                               FD_CategoryHandle   *categoryHandle,
                                               unsigned int index )
{
   FD_PROLOG
   FD_PrivateHandle *privData;

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetNextCategoryHandle );

   (void)index; /* Get ride of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(93) );
   }

   /* No category left. */
   if( privData->categoryIter >= 2 )
   {
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   }

   /* Set the categoryHandle. */
   categoryHandle->string = privData->ta_sim_mrg_cat;
   categoryHandle->nbSymbol = 1;
   categoryHandle->opaqueData = (void *)1;

   privData->categoryIter++;

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                              FD_CategoryHandle   *categoryHandle,
                                              FD_SymbolHandle     *symbolHandle )
{
   FD_PROLOG
   FD_PrivateHandle *privData;

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetFirstSymbolHandle );

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateHandle *)(handle->opaqueData);

   if( !privData || !categoryHandle->string )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(94) );
   }

   /* Get the first symbol in this category. */
   switch( (unsigned long)categoryHandle->opaqueData )
   {
   case 0: /* This is FD_SIM_REF */
      privData->catRefIter = 1;
      symbolHandle->string = privData->daily_ref_0;
      symbolHandle->opaqueData = (void *)0;      
      break;
   case 1: /* This is FD_SIM_MRG */
      privData->catMrgIter = 1;
      symbolHandle->string = privData->mrg_0;
      symbolHandle->opaqueData = (void *)0;      
      break;
   default:
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(95) );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                             FD_CategoryHandle   *categoryHandle,
                                             FD_SymbolHandle     *symbolHandle,
                                             unsigned int index )
{
   FD_PROLOG
   FD_PrivateHandle *privData;

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetNextSymbolHandle );

   (void)index; /* Get ride of compiler warnings. */

   if( (handle == NULL) || (categoryHandle == NULL) || (symbolHandle == NULL) )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   privData = (FD_PrivateHandle *)(handle->opaqueData);

   if( !privData )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(96) );
   }
   /* Get the first symbol in this category. */
   switch( (unsigned long)categoryHandle->opaqueData )
   {
   case 0: /* This is FD_SIM_REF */
      if( privData->catRefIter == 1 )
      {
         symbolHandle->string = privData->intra_ref_0;
         symbolHandle->opaqueData = (void *)1;
         privData->catRefIter = 2;
      }
      else
      {
         FD_TRACE_RETURN( FD_END_OF_INDEX );
      }
      break;
   case 1: /* This is FD_SIM_MRG */
      FD_TRACE_RETURN( FD_END_OF_INDEX );
   default:
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(97) );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_SIMULATOR_GetHistoryData( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle   *categoryHandle,
                                        FD_SymbolHandle     *symbolHandle,
                                        FD_Period            period,
                                        const FD_Timestamp  *start,
                                        const FD_Timestamp  *end,
                                        FD_Field             fieldToAlloc,
                                        FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG
   FD_PrivateHandle *privateHandle;
   FD_RetCode retCode;
   FD_Timestamp *timestamp;
   FD_Real *open, *high, *low, *close;
   FD_Integer *volume;
   unsigned int i;

   (void)fieldToAlloc;
   (void)end;
   (void)start;
   (void)period;

   FD_TRACE_BEGIN(  FD_SIMULATOR_GetHistoryData );

   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateHandle *)handle->opaqueData;
   FD_ASSERT( privateHandle != NULL );
   FD_ASSERT( paramForAddData != NULL );
   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );

   retCode = FD_INTERNAL_ERROR(98);

   /* Note: start/end index are currently ignored
    *       in this data source.
    */

   /* Identify the category. */
   switch( (unsigned long)categoryHandle->opaqueData )
   {
   case 0: /* This is FD_SIM_REF */
      switch( (unsigned long)symbolHandle->opaqueData )
      {
      case 0: /* DAILY_REF_0 */
          timestamp = (FD_Timestamp *)NULL;
          open = high = low = close = (FD_Real *)NULL;
          volume = (FD_Integer *)NULL;

          #define FD_FIELD_ALLOC_COPY( varName, varType, varSize) { \
             varName = FD_Malloc( sizeof( varType ) * varSize ); \
             if( !varName ) \
             { \
                FREE_IF_NOT_NULL( open         ); \
                FREE_IF_NOT_NULL( high         ); \
                FREE_IF_NOT_NULL( low          ); \
                FREE_IF_NOT_NULL( close        ); \
                FREE_IF_NOT_NULL( volume       ); \
                FD_TRACE_RETURN( FD_ALLOC_ERR ); \
             } \
             memcpy( varName, FD_SREF_##varName##_daily_ref_0_PRIV, sizeof( varType )*varSize ); }

             FD_FIELD_ALLOC_COPY( open,      FD_Real,      FD_REF_DAILY_NB_BARS );
             FD_FIELD_ALLOC_COPY( high,      FD_Real,      FD_REF_DAILY_NB_BARS );
             FD_FIELD_ALLOC_COPY( low,       FD_Real,      FD_REF_DAILY_NB_BARS );
             FD_FIELD_ALLOC_COPY( close,     FD_Real,      FD_REF_DAILY_NB_BARS );
             FD_FIELD_ALLOC_COPY( volume,    FD_Integer,   FD_REF_DAILY_NB_BARS );         
         #undef FD_FIELD_ALLOC_COPY

         /* Set the timestamp. */
         timestamp = FD_Malloc( sizeof( FD_Timestamp ) * FD_REF_DAILY_NB_BARS );
         if( !timestamp )
         {
            FD_Free(  open   );
            FD_Free(  high   );
            FD_Free(  low    );
            FD_Free(  close  );
            FD_Free(  volume );
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }

         for( i=0; i < FD_REF_DAILY_NB_BARS; i++ )
            FD_TimestampCopy( &timestamp[i], &FD_SREF_timestamp_daily_ref_0_PRIV[i] );

         if( privateHandle->flags & FD_SOURCE_USES_END_OF_PERIOD )
         {
             for( i=0; i < FD_REF_DAILY_NB_BARS; i++ )
                 FD_NextDay( &timestamp[i] );
         }

          retCode = FD_HistoryAddData( paramForAddData,
                                       FD_REF_DAILY_NB_BARS, FD_DAILY,                                      
                                       timestamp,
                                       open, high,                                      
                                       low, close,
                                       volume, NULL );                                      
          break;

      case 1: /* INTRA_REF_0 */
          /* Allocate the rest. */
          timestamp = (FD_Timestamp *)NULL;
          open = high = low = close = (FD_Real *)NULL;

          #define FD_FIELD_ALLOC_COPY( varName, varType, varSize) { \
                  varName = FD_Malloc( sizeof( varType ) * varSize ); \
                  if( !varName ) \
                  { \
                     FD_Free(  timestamp ); \
                     FREE_IF_NOT_NULL( open      ); \
                     FREE_IF_NOT_NULL( high      ); \
                     FREE_IF_NOT_NULL( low       ); \
                     FREE_IF_NOT_NULL( close     ); \
                     FD_TRACE_RETURN( FD_ALLOC_ERR ); \
                  } \
                  memcpy( varName, FD_SREF_##varName##_daily_ref_0_PRIV, sizeof( varType )*varSize ); }

         FD_FIELD_ALLOC_COPY( open,      FD_Real,      FD_REF_INTRA_NB_BARS );
         FD_FIELD_ALLOC_COPY( high,      FD_Real,      FD_REF_INTRA_NB_BARS );
         FD_FIELD_ALLOC_COPY( low,       FD_Real,      FD_REF_INTRA_NB_BARS );
         FD_FIELD_ALLOC_COPY( close,     FD_Real,      FD_REF_INTRA_NB_BARS );
         #undef FD_FIELD_ALLOC_COPY

         /* Set the timestamp. */
         timestamp = (FD_Timestamp *)FD_Malloc( sizeof( FD_Timestamp ) * FD_REF_INTRA_NB_BARS );
         if( !timestamp )
         {
            FREE_IF_NOT_NULL( open  );
            FREE_IF_NOT_NULL( high  );
            FREE_IF_NOT_NULL( low   );
            FREE_IF_NOT_NULL( close );
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }

         for( i=0; i < FD_REF_INTRA_NB_BARS; i++ )
         {
            if( privateHandle->flags & FD_SOURCE_USES_END_OF_PERIOD )
               FD_AddTimeToTimestamp( &timestamp[i], &FD_SREF_timestamp_intra_ref_0_PRIV[i], FD_10MINS );
            else
               FD_TimestampCopy( &timestamp[i], &FD_SREF_timestamp_intra_ref_0_PRIV[i] );
         }

         retCode = FD_HistoryAddData( paramForAddData,
                                      FD_REF_INTRA_NB_BARS, FD_10MINS,
                                      timestamp,
                                      open, high,                                      
                                      low, close,                                      
                                      NULL, NULL );
                                      
         break;
      }
      break;

   case 1: /* This is FD_SIM_MRG */
      retCode = addSimMrgData( privateHandle, 
                               paramForAddData );
      break;
   }

   FD_TRACE_RETURN( retCode );
}

/**** Local functions definitions.     ****/
static void freePrivateHandle( FD_PrivateHandle *privData )
{
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   if( stringCache )
   {
      if( privData->ta_sim_ref_cat )
         FD_StringFree( stringCache, privData->ta_sim_ref_cat );

      if( privData->ta_sim_mrg_cat )
         FD_StringFree( stringCache, privData->ta_sim_mrg_cat );

      if( privData->daily_ref_0 )
         FD_StringFree( stringCache, privData->daily_ref_0 );

      if( privData->intra_ref_0 )
         FD_StringFree( stringCache, privData->intra_ref_0 );

      if( privData->mrg_0 )
         FD_StringFree( stringCache, privData->mrg_0 );
   }

   FREE_IF_NOT_NULL( privData->mrgHistory.open );
   FREE_IF_NOT_NULL( privData->mrgHistory.high );
   FREE_IF_NOT_NULL( privData->mrgHistory.low );
   FREE_IF_NOT_NULL( privData->mrgHistory.close );
   FREE_IF_NOT_NULL( privData->mrgHistory.volume );
   FREE_IF_NOT_NULL( privData->mrgHistory.openInterest );
   FREE_IF_NOT_NULL( privData->mrgHistory.timestamp );

   FD_Free(  privData );    
}


static FD_RetCode addSimMrgData( FD_PrivateHandle *privData,
                                 FD_ParamForAddData  *paramForAddData )
{
   (void)paramForAddData;
   (void)privData;
#if 0
   /* Allocate the data if not already done. */
   if( !privData->mrgAllocated )
   {
      memset( privData->mrgHistory, 0, sizeof( FD_History ) );
      privData->mrgHistory.open         = FD_Malloc( sizeof( FD_Real ) * 1000 ) );
      privData->mrgHistory.high         = FD_Malloc( sizeof( FD_Real ) * 1000 ) );
      privData->mrgHistory.low          = FD_Malloc( sizeof( FD_Real ) * 1000 ) );
      privData->mrgHistory.close        = FD_Malloc( sizeof( FD_Real ) * 1000 ) );
      privData->mrgHistory.volume       = FD_Malloc( sizeof( FD_Integer ) * 1000 ) );
      privData->mrgHistory.openInterest = FD_Malloc( sizeof( FD_Integer ) * 1000 ) );
      privData->mrgHistory.timestamp    = FD_Malloc( sizeof( FD_Timestamp ) * 1000 ) );

      if( !privData->mrgHistory.open         ||
          !privData->mrgHistory.high         ||
          !privData->mrgHistory.low          ||
          !privData->mrgHistory.close        ||
          !privData->mrgHistory.volume       ||
          !privData->mrgHistory.openInterest ||
          !privData->mrgHistory.timestamp )
      {
         FREE_IF_NOT_NULL( privData->mrgHistory.open );
         FREE_IF_NOT_NULL( privData->mrgHistory.high );
         FREE_IF_NOT_NULL( privData->mrgHistory.low );
         FREE_IF_NOT_NULL( privData->mrgHistory.close );
         FREE_IF_NOT_NULL( privData->mrgHistory.volume );
         FREE_IF_NOT_NULL( privData->mrgHistory.openInterest );
         FREE_IF_NOT_NULL( privData->mrgHistory.timestamp );
         return FD_ALLOC_ERR;
      }
   }
#endif

   return FD_SUCCESS;
}
