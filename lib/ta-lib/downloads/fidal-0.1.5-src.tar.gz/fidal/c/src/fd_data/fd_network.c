/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  052101 MF   First version.
 *  060302 MF   Add better retry/timeout mechanism.
 *  121204 MF   Return FD_INTERNET_NO_CONTENT when a HTTP response
 *              has no content.
 */

/* Description:
 *    Provides functionality for fetching data from internet.
 *    
 *    On WIN32, both the WinInet or libCurl library are
 *    supported. WinInet is the prefered choice.
 *
 *    On all unix platform, libCurl is used.
 */

/* #define DEBUG_PRINTF 1 */

/**** Headers ****/
#if !defined( USE_WININET ) && !defined( USE_LIBCURL )
   /* If the user does not specify its preference in
    * the makefile options, use the default choices.
    */
   #if defined( WIN32 )
      /* Win32 platform use WinInet.lib by default. */
      #define USE_WININET
   #else
      /* All non-win32 platform use libCurl.lib by default. */
      #define USE_LIBCURL
   #endif
#endif

/* Just check for unsupported setup */
#if defined(LIBCURL) && defined(USE_WININET)
#error You must choose bettween LIBCURL and WinInet!
#endif

#if defined(USE_WININET) && !defined(WIN32)
#error WinInet can be used only on win32 platform.
#endif

#include <string.h>

#include "fd_common.h"
#include "fd_trace.h"
#include "fd_magic_nb.h"
#include "fd_system.h"
#include "fd_global.h"
#include "fd_memory.h"
#include "fd_network.h"
#include "fd_source.h"

#if defined( USE_WININET )
   #include "windows.h"
   #include "wininet.h"   
#endif

#if defined( USE_LIBCURL )
   #include "curl/curl.h"
#endif

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
FD_FILE_INFO;

#define BUFFER_SIZE 1500

typedef struct
{
   unsigned int magicNb;

   /* Variables describing where and how to fetch the data. */
   const char *webSiteAddr;
   const char *webSitePage;
   const char *proxyName;
   const char *proxyPort;
   
   /* Final result. 0 if success. OS dependent. */
   unsigned int finalErrorCode; 

   /* Final result from FIDAL. */
   FD_RetCode finalRetCode;

} FD_WebPageHiddenData;

typedef struct
{
   /* Indicate if fundamental initialization succeed,
    * if not, all subsequent network operations will
    * failed gracefuly.
    */
   unsigned int initialized; 

   #if defined( USE_WININET )
   /* Indicate if a connection to internet
    * is currently active. Protected by
    * a mutexSema.
    */
   unsigned int connected;

   /* Will be different of NULL when connected.
    * must be freed at shutdown.
    */
   HINTERNET hInternet;
   #endif

   #if defined( USE_LIBCURL )
   CURL *curlHandle;
   #endif

   #if !defined( FD_SINGLE_THREAD )
   /* Serialize the web access for the time being,
    * until appropriate stress testing is done.
    *
    * On Win32/WinInet, this mutex is also used to protect
    * the variable 'connected' to make sure only one task
    * proceed to initialize the internet connection.
    */
   FD_Sema mutexSema;
   #endif

} FD_NetworkGlobal;

/**** Local functions declarations.    ****/
FD_RetCode internalWebPageAlloc( const char    *webSiteAddr,
                                 const char    *webSitePage,
                                 const char    *proxyName,
                                 const char    *proxyPort,
                                 FD_WebPage   **webPageAllocated );

static FD_RetCode FD_NetworkGlobalInit    ( void **globalToAlloc );
static FD_RetCode FD_NetworkGlobalShutdown( void *globalAllocated );

#if defined( USE_WININET )
static FD_RetCode fetchUsingWinInet( FD_NetworkGlobal *global,
                                     FD_WebPage       *webPage );

static FD_RetCode buildListDataWinInet( FD_WebPage *webPage,
                                        HINTERNET hRessource );

static FD_RetCode FD_SetReceiveTimeout( unsigned long receiveTimeout,
                                        HINTERNET hWebPage );
#endif

#if defined( USE_LIBCURL )
static FD_RetCode fetchUsingLibCurl( FD_NetworkGlobal *global,
                                     FD_WebPage       *webPage );
static FD_RetCode rfc1945StatusToRetCode( unsigned int httpErrorCode );

size_t libcurlWriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data);
#endif


/**** Local variables definitions.     ****/
const FD_GlobalControl FD_NetworkGlobalControl =
{
   FD_NETWORK_GLOBAL_ID,
   FD_NetworkGlobalInit,
   FD_NetworkGlobalShutdown
};

/**** Global functions definitions.   ****/
FD_RetCode FD_WebPageAlloc( const char    *webSiteAddr,
                            const char    *webSitePage,
                            const char    *proxyName,
                            const char    *proxyPort,
                            FD_WebPage   **webPageAllocated,
                            unsigned int   nbAttempt,
                            void          *paramForAddData )
{
   FD_RetCode retCode;
   unsigned int i,j, k;
   FD_ParamForAddData *paramForAddDataPtr;

   paramForAddDataPtr = (FD_ParamForAddData *)paramForAddData;

   /* Make sure there is at least one attempt. */
   if( nbAttempt == 0 )
      nbAttempt = 1;

   /* Do not attempt more than 50 times (realistic upper limit). */
   if( nbAttempt > 50 )
      nbAttempt = 50;

   retCode = FD_SUCCESS;

   for( i=0; i < nbAttempt; i++ )
   {
      if( i > 0 )
      {
         /* Some delay before a new attempt. 
          * We do not want to irritate the server.
          * Wait up to 20 seconds.
          */
         j = i*2;
         if( j > 20 ) j = 20;

         retCode = FD_DriverShouldContinue(paramForAddDataPtr);
         k = 0;
         while( (retCode == FD_SUCCESS) && (k++<j) )
         {
            FD_Sleep( 1 ); 
            retCode = FD_DriverShouldContinue(paramForAddDataPtr);
         }
         if( retCode != FD_SUCCESS )
            return retCode;
      }

      /* On data retreival problems, keep retrying
       * many times. FD_INTERNET_READ_DATA_FAILED means
       * that the server can be reached, but somehow the 
       * transmission of the data was interupted. So it is
       * worth to give multiple re-try immediatly.
       *
       * All other type of failure will retry
       * only "nbAttempt" times.
       */
      retCode = FD_INTERNET_READ_DATA_FAILED;
      for( j=0; (retCode == FD_INTERNET_READ_DATA_FAILED) && (j < 100); j++ )
      {
         retCode = internalWebPageAlloc( webSiteAddr,
                                         webSitePage,
                                         proxyName,
                                         proxyPort,
                                         webPageAllocated );
         if( retCode == FD_INTERNET_READ_DATA_FAILED )
            FD_Sleep( 1 ); /* 1 second */
      }

      if( retCode == FD_SUCCESS )
         return FD_SUCCESS;
   }

   return retCode;
}


FD_RetCode FD_WebPageFree( FD_WebPage *webPage )
{
   FD_WebPageHiddenData *hiddenData;

   if( webPage ) 
   {      
      hiddenData = webPage->hiddenData;
      if( !hiddenData )
         return FD_INTERNAL_ERROR(32);

      if( hiddenData->magicNb != FD_WEBPAGE_MAGIC_NB )
         return FD_BAD_OBJECT;

      /* The object is validated, can start to free ressources
       * from this point.
       */

      /* Free private data */
      FD_Free( hiddenData );

      /* Free public data. */
      if( webPage->content )
         FD_StreamFree( webPage->content );

      FD_Free( webPage );
   }

   return FD_SUCCESS;
}

/**** Local functions definitions.     ****/
static FD_RetCode FD_NetworkGlobalInit( void **globalToAlloc )
{
   #if !defined( FD_SINGLE_THREAD )
   FD_RetCode retCode;
   #endif
   FD_NetworkGlobal *global;

   if( !globalToAlloc )
      return FD_BAD_PARAM;

   *globalToAlloc = NULL;

   #if defined( USE_LIBCURL )
      #if defined(WIN32)
         if( curl_global_init(CURL_GLOBAL_WIN32) != CURLE_OK )
            return FD_LIBCURL_GLOBAL_INIT_FAILED;
      #else
         if( curl_global_init(CURL_GLOBAL_NOTHING) != CURLE_OK )
            return FD_LIBCURL_GLOBAL_INIT_FAILED;
      #endif
   #endif

   global = (FD_NetworkGlobal *)FD_Malloc( sizeof( FD_NetworkGlobal ) );
   if( !global )
      return FD_ALLOC_ERR;

   memset( global, 0, sizeof( FD_NetworkGlobal ) );

   #if defined( USE_LIBCURL )
      global->curlHandle = curl_easy_init();
      if( global->curlHandle == NULL )
      {
         FD_Free(  global );
         return FD_LIBCURL_INIT_FAILED;
      }
   #endif

   #if !defined( FD_SINGLE_THREAD )
      /* Initialize the mutex in a non-block state. */
      retCode = FD_SemaInit( &global->mutexSema, 1 );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(  global );
         return retCode;
      }
   #endif

   global->initialized = 1;

   /* Success, return the allocated memory to the caller. */
   *globalToAlloc = global;
   return FD_SUCCESS;
}

static FD_RetCode FD_NetworkGlobalShutdown( void *globalAllocated )
{
   FD_NetworkGlobal *global;
   FD_RetCode retCode = FD_SUCCESS;

   global = (FD_NetworkGlobal *)globalAllocated;

   if( !global )
      return retCode;

   if( global->initialized )
   {
      #if defined( USE_WININET )
         if( global->hInternet )
            InternetCloseHandle( global->hInternet);
      #endif

      #if defined( USE_LIBCURL )
         curl_global_cleanup();
      #endif

      global->initialized = 0;
   }

   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaDestroy( &global->mutexSema );
   #endif

   FD_Free( global );

   return retCode;
}

#if defined( USE_LIBCURL )
static FD_RetCode fetchUsingLibCurl( FD_NetworkGlobal *global,
                                     FD_WebPage       *webPage )
{
   FD_PROLOG

   FD_RetCode retCode;
   FD_WebPageHiddenData *webPageHidden;
   const char *string1, *string2, *string3;
   unsigned int urlLength;
   char *urlString;
   CURLcode retValue;
   long curlInfo;

   FD_TRACE_BEGIN( fetchUsingLibCurl );

   FD_ASSERT( webPage != NULL );

   webPageHidden = (FD_WebPageHiddenData *)webPage->hiddenData;   
  
   /* Open an internet session. */

   /* Create the URL. */
   string1 = "http://";
   urlLength = strlen( string1 ) + 1;
   if( webPageHidden->webSiteAddr )
   {
      string2 = webPageHidden->webSiteAddr;
      urlLength += strlen( string2 );
   }
   else
      string2 = NULL;

   if( webPageHidden->webSitePage )
   {
      string3 = webPageHidden->webSitePage;
      urlLength += strlen( string3 ) + 1;
   }
   else
      string3 = NULL;

   urlString = FD_Malloc( urlLength );
   if( !urlString )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   sprintf( urlString, "%s%s%s%s", string1? string1:"",
                             string2? string2:"", 
                             string3 && string3[0] != '/'? "/":"", 
                             string3? string3:"" );
   
   /* Serialize the request until a stress testing 
    * application proove that libcurl is multi-thread safe.
    */
   #if !defined( FD_SINGLE_THREAD )
      retCode = FD_SemaWait( &global->mutexSema );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(  urlString );
         FD_TRACE_RETURN( retCode );
      }
   #endif

   /* Specify URL to get */
   curl_easy_setopt(global->curlHandle, CURLOPT_URL, urlString );
 
   /* Send all data to the callback function  */
   curl_easy_setopt(global->curlHandle, CURLOPT_WRITEFUNCTION,
                    libcurlWriteMemoryCallback);
 
   /* Specify the opaque data ptr for the callback function */
   curl_easy_setopt(global->curlHandle, CURLOPT_FILE, (void *)webPage);

   /* Fetch it. */
   retValue = curl_easy_perform(global->curlHandle);

   if( retValue == CURLE_OK )
      retCode = FD_SUCCESS;
   else
   {
      retValue = curl_easy_getinfo( global->curlHandle, CURLINFO_HTTP_CODE, &curlInfo );
      if( retValue == CURLE_OK )
         retCode = rfc1945StatusToRetCode( curlInfo );
      else
         retCode = FD_HTTP_SC_UNKNOWN;
   }

   #if !defined( FD_SINGLE_THREAD )
      FD_SemaPost( &global->mutexSema  );
   #endif

   /* Free the url. */
   FD_Free(  urlString );

   FD_TRACE_RETURN( retCode );
}

size_t libcurlWriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data)
{
   register int bufferSize;
   FD_WebPage *webPage;
   FD_WebPageHiddenData *webPageHidden;
   FD_RetCode retCode;
   char *buffer;

   webPage = (FD_WebPage *)data;
   webPageHidden = (FD_WebPageHiddenData *)webPage->hiddenData;   

   bufferSize = size * nmemb;
   
   /* Make a copy of the provided data. */
   buffer = FD_Malloc( bufferSize );
   if( !buffer )
      return 0; /* Error. */

   memcpy( buffer, ptr, bufferSize );

   /* Add the data to the stream. */
   if( !webPage->content )
   {
      /* The first buffer will initiate the creation of
       * the stream.
       */
      webPage->content = FD_StreamAllocFromBuffer( buffer, bufferSize,
                                                   NULL, NULL );

      if( !webPage->content )
      {
         FD_Free(  buffer );
         return 0; /* Error. */
      }
   }
   else
   {
      /* Add the buffer to the stream. */
      retCode = FD_StreamAddBuffer( webPage->content, 
                                    buffer, bufferSize,
                                    NULL, NULL );
      if( retCode != FD_SUCCESS )
      {
         FD_Free(  buffer );
         return 0; /* Error */
      }
   }

   return bufferSize;
}
#endif

#if defined( USE_WININET )
static FD_RetCode fetchUsingWinInet( FD_NetworkGlobal *global,
                                     FD_WebPage       *webPage )
{
   FD_PROLOG

   FD_RetCode retCode;
   DWORD retDWORD;
   LPCTSTR lpszProxyName;
   FD_WebPageHiddenData *webPageHidden;
   HINTERNET hSession, hWebPage;

   FD_TRACE_BEGIN( fetchUsingWinInet );

   webPageHidden = (FD_WebPageHiddenData *)webPage->hiddenData;   

   retCode = FD_SUCCESS; /* Will change if an error occured. */
   if( !global->connected )
   {
      #if !defined( FD_SINGLE_THREAD )
         FD_SemaWait( &global->mutexSema );
      #endif

         /* Check again if connected within the mutex. To avoid
          * multiple task to initialize at the same time.
          */
         if( !global->connected )
         {                  
            /* Open and verify connection with a known URL. */
            retDWORD = InternetAttemptConnect(0);
            if( retDWORD != ERROR_SUCCESS )
               retCode = FD_NO_INTERNET_CONNECTION;
            else
            {
               /* needed?
                if( InternetCheckConnection((LPCTSTR)NULL, FLAG_ICC_FORCE_CONNECTION, 0 ) != 0 )
                  retCode = FD_INTERNET_ACCESS_FAILED;
                */

               /* Ok.. the last step is to get an handle used for
                * retreiving the Web pages.
                */
               if( webPageHidden->proxyName )
               {           
                  lpszProxyName = FD_Malloc( 100 + strlen( webPageHidden->proxyName ) );
                  if( !lpszProxyName )
                     retCode = FD_ALLOC_ERR;
                  else
                     sprintf( (char *)lpszProxyName, "http=http://%s:%s",
                              webPageHidden->proxyName,
                              webPageHidden->proxyPort? "80":webPageHidden->proxyPort );                      
               }
               else
                  lpszProxyName = NULL;
               
               if( retCode == FD_SUCCESS ) 
               {
                  global->hInternet = InternetOpen( "FIDAL",
                                                    INTERNET_OPEN_TYPE_PRECONFIG,
                                                     lpszProxyName, NULL, 0 );
               }

               if( lpszProxyName )
                  FD_Free(  (void *)lpszProxyName );

            }

            if( !global->hInternet )
               webPageHidden->finalErrorCode = GetLastError();
            else
            {
               /* Success. Set a variable to avoid to connect again.
                * This variable will also make sure that the hInternet
                * is freed upon shutdown.
                */
               global->connected = 1; /* Success */
            }
         }
      #if !defined( FD_SINGLE_THREAD )
         FD_SemaPost( &global->mutexSema  );
      #endif

      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }            
   }

   if( !global->hInternet )
   {
      /* May be returned in multi-thread situation if
       * the inital thread did not yet complete or succeed
       * to establish the internet access.
       */
      FD_TRACE_RETURN( FD_INTERNET_NOT_OPEN_TRY_AGAIN );
   }
  
   /* Open an internet session. */
   hSession = InternetConnect( global->hInternet,
                               webPageHidden->webSiteAddr,
                               INTERNET_DEFAULT_HTTP_PORT,
                               NULL, NULL,
                               (unsigned long)INTERNET_SERVICE_HTTP,
                               0, 0 );

   if( !hSession )
   {
      /* Did not work.... mmmm.... always try a second time. */
      hSession = InternetConnect( global->hInternet,
                                  webPageHidden->webSiteAddr,
                                  INTERNET_DEFAULT_HTTP_PORT,
                                  NULL, NULL,
                                  (unsigned long)INTERNET_SERVICE_HTTP,
                                  0, 0 );
   }

   if( !hSession )
   {
      FD_TRACE_RETURN( FD_INTERNET_SERVER_CONNECT_FAILED );
   }
   else
   {
      hWebPage = HttpOpenRequest( hSession, "GET",
                                  webPageHidden->webSitePage,
                                  NULL,
                                  NULL,
                                  NULL,
                                  INTERNET_FLAG_NEED_FILE|
                                  INTERNET_FLAG_CACHE_IF_NET_FAIL|                                 
                                  INTERNET_FLAG_NO_UI|
                                  INTERNET_FLAG_NO_COOKIES|
                                  INTERNET_FLAG_RESYNCHRONIZE,
                                  0 );
      if( !hWebPage )
         retCode = FD_INTERNET_OPEN_REQUEST_FAILED;
      else
      {         
         retCode = FD_SetReceiveTimeout( 10000 /* 10 seconds */,
                                         hWebPage );
         if( retCode == FD_SUCCESS )
         {
            if( !HttpSendRequest( hWebPage, 0, 0, 0, 0 ) )
               retCode = FD_INTERNET_SEND_REQUEST_FAILED;
            else
               retCode = buildListDataWinInet( webPage, hWebPage );
         }

         InternetCloseHandle( hWebPage );
      }
      
      InternetCloseHandle( hSession );
   }

   FD_TRACE_RETURN( retCode );
}
#endif

#if defined( USE_WININET )
static FD_RetCode FD_SetReceiveTimeout( DWORD     newTimeout, /* milliseconds */
                                        HINTERNET hWebPage )
{
   BOOL status;

   /* Set the timeout who is going to affect calls to
    * InternetReadFile when retreiving data.
    */

   #if 0
   /* Code for debugging */
	unsigned char *optionString;
	DWORD optionStringLength = 0;
   DWORD receiveTimeout;

	status = InternetQueryOption( hWebPage, 
                                 INTERNET_OPTION_RECEIVE_TIMEOUT,
			                        NULL, &optionStringLength );
	optionString = FD_Malloc( optionStringLength + 1);
	optionString[optionStringLength] = 0;
	InternetQueryOption( hWebPage, INTERNET_OPTION_RECEIVE_TIMEOUT,
			               &receiveTimeout, &optionStringLength );
   /*printf("GET INTERNET_OPTION_RECEIVE_TIMEOUT = %u\n", receiveTimeout );*/
	FD_Free(  (void *) optionString );
   #endif

   status = InternetSetOption( hWebPage,
                               INTERNET_OPTION_RECEIVE_TIMEOUT,
                               &newTimeout,
                               sizeof(DWORD) );

	if( !status )
      return FD_INTERNET_SET_RX_TIMEOUT_FAILED;

   return FD_SUCCESS;
}
#endif

#if defined( USE_WININET )
static FD_RetCode buildListDataWinInet( FD_WebPage *webPage,
                                        HINTERNET hRessource )
{
   FD_PROLOG

   LPSTR    lpszData;      /* buffer for the data */
   DWORD    dwSize;        /* size of the data available */
   DWORD    dwDownloaded;  /* size of the downloaded data */
   FD_RetCode retCode;
   int again;
   int i;
   BOOL status;

   FD_TRACE_BEGIN( buildListDataWinInet );

   /* This loop handles reading the data.   */
   again = 1;
   while( again )
   {
      /* The call to InternetQueryDataAvailable determines the amount
 		 * of data available to download.
       */
      status = FALSE;
      for( i = 0; (status == FALSE) && (i < 2); i++ )
         status = InternetQueryDataAvailable(hRessource,&dwSize,0,0);

	   if( !status )
	   {
		   /*printf("buildListDataWinInet(): InternetQueryDataAvailable() TIMED OUT %d TIMES!\n", i );*/
		   FD_TRACE_RETURN( FD_INTERNET_READ_DATA_FAILED );
	   }
      else if( dwSize == 0 )
      {
         again = 0; /* No more data. Exit. */
      }
      else
      {    
         /* Allocate a buffer of the size returned by
          * InternetQueryDataAvailable.
          */
         lpszData = FD_Malloc( dwSize );

         if( !lpszData )
         {
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }

         /* Read the data from the HINTERNET handle. */
         if(!InternetReadFile(hRessource,(LPVOID)lpszData,dwSize,&dwDownloaded))
         {
            again = 0;
            FD_Free( lpszData );
         }
         else
         {
            if( !webPage->content )
            {
               /* The first buffer will initiate the creation of
                * the stream. If there is any failure, while adding
                * more data to this webPage->content, the partially
                * filled stream will be free when FD_WebPageFree
                * will do the clean-up in internalWebPageAlloc.
                */
               webPage->content = FD_StreamAllocFromBuffer( (unsigned char *)lpszData, dwSize,
                                                            NULL, NULL );

               if( !webPage->content )
               {
                  FD_Free( lpszData );
                  FD_TRACE_RETURN( FD_ALLOC_ERR );
               } 
            }
            else
            {
               /* Add the buffer to the stream. */
               retCode = FD_StreamAddBuffer( webPage->content, (unsigned char *)lpszData, dwSize, NULL, NULL );
               if( retCode != FD_SUCCESS )
               {
                  FD_Free( lpszData );
                  FD_TRACE_RETURN( FD_ALLOC_ERR );
               }
            }

            /* Check the size of the remaining data.  If it is zero, exit. */
            if (dwDownloaded == 0)
            {
               again = 0;
            }
         }
      }
   }

   /* If there is no content, must be an error. */
   if( !webPage->content )
      FD_TRACE_RETURN( FD_INTERNET_NO_CONTENT );

   /* Everything suceed!  */
   FD_TRACE_RETURN( FD_SUCCESS );
}
#endif

FD_RetCode internalWebPageAlloc( const char    *webSiteAddr,
                                 const char    *webSitePage,
                                 const char    *proxyName,
                                 const char    *proxyPort,
                                 FD_WebPage   **webPageAllocated )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_NetworkGlobal *global;
   FD_WebPage *tmpWebPage;
   FD_WebPageHiddenData *webPageHiddenData;

   if( !webSiteAddr || !webPageAllocated )
      return FD_BAD_PARAM;

   FD_TRACE_BEGIN(  FD_WebPageAlloc );

   *webPageAllocated = NULL;

   /* Get the pointer on the global variables. */
   retCode = FD_GetGlobal(  &FD_NetworkGlobalControl, (void *)&global );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Make sure the network library was initialized. */
   if( !global->initialized )
   {
      FD_TRACE_RETURN( FD_SOCKET_LIB_INIT_ERR );
   }

   /* Alloc the FD_WebPage. */
   tmpWebPage = (FD_WebPage *) FD_Malloc( sizeof(FD_WebPage) );
   if( !tmpWebPage )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }
   memset( tmpWebPage, 0, sizeof( FD_WebPage ) );

   /* Alloc the hidden implementation of a FD_WebPage. */
   webPageHiddenData = (FD_WebPageHiddenData *) FD_Malloc( sizeof(FD_WebPageHiddenData));

   if( !webPageHiddenData )
   {
      FD_Free(  tmpWebPage );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   memset( webPageHiddenData, 0, sizeof( FD_WebPageHiddenData ) );
   webPageHiddenData->magicNb     = FD_WEBPAGE_MAGIC_NB;
   webPageHiddenData->webSiteAddr = webSiteAddr;
   webPageHiddenData->webSitePage = webSitePage;
   webPageHiddenData->proxyName   = proxyName;
   webPageHiddenData->proxyPort   = proxyPort;

   tmpWebPage->hiddenData = webPageHiddenData;

   /* From this point, FD_WebPageFree shall be called to clean-up. */

   #ifdef DEBUG_PRINTF
      printf( "Fetching [%s][%s]", webSiteAddr, webSitePage );
   #endif

   #if defined( USE_WININET )
      retCode = fetchUsingWinInet( global, tmpWebPage );
   #endif

   #if defined( USE_LIBCURL )
      retCode = fetchUsingLibCurl( global, tmpWebPage );
   #endif

   if( retCode != FD_SUCCESS )
   {
      /* If an error occured at any point in this module,
       * we are sure to free up everything by ending-up here.
       * It is assumed that all ressources are referenced
       * within the 'tmpWebPage' of course.
       */
      FD_WebPageFree( tmpWebPage );
      FD_TRACE_RETURN( retCode );
   }
   
   /* Everything is fine! Return the page to the caller. */
   *webPageAllocated = tmpWebPage; 
   FD_TRACE_RETURN( FD_SUCCESS );
}

#if defined( USE_LIBCURL )
static FD_RetCode rfc1945StatusToRetCode( unsigned int httpErrorCode )
{
   switch( httpErrorCode )
   {
   case 301:
      return FD_HTTP_SC_301;     /* Moved Permanently */
   case 302:
      return FD_HTTP_SC_302;     /* Moved Temporarily */
   case 304:
      return FD_HTTP_SC_304;     /* Not Modified      */
   case 400:
      return FD_HTTP_SC_400;     /* Bad Request       */
   case 401:
      return FD_HTTP_SC_401;     /* Unauthorized      */
   case 403:
      return FD_HTTP_SC_403;     /* Forbidden         */
   case 404:
      return FD_HTTP_SC_404;     /* Not Found         */
   case 500:
      return FD_HTTP_SC_500;     /* Internal Server Error */
   case 501:
      return FD_HTTP_SC_501;     /* Not Implemented */
   case 502:
      return FD_HTTP_SC_502;     /* Bad Gateway */
   case 503:
      return FD_HTTP_SC_503;     /* Service Unavailable */
   }

   return FD_HTTP_SC_UNKNOWN; /* Unknown error code. */ 
}
#endif
