#ifndef FD_YAHOO_HANDLE_H
#define FD_YAHOO_HANDLE_H

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FD_YAHOO_IDX_H
   #include "fd_yahoo_idx.h"
#endif

#ifndef FD_READOP_H
   #include "fd_readop.h"
#endif

typedef struct
{   
   /* Keep a local copy of the initial parameters. */
   const FD_AddDataSourceParamPriv *param;

   /* Represent all the categories and symbols available. */
   FD_YahooIdx *index;

   /* Copy of the optional "server=" modifier */
   FD_String *userSpecifiedServer;
    
   /* When 'index' is NULL, it means it is only one symbol.
    * In that case the info to reach the Yahoo! web site 
    * and the proper symbol is in the following "webSite"
    * variables.
    */
   FD_CountryId webSiteCountry;
   FD_String *webSiteSymbol;

   /* The read operations for interpreting the Yahoo! CSV format. */
   FD_ReadOpInfo *readOp6Fields;
   FD_ReadOpInfo *readOp5Fields;
   FD_ReadOpInfo *readOp2Fields;
} FD_PrivateYahooHandle;

/* Alloc/Free for FD_DataSourceHandle.
 * Takes care also to alloc/initialize/free the FD_PrivateHandle which
 * become the 'opaque' part of the FD_DataSourceHandle.
 */
FD_DataSourceHandle *FD_YAHOO_DataSourceHandleAlloc( void );
FD_RetCode FD_YAHOO_DataSourceHandleFree( FD_DataSourceHandle *handle );

#endif
