/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *  032704 MF   Add CSI and CSIM support.
 *  061004 MF   Add FD_YAHOO_ONE_SYMBOL
 */

/* Description:
 *    This file helps to make abstraction of the different data source.
 *
 *    It defines basically two global variable:
 *
 *    FD_gDataSourceTable
 *       This table provides all the functions needed for accessing
 *       all the different data source format.
 *       For each element of the FD_SourceId enumeration, there
 *       is one entry in the gDataSourceTable.
 *
 *    FD_gDataSourceTableSize
 *       The number of entry in the FD_gDataSourceTable.
 *       Take note that the number of entry MUST correspond
 *       to the number of entry in the FD_SourceId enumeration.
 *
 */

/**** Headers ****/
#include "fd_source.h"
#include "fd_ascii.h"
#include "fd_simulator.h"
#include "fd_yahoo.h"
#include "fd_sql.h"
#include "fd_csi.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
const FD_DataSourceDriver FD_gDataSourceTable[] =
{
    {   /* FD_ASCII_FILE format. */
        "ASCII",
        FD_ASCII_InitializeSourceDriver,
        FD_ASCII_ShutdownSourceDriver,
        FD_ASCII_GetParameters,
        FD_ASCII_OpenSource,
        FD_ASCII_CloseSource,
        FD_ASCII_GetFirstCategoryHandle,
        FD_ASCII_GetNextCategoryHandle,
        FD_ASCII_GetFirstSymbolHandle,
        FD_ASCII_GetNextSymbolHandle,
        FD_ASCII_GetHistoryData
    },

    {   /* FD_SIMULATOR data source. */
        "SIMULATOR",
        FD_SIMULATOR_InitializeSourceDriver,
        FD_SIMULATOR_ShutdownSourceDriver,
        FD_SIMULATOR_GetParameters,
        FD_SIMULATOR_OpenSource,
        FD_SIMULATOR_CloseSource,
        FD_SIMULATOR_GetFirstCategoryHandle,
        FD_SIMULATOR_GetNextCategoryHandle,
        FD_SIMULATOR_GetFirstSymbolHandle,
        FD_SIMULATOR_GetNextSymbolHandle,
        FD_SIMULATOR_GetHistoryData
    },

    {   /* FD_YAHOO_WEB data source. */
        "YAHOO_WEB",
        FD_YAHOO_InitializeSourceDriver,
        FD_YAHOO_ShutdownSourceDriver,
        FD_YAHOO_GetParameters,
        FD_YAHOO_OpenSource,
        FD_YAHOO_CloseSource,
        FD_YAHOO_GetFirstCategoryHandle,
        FD_YAHOO_GetNextCategoryHandle,
        FD_YAHOO_GetFirstSymbolHandle,
        FD_YAHOO_GetNextSymbolHandle,
        FD_YAHOO_GetHistoryData
    },

    {   /* FD_SQL data source. */
        "SQL",
        FD_SQL_InitializeSourceDriver,
        FD_SQL_ShutdownSourceDriver,
        FD_SQL_GetParameters,
        FD_SQL_OpenSource,
        FD_SQL_CloseSource,
        FD_SQL_GetFirstCategoryHandle,
        FD_SQL_GetNextCategoryHandle,
        FD_SQL_GetFirstSymbolHandle,
        FD_SQL_GetNextSymbolHandle,
        FD_SQL_GetHistoryData
    },

    {   /* FD_CSI format. */
        "CSI",
        FD_CSI_InitializeSourceDriver,
        FD_CSI_ShutdownSourceDriver,
        FD_CSI_GetParameters,
        FD_CSI_OpenSource,
        FD_CSI_CloseSource,
        FD_CSI_GetFirstCategoryHandle,
        NULL,
        FD_CSI_GetFirstSymbolHandle,
        FD_CSI_GetNextSymbolHandle,
        FD_CSI_GetHistoryData
    },

    {   /* FD_CSIM format. */
        "CSIM",
        FD_CSIM_InitializeSourceDriver,
        FD_CSIM_ShutdownSourceDriver,
        FD_CSIM_GetParameters,
        FD_CSIM_OpenSource,
        FD_CSIM_CloseSource,
        FD_CSIM_GetFirstCategoryHandle,
        NULL,
        FD_CSIM_GetFirstSymbolHandle,
        FD_CSIM_GetNextSymbolHandle,
        FD_CSIM_GetHistoryData
    },

    {   /* FD_YAHOO_ONE_SYMBOL data source. */
        "YAHOO",
        FD_YAHOO_InitializeSourceDriver,
        FD_YAHOO_ShutdownSourceDriver,
        FD_YAHOO_GetParameters,
        FD_YAHOO_OpenSource,
        FD_YAHOO_CloseSource,
        FD_YAHOO_GetFirstCategoryHandle,
        NULL,
        FD_YAHOO_GetFirstSymbolHandle,
        FD_YAHOO_GetNextSymbolHandle,
        FD_YAHOO_GetHistoryData
    }
};

const unsigned int FD_gDataSourceTableSize = (sizeof(FD_gDataSourceTable)/sizeof(FD_DataSourceDriver));

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
/* None */

/**** Global functions definitions.   ****/
/* None */

/**** Local functions definitions.     ****/
/* None */



