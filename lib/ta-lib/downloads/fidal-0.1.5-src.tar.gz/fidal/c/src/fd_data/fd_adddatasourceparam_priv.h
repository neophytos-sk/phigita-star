#ifndef FD_ADDDATASOURCEPARAM_PRIV_H
#define FD_ADDDATASOURCEPARAM_PRIV_H

/* The following is a private copy of the user provided
 * parameters for a FD_AddDataSource call.
 *
 * Code is in 'fd_data_interface.c'
 */
typedef struct
{
  FD_SourceId   id;
  FD_SourceFlag flags;
  FD_Period     period;

  FD_String *location;
  FD_String *info;
  FD_String *username;
  FD_String *password;
  FD_String *category;
  FD_String *country;
  FD_String *exchange;
  FD_String *type;
  FD_String *symbol;
  FD_String *sourceName;
} FD_AddDataSourceParamPriv;

#endif
