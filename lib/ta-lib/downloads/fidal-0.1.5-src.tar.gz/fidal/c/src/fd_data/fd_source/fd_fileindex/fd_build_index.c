/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *
 */

/* Description:
 *       From the FD_AsciiFileData->listLocateToken Do the
 *       following for each identified category:
 *           - Add a FD_AsciiFileData->listCategory entry.
 *           - Add all symbols in the FD_FileIndexCategoryData->listSymbol
 */

/**** Headers ****/
#include <stddef.h>
#include <string.h>
#include <ctype.h>
#include "fd_memory.h"
#include "fd_system.h"
#include "fd_trace.h"
#include "fidal.h"
#include "fd_fileindex_priv.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   FD_ListIter iter;
   FD_TokenInfo *curToken;
   const char   *curPosInToken;
} FD_PatternIter;

/**** Local functions declarations.    ****/
static FD_RetCode buildIndexList  ( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth );
static FD_RetCode processDirectory( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth );
static FD_RetCode processFiles    ( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth );

static FD_RetCode makePathPattern( FD_FileIndexPriv *fileIndexPriv,
                                   FD_ValueTreeNode *node, int maxDepth,
                                   char *bufferToUse, int maxBufferSize );


static FD_RetCode fieldToStr( FD_TokenInfo *currentToken,
                              FD_ValueTreeNode *currentValue,
                              char *str, int maxStrLength,
                              int *nbCharAdded, int *valueConsumed );

static FD_RetCode extractTokenValue( FD_FileIndexPriv *fileIndexPriv,
                                     FD_ValueTreeNode **addedHead,
                                     const char *string,
                                     int allowIndexUpdate );

static FD_RetCode extractTokenValueRecursive( FD_FileIndexPriv *fileIndexPriv,
                                              FD_PatternIter *iter,
                                              const char *string,
                                              unsigned int firstOfOneOrMore );

static FD_RetCode addValueDown( FD_FileIndexPriv *fileIndexPriv,
                                FD_TokenId id,
                                const char *string );

static FD_RetCode addCurrentDataToIndex( FD_FileIndexPriv *fileIndexPriv,
                                         FD_ValueTreeNode *treeNodeValue );

static FD_RetCode FD_PatternInit( FD_FileIndexPriv *fileIndexPriv, FD_PatternIter *iter );
static char getPatternChar ( FD_PatternIter *iter );
static char nextPatternChar( FD_PatternIter *iter );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_FileIndexBuildIndex( FD_FileIndexPriv *fileIndexPriv )
{
   FD_PROLOG
   FD_RetCode retCode;
   unsigned int fileDepth;

   if( !fileIndexPriv )
      return FD_ALLOC_ERR;

   FD_TRACE_BEGIN(  FD_FileIndexBuildIndex );

   /* Verify parameters. */
   if( !fileIndexPriv->listLocationToken )
   {
      FD_FATAL( NULL, fileIndexPriv, fileIndexPriv->listLocationToken );
   }

   /* Identify at which level that files are
    * processed instead of directories.
    */
   fileDepth = FD_FileIndexIdentifyFileDepth( fileIndexPriv );

   if( fileDepth == 0 )
   {
      FD_TRACE_RETURN( FD_INVALID_PATH );
   }

   retCode = buildIndexList( fileIndexPriv, fileDepth );

   FD_TRACE_RETURN( retCode );
}


/* The path is build in the provided buffer.
 * All wildcards are resolved using the provided FD_ValueTreeNode.
 */
FD_RetCode FD_FileIndexMakePathPattern( FD_FileIndexPriv *fileIndexPriv,
                                        FD_ValueTreeNode *node,
                                        char *bufferToUse,
                                        int maxBufferSize )
{
   FD_PROLOG
   int maxDepth;
   FD_RetCode retCode;

   FD_TRACE_BEGIN(  FD_FileIndexMakePathPattern );

   FD_ASSERT( fileIndexPriv != NULL );
   FD_ASSERT( node !=  NULL );
   FD_ASSERT( bufferToUse != NULL );
   FD_ASSERT( maxBufferSize >= 1 );

   FD_ASSERT( fileIndexPriv->listLocationToken != NULL );
   maxDepth = FD_ListSize( fileIndexPriv->listLocationToken ) - 1;
   FD_ASSERT( maxDepth >= 1 );

   bufferToUse[0] = '\0';

   retCode = makePathPattern( fileIndexPriv, node, maxDepth,
                           bufferToUse, maxBufferSize );

   FD_TRACE_RETURN( retCode );
}


/**** Local functions definitions.     ****/
static FD_RetCode buildIndexList( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth )
{
   FD_PROLOG
   FD_RetCode retCode;

   /* Note: this function is recursively called. */

   /* Validate parameters. */
   if( fileIndexPriv == NULL )
      return FD_ALLOC_ERR;

   FD_TRACE_BEGIN(  buildIndexList );

   if( fileIndexPriv->curTokenDepth > 500 )
   {
      FD_FATAL(  NULL, fileIndexPriv->curTokenDepth, 0 );
   }

   if( fileIndexPriv->curToken )
   {
      if( (fileIndexPriv->curToken->id == FD_INVALID_TOKEN_ID) ||
          (fileIndexPriv->curToken->id > FD_NB_TOKEN_ID) ||
          (fileIndexPriv->curToken->id == FD_TOK_END) )
      {
         FD_FATAL(  NULL, fileIndexPriv->curTokenDepth, fileIndexPriv->curToken->id );
      }
   }

   /* Get next (first?) token. */
   retCode = FD_FileIndexMoveToNextToken( fileIndexPriv );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   if( fileIndexPriv->curToken == NULL )
   {
      FD_FATAL(  NULL, fileIndexPriv->prevToken, fileIndexPriv->nextToken );
   }

   /* Skip all fix part not requiring processing. */
   while( (fileIndexPriv->curTokenDepth < fileDepth) &&
          ((fileIndexPriv->curToken->id == FD_TOK_FIX) || (fileIndexPriv->curToken->id == FD_TOK_SEP)) )
   {
      retCode = FD_FileIndexMoveToNextToken( fileIndexPriv );
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }
   }

   /* At this point one of the following may have happen:
    *  - It hit a field or wildcard that needs to be resolved.
    *  - It hit the file depth.
    */
   if( fileIndexPriv->curTokenDepth < fileDepth )
   {
      retCode = processDirectory( fileIndexPriv, fileDepth );
      FD_TRACE_RETURN( retCode );
   }
   else
   {
      retCode = processFiles( fileIndexPriv, fileDepth );
      FD_TRACE_RETURN( retCode );
   }
}



static FD_RetCode makePathPattern( FD_FileIndexPriv *fileIndexPriv,
                                   FD_ValueTreeNode *node, int maxDepth,
                                   char *bufferToUse, int maxBufferSize )
{
   FD_PROLOG
   FD_List *listOfValue;
   FD_TokenInfo *currentToken;
   FD_ValueTreeNode *currentValue;
   FD_RetCode retCode;

   int i;
   int nbCharAdded, valueConsumed;
   unsigned int nbChar;

   if( !fileIndexPriv )
      return FD_INTERNAL_ERROR(63);

   FD_TRACE_BEGIN( makePathPattern );

   /* Build a list of value up to the root. */
   listOfValue = FD_ListAlloc( );

   if( !listOfValue )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   while( node != fileIndexPriv->root )
   {
      retCode = FD_ListAddHead( listOfValue, node );
      if( retCode != FD_SUCCESS )
      {
         FD_ListFree( listOfValue );
         FD_TRACE_RETURN( retCode );
      }
      node = node->parent;
   }

   /* Build the complete path in the provided buffer. */
   currentToken = (FD_TokenInfo *)     FD_ListAccessHead( fileIndexPriv->listLocationToken  );
   currentValue = (FD_ValueTreeNode *) FD_ListAccessHead( listOfValue );
   nbChar = 0;

   for( i=0; i < maxDepth; i++ )
   {
      if( !currentToken )
      {
         FD_ListFree( listOfValue );
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(64) );
      }

      /* Add the field. */
      valueConsumed = 0;
      nbCharAdded = 0;
      retCode = fieldToStr( currentToken, currentValue,
                            &bufferToUse[nbChar], maxBufferSize,
                            &nbCharAdded, &valueConsumed );

      if( retCode != FD_SUCCESS )
      {
         FD_ListFree( listOfValue );
         FD_TRACE_RETURN( retCode );
      }

      nbChar += nbCharAdded;
      maxBufferSize -= nbCharAdded;

      /* Go to the next token. */
      if( valueConsumed )
         currentValue = FD_ListAccessNext( listOfValue );
      currentToken = FD_ListAccessNext( fileIndexPriv->listLocationToken );
   }

   FD_ListFree( listOfValue );

   /* Note: When returning from 'makePathPattern' it should still
    * be in the same position we were in the 'fileIndexPriv->listLocationToken'.
    * (this is becoming ugly to have this kind of dependency... )
    */
   currentToken = FD_ListAccessNext( fileIndexPriv->listLocationToken );
   if( fileIndexPriv->curToken )
   {
      if( currentToken != fileIndexPriv->nextToken )
      {
         FD_FATAL( NULL, currentToken->id, fileIndexPriv->curToken->id );
      }
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode fieldToStr( FD_TokenInfo *currentToken,
                              FD_ValueTreeNode *currentValue,
                              char *str, int maxStrLength,
                              int *nbCharAdded, int *valueConsumed )
{
   int strLength;
   const char *strToUse;

   if( (!currentToken) || (!str) )
      return FD_INTERNAL_ERROR(65);

   if( maxStrLength == 0 )
      return FD_INTERNAL_ERROR(66);

   if( nbCharAdded )
      *nbCharAdded = 0;

   if( valueConsumed )
      *valueConsumed = 0;

   switch( currentToken->id )
   {
   case FD_TOK_FIX:
   case FD_TOK_SEP:
      if( currentToken->value )
         strToUse  = FD_StringToChar( currentToken->value );
      else
         return FD_INTERNAL_ERROR(67);
      break;

   case FD_TOK_END:
      return FD_INTERNAL_ERROR(68);

   case FD_TOK_WILD:
   case FD_TOK_WILD_CHAR:
   case FD_TOK_SYM:
   case FD_TOK_CAT:
   case FD_TOK_CATC:
   case FD_TOK_CATX:
   case FD_TOK_CATT:
      if( !currentValue )
      {
         if( currentToken->value )
            strToUse  = FD_StringToChar( currentToken->value );
         else
            return FD_INTERNAL_ERROR(69);
      }
      else
      {
         if( currentValue->string )
            strToUse = FD_StringToChar( currentValue->string );
         else
         {
            if( currentToken->id != FD_TOK_WILD )
               return FD_INTERNAL_ERROR(70);
            strToUse = "";
         }

         if( valueConsumed )
            *valueConsumed = 1;
      }
      break;

   default:
      if( (!currentValue) || (!currentValue->string) )
      {
         if( currentToken->value )
            strToUse  = FD_StringToChar( currentToken->value );
         else
            return FD_INTERNAL_ERROR(71);
      }
      else
      {
         strToUse = FD_StringToChar( currentValue->string );
         if( valueConsumed )
            *valueConsumed = 1;
      }
      break;
   }

   strLength = strlen( strToUse );

   if( strLength >= maxStrLength )
      return FD_INTERNAL_ERROR(72);

   strcpy( str, strToUse );
   if( nbCharAdded )
      *nbCharAdded = strLength;

   return FD_SUCCESS;
}

static FD_RetCode processDirectory( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_Directory *directory;
   char *basename;
   int rememberDepth;
   FD_ValueTreeNode *addedHead;
   FD_String *curDirectoryString;
   int dataSourceEmpty;
   FD_StringCache *stringCache;

   if( !fileIndexPriv )
      return FD_INTERNAL_ERROR(73);

   FD_TRACE_BEGIN(  processDirectory );

   stringCache = FD_GetGlobalStringCache( );

   /* Note: This function is recursively called. */

   /* Assume the fileIndexPriv source is empty from this level, until
    * the contrary is found.
    */
   dataSourceEmpty = 1;

   /* Locally allocated ressources. */
   addedHead = NULL;
   directory = NULL;
   curDirectoryString = NULL;

   /* Define a local MACRO for clean return of this function. */
   #define CLEAN_UP \
   { \
      if(addedHead) \
      { \
         fileIndexPriv->currentNode=addedHead->parent; \
         FD_FileIndexFreeValueTree(addedHead); \
      } \
      if(directory) \
         FD_DirectoryFree(directory); \
      if(curDirectoryString) \
         FD_StringFree(stringCache,curDirectoryString);  \
   }
       
   #define RETURN(retCode ) \
   { \
      CLEAN_UP;   \
      FD_TRACE_RETURN( retCode ); \
   }

   /* Some quick sanity check. */
   if( !(fileIndexPriv->nextToken) || !(fileIndexPriv->curToken) )
   {
      CLEAN_UP;
      FD_FATAL(  NULL, fileIndexPriv->nextToken, fileIndexPriv->curToken );
   }

   if( (fileIndexPriv->curToken->id == FD_TOK_END) ||
       (fileIndexPriv->nextToken->id == FD_TOK_END) )
   {
      CLEAN_UP;
      FD_FATAL(  NULL, fileIndexPriv->nextToken->id, fileIndexPriv->curToken->id );
   }

   /* Skip tokens until the next FD_TOK_SEP. The directory
    * pattern will be build up to this token (excluding the
    * trailing FD_TOK_SEP of course).
    */
   while( fileIndexPriv->curToken->id != FD_TOK_SEP )
   {
      /* Skip to the next token. */
      FD_FileIndexMoveToNextToken( fileIndexPriv );
      if( !fileIndexPriv->curToken || (fileIndexPriv->curToken->id == FD_TOK_END) )
         RETURN( FD_INTERNAL_ERROR(74) );
   }

   /* Remember the token depth for the processing of directory at this level. */
   rememberDepth = fileIndexPriv->curTokenDepth;

   /* Identify the basename and the pattern. */
   retCode = makePathPattern( fileIndexPriv, fileIndexPriv->currentNode, fileIndexPriv->curTokenDepth-1,
                              fileIndexPriv->scratchPad, FD_SOURCELOCATION_MAX_LENGTH );
   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   basename = fileIndexPriv->scratchPad;

   /* Get all the corresponding directory entries. */
   retCode = FD_DirectoryAlloc( basename, &directory );
   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   /* Iterate for each sub-directory. */
   while( directory->nbDirectory )
   {
      curDirectoryString = (FD_String *) FD_ListRemoveHead( directory->listOfDirectory );
      if( !curDirectoryString )
         RETURN( FD_INTERNAL_ERROR(75) );

      /* For each sub-directory entry, extract potential
       * new token values.
       *
       * About 'addedHead': if fields values are added for this path, keep
       * track of the root of it. If there is no fileIndexPriv found under the
       * specified path, all corresponding values are going to be freed.
       *
       * When an internal error occured, we do some clean-up, including the
       * removal of all value added from addedHead.
       */
      addedHead = NULL;
      retCode = extractTokenValue( fileIndexPriv,
                                   &addedHead,
                                   FD_StringToChar( curDirectoryString ),
                                   0 );

      /* Some sanity check. */
      if( !fileIndexPriv->nextToken )
         RETURN( FD_INTERNAL_ERROR(76) );

      if( fileIndexPriv->nextToken->id == FD_TOK_END )
      {
         /* End-up here if FD_TOK_END is prematury seen... */
         FD_FATAL(  NULL, fileIndexPriv->curTokenDepth, fileIndexPriv->nextToken->id );         
      }

      /* Trap all internal error from extractTokenValue */
      if( (retCode != FD_SUCCESS) && (retCode != FD_NO_DATA_SOURCE) )
         RETURN( retCode );

      /* Just keep processing recursively for the next leg if that one
       * was valid.
       */
      if( retCode == FD_SUCCESS )
      {
         /* Recursive call. */
         retCode = buildIndexList( fileIndexPriv, fileDepth );

         if( retCode == FD_SUCCESS )
            dataSourceEmpty = 0; /* We got some fileIndexPriv! */
         else if( retCode != FD_NO_DATA_SOURCE )
         {
            /* An error other than FD_NO_DATA_SOURCE occured. */
            RETURN( retCode );
         }
      }

      if( addedHead != NULL )
      {
         fileIndexPriv->currentNode = addedHead->parent;

         if( retCode == FD_NO_DATA_SOURCE )
         {
            /* FD_NO_DATA_SOURCE was establish and some value are still in
             * the value tree... make sure all added values are freed.
             */
            FD_FileIndexFreeValueTree( addedHead );
         }

         /* At this point the value are either good and belongs to the
          * tree value, or the values has been freed. In either case, we do
          * not wish to free these values again...
          */
         addedHead = NULL;
      }

      /* Re-position the processing of the token at the same
       * level for processing another possible directory.
       */
      FD_FileIndexMoveToDepth( fileIndexPriv, rememberDepth );

      /* Proceed to the next directory entry. */
      FD_StringFree( stringCache, curDirectoryString );
      curDirectoryString = NULL;
      directory->nbDirectory--;
   }

   /* Clean-up and return successfully. */
   retCode = FD_DirectoryFree( directory );
   directory = NULL;
   if( retCode != FD_SUCCESS )
      RETURN( FD_ALLOC_ERR );

   if( dataSourceEmpty )
      RETURN( FD_NO_DATA_SOURCE );

   RETURN( FD_SUCCESS );
   #undef RETURN
   #undef CLEAN_UP
}

static FD_RetCode processFiles( FD_FileIndexPriv *fileIndexPriv, unsigned int fileDepth )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_Directory *directory;
   char *basename;
   int rememberDepth;
   FD_ValueTreeNode *addedHead;
   FD_String *curFileString;
   FD_StringCache *stringCache;

   int dataSourceEmpty;

   (void)fileDepth; /* Get ride of compiler warning. */

   if( !fileIndexPriv )
      return FD_INTERNAL_ERROR(78);

   FD_TRACE_BEGIN(  processFiles );

   stringCache = FD_GetGlobalStringCache( );

   /* Processing Files. */

   /* Note: This function is recursively called. */

   /* Initialize local variable. */
   addedHead = NULL;
   directory = NULL;
   curFileString = NULL;

   /* Assume the fileIndexPriv source is empty from this level, until
    * the contrary is found.
    */
   dataSourceEmpty = 1;

   /* Define a local MACRO for clean return of this function. */

   #define CLEAN_UP { \
   if(addedHead) \
   { \
      fileIndexPriv->currentNode=addedHead->parent; \
      FD_FileIndexFreeValueTree(addedHead);\
   } \
   if(directory) \
      FD_DirectoryFree(directory); \
   if(curFileString) \
      FD_StringFree(stringCache,curFileString); \
   }

   #define RETURN(retCode) { \
      CLEAN_UP; \
      FD_TRACE_RETURN( retCode ); \
   }

   /* Some quick sanity check. */
   if( !(fileIndexPriv->nextToken) || !(fileIndexPriv->curToken) )
   {
      CLEAN_UP;
      FD_FATAL( NULL, fileIndexPriv->nextToken, fileIndexPriv->curToken );
   }

   if( fileIndexPriv->curToken->id == FD_TOK_END )
   {
      CLEAN_UP;
      FD_FATAL( NULL, fileIndexPriv->nextToken->id, fileIndexPriv->curToken->id );      
   }

   /* Skip tokens until the FD_TOK_END. The directory pattern
    * pattern will be build up to this token (excluding FD_TOK_END
    * itself of course).
    */
   while( fileIndexPriv->curToken->id != FD_TOK_END )
      FD_FileIndexMoveToNextToken( fileIndexPriv );

   /* Remember the token depth for the processing of files at this level. */
   rememberDepth = fileIndexPriv->curTokenDepth;

   /* Identify the basename and the pattern. */
   retCode = makePathPattern( fileIndexPriv, 
                              fileIndexPriv->currentNode,
                              fileIndexPriv->curTokenDepth-1,
                              fileIndexPriv->scratchPad,
                              FD_SOURCELOCATION_MAX_LENGTH );
   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   basename = fileIndexPriv->scratchPad;

   /* Get all the corresponding files entries. */
   retCode = FD_DirectoryAlloc( basename, &directory );
   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   /* Iterate for each file. */
   while( directory->nbFile )
   {
      curFileString = (FD_String *) FD_ListRemoveHead( directory->listOfFile );
      if( !curFileString )
         RETURN( FD_INTERNAL_ERROR(79) );

      /* For each files, extract potential new token values.
       *
       * About 'addedHead': if fields values are added for this path, keep
       * track of the root of it. If an error occured these fields must
       * be freed.
       */

      /* printf( " File:[%s]\n", FD_StringToChar( curFileString ) ); */

      addedHead = NULL;
      retCode = extractTokenValue( fileIndexPriv, &addedHead,
                                   FD_StringToChar( curFileString ),
                                   1 );

      if( retCode == FD_SUCCESS )
         dataSourceEmpty = 0; /* We got at least one file... */
      else if( retCode != FD_NO_DATA_SOURCE )
         RETURN( retCode );

      if( addedHead != NULL )
      {
         fileIndexPriv->currentNode = addedHead->parent;

         if( retCode == FD_NO_DATA_SOURCE )
         {
            /* FD_NO_DATA_SOURCE was establish and some value are still in
             * the value tree... make sure all added values are freed.
             */
            FD_FileIndexFreeValueTree( addedHead );
         }

         /* At this point the value are either good and belongs to the
          * tree value, or the values has been freed. In either case, we do
          * not wish to free these values again...
          */
         addedHead = NULL;
      }

      /* Just keep processing for the next file. */

      /* Re-position currentNode for adding at the correct place
       * in the tree.
       */
      if( addedHead )
      {
         fileIndexPriv->currentNode = addedHead->parent;
         addedHead = NULL;
      }

      /* Re-position the processing of the token at the same
       * level for processing another possible file.
       */
      FD_FileIndexMoveToDepth( fileIndexPriv, rememberDepth );

      /* Proceed to the next file entry. */
      FD_StringFree( stringCache, curFileString );
      curFileString = NULL;
      directory->nbFile--;
   }

   /* Clean-up and return successfully. */
   retCode = FD_DirectoryFree( directory );
   directory = NULL;
   if( retCode != FD_SUCCESS )
      RETURN( retCode );

   if( dataSourceEmpty )
      RETURN( FD_NO_DATA_SOURCE );

   RETURN( FD_SUCCESS );
   #undef RETURN
   #undef CLEAN_UP
}

static FD_RetCode FD_PatternInit( FD_FileIndexPriv *fileIndexPriv,
                                  FD_PatternIter *iter )
{
   FD_PROLOG
   FD_RetCode retCode;

   FD_TRACE_BEGIN(  FD_PatternInit );

   FD_ASSERT( fileIndexPriv != NULL );
   FD_ASSERT( iter != NULL );
   FD_ASSERT( fileIndexPriv->curToken != NULL );
   FD_ASSERT( fileIndexPriv->curToken->id != FD_TOK_END );
   FD_ASSERT( fileIndexPriv->listLocationToken != NULL );

   retCode = FD_ListIterInit( &iter->iter, fileIndexPriv->listLocationToken );
   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   /* Position 'iter->curToken' on the currentToken of 'fileIndexPriv'. */
   iter->curToken = FD_ListIterHead( &iter->iter );
   if( !iter->curToken )
   {
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(80) );
   }

   while( iter->curToken != fileIndexPriv->curToken )
   {
      iter->curToken = FD_ListIterNext( &iter->iter );
      if( !iter->curToken )
      {
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(81) );
      }
   }

   /* Some fields receive special iteration within their value string.
    *   FD_TOK_FIX, FD_TOK_SYMF, FD_TOK_SYM, FD_TOK_CAT,
    *   FD_TOK_CATC, FD_TOK_CATX, FD_TOK_CATT
    *
    * All other fields go always to the next token.
    */
   switch( iter->curToken->id )
   {
   case FD_TOK_FIX:
   case FD_TOK_SYMF:
   case FD_TOK_SYM:
   case FD_TOK_CAT:
   case FD_TOK_CATC:
   case FD_TOK_CATX:
   case FD_TOK_CATT:
      iter->curPosInToken = FD_StringToChar( iter->curToken->value );
      break;
   default:
      iter->curPosInToken = NULL;
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

static char nextPatternChar( FD_PatternIter *iter )
{
   FD_ASSERT_RET( iter != NULL, '\0' );
   FD_ASSERT_RET( iter->curToken != NULL, '\0' );

   if( ((iter->curToken->id) == FD_TOK_END) ||
       ((iter->curToken->id) == FD_TOK_SEP) )
      return '\0';

   /* Some fields receive special iteration within their value string.
    *   FD_TOK_FIX, FD_TOK_SF, FD_X_ and FD_TOK_S
    *
    * All other fields go always to the next token.
    */
    if( !iter->curPosInToken || (*(iter->curPosInToken+1) == '\0') )
    {
       /* Move to next token. */
       iter->curToken = FD_ListIterNext( &iter->iter );

       if( !iter->curToken )
       {
          FD_FATAL_RET( NULL, 0, 0, '\0' );
       }

       switch( iter->curToken->id )
       {
       case FD_TOK_FIX:
       case FD_TOK_SYMF:
       case FD_TOK_SYM:
       case FD_TOK_CAT:
       case FD_TOK_CATC:
       case FD_TOK_CATX:
       case FD_TOK_CATT:
          iter->curPosInToken = FD_StringToChar( iter->curToken->value );
          break;

       case FD_TOK_SEP:
       case FD_TOK_END:
          return '\0';

       default:
          iter->curPosInToken = NULL;
       }
    }
    else
    {
       /* Move to next character. */
       iter->curPosInToken++;
    }

    return getPatternChar( iter);
}

static char getPatternChar ( FD_PatternIter *iter )
{
   FD_ASSERT_RET( iter != NULL, '\0' );
   FD_ASSERT_RET( iter->curToken != NULL,'\0' );

   /* These token delimitate the end of the pattern... */
   if( (iter->curToken->id == FD_TOK_SEP) ||
       (iter->curToken->id == FD_TOK_END) )
      return '\0';

   if( iter->curToken->id == FD_TOK_WILD )
      return '*'; /* Zero or more character */

   if( iter->curToken->id == FD_TOK_WILD_CHAR )
      return '?'; /* One character. */

   FD_ASSERT_RET( iter->curPosInToken != NULL, 0 );

   switch( iter->curToken->id )
   {
      case FD_TOK_SYM:
      case FD_TOK_CAT:
      case FD_TOK_CATC:
      case FD_TOK_CATX:
      case FD_TOK_CATT:
         /* A trick to get the logic for "one or more character" */
         if( *(iter->curPosInToken+1) != '\0' )
            return '|'; /* One character kept in memory for next '*'. */
         else
            return '*'; /* Zero or more character following the '|' */
      default:
         /* Do nothing */
         break;
   }

   return *iter->curPosInToken;
}

static FD_RetCode extractTokenValue( FD_FileIndexPriv *fileIndexPriv,
                                     FD_ValueTreeNode **addedHead,
                                     const char *string,
                                     int allowIndexUpdate )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_PatternIter iterPattern;
   unsigned int atLeastOneValueToExtract; /* Boolean */
   int rememberStartOfLeg, rememberEndOfLeg;
   FD_ValueTreeNode *rememberTail;

   FD_TRACE_BEGIN(  extractTokenValue );

   /* Note: for proper clean-up of ressources used by this function, you must
    * exit by jumping at  extractTokenValue_exit.
    */
   FD_ASSERT( fileIndexPriv != NULL );
   FD_ASSERT( addedHead != NULL );
   FD_ASSERT( string != NULL );
   FD_ASSERT( (allowIndexUpdate == 0) || (allowIndexUpdate == 1) );

   /* When calling this function, it is assumed that the fileIndexPriv->curtoken is
    * somewhere in the leg that needs to be resolved.
    *
    * A leg is all the character included between two separator (the separator
    * may not be there though).
    *
    * When this function return, the fileIndexPriv->curToken will be position at the end
    * of the processed leg (either on the FD_TOK_SEP or the FD_TOK_END).
    */
   rememberEndOfLeg = -1;
   rememberStartOfLeg = -1;

   /* The addedHead will be set and returned to the user only on success. */
   *addedHead = NULL;

   /* Remember tail is needed to re-build the complete path and it must
    * point to the last stored valued in the value tree (it will be a leaf).
    */
   rememberTail = fileIndexPriv->currentNode;

   /* Move back to the first token starting this leg. */
   do
   {
      retCode = FD_FileIndexMoveToPrevToken( fileIndexPriv );
      if( retCode != FD_SUCCESS )
         goto extractTokenValue_exit;
   }
   while( (fileIndexPriv->curToken->id != FD_TOK_SEP) && (fileIndexPriv->prevToken != NULL) );

   if( fileIndexPriv->prevToken != NULL )
   {
      retCode = FD_FileIndexMoveToNextToken( fileIndexPriv );
      if( retCode != FD_SUCCESS )
         goto extractTokenValue_exit;
   }

   /* Pre-allocate all the values needed in the value tree. */
   rememberStartOfLeg = fileIndexPriv->curTokenDepth;
   atLeastOneValueToExtract = 0;
   while( (fileIndexPriv->curToken->id != FD_TOK_END) &&
          (fileIndexPriv->curToken->id != FD_TOK_SEP) )
   {
      switch( fileIndexPriv->curToken->id )
      {
      case FD_TOK_WILD:
      case FD_TOK_WILD_CHAR:
      case FD_TOK_SYM:
      case FD_TOK_CAT:
      case FD_TOK_CATC:
      case FD_TOK_CATX:
      case FD_TOK_CATT:
         if( atLeastOneValueToExtract == 0 )
         {
            retCode = FD_FileIndexAddTreeValue( fileIndexPriv, NULL, addedHead );
            rememberTail = *addedHead;
         }
         else
            retCode = FD_FileIndexAddTreeValue( fileIndexPriv, NULL, &rememberTail );

         if( retCode != FD_SUCCESS )
            goto extractTokenValue_exit;

         if( *addedHead == NULL )
         {
            FD_FATAL( NULL, *addedHead, 0 );
         }

         atLeastOneValueToExtract = 1;
         break;

      case FD_TOK_SYMF:
         fileIndexPriv->currentSymbolString = fileIndexPriv->curToken->value;
         break;

      default:
         /* Do nothing */
         break;
      }

      retCode = FD_FileIndexMoveToNextToken( fileIndexPriv );
      if( retCode != FD_SUCCESS )
         goto extractTokenValue_exit;
   }

   if( !atLeastOneValueToExtract )
   {
      /* fileIndexPriv->currentCategoryString = fileIndexPriv->initialCategoryString; */

      retCode = addCurrentDataToIndex( fileIndexPriv,  rememberTail );

      goto extractTokenValue_exit;
   }

   /* Remember where this leg finish, since it needs to be in that position
    * before returning from this function.
    */
   rememberEndOfLeg = fileIndexPriv->curTokenDepth;

   /* Re-position the "fileIndexPriv->curToken" to the beginning. */
   retCode = FD_FileIndexMoveToDepth( fileIndexPriv, rememberStartOfLeg );
   if( retCode != FD_SUCCESS )
      goto extractTokenValue_exit;

   /* Reposition the "fileIndexPriv->currentNode" to the beginning. */
   retCode = FD_FileIndexSetCurrentTreeValueNode( fileIndexPriv, *addedHead );
   if( retCode != FD_SUCCESS )
      goto extractTokenValue_exit;

   /* Start the mechanism for iterating in the pattern. */
   retCode = FD_PatternInit( fileIndexPriv, &iterPattern );
   if( retCode != FD_SUCCESS )
      goto extractTokenValue_exit;

   /* Start to recursively extract the token values while
    * modifying the value in the value tree.
    */
   retCode = extractTokenValueRecursive( fileIndexPriv, &iterPattern, string, 0 );

   if( retCode != FD_SUCCESS )
      goto extractTokenValue_exit;

   /* Everything got parsed/extracted correctly, create the symbol
    * and the category if the caller asked for it.
    */
   if( allowIndexUpdate )
   {
      if( !fileIndexPriv->currentSymbolString )
      {
         retCode = FD_INTERNAL_ERROR(83);
         goto extractTokenValue_exit;
      }

      #if 0
      !!! To be removed?
      /* If there is no fileIndexPriv->currentCategoryString extracted
       * from the path, take the user provided categoryString.
       */
      if( !fileIndexPriv->currentCategoryString )
         fileIndexPriv->currentCategoryString = fileIndexPriv->initialCategoryString;
      #endif

      retCode = addCurrentDataToIndex( fileIndexPriv, rememberTail );
   }

   /* Must stay the only possible exit point of this function. */
extractTokenValue_exit:
   /* retCode and rememberEndOfLeg must be set before jumping here. */

   if( retCode != FD_SUCCESS )
   {
      if( *addedHead )
      {
         /* Reset the currentNode and get ride of all values that were
          * used while going down on this path.
          */
         fileIndexPriv->currentNode = (*addedHead)->parent;
         FD_FileIndexFreeValueTree( *addedHead );
         *addedHead = NULL;
      }
   }

   /* Attempt to re-position the "fileIndexPriv->curToken" to the end of the leg. */
   if( rememberEndOfLeg != -1 )
      FD_FileIndexMoveToDepth( fileIndexPriv, rememberEndOfLeg );

   FD_TRACE_RETURN( retCode );
}

/* Set the 'fileIndexPriv->currentNode' and move down to the first child. */
static FD_RetCode addValueDown( FD_FileIndexPriv *fileIndexPriv,
                                FD_TokenId id,
                                const char *string )
{
   FD_String *newStr;
   FD_RetCode retCode;
   FD_StringCache *stringCache;
   
   stringCache = FD_GetGlobalStringCache( );

   newStr = FD_StringAlloc( stringCache, string );

   if( !newStr )
      return FD_ALLOC_ERR;

   retCode = FD_FileIndexChangeValueTreeNodeValue( fileIndexPriv->currentNode, newStr );

   switch( id )
   {
   case FD_TOK_SYM:
      fileIndexPriv->currentSymbolString = fileIndexPriv->currentNode->string;
      break;
   case FD_TOK_CAT:
      fileIndexPriv->currentCategoryString = fileIndexPriv->currentNode->string;
      break;
   case FD_TOK_CATC:
      fileIndexPriv->currentCategoryCountryString = fileIndexPriv->currentNode->string;
      break;
   case FD_TOK_CATX:
      fileIndexPriv->currentCategoryExchangeString = fileIndexPriv->currentNode->string;
      break;
   case FD_TOK_CATT:
      fileIndexPriv->currentCategoryTypeString = fileIndexPriv->currentNode->string;
      break;

   default:
      /* Do nothing */
      break;
   }

   FD_StringFree( stringCache, newStr );

   if( retCode != FD_SUCCESS )
      return retCode;

   FD_FileIndexGoDownTreeValue( fileIndexPriv );

   return FD_SUCCESS;
}

static FD_RetCode extractTokenValueRecursive( FD_FileIndexPriv *fileIndexPriv,
                                              FD_PatternIter *iter,
                                              const char *string,
                                              unsigned int firstOfOneOrMore )
{
    FD_PROLOG
    int i, again;
    int patternChar, stringChar;
    /* int caseSensitive; */
    FD_RetCode retCode;
    FD_ValueTreeNode *currentNode;
    FD_PatternIter iterCopy;
    char tmpOneCharBuf[2];
    FD_TokenId curTokenId;

    FD_TRACE_BEGIN( extractTokenValueRecursive );

    firstOfOneOrMore = 0;

    tmpOneCharBuf[0] = '\0';
    tmpOneCharBuf[1] = '\0';

    /* caseSensitive = FD_IsFileSystemCaseSensitive(); */

    patternChar = getPatternChar( iter);

    /* ScratchPad used as temporary buffer. */
    fileIndexPriv->scratchPad[0] = '\0';
    again = 1;

    while( patternChar != '\0')
    {
        stringChar = *string;

        /* Keep track of the token id being processed. */
        curTokenId = iter->curToken->id;

        /* Move to the next character in the pattern. */
        nextPatternChar( iter);

        switch( patternChar )
        {
        case '?':
           /* Eat the character for the '?' */
           if( stringChar == '\0' )
           {
              FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
           }
           string++;

           /* Save the value in the "value tree". */
           tmpOneCharBuf[0] = (char)stringChar;
           retCode = addValueDown( fileIndexPriv, iter->curToken->id, &tmpOneCharBuf[0] );
           tmpOneCharBuf[0] = '\0';

           if( retCode != FD_SUCCESS )
           {
              FD_TRACE_RETURN( retCode );
           }

           break;

        case '|': /* One or more character. */

            /* This special pattern is used for fields like FD_TOK_SYM, FD_TOK_CAT etc... */
            if( firstOfOneOrMore != '\0' )
            {
               FD_TRACE_RETURN( FD_INTERNAL_ERROR(84) );
            }

            if( stringChar == '\0' )
            {
               FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
            }

            string++;

            /* Keep track of this character. It will be
             * concatenated with the character extracted from the
             * following '*' processing.
             */
            tmpOneCharBuf[0] = (char)stringChar;
            firstOfOneOrMore = stringChar;
            break;

        case '*':
            /* Replace by strlen !?!?!? */
            i = 0;
            while (string[i] != '\0')
               i++;

            if( getPatternChar(iter) == '\0' )
            {
               /* There is not pattern following, that means the '*'
                * is the last pattern on the line. Simply take the
                * remaining of the string.
                */
               again = 0; /* Indicates sub string resolved. */
            }
            else if( i != 0 )
            {
               again = 1;
               while( i  && again )
               {
                  /* Call recursively while saving/restoring the currentNode. */
                  currentNode = FD_FileIndexGetCurrentTreeValueNode( fileIndexPriv );
                  FD_ASSERT( currentNode != NULL );
                  FD_FileIndexGoDownTreeValue( fileIndexPriv );
                  iterCopy = *iter; /* Recursive call use their own iterator... */
                  retCode = extractTokenValueRecursive( fileIndexPriv, &iterCopy, ( const char *)&string[i-1], firstOfOneOrMore );
                  FD_FileIndexSetCurrentTreeValueNode( fileIndexPriv, currentNode );

                  if( retCode != FD_SUCCESS )
                  {
                     if( retCode == FD_NO_DATA_SOURCE )
                        i--;  /* Cannot resolve remaining of pattern. Try again. */
                     else
                        return retCode; /* Something wrong happen. */
                  }
                  else
                  {
                     again = 0; /* Exit the loop. Sub pattern resolved */
                     i--;
                  }
               }
            }

            /* The remaining of the pattern is resolved starting at 'string[i-1]'.
             * Put in scratchPad all the potential character forming the '*'
             * between string[0..i-1]
             *
             * (Concatenate to possibly already extracted firstOfOneChar when
             *  processing the '*' for a '|').
             */
            if( firstOfOneOrMore )
            {
               fileIndexPriv->scratchPad[0] = tmpOneCharBuf[0];
               strcpy( &fileIndexPriv->scratchPad[1], string );
               if( i == 0 )
                  fileIndexPriv->scratchPad[1] = '\0';
               else
                  fileIndexPriv->scratchPad[i+1] = '\0';
               firstOfOneOrMore = 0;
            }
            else
            {
               if( i == 0 )
                  fileIndexPriv->scratchPad[0] = '\0';
               else
               {
                  strcpy( fileIndexPriv->scratchPad, string );
                  fileIndexPriv->scratchPad[i] = '\0';
               }
            }

            /* Always do the writing even if empty string. */
            retCode = addValueDown( fileIndexPriv, curTokenId, fileIndexPriv->scratchPad );
            if( retCode != FD_SUCCESS )
            {
               FD_TRACE_RETURN( retCode );
            }

            if( again == 0 )
            {
               FD_TRACE_RETURN( FD_SUCCESS );
            }
            else
            {
               FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
            }

        default:
            /* Validate that it is a good character indeed... */
/*            if( caseSensitive )
            {
               if( stringChar != patternChar )
               {
                  FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
               }
            }
            else */
            if( toupper(stringChar) != toupper(patternChar) )
            {
               FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
            }

            string++;
            break;
        }

        patternChar = getPatternChar(iter);
    }

    /* Trap case where string is longer than the expected pattern... */
    if( *string != '\0' )
    {
        FD_TRACE_RETURN( FD_NO_DATA_SOURCE );
    }

    /* Pattern correctly identify and all token extracted!
     * (except may be some '*' on the way back of the recursion...)
     */
    FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode addCurrentDataToIndex( FD_FileIndexPriv *fileIndexPriv,
                                         FD_ValueTreeNode *treeNodeValue )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileIndexCategoryData *addedCategory;
   FD_String *theCategoryString;
   char *tmpBuffer;
   unsigned int tmpBufferSize;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN(  addCurrentDataToIndex );
   FD_ASSERT( fileIndexPriv != NULL );

   stringCache = FD_GetGlobalStringCache( );

   if( fileIndexPriv->currentSymbolString == NULL )
   {
      FD_FATAL(  NULL, fileIndexPriv->currentSymbolString, fileIndexPriv->currentCategoryString );
   }

   /* Build the category string. */
   if( fileIndexPriv->currentCategoryCountryString ||
       fileIndexPriv->currentCategoryExchangeString ||
       fileIndexPriv->currentCategoryTypeString )
   {
      /* A partial category was provided. Complete the
       * missing component and build a category string.
       */
      if( !fileIndexPriv->currentCategoryCountryString )
         fileIndexPriv->currentCategoryCountryString = fileIndexPriv->initialCategoryCountryString;

      if( !fileIndexPriv->currentCategoryExchangeString )
         fileIndexPriv->currentCategoryExchangeString = fileIndexPriv->initialCategoryExchangeString;

      if( !fileIndexPriv->currentCategoryTypeString )
         fileIndexPriv->currentCategoryTypeString = fileIndexPriv->initialCategoryTypeString;

      tmpBufferSize  = strlen( FD_StringToChar(fileIndexPriv->currentCategoryCountryString) );
      tmpBufferSize += strlen( FD_StringToChar(fileIndexPriv->currentCategoryExchangeString) );
      tmpBufferSize += strlen( FD_StringToChar(fileIndexPriv->currentCategoryTypeString) );
      tmpBufferSize += 3;

      tmpBuffer = FD_Malloc( tmpBufferSize );
      if( !tmpBuffer )
      {
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      sprintf( tmpBuffer, "%s.%s.%s",
               FD_StringToChar(fileIndexPriv->currentCategoryCountryString),
               FD_StringToChar(fileIndexPriv->currentCategoryExchangeString),
               FD_StringToChar(fileIndexPriv->currentCategoryTypeString ));
               
      theCategoryString = FD_StringAlloc( stringCache, tmpBuffer );
      FD_Free(  tmpBuffer );
   }
   else if( !fileIndexPriv->currentCategoryString )
   {
      /* Use the default category. */
      theCategoryString = FD_StringDup( stringCache, fileIndexPriv->initialCategoryString );
   }
   else
      theCategoryString = FD_StringDup( stringCache, fileIndexPriv->currentCategoryString );

   retCode = FD_FileIndexAddCategoryData( fileIndexPriv,
                                          theCategoryString,
                                          &addedCategory );

   FD_StringFree( stringCache, theCategoryString );

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   retCode = FD_FileIndexAddSymbolData( addedCategory,
                                        fileIndexPriv->currentSymbolString,
                                        treeNodeValue, NULL );

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}
