#ifndef FD_SOURCE_H
#define FD_SOURCE_H

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_ADDDATASOURCEPARAMPRIV_H
   #include "fd_adddatasourceparam_priv.h"
#endif

/* Flags to indicate which functionality is supported by this data
 * source driver.
 *
 * FD_SLOW_ACCESS
 *   Indicates that the retreival of the data cannot be done as fast as a
 *   locally accessible database. This may result into multithreading when
 *   retreiving data. Any data source relying solely on internet should be
 *   characterize as slow access.
 *
 * FD_LOCATION_IS_PATH
 *   Indicates that the "location" parameter when doing FD_AddDataSource
 *   is expected to be a filesystem path. In that case, FIDAL might adapt
 *   the location (depending of the platform on which it is running) before
 *   passing it to the driver.
 *
 * The list of flags here are not accessible to the FIDAL user.
 * See fd_defs.h for the flags accessible to the FIDAL user.
 */

/* Note: for the 16 less significant bits, see fd_defs.h */
#define FD_SLOW_ACCESS      (1<<16)
#define FD_LOCATION_IS_PATH (1<<17)

typedef struct
{
   unsigned int flags;
} FD_DataSourceParameters;

/* The following handles allow the data source to pass some needed
 * information back to the FIDAL.
 * But the most important aspect of these handle is to provide a way
 * to hide driver specific information into the 'opaque' pointer.
 */
typedef struct
{
   /* Public value that must be initialize by 'openSource()'. */
   unsigned int nbCategory;  /* Number of category in that data source. */

   /* Private opaque data. The data source driver can set that
    * pointer to whatever they need.
    */
   void *opaqueData;
} FD_DataSourceHandle;

typedef struct
{
   /* Public value that must be initialize by 'getXXXXXCategoryHandle()'. */
   FD_String *string;     /* String of this category. */
   unsigned int nbSymbol; /* Number of symbol under that category. */

   /* Private opaque data. The data source driver can set that
    * pointer to whatever they need.
    */
   void *opaqueData;
} FD_CategoryHandle;

typedef struct
{
   /* Public value that must be initialize by 'getXXXXXSymbolHandle()'. */
   FD_String *string;  /* String for the symbol (ticker). */

   /* Private opaque data. The data source driver can set that
    * pointer to whatever they need.
    */
   void *opaqueData;
} FD_SymbolHandle;

/* The following function can be called by the driver from the
 * getHistoryData() function only! (see below)
 * It allows to add the data who is going to be used in the merging
 * mechanism for building the FD_History.
 *
 * The added data must have been allocated with FD_Malloc.
 * Once the pointer is pass to FD_HistoryData, the driver
 * is not the owner of that data anymore, and it should never
 * attempt to free it.
 */
typedef unsigned int FD_ParamForAddData; /* hidden implementation. */

FD_RetCode FD_HistoryAddData( FD_ParamForAddData *paramForAddData,
                              unsigned int nbBarAdded,
                              FD_Period period,
                              FD_Timestamp *timestamp,
                              FD_Real *open,
                              FD_Real *high,
                              FD_Real *low,
                              FD_Real *close,
                              FD_Integer *volume,
                              FD_Integer *openInterest );

/* The following can be called by the driver from the getHistoryData() 
 * function only.
 * This allow the driver to verify if the driver should abort 
 * the data retreival operation (typically because exceeding user specified timeout).
 *
 * When returning a value != FD_SUCCESS, the driver should return from the getHistoryData 
 * with the error code returned by FD_DriverShouldContinue().
 */
FD_RetCode FD_DriverShouldContinue( FD_ParamForAddData *paramForAddData );

/* The following functions can be called by the driver from the
 * GetHistoryData() function only! (see below)
 *
 * It allows to add split/value adjustment for building
 * the FD_History.
 *
 * In other word, the driver adds the raw data and the adjustment
 * are done by FIDAL (as needed).
 */
FD_RetCode FD_HistoryAddSplitAdjust( FD_ParamForAddData *paramForAddData, FD_Timestamp *when, double factor );
FD_RetCode FD_HistoryAddValueAdjust( FD_ParamForAddData *paramForAddData, FD_Timestamp *when, double amount );

/* Allows the data source driver to cancel all the data
 * who was added up to now. This might be useful if
 * the data source driver needs to restart the processing
 * of adding the data.
 */
FD_RetCode FD_HistoryAddDataReset( FD_ParamForAddData *paramForAddData );

/* The source driver can get some info who is derived from all
 * the added data up to now.
 */
typedef struct
{
   /* These reflect the cummulation of ALL bar added up to now */    
   FD_Timestamp highestTimestamp;
   FD_Timestamp lowestTimestamp;

   /* These are reset EVERYTIME FD_GetInfoFromAddedData is called.
    * In other word, these reflect the cummulation of what
    * happen since the las FD_GetInfoFromAddedData was called.
    * Take note that this function is reserved exclusively
    * for being called by the data source driver.
    */
   unsigned int barAddedSinceLastCall; /* boolean */
   FD_Timestamp lowestTimestampAddedSinceLastCall;
   FD_Timestamp highestTimestampAddedSinceLastCall; 
} FD_InfoFromAddedData;

FD_RetCode FD_GetInfoFromAddedData( FD_ParamForAddData *paramForAddData,
                                    FD_InfoFromAddedData *info );


typedef struct
{
    const char *defaultName;

    /* The driver initialization is the VERY first
     * function called. This allows the driver to initialize
     * its own global variables etc...
     */
    FD_RetCode (*initializeSourceDriver)( void );

    /* Free all ressources. Call only if the initialization
     * succeed.
     */
    FD_RetCode (*shutdownSourceDriver)( void );

    /* Allows the data source to indicate which capability
     * are available from it. Can be called before the open
     * but only after the initialization.
     */
    FD_RetCode (*getParameters)( FD_DataSourceParameters *param );

    /* The data cannot be access from the source without
     * opening it.
     *
     * A driver should allow to open multiple source simultaneouly.
     * The FD_DataSourceHandle allows to differentiate the instances.
     *
     * FD_AddDataSourceParam is a local copy of all the parameters
     * pass by the library user. The data source can safely keep
     * a pointer on these parameters until closeSource gets called.
     */
    FD_RetCode (*openSource)( const FD_AddDataSourceParamPriv *param,
                              FD_DataSourceHandle **handle );

    FD_RetCode (*closeSource)( FD_DataSourceHandle *handle );

    /* The followings allows to get the "index" of the category and symbol
     * provided by this data source.
     *
     * The driver can set 'opaque' information to each category/symbol.
     *
     * The categoryHandle and symbolHandle are already allocated, the driver
     * just need to fill up the information.
     *
     * The pointers in the 'handles' must stay valid until the source is 
     * closed with closeSource.
     *
     * The driver is responsible to de-allocate the 'string' found
     * in the handles when closeSource will get called.
     *
     * Must return FD_END_OF_INDEX if no further elements are available.
     */
    FD_RetCode (*getFirstCategoryHandle)( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle *categoryHandle );

    FD_RetCode (*getNextCategoryHandle) ( FD_DataSourceHandle *handle,
                                          FD_CategoryHandle *categoryHandle,
                                          unsigned int index );

    FD_RetCode (*getFirstSymbolHandle)( FD_DataSourceHandle *handle,
                                        FD_CategoryHandle *categoryHandle,
                                        FD_SymbolHandle *symbolHandle );

    FD_RetCode (*getNextSymbolHandle)( FD_DataSourceHandle *handle,
                                       FD_CategoryHandle *categoryHandle,
                                       FD_SymbolHandle *symbolHandle,
                                       unsigned int index );

    /* GetHistoryData allows the driver to provides the data used to
     * build the FD_History.
     *
     * The main responsibility of this function is to retreive the data
     * corresponding to the symbol and pass it to the library by
     * doing one or many call to FD_HistoryAddData().
     */
    FD_RetCode (*getHistoryData)( FD_DataSourceHandle *handle,
                                  FD_CategoryHandle   *categoryHandle,
                                  FD_SymbolHandle     *symbolHandle,
                                  FD_Period            period,
                                  const FD_Timestamp  *start,
                                  const FD_Timestamp  *end,
                                  FD_Field             fieldToAlloc,
                                  FD_ParamForAddData  *paramForAddData );

} FD_DataSourceDriver;

/* Global variables defined in fd_source.c */
extern const FD_DataSourceDriver  FD_gDataSourceTable[];
extern const unsigned int         FD_gDataSourceTableSize;

#endif

