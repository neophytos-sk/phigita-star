#ifndef FD_YAHOO_IDX_H
#define FD_YAHOO_IDX_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_STREAM_H
   #include "fd_stream.h"
#endif

#ifndef FD_COUNTRY_INFO
   #include "fd_country_info.h"
#endif

#ifndef FD_YAHOO_PRIV_H
   #include "fd_yahoo_priv.h"
#endif

typedef struct
{
   FD_String *name; /* Name of this category. */

   unsigned int nbSymbol; /* Nb of symbols in this cateogry. */
   FD_String **symbols;   /* Name of symbols in this category. */

   /* Do not modify the following! */
   void *hiddenData;
} FD_YahooCategory;

typedef struct
{
   FD_CountryId countryId;        /* The country of this index. */

   unsigned char countryAbbrev[3]; /* A 2 letters abbreviation for this
                                    * country. NULL terminated.
                                    */

   unsigned int nbCategory;
   FD_YahooCategory **categories;

   FD_Timestamp creationDate;

   /* Do not modify the following! */
   void *hiddenData;
} FD_YahooIdx;

/* Build an index using the online Yahoo! web site.
 *
 * The strategy indicates how the index could be build.
 *
 * FD_USE_STREAM: Use the provided stream for building
 * the index.
 *
 * FD_USE_LOCAL_CACHE: Use the local cache to retreive
 * the index. An optional timeout can be provided.
 *
 * FD_USE_REMOTE_CACHE: Give the possibility to avoid to 
 * bother Yahoo! by using a pre-assembled index stored
 * at fidalsoft.org. An optional timeout can be provided.
 *
 * FD_USE_YAHOO_SITE: Build the index by accessing
 * directly the Yahoo! web site as the source. This is
 * requiring a lot of bandwidth and patience (can take
 * many hours).
 *
 * FD_USE_YAHOO_AND_REMOTE_MERGE
 * Use remote Yahoo! web site and fidalsoft.org to update
 * more quickly a local index.
 *
 * Note 1: The strategy can be mixed and are going to be attempted
 *         in the order state above. Example:
 *            FD_USE_YAHOO_SITE|FD_USE_REMOTE_CACHE will first
 *            try the remote cache, if it fails it will then
 *            rebuild the index directly from Yahoo!.
 *
 * Note 2: if 'stream' is provided, the index is inconditionaly
 *         build from this stream. No other strategy are
 *         attempted.
 */
typedef enum
{
   FD_USE_STREAM                 = 0x02,
   FD_USE_LOCAL_CACHE            = 0x04,
   FD_USE_REMOTE_CACHE           = 0x08,
   FD_USE_YAHOO_SITE             = 0x10,
   FD_USE_YAHOO_AND_REMOTE_MERGE = 0x20
} FD_YahooIdxStrategy;

FD_RetCode FD_YahooIdxAlloc( FD_CountryId           countryId,
                             FD_YahooIdx          **yahooIdxAllocated,
                             FD_YahooIdxStrategy    strategy,
                             FD_Stream             *stream,
                             FD_Timestamp          *localCacheTimeout,
                             FD_Timestamp          *remoteCacheTimeout );

FD_RetCode FD_YahooIdxFree( FD_YahooIdx *idxToBefreed );

/* Compress an index and transform it into a stream of bytes. This stream
 * can be used to rebuild at a later time the index by using the FD_USE_STREAM
 * strategy.
 *
 * Error detection are included in the stream, allowing to transmit/store that
 * stream with confidence. Using that stream, you are guaranteed that the index
 * will be identical when FD_YahooIdxAlloc succeed.
 *
 * The exact same stream is used for the local and remote cache.
 */
FD_RetCode FD_YahooIdxStream( const FD_YahooIdx *idx, FD_Stream **streamAllocated );

/* Get the decoding parameters. 
 *
 * Inside a yahoo index, some decoding information are stored. This
 * information will allow to potentially adapt to a new parsing for
 * the Yahoo! web pages (without having to change the library).
 * 
 * The specific web site address and page location is also encoded.
 */
typedef enum {FD_YAHOOIDX_CSV_PAGE,
              FD_YAHOOIDX_MARKET_PAGE,
              FD_YAHOOIDX_INFO,
              FD_YAHOOIDX_ADJUSTMENT} FD_DecodeType;

FD_DecodingParam *FD_YahooIdxDecodingParam( FD_YahooIdx *idx, FD_DecodeType type );

/* Get the decoding parameters to get the market data from 
 * a specific Yahoo! web site.
 */ 
FD_RetCode FD_YahooIdxDataDecoding( FD_CountryId id,
                                    FD_DecodeType type,
                                    FD_DecodingParam *param );

#endif
