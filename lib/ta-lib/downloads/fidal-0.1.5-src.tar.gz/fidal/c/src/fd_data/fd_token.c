/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  010301 MF   First version.
 *  040304 MF   Add FD_TOK_SKIP_NON_DIGIT_LINE
 */

/* Description:
 *   Utility functions describing the tokens used to parse
 *   strings containing TA related fields (like "[D][M][Y]").
 */

/**** Headers ****/
#include <stdlib.h>

#include "fd_token.h"
#include "fd_common.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
/* None */

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

unsigned int FD_TokenMaxSize( FD_TokenId id )
{
   /* NOTE: The following data structure MUST correspond exactly to the
    *       FD_TokenId enumeration order!
    */

   /* Zero indicates that the size is not pre-determined. */

   static int tokenSize[] =
   {
      0, /* FD_TOK_FIX */

      4, /* FD_TOK_YYYY */
      2, /* FD_TOK_YY   */
      0, /* FD_TOK_Y    */

      0, /* FD_TOK_M   */
      2, /* FD_TOK_MM  */
      3, /* FD_TOK_MMM */

      0, /* FD_TOK_D */
      2, /* FD_TOK_DD */

      0, /* FD_TOK_CAT */
      0, /* FD_TOK_CATC */
      0, /* FD_TOK_CATX */
      0, /* FD_TOK_CATT */

      0, /* FD_TOK_SYM */
      0, /* FD_TOK_SYMF */
      1, /* FD_TOK_SEP */

      0, /* FD_TOK_WILD */
      1, /* FD_TOK_WILD_CHAR */

      0, /* FD_TOK_OPEN */
      0, /* FD_TOK_HIGH */
      0, /* FD_TOK_LOW */
      0, /* FD_TOK_CLOSE */
      0, /* FD_TOK_VOLUME */
      0, /* FD_TOK_OPENINTEREST */

      0, /* FD_TOK_HOUR */
      0, /* FD_TOK_MIN */
      0, /* FD_TOK_SEC */

      2, /* FD_TOK_HH */
      2, /* FD_TOK_MN */
      2, /* FD_TOK_SS */

      0,   /* FD_TOK_SKIP_REAL */
      0,   /* FD_TOK_SKIP_INTEGER */
      0,   /* FD_TOK_SKIP_N_CHAR */
      0,   /* FD_TOK_SKIP_N_HEADER_LINE */
      0,   /* FD_TOK_SKIP_NON_DIGIT_LINE */

      0, /* FD_END */
   };

   /* Note: 0 means unspecified number of character (wild) */

   if( (id == FD_INVALID_TOKEN_ID) || (id < 0) )
   {
      FD_FATAL_RET( NULL, id, FD_INVALID_TOKEN_ID, 0 );
   }

   return tokenSize[id];
}


const char *FD_TokenDebugString( FD_TokenId id )
{
   /* NOTE: The following data structure MUST correspond exactly to the
    *       FD_TokenId enumeration order!
    */
   static const char *tokenString[] =
   {
      "FIX",

      "YEAR",
      "YEAR",
      "YEAR",
      "MONTH",
      "MONTH",
      "MONTH",
      "DAY",
      "DAY",

      "CATEGORY",
      "COUNTRY",
      "EXCHANGE",
      "TYPE",
      "SYMBOL",

      "SYMBOL",
      "SEP",
      "WILD",
      "WILD CHAR",

      "OPEN",
      "HIGH",
      "LOW",
      "CLOSE",
      "VOLUME",
      "OPEN INTEREST",

      "HOUR",
      "MINUTE",
      "SECOND",

      "HOUR",
      "MINUTE",
      "SECOND",

      "SKIP REAL",
      "SKIP INTEGER",
      "SKIP CHAR",
      "SKIP HEADER_LINE",
      "SKIP NON-DIGIT LINE",

      "END"
   };

   if( (id == FD_INVALID_TOKEN_ID) || (id < 0) )
      return (char *)NULL;

   return tokenString[id];
}

const char *FD_TokenString( FD_TokenId id )
{
   /* NOTE: The following data structure MUST correspond exactly to the
    *       FD_TokenId enumeration order!
    */
   static const char *tokenString[] =
   {
      NULL, /* FD_TOK_FIX */

      "YYYY",
      "YY",
      "Y",
      "M",
      "MM",
      "MMM",
      "D",
      "DD",

      "CAT",
      "CATC",
      "CATX",
      "CATT",
      "SYM",

      NULL, /* FD_TOK_SYMF */
      NULL, /* FD_TOK_SEP */
      NULL, /* FD_TOK_WILD */
      NULL, /* FD_TOK_WILDCHAR */

      "O",
      "H",
      "L",
      "C",
      "V",
      "OI",

      "HOUR",
      "MIN",
      "SEC",

      "HH",
      "MN",
      "SS",

      "-R",   /* FD_TOK_SKIP_N_REAL */
      "-I",   /* FD_TOK_SKIP_N_INTEGER */
      "-C",   /* FD_TOK_SKIP_N_CHAR */
      "-H",   /* FD_TOK_SKIP_N_HEADER_LINE */
      "-NDL", /* FD_TOK_SKIP_NON_DIGIT_LINE */

      NULL  /* FD_TOK_END */
   };

   if( (id == FD_INVALID_TOKEN_ID) || (id < 0) )
      return (char *)NULL;

   return tokenString[id];
}

/**** Local functions definitions.     ****/
/* None */

