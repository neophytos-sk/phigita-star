#ifndef FD_ASCII_HANDLE_H
#define FD_ASCII_HANDLE_H

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FD_FILEINDEX_H
   #include "fd_fileindex.h"
#endif

#ifndef FD_READOP_H
   #include "fd_readop.h"
#endif

#ifndef FD_DAFD_UDB_H
   #include "fd_data_udb.h"
#endif

typedef struct
{  
   /* Keep a ptr on the user FD_AddDataSource parameters. */
   const FD_AddDataSourceParamPriv *param;

   /* The FD_FileIndex represent all the categories and symbols
    * extracted from the provided 'sourceLocation' and 'categoryString'.
    */
   FD_FileIndex *theFileIndex;

   /* Contains all the info for interpreting the ASCII file. */
   FD_ReadOpInfo *readOpInfo;

} FD_PrivateAsciiHandle;

/* Alloc/Free for the FD_DataSourceHandle.
 *
 * Takes care also to alloc/initialize/free the FD_PrivateAsciiHandle
 * which is the 'opaque' part of the FD_DataSourceHandle.
 */
FD_DataSourceHandle *FD_ASCII_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param );

FD_RetCode FD_ASCII_DataSourceHandleFree( FD_DataSourceHandle *handle );

/* Build (or re-build) the FD_FileIndex for this handle. */
FD_RetCode FD_ASCII_BuildFileIndex( FD_DataSourceHandle *handle );

/* Build the list of "read operations" to perform for this ASCII file. */
FD_RetCode FD_ASCII_BuildReadOpInfo( FD_DataSourceHandle *handle );

#endif
