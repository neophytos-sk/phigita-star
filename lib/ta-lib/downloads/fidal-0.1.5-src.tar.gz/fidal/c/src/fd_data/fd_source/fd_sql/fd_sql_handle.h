#ifndef FD_SQL_HANDLE_H
#define FD_SQL_HANDLE_H

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

#ifndef FD_LIST_H
   #include "fd_list.h"
#endif

#ifndef FD_DAFD_UDB_H
   #include "fd_data_udb.h"
#endif

#ifndef FD_SQL_MINIDRIVER_H
   #include "fd_sql_minidriver.h"
#endif

#define FD_SQL_CATEGORY_COLUMN              "category"
#define FD_SQL_SYMBOL_COLUMN                "symbol"
#define FD_SQL_DATE_COLUMN                  "date"
#define FD_SQL_TIME_COLUMN                  "time"
#define FD_SQL_OPEN_COLUMN                  "open"
#define FD_SQL_HIGH_COLUMN                  "high"
#define FD_SQL_LOW_COLUMN                   "low"
#define FD_SQL_CLOSE_COLUMN                 "close"
#define FD_SQL_VOLUME_COLUMN                "volume"
#define FD_SQL_OI_COLUMN                    "oi"

#define FD_SQL_MAX_COLUMN_NAME_SIZE         10


#define FD_SQL_CATEGORY_PLACEHOLDER         "$c"
#define FD_SQL_SYMBOL_PLACEHOLDER           "$s"
#define FD_SQL_START_DATE_PLACEHOLDER       "$<"
#define FD_SQL_END_DATE_PLACEHOLDER         "$>"
#define FD_SQL_START_TIME_PLACEHOLDER       "$["
#define FD_SQL_END_TIME_PLACEHOLDER         "$]"

/* placeholders not supported yet
#define FD_SQL_COUNTRY_PLACEHOLDER          "$z"
#define FD_SQL_EXCHANGE_PLACEHOLDER         "$x"
#define FD_SQL_TYPE_PLACEHOLDER             "$t"
*/


typedef struct
{
   /* the name of the category */
   FD_String *category;

   /* List of symbols in this category.
    * Elements on this list are of FD_String type.
    */
   FD_List *theSymbols;

} FD_SQLCategoryNode;

typedef struct
{  
   /* Keep a ptr on the user FD_AddDataSource parameters. */
   const FD_AddDataSourceParamPriv *param;

   /* database name (from location) */
   FD_String *database;

   /* theSymbolsIndex represent all the categories and symbols
    * extracted from the provided data source parameters.
    * Elements on this list are of FD_SQLCategoryNode type.
    */
   FD_List *theCategoryIndex;

   /* minidriver for this connection */
   const FD_SQL_Minidriver *minidriver;

   /* Contains database connection object 
    * It is opaque data used by connection minidrivers
    */
   void *connection;

} FD_PrivateSQLHandle;

/* Alloc/Free for the FD_DataSourceHandle.
 *
 * Takes care also to alloc/initialize/free the FD_PrivateSQLHandle
 * which is the 'opaque' part of the FD_DataSourceHandle.
 */
FD_DataSourceHandle *FD_SQL_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param );

FD_RetCode FD_SQL_DataSourceHandleFree( FD_DataSourceHandle *handle );

/* Build (or re-build) the categories and symbols index for this handle. */
FD_RetCode FD_SQL_BuildSymbolsIndex( FD_DataSourceHandle *handle );


#endif

