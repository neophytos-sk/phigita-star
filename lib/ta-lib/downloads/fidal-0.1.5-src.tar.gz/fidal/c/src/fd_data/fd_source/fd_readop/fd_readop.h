#ifndef FD_READOP_H
#define FD_READOP_H

#ifndef FIDAL_H
   #include "fidal.h"
#endif

#ifndef FD_SYSTEM_H
   #include "fd_system.h"
#endif

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

/* Provides all the functionality for
 * speed optimized read of ASCII file.
 *
 * Note: the file can be in fact a stream in
 *       memory, but this module won't make the
 *       difference.
 *
 * I have to admit, this is slightly complex and
 * a simpler approach could have been choosen. On
 * the other side, the speed here is everything.
 */

/* Definition used for defining a FD_ReadOp.
 * One read operation is encoded within one 32 bit. The fields
 * of the 32 bit provides the following information:
 *  - Should we read an integer or a real? (FD_IS_REAL_CMD...)
 *  - Is that read operation can be skip because the
 *    user did not request for this field when building the
 *    FD_History? (FD_CMD_SKIP_FLAG)
 *  - Is that read operation can be skip because a value must
 *    be permanently skip in the file? (FD_CMD_PERMANENT_SKIP_FLAG)
 *  - Where do I store the read data? (FD_GET_IDX).
 *  - Is this the last operation needed because the user
 *    already got all its field for its FD_History? (FD_CMD_READ_STOP_FLAG)
 *  - Is this the VERY last read operation? (FD_CMD_LAST_FLAG).
 *  - After that read operation, did we get everything needed
 *    to build and validate the timestamp? (FD_FIELD_TIMESTAMP_COMPLETE_FLAG).
 *  - Shall lines not starting with a digit be skipped? (FD_CMD_SKIP_NDL_FLAG).
 */
#define FD_CMD_READ_REAL              0x00000100
#define FD_CMD_READ_INTEGER           0x00000200
#define FD_CMD_READ_MONTH_CHAR        0x00000400
#define FD_CMD_PERMANENT_SKIP_FLAG    0x00000800
#define FD_FIELD_TIMESTAMP_COMPLETE_FLAG    0x00001000
#define FD_CMD_SKIP_FLAG              0x00002000
#define FD_CMD_READ_STOP_FLAG         0x00004000
#define FD_CMD_REPLACE_ZERO           0x00008000
#define FD_CMD_SKIP_NDL_FLAG          0x00010000
#define FD_CMD_LAST_FLAG             (0x00080000|FD_CMD_READ_STOP_FLAG)

#define FD_FIELD_CLOSE_IDX        0x00000000
#define FD_FIELD_OPEN_IDX         0x00000001
#define FD_FIELD_HIGH_IDX         0x00000002
#define FD_FIELD_LOW_IDX          0x00000003
#define FD_REAL_ARRAY_SIZE  4

#define FD_FIELD_VOLUME_IDX       0x00000007
#define FD_FIELD_OPENINTEREST_IDX 0x00000006
#define FD_YEAR_IDX         0x00000005
#define FD_MONTH_IDX        0x00000004
#define FD_DAY_IDX          0x00000003
#define FD_HOUR_IDX         0x00000002
#define FD_MIN_IDX          0x00000001
#define FD_SEC_IDX          0x00000000
#define FD_INTEGER_ARRAY_SIZE 8

#define FD_GET_IDX(v)        ((v)&0x000000FF)
#define FD_SET_IDX(v,idx)    {(v)&=0xFFFFFF00; (v)|=(idx&0x000000FF);}

#define FD_GET_NB_NUMERIC(v)     (((v)>>24) & 0x00000FFF)
#define FD_SET_NB_NUMERIC(v,cmd) {(v)&=0x000FFFFF; (v)|=((cmd<<24)&0xFFF00000);}

#define FD_SET_SKIP_FLAG(v)  {(v)|=FD_CMD_SKIP_FLAG;}
#define FD_CLR_SKIP_FLAG(v)  {(v)&=~FD_CMD_SKIP_FLAG;}
#define FD_IS_SKIP_SET(v)    ((v)&FD_CMD_SKIP_FLAG)

#define FD_SET_PERMANENT_SKIP_FLAG(v)  {(v)|=FD_CMD_PERMANENT_SKIP_FLAG;}
#define FD_CLR_PERMANENT_SKIP_FLAG(v)  {(v)&=~FD_CMD_PERMANENT_SKIP_FLAG;}
#define FD_IS_PERMANENT_SKIP_SET(v)    ((v)&FD_CMD_PERMANENT_SKIP_FLAG)

#define FD_SET_LAST_FLAG(v)  {(v)|=FD_CMD_LAST_FLAG;}
#define FD_CLR_LAST_FLAG(v)  {(v)&=~FD_CMD_LAST_FLAG;}
#define FD_IS_LAST_SET(v)    ((v)&FD_CMD_LAST_FLAG)

#define FD_SET_READ_STOP_FLAG(v)    {(v)|=FD_CMD_READ_STOP_FLAG;}
#define FD_CLR_READ_STOP_FLAG(v)    {(v)&=~FD_CMD_READ_STOP_FLAG;}
#define FD_IS_READ_STOP_FLAG_SET(v) ((v)&FD_CMD_READ_STOP_FLAG)

#define FD_SET_TIMESTAMP_COMPLETE(v) {(v)|=FD_FIELD_TIMESTAMP_COMPLETE_FLAG;}
#define FD_CLR_TIMESTAMP_COMPLETE(v) {(v)&=~FD_FIELD_TIMESTAMP_COMPLETE_FLAG;}
#define FD_IS_TIMESTAMP_COMPLETE(v)  ((v)&FD_FIELD_TIMESTAMP_COMPLETE_FLAG)

#define FD_SET_REPLACE_ZERO(v) {(v)|=FD_CMD_REPLACE_ZERO;}
#define FD_CLR_REPLACE_ZERO(v) {(v)&=~FD_CMD_REPLACE_ZERO;}
#define FD_IS_REPLACE_ZERO(v)  ((v)&FD_CMD_REPLACE_ZERO)

#define FD_IS_REAL_CMD(v)    ((v)&FD_CMD_READ_REAL)
#define FD_IS_INTEGER_CMD(v) ((v)&FD_CMD_READ_INTEGER)

#define FD_SET_SKIP_NDL_FLAG(v) {(v)|=FD_CMD_SKIP_NDL_FLAG;}
#define FD_CLR_SKIP_NDL_FLAG(v) {(v)&=~FD_CMD_SKIP_NDL_FLAG;}
#define FD_IS_SKIP_NDL_FLAG(v)  ((v)&FD_CMD_SKIP_NDL_FLAG)


typedef unsigned int FD_ReadOp;

typedef struct
{
   /* The parameter defining the fields. 
    * Example: "[YYYY][MM][DD][O][C][V]"
    */
   const char *sourceInfo;
   FD_Period period;

   /* Parameter that was used at creation */
   unsigned int readOpFlags;   

   /* The following array describes the series of operations that needs
    * to be performed for reading one line of the ASCII files.
    */
   FD_ReadOp *arrayReadOp;
   unsigned int nbReadOp;

   /* Some additional information for correctly processing the input file. */
   unsigned int nbHeaderLineToSkip;
   unsigned int openInterestMult; /* 1, 10, 100, 1000, 10000 */
   unsigned int volumeMult;       /* 1, 10, 100, 1000, 10000 */

   /* Indicates all the fields that can be provided. */
   FD_Field fieldProvided;
} FD_ReadOpInfo;

FD_RetCode FD_ReadOpInfoAlloc( const char *sourceInfo,
                               FD_ReadOpInfo **allocatedInfo,
                               unsigned int readOpFlags );

FD_RetCode FD_ReadOpInfoFree( FD_ReadOpInfo *readOpInfoToBeFreed );

FD_RetCode FD_ReadOp_Optimize( FD_ReadOpInfo *readOpInfo,
                               FD_Period      period,
                               FD_Field       fieldToAlloc );

FD_RetCode FD_ReadOp_Do( FD_FileHandle       *fileHandle,
                         const FD_ReadOpInfo *readOpInfo,
                         FD_Period            period,
                         const FD_Timestamp  *start,
                         const FD_Timestamp  *end,
                         unsigned int         minimumNbBar,
                         FD_Field             fieldToAlloc,
                         FD_ParamForAddData  *paramForAddData,
                         unsigned int        *nbBarAdded );

unsigned int FD_ReadOpToField( FD_ReadOp readOp );

/* Allocate a new readOpInfo from an existing one. */
FD_RetCode FD_ReadOpInfoClone( FD_ReadOpInfo **allocatedInfo, FD_ReadOpInfo *src );

 /* See fd_readop_estalloc.c */
typedef struct
{
  unsigned int minimumSize;
  unsigned int maximumSize;
} FD_EstimateInfo;

FD_RetCode FD_EstimateAllocInit( const FD_Timestamp *start,
                                 const FD_Timestamp *end,
                                 FD_Period period,
                                 unsigned int minimumSize,
                                 unsigned int maximumSize,
                                 FD_EstimateInfo *estimationInfo,
                                 unsigned int *nbElementToAllocate );

FD_RetCode FD_EstimateAllocNext( FD_EstimateInfo *estimationInfo,
                                 unsigned int *nbElementToAllocate );



#endif

