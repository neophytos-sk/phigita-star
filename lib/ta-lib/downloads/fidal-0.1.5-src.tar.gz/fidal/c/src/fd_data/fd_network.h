#ifndef FD_NETWORK_H
#define FD_NETWORK_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_STREAM_H
   #include "fd_stream.h"
#endif

/* Functionality for fetching a Web Page. */
typedef struct
{
   /* The content of the page is put in 
    * a FD_Stream. The header portion is
    * stripped from the page.
    */
   FD_Stream *content;

   /* Do not modify the following variable. */
   void *hiddenData;
} FD_WebPage;

/* Fetch the specified web page.
 *
 * Example 1  (http://www.yahoo.com):           
 *    FD_WebPage *webPage;
 *    FD_WebPageAlloc( "www.yahoo.com",
 *                     NULL, NULL, NULL, &webPage, 1 );
 *
 * Example 2 (http://finance.yahoo.com/q?s=LNUX&d=v1):
 *    FD_WebPage *webPage;
 *    FD_WebPageAlloc( "finance.yahoo.com",
 *                     "q?s=LNUX&d=v1", NULL, NULL, &webPage, 1 );
 *           
 * If no proxy is used, 'proxyName' and 'proxyPort' shall
 * be NULL. If 'proxyName' is specified but not 'proxyPort',
 * port 80 is used as the default. Note: When these parameters
 * are NULL on Windows, the proxy settings (if applicable) are
 * retreived for you from the registry.
 *
 * webSiteAddr can be the dotted-decimal address as well (x.x.x.x)
 *
 * Leave paramForAddData to NULL. This parameter is used exclusively
 * to control timeout when the call is done from the FIDAL data source
 * drivers.
 */
FD_RetCode FD_WebPageAlloc( const char    *webSiteAddr,
                            const char    *webSitePage,
                            const char    *proxyName,
                            const char    *proxyPort,
                            FD_WebPage   **webPageAllocated,
                            unsigned int   nbAttempt,
                            void          *paramForAddData  );

/* When FD_WebPageAlloc return FD_SUCCESS, the
 * allocated web page must be eventually freed
 * with FD_WebPageFree.
 */
FD_RetCode FD_WebPageFree( FD_WebPage *webPage );

#endif

