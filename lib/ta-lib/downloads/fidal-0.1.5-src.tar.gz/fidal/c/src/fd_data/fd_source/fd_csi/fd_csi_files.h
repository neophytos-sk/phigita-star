
#ifndef FD_CSI_FILES_H
#define FD_CSI_FILES_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

typedef struct MasterListRecordType {
    unsigned long csinum;
    unsigned long dydm;
    long strike; // + is call, - is put, 0 is non-option
    short cvf;
    FD_Period Period;
    int IsStock; // Boolean
    int Deleted; // Boolean
    char Name[80];
    char Symbol[10];
    char PricingUnits[5];
} MasterListRecord;

typedef struct {
  long date, dydm, strike, open, high, low, close, ClosingBid, ClosingAsk, vol, oi, tvol, toi;
} SingleContractDataDayCore;

FD_RetCode ReadCSIMaster  (const char *DirectoryName, struct MasterListRecordType **outMasterList, int *outNRec);
FD_RetCode ReadCSIMMaster (const char *DirectoryName, struct MasterListRecordType **outMasterList, int *outNRec);

FD_RetCode ReadCSIData    (const char *DirectoryName, int FileNumber, short cvf, SingleContractDataDayCore **outDataList, int *outNRec);
FD_RetCode ReadCSIMData   (const char *DirectoryName, int FileNumber, short cvf, SingleContractDataDayCore **outDataList, int *outNRec);

#endif
