/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  031904 MF   First version.
 */

/* Description:
 *    Allows to allocate/de-allocate FD_DataSourceHandle structure.
 */

/**** Headers ****/
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_csi_handle.h"
#include "fd_global.h"
#include "fd_string.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/
static FD_PrivateCSIHandle *allocPrivateHandle( void );
static FD_RetCode freePrivateHandle( FD_PrivateCSIHandle *privateHandle );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/

FD_DataSourceHandle *FD_CSI_DataSourceHandleAlloc( const FD_AddDataSourceParamPriv *param )
{
   FD_DataSourceHandle *handle;
   FD_PrivateCSIHandle *privateHandle;

   FD_ASSERT_RET( param != NULL, (FD_DataSourceHandle *)NULL );
      
   handle = (FD_DataSourceHandle *)FD_Malloc(sizeof( FD_DataSourceHandle ));
   if( !handle )
      return (FD_DataSourceHandle *)NULL;

   memset( handle, 0, sizeof(handle) );

   /* Allocate the opaque data. */
   handle->opaqueData = allocPrivateHandle();
   if( !handle->opaqueData )
   {
      FD_CSI_DataSourceHandleFree( handle );
      return (FD_DataSourceHandle *)NULL;
   }

   /* Keep a pointer on the FD_AddDataSourcePriv parameters.
    * This pointer (and its content) is guaranteed to be good
    * until CloseSource gets called.
    */
   privateHandle = (FD_PrivateCSIHandle *)handle->opaqueData;   
   privateHandle->param = param;

   return handle;
}

FD_RetCode FD_CSI_DataSourceHandleFree( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_PrivateCSIHandle *privateHandle;

   FD_TRACE_BEGIN( FD_CSI_DataSourceHandleFree );
   FD_ASSERT( handle != NULL );

   privateHandle = (FD_PrivateCSIHandle *)handle->opaqueData;

   if( freePrivateHandle( (FD_PrivateCSIHandle *)handle->opaqueData ) != FD_SUCCESS )
   {
      FD_FATAL(  NULL, handle, 0 );
   }

   FD_Free( handle );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_CSI_BuildIndex( FD_DataSourceHandle *handle )
{
   FD_PROLOG
   FD_PrivateCSIHandle *privateHandle;
   FD_String *stringTmp;   
   FD_String **indexString;
   FD_StringCache *stringCache;
   const char *directory;

   struct MasterListRecordType *outMasterList;
   int outNRec;
   FD_RetCode retCode;
   int i;

   FD_TRACE_BEGIN( FD_CSI_BuildIndex );

   FD_ASSERT( handle != NULL );
   privateHandle = (FD_PrivateCSIHandle *)handle->opaqueData;

   FD_ASSERT( privateHandle != NULL );
   FD_ASSERT( privateHandle->param != NULL );
   FD_ASSERT( privateHandle->param->category != NULL );
   FD_ASSERT( privateHandle->param->location != NULL );

   /* De-allocate potentialy already existing file index. */
   if( privateHandle->index != NULL )
   {
      // An error for now, will be implemented correctly later (as needed).
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Get the directory, if none provided, just use current one. */
   directory = ".";
   stringTmp = privateHandle->param->location;
   if( stringTmp )
   {
      directory = FD_StringToChar(stringTmp);
      if( directory[0] == '\0' )
         directory = ".";
   }
  
   /* Allocate new file index. */   
   outMasterList = NULL;
   outNRec = 0;
   switch( privateHandle->param->id )
   {
   case FD_CSI:  
      retCode = ReadCSIMaster(directory, &outMasterList, &outNRec);
      break;
   case FD_CSIM:  
      retCode = ReadCSIMMaster(directory, &outMasterList, &outNRec);
      break;
   default:
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(165) );
   }

   if( retCode != FD_SUCCESS )
   {
      FD_TRACE_RETURN( retCode );
   }

   FD_ASSERT( outMasterList != NULL );

   /* Build an index of FD_String */
   if( outNRec > 0 )
   {
      indexString = (FD_String **) FD_Malloc( sizeof( FD_String * ) * outNRec );;
      
      if( !indexString )
      {
         FD_Free( outMasterList );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      stringCache = FD_GetGlobalStringCache();
      for ( i=0; i < outNRec; i++ )
      {
         stringTmp = FD_StringAlloc_ULong( stringCache, outMasterList[i].csinum );
         if( !stringTmp )
         {
            while( --i >= 0 )
            {
               FD_StringFree( stringCache, indexString[i] );
            }
            FD_Free( outMasterList );
            FD_Free( (void *)indexString );
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }
         indexString[i] = stringTmp;
      }
      privateHandle->indexString = indexString;
   }

   /* Success */
   privateHandle->index     = outMasterList;
   privateHandle->indexSize = outNRec;

   FD_TRACE_RETURN( FD_SUCCESS );
}

/**** Local functions definitions.     ****/

static FD_PrivateCSIHandle *allocPrivateHandle( void  )
{
   FD_PrivateCSIHandle *privateHandle;
   FD_String *stringTmp;

   privateHandle = (FD_PrivateCSIHandle *)FD_Malloc( sizeof( FD_PrivateCSIHandle ) );
   if( !privateHandle )
      return NULL;

   memset( privateHandle, 0, sizeof( FD_PrivateCSIHandle ) );

   stringTmp = FD_StringAlloc(FD_GetGlobalStringCache(),"CSI_ID");
   if( !stringTmp )
   {
      FD_Free( privateHandle );
      return (FD_PrivateCSIHandle *)NULL;
   }
   
   privateHandle->category = stringTmp;

   return privateHandle;
}

static FD_RetCode freePrivateHandle( FD_PrivateCSIHandle *privateHandle )
{
   int i;
   FD_StringCache *stringCache;

   if( privateHandle )
   {
      FREE_IF_NOT_NULL( privateHandle->index );
      stringCache = FD_GetGlobalStringCache();
      FD_StringFree( stringCache, privateHandle->category );
      if( privateHandle->indexString )
      {
         for( i=0; i < privateHandle->indexSize; i++ )
            FD_StringFree( stringCache, privateHandle->indexString[i] );

         FD_Free( (void *)privateHandle->indexString);
      }
      FD_Free( privateHandle );
   }

   return FD_SUCCESS;
}
