#ifndef FD_SIMULATOR_H
#define FD_SIMULATOR_H

#ifndef FD_SOURCE_H
   #include "fd_source.h"
#endif

/* See fd_source.h and fd_source.c for more information about these
 * functions.
 */
FD_RetCode FD_SIMULATOR_InitializeSourceDriver(void);

FD_RetCode FD_SIMULATOR_ShutdownSourceDriver(void);

FD_RetCode FD_SIMULATOR_GetParameters( FD_DataSourceParameters *param );

FD_RetCode FD_SIMULATOR_OpenSource( const FD_AddDataSourceParamPriv *param,
                                    FD_DataSourceHandle **handle );

FD_RetCode FD_SIMULATOR_CloseSource( FD_DataSourceHandle *handle );


FD_RetCode FD_SIMULATOR_GetFirstCategoryHandle( FD_DataSourceHandle *handle,
                                                FD_CategoryHandle   *categoryHandle );

FD_RetCode FD_SIMULATOR_GetNextCategoryHandle( FD_DataSourceHandle *handle,
                                               FD_CategoryHandle   *categoryHandle,\
                                               unsigned int index );

FD_RetCode FD_SIMULATOR_GetFirstSymbolHandle( FD_DataSourceHandle *handle,
                                              FD_CategoryHandle   *categoryHandle,
                                              FD_SymbolHandle     *symbolHandle );

FD_RetCode FD_SIMULATOR_GetNextSymbolHandle( FD_DataSourceHandle *handle,
                                             FD_CategoryHandle   *categoryHandle,
                                             FD_SymbolHandle     *symbolHandle,
                                             unsigned int index );

FD_RetCode FD_SIMULATOR_GetHistoryData( FD_DataSourceHandle *handle,
                                    FD_CategoryHandle   *categoryHandle,
                                    FD_SymbolHandle     *symbolHandle,
                                    FD_Period            period,
                                    const FD_Timestamp  *start,
                                    const FD_Timestamp  *end,
                                    FD_Field             fieldToAlloc,
                                    FD_ParamForAddData  *paramForAddData );
#endif

