#ifndef FD_FILEINDEX_H
#define FD_FILEINDEX_H

#ifndef FD_COMMON_H
   #include "fd_common.h"
#endif

#ifndef FD_STRING_H
   #include "fd_string.h"
#endif

/* This utility allows to build an index of files using a path containing
 * some wildcard patterns.
 *
 * The path patterns can contains '?' and '*', but also some special fields
 * like [S],[YYYY] etc... the value of these fields are going to be
 * extracted for each applicable path/file.
 *
 * Simplified Example:
 *  c:\test\*\[s].txt
 *  This will build an index of all .txt files in a subdirectory inside test.
 *  Further more, the section before the .txt section will be extracted to
 *  become the "Symbol" fields.
 *
 *  Possible good value for this path would be:
 *  c:\test\nasdaq\ABC.txt   -> where [s]="ABC"
 *  c:\test\nasdaq\a.txt     -> where [s]="a"
 *  c:\test\amex\a.txt       -> where [s]="a"
 *
 * Once the FileIndex is allocated, it is possible to iterate between all
 * the symbols and categories. At each iteration, a FD_FileInfo is returned.
 * From FD_FileInfo can be obtained the extracted "fields" value and the
 * complete path of the file itself.
 */


/* Functions to build the index of files. */
typedef unsigned int FD_FileIndex; /* Implementation hidden. */

FD_RetCode FD_FileIndexAlloc( FD_String *path,
                              FD_String *initialCategory,
                              FD_String *initialCategoryCountry,
                              FD_String *initialCategoryExchange,
                              FD_String *initialCategoryType,
                              FD_FileIndex **newIndex );

FD_RetCode FD_FileIndexFree( FD_FileIndex *toBeFreed );

/* Return the number of category in this index. */
unsigned int FD_FileIndexNbCategory( FD_FileIndex *fileIndex );

/* Function to iterate sequentially within the index.
 * Only one iterator per FD_FileIndex.
 * When iterating symbol, it is iterating only in the current
 * active category.
 *
 * The active directory is determined by the FD_FileIndexFirstCategory,
 * FD_FileIndexNextCategory and FD_FileIndexSelectCategory.
 */
typedef unsigned int FD_FileInfo; /* Implementation hidden. */

FD_String *FD_FileIndexFirstCategory( FD_FileIndex *fileIndex );
FD_String *FD_FileIndexNextCategory ( FD_FileIndex *fileIndex );

FD_RetCode FD_FileIndexSelectCategory( FD_FileIndex *fileIndex,
                                       FD_String *category );

FD_FileInfo *FD_FileIndexFirstSymbol( FD_FileIndex *fileIndex );
FD_FileInfo *FD_FileIndexNextSymbol ( FD_FileIndex *fileIndex );

/* Return the number of symbol for the current category. */
unsigned int FD_FileIndexNbSymbol( FD_FileIndex *fileIndex );

/* Function to extract information from a FD_FileInfo. */
FD_String   *FD_FileInfoSymbol  ( FD_FileInfo *fileInfo );
FD_String   *FD_FileInfoCategory( FD_FileInfo *fileInfo );

const char *FD_FileInfoPath( FD_FileInfo *fileInfo );

/* Note 1: The pointer returned by FD_FileInfoPath will stay valid until
 *         the next call to any functions defined in this header file.
 *         If you need the pointer beyhond this timeframe, the caller will
 *         need to keep a copy of the pointed data.
 *
 * Note 2: FD_FileInfoSymbol and FD_FileInfoCategory will ALWAYS returned
 *         a string since each symbol will always fall into one category.
 *
 * Note 3: If many files are found for the same extracted symbol string, the
 *         index keep track of only the first file.
 */

#endif

