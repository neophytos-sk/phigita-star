/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  070701 MF   First version.
 *  041802 MF   Add better retry/timeout mechanism.
 *  061404 MF   Add FD_YAHOO_ONE_SYMBOL support.
 */

/* Description:
 *    Get historical data from the Yahoo! Web Site. 
 */

/* #define DEBUG_PRINTF 1 */

/**** Headers ****/
#include <stdlib.h>
#include <string.h>
#include "fd_yahoo_priv.h"
#include "fd_yahoo_handle.h"
#include "fd_yahoo_idx.h"
#include "fd_trace.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
typedef struct
{
   /* Maximum length when concatenating all 
    * the "part" and assuming that the date
    * use no more than 8 characters each.
    */
   unsigned int maxTotalLength;

   /* Divide the UIR suffix in a such way that
    * it is easy to change some fields within it.
    */

   const char *part1;
   unsigned int part1Length;
   /* &a=<dd> start day inserted here */
   /* &b=<mm> start month inserted here */
   /* &c=<yyyy> start year inserted here */
   const char *part2;
   unsigned int part2Length;
   /* &d=<dd> end day inserted here */
   /* &e=<mm> end month inserted here */
   /* &f=<yyyy> end year inserted here */
   const char *part3;
   unsigned int part3Length;
} FD_UIRSuffixParsing;


/* Structure used while parsing the adjustment table from Yahoo! */
#define MAX_FIRST_COLUMN_SIZE 100
typedef struct
{
   FD_PrivateYahooHandle *yahooHandle;
   FD_ParamForAddData *paramForAddData;
   char firstColumn[MAX_FIRST_COLUMN_SIZE]; /* Store the date found in the first column. */
} FD_AdjustDataParse;

/**** Local functions declarations.    ****/
static unsigned int nbCommaField( FD_Stream *csvFile );

static int setUIRSuffixParsing( const char *uirSuffix,
                                FD_UIRSuffixParsing *parseOutput );

static void buildUIRSuffix( const FD_UIRSuffixParsing *parsedString,
                            FD_Timestamp *startTimestamp,
                            FD_Timestamp *endTimestamp,
                            char *output );

static int isGapAcceptable( FD_Timestamp *lastBarTimestampAdded,
                            FD_Timestamp *lastBarTimestamp );

static unsigned int FD_DateWithinRange( unsigned int year,
                                        unsigned int month,
                                        unsigned int day,
                                        const FD_Timestamp *t1,
                                        const FD_Timestamp *t2 );

static FD_RetCode doAdjustments( FD_DecodingParam *localDecodingParam,
                                 FD_String *yahooName,
                                 FD_PrivateYahooHandle *yahooHandle,
                                 const char *overideServerAddr,
                                 FD_ParamForAddData  *paramForAddData );

static FD_RetCode processAdjustmentTable( unsigned int line,
                                          unsigned int column,
                                          const char *data,
                                          const char *href,
                                          void *opaqueData );

static double parseStringForDividend( const char *str );
static double parseStringForSplit( const char *str );
static int   parseDate( const char *str, FD_Timestamp *timestamp );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_RetCode FD_GetHistoryDataFromWeb( FD_DataSourceHandle *handle,
                                     FD_CategoryHandle   *categoryHandle,
                                     FD_SymbolHandle     *symbolHandle,
                                     FD_Period            period,
                                     const FD_Timestamp  *start,
                                     const FD_Timestamp  *end,
                                     FD_Field             fieldToAlloc,
                                     FD_ParamForAddData  *paramForAddData )
{
   FD_PROLOG

   FD_RetCode retCode;
   FD_StringCache *stringCache;
   FD_String *yahooName;
   FD_WebPage *webPage;
   FD_PrivateYahooHandle *yahooHandle;
   FD_DecodingParam localDecodingParam;
   FD_DecodingParam directYahooDecodingParam;
   const FD_DecodingParam *decodingParam;
   FD_FileHandle *fileHandle;
   FD_ReadOpInfo *readOpInfo;
   FD_UIRSuffixParsing suffixParsing;
   FD_Timestamp firstBarTimestamp, lastBarTimestamp, prevEndDate;
   FD_InfoFromAddedData infoFromAddedData;
   FD_DayOfWeek dayOfWeek;
   FD_Timestamp curAdjustYear, lastAdjustYear;  
   const char *overideServerAddr;

   int nbEstimateBar;
   int nbField;
   unsigned int nbBarAdded, nbTotalBarAdded;
   int again, firstTime, nbBatch;
   int zeroBarAddedAttempt;
   int doAdjustment;

   FD_TRACE_BEGIN( FD_GetHistoryDataFromWeb );

   /* Initialize some local variables. */
   stringCache   = FD_GetGlobalStringCache();
   yahooHandle   = (FD_PrivateYahooHandle *)handle->opaqueData;
   readOpInfo    = NULL;
   nbEstimateBar = 0;

   FD_ASSERT( categoryHandle != NULL );
   FD_ASSERT( symbolHandle != NULL );
   FD_ASSERT( categoryHandle->string != NULL );
   FD_ASSERT( symbolHandle->string != NULL );

   retCode = FD_BAD_PARAM;

   /* Set the initial first/last timestamp */
   if( start )
      FD_TimestampCopy( &firstBarTimestamp, start );
   else
      FD_SetDate( 1950, 1, 1, &firstBarTimestamp );

   if( end )
      FD_TimestampCopy( &lastBarTimestamp, end );
   else
      FD_SetDateNow( &lastBarTimestamp );

   /* Time component is not important for Yahoo! but all end of day
    * price bar use 00:00:00, so do the same here.
    */
   FD_SetTime( 0, 0, 0, &firstBarTimestamp );
   FD_SetTime( 0, 0, 0, &lastBarTimestamp );

   /* Make sure that lastBarTimestamp is a week-day. */
   dayOfWeek = FD_GetDayOfTheWeek( &lastBarTimestamp );
   if( (dayOfWeek == FD_SUNDAY) || (dayOfWeek == FD_SATURDAY) )
      FD_PrevWeekday( &lastBarTimestamp );

   FD_ASSERT( yahooHandle != NULL );

   if( yahooHandle->param->id == FD_YAHOO_ONE_SYMBOL )
   {
      /* User specified Yahoo! name. */
      yahooName = FD_StringDup(stringCache,yahooHandle->webSiteSymbol);
      FD_ASSERT( yahooName != NULL );
   }
   else
   {
      /* Map the FIDAL name into the Yahoo! name. */
      retCode = FD_AllocStringFromLibName( categoryHandle->string,
                                           symbolHandle->string,
                                           &yahooName );  
      if( retCode != FD_SUCCESS )
      {
         FD_TRACE_RETURN( retCode );
      }

      FD_ASSERT( yahooName != NULL );
   }

   /* Check if the user did overide the server address in the location parameter. 
    * (as needed, convert from FD_String to char *)
    */
   if( yahooHandle->userSpecifiedServer )
      overideServerAddr = FD_StringToChar(yahooHandle->userSpecifiedServer);
   else
      overideServerAddr = NULL;
   
   /* Get the decoding parameter for the CSV web page. */
   if( yahooHandle->param->id == FD_YAHOO_ONE_SYMBOL )
   {
      retCode = FD_YahooIdxDataDecoding( yahooHandle->webSiteCountry,
                                         FD_YAHOOIDX_CSV_PAGE,
                                         &directYahooDecodingParam );
      if( retCode != FD_SUCCESS )
      {
         FD_StringFree( stringCache, yahooName );
         FD_TRACE_RETURN( retCode );
      }
      decodingParam = &directYahooDecodingParam;
   }
   else
   {
      decodingParam = FD_YahooIdxDecodingParam( yahooHandle->index, FD_YAHOOIDX_CSV_PAGE );
      if( !decodingParam )
      {
         FD_StringFree( stringCache, yahooName );
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(103) );
      }
   }

   localDecodingParam = *decodingParam;

   /* Check if split/value adjustment are necessary. */
   if( (yahooHandle->param->flags & FD_DO_NOT_SPLIT_ADJUST) &&
       (yahooHandle->param->flags & FD_DO_NOT_VALUE_ADJUST) )
   {
      doAdjustment = 0;
   }
   else
      doAdjustment = 1;


   /* Parse the uirSuffix so the start/end date can be changed. */
   if( !setUIRSuffixParsing( decodingParam->uirSuffix, &suffixParsing ) )
   {
      /* This should never happen unless the
       * Yahoo! index protocol has been broken.
       */
      /* Clean-up and exit */
      FD_StringFree( stringCache, yahooName );
      FD_TRACE_RETURN( FD_INTERNAL_ERROR(104) );
   }

   /* Use a local copy of the decoding param. 
    * This is because the uirSuffix is replaced with
    * an allocated buffer (so the date field can be
    * manipulated).
    */

   /* Replace the uirSuffix with a large local buffer. */
   localDecodingParam.uirSuffix = FD_Malloc( suffixParsing.maxTotalLength );
   if( !localDecodingParam.uirSuffix )
   {
      /* Clean-up and exit */
      FD_StringFree( stringCache, yahooName );
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   /* Change the dates in the uirSuffix. */
   buildUIRSuffix( &suffixParsing,
                   &firstBarTimestamp, &lastBarTimestamp,
                   (char *)localDecodingParam.uirSuffix );

   /* nbBatch is a safety net to make sure that
    * FIDAL won't stay forever in the while loop
    * in case Yahoo! changes their protocol.
    */
   nbBatch = 0; 

   /* Sometime Yahoo! return an empty csv file. Make
    * multiple attempts in that case.
    */
   zeroBarAddedAttempt = 0;

   again = 1;
   firstTime = 1;
   nbTotalBarAdded = 0;
   while( again && (++nbBatch < 100) && (zeroBarAddedAttempt < 10) )
   {    
      retCode = FD_DriverShouldContinue(paramForAddData);
      if( retCode != FD_SUCCESS )
      {
         FD_StringFree( stringCache, yahooName );
         FD_Free( (char *)localDecodingParam.uirSuffix );
         #if !defined( FD_SINGLE_THREAD )   
            if( readOpInfo )
               FD_ReadOpInfoFree( readOpInfo );
         #endif
         FD_TRACE_RETURN( retCode );
      }

      if( FD_TimestampLess(&lastBarTimestamp,&firstBarTimestamp) )
      {
          /* Get out of this loop if all the requested data
           * has been retreived already.
           */
         again = 0;
         break;
      }   

      retCode = FD_WebPageAllocFromYahooName( &localDecodingParam,
                                              FD_StringToChar(yahooName),
                                              overideServerAddr,
                                              &webPage, paramForAddData );
           
      if( retCode != FD_SUCCESS )
      {
         FD_StringFree( stringCache, yahooName );
         FD_Free( (char *)localDecodingParam.uirSuffix );
         #if !defined( FD_SINGLE_THREAD )   
            if( readOpInfo )
               FD_ReadOpInfoFree( readOpInfo );
         #endif
         FD_TRACE_RETURN( retCode );
      }

      /* Disguise the webPage stream into a "file". That way the speed
       * optimized ASCII decoder can be re-used (FD_ReadOp stuff).
       */
      retCode = FD_FileSeqOpenFromStream( webPage->content, &fileHandle );
      if( retCode != FD_SUCCESS )
      {
         /* Clean-up and exit */
         FD_StringFree( stringCache, yahooName );
         FD_WebPageFree( webPage );
         FD_Free( (char *)localDecodingParam.uirSuffix );
         #if !defined( FD_SINGLE_THREAD )   
            if( readOpInfo )
               FD_ReadOpInfoFree( readOpInfo );
         #endif
         FD_TRACE_RETURN( retCode );
      }

      if( firstTime )
      {
         /* Make assumption of the data provided
          * base on the number of fields in the CSV file.
          */
         nbField = nbCommaField( webPage->content );
         switch( nbField )
         {
         case 2:
            readOpInfo = yahooHandle->readOp2Fields;
            break;
         case 5:
            readOpInfo = yahooHandle->readOp5Fields;
            break;
         default:
            readOpInfo = yahooHandle->readOp6Fields;
         }

         #if !defined( FD_SINGLE_THREAD )   
            /* Must use a local copy if multi-threaded */
            retCode = FD_ReadOpInfoClone(&readOpInfo, readOpInfo);
            if( retCode != FD_SUCCESS )
            {
               /* Clean-up and exit */
               FD_StringFree( stringCache, yahooName );
               FD_WebPageFree( webPage );
               FD_Free( (char *)localDecodingParam.uirSuffix );
               FD_TRACE_RETURN( retCode );
            }
         #endif

         /* User asking for all the fields? */
         if( fieldToAlloc == FD_FIELD_ALL )
         {
            switch( nbField )
            {
            case 2:
               fieldToAlloc = FD_FIELD_CLOSE|FD_FIELD_TIMESTAMP;
               break;
            case 5:
               fieldToAlloc = FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_CLOSE|FD_FIELD_TIMESTAMP;
               break;
            default:
               fieldToAlloc = FD_FIELD_OPEN|FD_FIELD_HIGH|FD_FIELD_LOW|FD_FIELD_CLOSE|FD_FIELD_VOLUME|FD_FIELD_TIMESTAMP;
            }
         }

         /* Optimize the read op for the requested data. */
         retCode = FD_ReadOp_Optimize( readOpInfo,
                                       period,
                                       fieldToAlloc );
         if( retCode != FD_SUCCESS )
         {
            /* Clean-up and exit */
            FD_StringFree( stringCache, yahooName );
            FD_WebPageFree( webPage );
            FD_Free( (char *)localDecodingParam.uirSuffix );
            #if !defined( FD_SINGLE_THREAD )   
               if( readOpInfo )
                  FD_ReadOpInfoFree( readOpInfo );
            #endif
            FD_TRACE_RETURN( retCode );
         }

         /* Make an estimation of the number of price bar. */
         nbEstimateBar  = FD_StreamCountChar( webPage->content, '\n' ) + 1;
         if( nbEstimateBar < 100 )
            nbEstimateBar = 100;
      }

      /* Interpret the CSV data. */
      retCode = FD_ReadOp_Do( fileHandle,                           
                              readOpInfo,
                              period, &firstBarTimestamp, &lastBarTimestamp,
                              nbEstimateBar, fieldToAlloc,
                              paramForAddData,
                              &nbBarAdded );

      FD_FileSeqClose( fileHandle );
      FD_WebPageFree( webPage );

      nbTotalBarAdded += nbBarAdded;

      if( retCode != FD_SUCCESS )
      {
         /* Clean-up and exit */
         FD_StringFree( stringCache, yahooName );
         FD_Free( (char *)localDecodingParam.uirSuffix );
         #if !defined( FD_SINGLE_THREAD )   
            if( readOpInfo )
               FD_ReadOpInfoFree( readOpInfo );
         #endif
         FD_TRACE_RETURN( retCode );
      }

      /* Yahoo! does not always return all the data it could, up to
       * the requested end date. It is important to detect these occurence
       * and cancel the usage of all data accumulated up to now. 
       */      
      FD_GetInfoFromAddedData( paramForAddData, &infoFromAddedData );
      if( infoFromAddedData.barAddedSinceLastCall )
      {
         /* Do some more checking by considering holidays, week-end etc... */
         if( !isGapAcceptable(&infoFromAddedData.highestTimestampAddedSinceLastCall, &lastBarTimestamp) )
         {
            /* Clean-up and exit */
            FD_StringFree( stringCache, yahooName );
            FD_Free( (char *)localDecodingParam.uirSuffix );
            #if !defined( FD_SINGLE_THREAD )   
               if( readOpInfo )
                  FD_ReadOpInfoFree( readOpInfo );
            #endif
            FD_TRACE_RETURN( FD_DATA_GAP );
         }
         
         FD_TimestampCopy( &lastBarTimestamp, &infoFromAddedData.lowestTimestamp );
      }

      #if DEBUG_PRINTF
      printf( "NB BAR ADDED=%d, TOTAL=%d\n", nbBarAdded, nbTotalBarAdded );
      #endif

      /* Verify if more data should be processed. 
       * Yahoo! sometimes slice their data, in 
       * batch of 200 price bars. 
       */
      if( firstTime && (nbBarAdded > 200) )
      {
         again = 0; /* Assume all the data extracted... exit the loop. */
      }
      else if( nbBarAdded == 0 )
      {
         /* Make multiple attempts when retreiving data succeed,
          * but somehow there is zero bar returned. 
          *
          * Sometimes this might be correct when there is truly no
          * more data available, so choosing an algorithm before
          * giving up is a comprimise between reliability and
          * usability. The data source is free... and you get
          * what you pay for after all ;)
          */
         if( (nbTotalBarAdded < 1000) && (zeroBarAddedAttempt >= 1) && (zeroBarAddedAttempt < 7) )
         {
            /* I did choose to add a delay when insufficient total data is returned. When
             * there is already ~5 years of data, most likely there is "Zero" returned
             * because there is NO more data available, so just do the retry without delay.
             */
            FD_Sleep(zeroBarAddedAttempt*2);
         }

         #if DEBUG_PRINTF
            printf( "Retry %d", zeroBarAddedAttempt );
         #endif

         zeroBarAddedAttempt++;
      }
      else
      {
         zeroBarAddedAttempt = 0;

         if( FD_TimestampEqual( &lastBarTimestamp, &prevEndDate ) )
         {
            /* prevEndDate is a "safety net" to
             * exit the loop early in case Yahoo! starts
             * to return always the same batch of data.
             * Just ignore the repetitive data and exit.
             */
            FD_Free( (char *)localDecodingParam.uirSuffix );
            FD_StringFree( stringCache, yahooName );
            #if !defined( FD_SINGLE_THREAD )   
               if( readOpInfo )
                  FD_ReadOpInfoFree( readOpInfo );
            #endif
            FD_TRACE_RETURN( FD_SUCCESS );
         }
         FD_TimestampCopy( &prevEndDate, &lastBarTimestamp );

         /* Request the data up to the day BEFORE
          * the last batch of data received.
          */
         FD_PrevDay( &lastBarTimestamp );

         /* Make sure that lastBarTimestamp is a week-day. */
         dayOfWeek = FD_GetDayOfTheWeek( &lastBarTimestamp );
         if( (dayOfWeek == FD_SUNDAY) || (dayOfWeek == FD_SATURDAY) )
            FD_PrevWeekday( &lastBarTimestamp );

         /* Change the dates in the uirSuffix. */
         buildUIRSuffix( &suffixParsing,
                         &firstBarTimestamp, &lastBarTimestamp,
                         (char *)localDecodingParam.uirSuffix );

         /* From that point, data is expected to be most likely
          * sent in batch of 200.
          */
         nbEstimateBar = 200;
      }
      
      firstTime = 0;
   }

   /* Get rid of some memory not used anymore. */
   FD_Free( (char *)localDecodingParam.uirSuffix );
   #if !defined( FD_SINGLE_THREAD )   
      if( readOpInfo )
         FD_ReadOpInfoFree( readOpInfo );
   #endif

   /* If adjusted data is requested, use splits and dividend info from Yahoo!. */
   if( doAdjustment && (nbTotalBarAdded >= 1) )
   {
      /* Get the decoding parameter for the adjustment page. */
      if( yahooHandle->param->id == FD_YAHOO_ONE_SYMBOL )
      {
         retCode = FD_YahooIdxDataDecoding( yahooHandle->webSiteCountry,
                                            FD_YAHOOIDX_ADJUSTMENT,
                                            &directYahooDecodingParam );
         if( retCode != FD_SUCCESS )
         {
            FD_StringFree( stringCache, yahooName );
            FD_TRACE_RETURN( retCode );
         }
         decodingParam = &directYahooDecodingParam;
      }
      else
      {
         decodingParam = FD_YahooIdxDecodingParam( yahooHandle->index, FD_YAHOOIDX_ADJUSTMENT );
         if( !decodingParam )
         {
            FD_StringFree( stringCache, yahooName );
            FD_TRACE_RETURN( FD_INTERNAL_ERROR(140) );
         }
      }
      localDecodingParam = *decodingParam;

      if( !setUIRSuffixParsing( decodingParam->uirSuffix, &suffixParsing ) )
      {
         /* This should never happen unless the
          * Yahoo! index protocol has been broken.
          */
         /* Clean-up and exit */
         FD_StringFree( stringCache, yahooName );
         FD_TRACE_RETURN( FD_INTERNAL_ERROR(141) );
      }

      /* Use a local copy of the decoding param. 
       * This is because the uirSuffix is replaced with
       * an allocated buffer (so the date field can be
       * manipulated).
       */

      /* Replace the uirSuffix with a large local buffer. */
      localDecodingParam.uirSuffix = FD_Malloc( suffixParsing.maxTotalLength );
      if( !localDecodingParam.uirSuffix )
      {
         /* Clean-up and exit */
         FD_StringFree( stringCache, yahooName );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }


      /* curAdjustYear indicates for which year the download is
       * taking place.
       */
      FD_SetDefault( &curAdjustYear );
      FD_SetDateNow( &curAdjustYear );

      /* Identify the oldest year for which data was downloaded */
      FD_GetInfoFromAddedData( paramForAddData, &infoFromAddedData );
      FD_TimestampCopy( &lastAdjustYear, &infoFromAddedData.lowestTimestamp );
      FD_PrevYear( &lastAdjustYear ); /* Get one more year to be on the safe side. */

      while( FD_TimestampLess( &lastAdjustYear, &curAdjustYear ) )
      {
         /* Set prevEndDate to two years earlier. */
         FD_TimestampCopy( &prevEndDate, &curAdjustYear );
         FD_PrevYear( &prevEndDate );
         FD_PrevYear( &prevEndDate );
         
         /* Change the dates in the uirSuffix. */
         FD_SetDate( FD_GetYear(&curAdjustYear), 12, 31, &curAdjustYear );
         FD_SetDate( FD_GetYear(&prevEndDate), 1, 1, &prevEndDate );
         buildUIRSuffix( &suffixParsing,
                         &prevEndDate, &curAdjustYear,
                         (char *)localDecodingParam.uirSuffix );

         retCode = doAdjustments( &localDecodingParam, yahooName,
                                  yahooHandle, NULL, paramForAddData );
         if( retCode != FD_SUCCESS )
         {
            /* Clean-up and exit */
            FD_StringFree( stringCache, yahooName );
            FD_Free( (char *)localDecodingParam.uirSuffix );
            FD_TRACE_RETURN( retCode );
         }

         /* Move 3 years earlier. */
         FD_PrevYear( &prevEndDate );
         FD_TimestampCopy( &curAdjustYear, &prevEndDate );
      }

      /* Clean-up what was allocated for the adjustment logic. */
      FD_Free( (char *)localDecodingParam.uirSuffix );
   }

   /* Clean-up and exit */
   FD_StringFree( stringCache, yahooName );
   FD_TRACE_RETURN( retCode );
}

/**** Local functions definitions.     ****/
static FD_RetCode doAdjustments( FD_DecodingParam *localDecodingParam,
                                 FD_String *yahooName,
                                 FD_PrivateYahooHandle *yahooHandle,
                                 const char *overideServerAddr,
                                 FD_ParamForAddData  *paramForAddData )
{
   FD_RetCode retCode;
   FD_WebPage *webPage;
   FD_Stream *stream;
   FD_StreamAccess *streamAccess;
   FD_AdjustDataParse adjustDataParse;

   adjustDataParse.paramForAddData = paramForAddData;
   adjustDataParse.yahooHandle = yahooHandle;

   /* Get the split/value adjustments from the Yahoo! web site */
   retCode = FD_WebPageAllocFromYahooName( localDecodingParam,
                                           FD_StringToChar(yahooName),
                                           overideServerAddr,
                                           &webPage, paramForAddData );

   if( retCode != FD_SUCCESS )
      return retCode;

   /* Parse the dividend/split information */
   stream = webPage->content;  
   streamAccess = FD_StreamAccessAlloc( stream );

   if( !streamAccess )
   {
      FD_WebPageFree( webPage );
      return FD_ALLOC_ERR;
   }

   retCode = FD_StreamAccessSearch( streamAccess, "Monthly" );
   if( retCode == FD_SUCCESS )
   {
      retCode = FD_StreamAccessSearch( streamAccess, "Last" );
      if( retCode == FD_SUCCESS )
      {
          /* Find the table of data. */
          retCode = FD_StreamAccessSearch( streamAccess, "yfnc_datamodoutline1" );;
          if( retCode == FD_SUCCESS )
          {
             retCode = FD_StreamAccessGetHTMLTable( streamAccess,
                                                    200,
                                                    processAdjustmentTable,
                                                    &adjustDataParse );
          }
      }
   }

   FD_StreamAccessFree( streamAccess );
   FD_WebPageFree( webPage );

   return retCode;   
}


static int setUIRSuffixParsing( const char *uirSuffix, FD_UIRSuffixParsing *parseOutput )
{
   int again, i;

   memset( parseOutput, 0, sizeof( FD_UIRSuffixParsing ) );

   /* Set the start of part1 */
   parseOutput->part1 = uirSuffix;

   /* Find the end of part1 */
   i = 0;
   again = 1;
   while( again )
   {
      if( uirSuffix[i]   == '&' &&
          uirSuffix[i+1] == 'a' &&
          uirSuffix[i+2] == '=' )
      {
         again = 0;
      }
      else if( uirSuffix[i] == '\0' )
         return 0;
      else
      {
         parseOutput->part1Length++;
         i++;
      }
   }
   
   /* Set the start of part2 */
   again = 1;
   while( again )
   {
      if( uirSuffix[i]   == '&' &&
          uirSuffix[i+1] == 'c' &&
          uirSuffix[i+2] == '=' )
      {
         again = 0;
         parseOutput->part2 = &uirSuffix[i+7];
         i += 7;
      }
      else if( uirSuffix[i] == '\0' )
         return 0;
      else
         i++;
   }

   /* Find the end of part2 */
   again = 1;
   while( again )
   {
      if( uirSuffix[i]   == '&' &&
          uirSuffix[i+1] == 'd' &&
          uirSuffix[i+2] == '=' )
      {
         again = 0;
      }
      else if( uirSuffix[i] == '\0' )
         return 0;
      else
      {
         parseOutput->part2Length++;
         i++;
      }
   }

   /* Set the start of part3 */
   again = 1;
   while( again )
   {
      if( uirSuffix[i]   == '&' &&
          uirSuffix[i+1] == 'f' &&
          uirSuffix[i+2] == '=' )
      {
         again = 0;
         parseOutput->part3 = &uirSuffix[i+7];
         i += 7;
      }
      else if( uirSuffix[i] == '\0' )
         return 0;
      else
         i++;
   }

   /* Find the end of part2 */
   again = 1;
   while( again )
   {
      if( uirSuffix[i] == '\0' )
      {
         parseOutput->maxTotalLength = parseOutput->part3Length +
                                       parseOutput->part2Length +
                                       parseOutput->part1Length +
                                       100;
         again = 0;
      }
      else
      {
         parseOutput->part3Length++;
         i++;
      }
   }

   return 1; /* Success! */
}

static void buildUIRSuffix( const FD_UIRSuffixParsing *parsedString,
                            FD_Timestamp *startTimestamp,
                            FD_Timestamp *endTimestamp,
                            char *output )
{  
   int i;

   strncpy( output, parsedString->part1, parsedString->part1Length );
   i = parsedString->part1Length;

   sprintf( output,
            "&a=%02d&b=%02d&c=%04d",
            FD_GetMonth( startTimestamp )-1, /* Yahoo! month is zero base */
            FD_GetDay( startTimestamp ),
            FD_GetYear( startTimestamp ) );
   i += 17;

   strncpy( &output[i], parsedString->part2, parsedString->part2Length );
   i += parsedString->part2Length;

   sprintf( &output[i],
            "&d=%02d&e=%02d&f=%04d",
            FD_GetMonth( endTimestamp )-1, /* Yahoo! month is zero base */
            FD_GetDay( endTimestamp ),
            FD_GetYear( endTimestamp ) );
   i += 17;

   strncpy( &output[i], parsedString->part3, parsedString->part3Length );
   i += parsedString->part3Length;

   output[i] = '\0';

   #if DEBUG_PRINTF
   printf( "New UIR=[%s]\n", output );
   #endif
}

static unsigned int nbCommaField( FD_Stream *csvFile )
{
   FD_RetCode retCode;
   FD_StreamAccess *streamAccess;
   unsigned int nbComma;
   unsigned char data;

   streamAccess = FD_StreamAccessAlloc( csvFile );
   if( !streamAccess )
      return 0;

   nbComma = 0;

#ifdef WIN32
#pragma warning( disable : 4127 ) /* Disable 'conditional expression is constant' */
#endif
   while(1)
   {
      retCode = FD_StreamAccessGetByte( streamAccess, &data );
      if( retCode != FD_SUCCESS )
      {
         FD_StreamAccessFree( streamAccess );
         return 0;
      }
      if( data == ',' )
         nbComma++;
      else if( data == '\n' )
      {
         FD_StreamAccessFree( streamAccess );
         return nbComma + 1;
      }
   }
#ifdef WIN32
#pragma warning( default : 4127 ) /* Restore warning settings. */
#endif
}

static int isGapAcceptable( FD_Timestamp *lastBarTimestampAdded,
                            FD_Timestamp *lastBarTimestamp )
{
   FD_RetCode retCode;
   unsigned int deltaDay, i;

   /* Verify if that gap in the data is acceptable. This is not
    * a "perfect" algorithm, but the idea is to avoid obvious
    * failure. Small failure might get through, but the consequence
    * won't be worst than a long week-end gap.
    */

   retCode = FD_TimestampDeltaDay( lastBarTimestampAdded, lastBarTimestamp, &deltaDay );
   if( (retCode != FD_SUCCESS) || (deltaDay >= 7) )
   {
      /* A gap of more than 7 days is an error for sure. Or may be the symbol
       * is not being traded anymore? Don't take a chance and return an error.
       */
      return 0;
   }

   /* The gap should not be more than 3 weekdays (after removing special case) */
   retCode = FD_TimestampDeltaWeekday( lastBarTimestampAdded, lastBarTimestamp, &deltaDay );
   if(  retCode != FD_SUCCESS ) 
   {
      return 0;
   }

   /* Handle special cases */

   /* Trading were suspended on many exchange on september 11 2001 to september 14 2001  */
   for( i=11; i <= 14; i++ )
   {
      if( FD_DateWithinRange( 2001,9,i, lastBarTimestampAdded, lastBarTimestamp ) )
         --deltaDay;
   }
      
   
   /* Handling holidays would be better here, any volunteer to implement this? */
   if( deltaDay > 3 )
      return 0;

   return 1; /* The gap is acceptable. */
}

/* Check if t0 is within the provided [t1..t2] range (inclusive check) */
static unsigned int FD_DateWithinRange( unsigned int year,
                                        unsigned int month,
                                        unsigned int day,
                                        const FD_Timestamp *t1,
                                        const FD_Timestamp *t2 )
{
   FD_Timestamp stamp;
   const FD_Timestamp *lowBorder;
   const FD_Timestamp *highBorder;

   /* Inverse t1 and t2 if not chronilogical order. */
   if( FD_TimestampLess( t2, t1 ) )
   {
      lowBorder = t2;
      highBorder = t1;
   }
   else
   {
      lowBorder = t1;
      highBorder = t2;
   }

   /* Build a timestamp for the date to be check */
   FD_SetDate( year, month, day, &stamp );  

   /* Check if exactly on boundary */
   if( FD_TimestampEqual( &stamp, lowBorder ) && FD_TimestampEqual( &stamp, highBorder ) )
   {
      return 1;
   }

   /* Check if within range. */
   if( FD_TimestampGreater( &stamp, lowBorder ) && FD_TimestampLess( &stamp, highBorder ) )
   {
      return 1;
   }

   return 0; /* Out-of-range */
}


static FD_RetCode processAdjustmentTable( unsigned int line,
                                          unsigned int column,
                                          const char *data,
                                          const char *href,
                                          void *opaqueData )
{
   FD_RetCode retCode;
   FD_AdjustDataParse *adjustData;
   FD_PrivateYahooHandle *yahooHandle;
   FD_ParamForAddData *paramForAddData;

   FD_Timestamp when;
   int cnvtDate;
   double value;

   (void)href;
   (void)line;

   adjustData = (FD_AdjustDataParse *)opaqueData;

   if( column == 0 )
      strncpy( adjustData->firstColumn, data, MAX_FIRST_COLUMN_SIZE );
   else if( column == 1 )
   {
      cnvtDate = 0;

      /* Look for dividend. */
      yahooHandle = adjustData->yahooHandle;
      paramForAddData = adjustData->paramForAddData;
    
      if( !(yahooHandle->param->flags & FD_DO_NOT_VALUE_ADJUST) )
      {
         value = parseStringForDividend( data );
         if( value < 0.0 )
            return FD_INVALID_YAHOO_DIVIDEND;

         if( value != 0.0 )
         {
            if( !cnvtDate )
            {
                if( parseDate( adjustData->firstColumn, &when ) )
                   cnvtDate = 1;
                else
                   return FD_INVALID_DATE;
            }

            retCode = FD_HistoryAddValueAdjust( paramForAddData, &when, value );
            if( retCode != FD_SUCCESS )
               return retCode;
            /*printf( "Dividend=%f [%s]\n", value, adjustData->firstColumn );*/
         } 
      }

      /* Look for split */
      if( !(yahooHandle->param->flags & FD_DO_NOT_SPLIT_ADJUST) )
      {
         value = parseStringForSplit( data );
         if( value != 0.0 )
         {
            if( !cnvtDate )
            {
                if( parseDate( adjustData->firstColumn, &when ) )
                   cnvtDate = 1;
                else
                   return FD_INVALID_DATE;
            }

            retCode = FD_HistoryAddSplitAdjust( paramForAddData, &when, (double)value );
            if( retCode != FD_SUCCESS )
               return retCode;
            /*printf( "Split=%f [%s]\n", value, adjustData->firstColumn );*/
         } 
      }      
      /*printf( "[%d,%d] [%s][%s][%s]\n", line, column, data, href, adjustData->firstColumn );*/
   }

   return FD_SUCCESS;
}

static int parseDate( const char *str, FD_Timestamp *timestamp )
{
   FD_Timestamp temp;
   int day, month, year;
   FD_RetCode retCode;
   int found;
   static const char *monthStr[12] = { "Jan", "Feb", "Mar",
                                       "Apr", "May", "Jun",
                                       "Jul", "Aug", "Sep",
                                       "Oct", "Nov", "Dec" };
   if( !timestamp || !str )
      return 0;

   /* Parse day */
   if( sscanf( str, "%d", &day ) != 1 )
      return 0;

   /* Parse Month */
   found = 0;
   month = 0;
   while( !found && (month < 12) )
   {
      if( strstr(str, monthStr[month] ) )
         found = 1;
      else
         month++;     
   }
   if( !found ) return 0;

   /* Parse Year */
   str = strchr( str, '-' );
   if( !str || str[1] == '\0' )
      return 0;
   str = strchr( str+1, '-' );
   if( !str || str[1] == '\0' )
      return 0;
   if( sscanf( str+1, "%d", &year ) != 1 )
      return 0;

   /* Build timestamp */
   FD_SetDefault( &temp );
   retCode = FD_SetDate( year, month+1, day, &temp );
   if( retCode != FD_SUCCESS )
      return 0;

   retCode = FD_TimestampCopy( timestamp, &temp );
   if( retCode != FD_SUCCESS )
      return 0;
   
   return 1;
}

static double parseStringForDividend( const char *str )
{
   float value;
   value = 0.0;

   if( str && strstr(str, "Cash Dividend" ) )
   {
      str = strchr( str, '$' );       
      if( str && (str[1] != '\0') )
      {
         sscanf( &str[1], "%f", &value );
      }
   }

   return (double)value;
}

static double parseStringForSplit( const char *str )
{
   double value;
   int fvalue, svalue;

   fvalue = svalue = 0;
   value = 0.0;
   
   if( str && strstr(str, "Stock Split" ) )
   {
      if( sscanf( str, "%d", &fvalue ) )
      {
         str = strchr( str, ':' );
         if( str && (str[1] != '\0') )
         {
            if( sscanf( &str[1], "%d", &svalue ) )
            {
               if( (fvalue != 0) & (svalue != 0) )
               {
                  value = (double)svalue/(double)fvalue;
               }
            }
         }
      }       
   }

   return value;
}
