/* FIDAL Copyright (c) 1999-2006, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  110199 MF   First version.
 *
 */

/* Description:
 *    Allocate/de-allocate a FD_FileIndexPriv.
 *    - Provides functions to add values/data to the FD_FileIndexPriv.
 */

/**** Headers ****/
#include <string.h>
#include "fidal.h"
#include "fd_memory.h"
#include "fd_trace.h"
#include "fd_fileindex_priv.h"
#include "fd_global.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* None */

/**** Local declarations.              ****/
/* None */

/**** Local functions.    ****/


/* functions for freeing lists of elements. */
static FD_RetCode freeListAndElement( FD_List *list,
                                      FD_RetCode (*freeFunc)( void *toBeFreed ));
static FD_RetCode freeFileIndexPriv( void *toBeFreed );
static FD_RetCode freeCategoryData( void *toBeFreed );
static FD_RetCode freeSymbolData( void *toBeFreed );
static FD_RetCode freeTokenInfo( void *toBeFreed );

static FD_ValueTreeNode *allocTreeNode( FD_ValueTreeNode *parent, FD_String *string );
static FD_RetCode freeTreeNode( void *toBeFreed );

/**** Local variables definitions.     ****/
FD_FILE_INFO;

/**** Global functions definitions.   ****/
FD_FileIndexPriv *FD_FileIndexPrivAlloc( FD_String *initialCategory,
                                         FD_String *initialCategoryCountry,
                                         FD_String *initialCategoryExchange,
                                         FD_String *initialCategoryType )
{
   FD_FileIndexPriv *fileIndexPrivData;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   /* Initialize the FD_FileIndexPriv element. */
   fileIndexPrivData = (FD_FileIndexPriv *)FD_Malloc( sizeof( FD_FileIndexPriv ) );

   if( !fileIndexPrivData )
      return NULL;

   /* initialize all fields to NULL. */
   memset( fileIndexPrivData, 0, sizeof( FD_FileIndexPriv ) );

   /* Now attempt to allocate all sub-elements. */
   stringCache = FD_GetGlobalStringCache();
   fileIndexPrivData->initialCategoryString         = FD_StringDup( stringCache, initialCategory );
   fileIndexPrivData->initialCategoryCountryString  = FD_StringDup( stringCache, initialCategoryCountry);
   fileIndexPrivData->initialCategoryExchangeString = FD_StringDup( stringCache, initialCategoryExchange );
   fileIndexPrivData->initialCategoryTypeString     = FD_StringDup( stringCache, initialCategoryType );

   if( (fileIndexPrivData->initialCategoryString         == NULL) ||
       (fileIndexPrivData->initialCategoryCountryString  == NULL) ||
       (fileIndexPrivData->initialCategoryExchangeString == NULL) ||
       (fileIndexPrivData->initialCategoryTypeString     == NULL) )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   fileIndexPrivData->scratchPad = (char *)FD_Malloc( FD_SOURCELOCATION_MAX_LENGTH+2 );
   if( !fileIndexPrivData->scratchPad )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   fileIndexPrivData->listLocationToken = FD_ListAlloc();
   if( !fileIndexPrivData->listLocationToken )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   fileIndexPrivData->listCategory = FD_ListAlloc();
   if( !fileIndexPrivData->listCategory )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   fileIndexPrivData->root = allocTreeNode( NULL, NULL );
   if( !fileIndexPrivData->root )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   fileIndexPrivData->currentNode = fileIndexPrivData->root;

   fileIndexPrivData->wildOneChar = FD_StringAlloc( stringCache, "?" );
   fileIndexPrivData->wildZeroOrMoreChar = FD_StringAlloc( stringCache, "*" );
   fileIndexPrivData->wildOneOrMoreChar = FD_StringAlloc( stringCache, "?*" );

   if( (!fileIndexPrivData->wildOneChar) ||
       (!fileIndexPrivData->wildZeroOrMoreChar) ||
       (!fileIndexPrivData->wildOneOrMoreChar) )
   {
      freeFileIndexPriv( (void *)fileIndexPrivData );
      return NULL;
   }

   return fileIndexPrivData;
}

FD_RetCode FD_FileIndexPrivFree( FD_FileIndexPriv *toBeFreed )
{
   return freeFileIndexPriv( toBeFreed );
}

FD_RetCode FD_FileIndexAddCategoryData( FD_FileIndexPriv *data,
                                        FD_String *stringCategory,
                                        FD_FileIndexCategoryData **added )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileIndexCategoryData *categoryData;
   unsigned int tmpInt;
   unsigned int categoryFound; /* Boolean */
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN(  FD_FileIndexAddCategoryData );

   stringCache = FD_GetGlobalStringCache();

   FD_ASSERT( data != NULL );
   FD_ASSERT( stringCategory != NULL );

   /* Trap the case where the category is already added. */
   categoryData = (FD_FileIndexCategoryData *)FD_ListAccessTail( data->listCategory );

   categoryFound = 0;
   while( categoryData && !categoryFound )
   {
      FD_ASSERT( categoryData->string != NULL );

      tmpInt = strcmp( FD_StringToChar( stringCategory ),
                       FD_StringToChar( categoryData->string ) );
      if( tmpInt == 0 )
         categoryFound = 1;
      else
         categoryData = (FD_FileIndexCategoryData *)FD_ListAccessPrev( data->listCategory );
   }

   if( !categoryFound )
   {
      /* This is a new category, so allocate the FD_FileIndexCategoryData */
      categoryData = (FD_FileIndexCategoryData *)FD_Malloc( sizeof(FD_FileIndexCategoryData) );

      if( !categoryData )
         FD_TRACE_RETURN( FD_ALLOC_ERR );

      /* Initialize the FD_FileIndexCategoryData */
      categoryData->parent = data;
      if( stringCategory )
      {
         categoryData->string = FD_StringDup( stringCache, stringCategory);    /* String for this category. Can be NULL. */
         if( !categoryData->string )
         {
            FD_Free(  categoryData );
            FD_TRACE_RETURN( FD_ALLOC_ERR );
         }
      }
      else
         categoryData->string = NULL;

      categoryData->listSymbol = FD_ListAlloc();

      if( !categoryData->listSymbol )
      {
         if( categoryData->string )
            FD_StringFree( stringCache, categoryData->string );
         FD_Free(  categoryData );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      /* Add it to the FD_FileIndexPriv */
      retCode = FD_ListAddTail( data->listCategory, categoryData );
      if( retCode != FD_SUCCESS )
      {
         FD_ListFree( categoryData->listSymbol );
         if( categoryData->string )
            FD_StringFree( stringCache, categoryData->string );
         FD_Free(  categoryData );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      #if 0
         printf( "**ADDING CATEGORY[%s]\n", FD_StringToChar( categoryData->string ) );
      #endif
   }

   /* Return the address of the object representing that category. */
   if( added )
      *added = categoryData;


   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_FileIndexAddTokenInfo( FD_FileIndexPriv *data,
                                     FD_TokenId id,
                                     FD_String *value,
                                     FD_TokenInfo *optBefore )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_TokenInfo *info;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN(  FD_FileIndexAddTokenInfo );

   stringCache = FD_GetGlobalStringCache();

   info = FD_Malloc( sizeof( FD_TokenInfo ) );

   if( !info )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   info->id = id;
   if( value == NULL )
      info->value = NULL;
   else
   {
      info->value = FD_StringDup( stringCache, value );

      if( !info->value )
      {
         FD_Free(  info );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
   }

   if( optBefore )
      retCode = FD_ListAddBefore( data->listLocationToken, optBefore, info );
   else
      retCode = FD_ListAddTail( data->listLocationToken, info );

    if( retCode != FD_SUCCESS )
    {
      if( info->value )
         FD_StringFree( stringCache, info->value );
      FD_Free( info );
      FD_TRACE_RETURN( retCode );
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}


FD_RetCode FD_FileIndexAddSymbolData( FD_FileIndexCategoryData *categoryData,
                                      FD_String *stringSymbol,
                                      FD_ValueTreeNode *treeNodeValue,
                                      FD_FileIndexSymbolData **added )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_FileIndexSymbolData *symbolData;
   unsigned int tmpInt;
   unsigned int symbolFound; /* Boolean */
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN(  FD_FileIndexAddSymbolData );

   stringCache = FD_GetGlobalStringCache();

   FD_ASSERT( categoryData != NULL );
   FD_ASSERT( categoryData->listSymbol != NULL );
   FD_ASSERT( stringSymbol != NULL );
   FD_ASSERT( treeNodeValue != NULL );

   if( added )
      *added = NULL;

   /* Trap the case where this symbol is already there for that
    * category. In that case, the information is ignored.
    * Under the same category, for the same datasource, only one file
    * is supported for a category-symbol pair.
    */
   symbolData = (FD_FileIndexSymbolData *)FD_ListAccessTail( categoryData->listSymbol );

   symbolFound = 0;
   while( symbolData && !symbolFound )
   {
      FD_ASSERT( symbolData->string != NULL );

      tmpInt = strcmp( FD_StringToChar( stringSymbol ),
                       FD_StringToChar( symbolData->string ) );
      if( tmpInt == 0 )
         symbolFound = 1;
      else
         symbolData = (FD_FileIndexSymbolData *)FD_ListAccessPrev( categoryData->listSymbol );
   }

   if( !symbolFound )
   {
      /* This is a new symbol, so allocate the FD_FileIndexSymbolData */
      symbolData = (FD_FileIndexSymbolData *)FD_Malloc( sizeof(FD_FileIndexSymbolData) );

      if( !symbolData )
      {
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      /* Initialize the FD_FileIndexSymbolData */
      symbolData->parent = categoryData;
      symbolData->node   = treeNodeValue;
      symbolData->string = FD_StringDup( stringCache, stringSymbol );
      if( !symbolData->string )
      {
         FD_Free(  symbolData );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }

      /* Add it to the category list. */
      retCode = FD_ListAddTail( categoryData->listSymbol, symbolData );
      if( retCode != FD_SUCCESS )
      {
         FD_StringFree( stringCache, symbolData->string );
         FD_Free( symbolData );
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
   }

   /* Return the address of the object representing that symbol. */
   if( added )
      *added = symbolData;


   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_FileIndexSetCurrentTreeValueNode( FD_FileIndexPriv *data, FD_ValueTreeNode *node )
{
   data->currentNode = node;
   return FD_SUCCESS;
}

FD_ValueTreeNode *FD_FileIndexGetCurrentTreeValueNode( FD_FileIndexPriv *data )
{
   return data->currentNode;
}

FD_RetCode FD_FileIndexFreeValueTree( FD_ValueTreeNode *fromNode )
{
   FD_PROLOG
   FD_RetCode retCode;
   FD_ValueTreeNode *tmp;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_FileIndexFreeValueTree );

   FD_ASSERT( fromNode != NULL );

   stringCache = FD_GetGlobalStringCache();

   /* Remove itself from parent->child list if parent still around. */
   if( fromNode->parent )
   {
      tmp = ((FD_ValueTreeNode *)fromNode->parent);
      if( tmp->child )
         FD_ListRemoveEntry( tmp->child, (void *)fromNode );
   }

   if( fromNode->string )
      FD_StringFree( stringCache, fromNode->string );

   /* Deletes all childs. */
   if( fromNode->child )
   {
      retCode = freeListAndElement( fromNode->child, freeTreeNode );
      if( retCode != FD_SUCCESS )
         FD_TRACE_RETURN( retCode );
   }

   FD_Free( fromNode );

   FD_TRACE_RETURN( FD_SUCCESS );
}

FD_RetCode FD_FileIndexAddTreeValue( FD_FileIndexPriv *data,
                                     FD_String *string,
                                     FD_ValueTreeNode **added )
{
   FD_PROLOG
   FD_ValueTreeNode *node;
   unsigned int allocateEmptyString;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN( FD_FileIndexAddTreeValue );

   stringCache = FD_GetGlobalStringCache();

   allocateEmptyString = 0;
   FD_ASSERT( data != NULL );

   if( added )
      *added = NULL;

   if( !string )
   {
      string = FD_StringAlloc( stringCache, "" );
      if( !string )
      {
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
      allocateEmptyString = 1;
   }

   /* Alloc the FD_ValueTreeNode */
   node = allocTreeNode( data->currentNode, string );

   if( allocateEmptyString )
      FD_StringFree( stringCache, string );

   if( !node )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   data->currentNode = node;

   if( added )
      *added = node;

   FD_TRACE_RETURN( FD_SUCCESS );
}

/* Allows to change the value associated to a FD_ValueTreeNode. */
FD_RetCode FD_FileIndexChangeValueTreeNodeValue( FD_ValueTreeNode *nodeToChange,
                                                 FD_String *newValue )
{
   FD_PROLOG
   FD_String *dup;
   FD_StringCache *stringCache;

   FD_TRACE_BEGIN(  FD_FileIndexChangeValueTreeNodeValue );

   stringCache = FD_GetGlobalStringCache();

   if( !nodeToChange )
   {
      FD_TRACE_RETURN( FD_BAD_PARAM );
   }

   if( nodeToChange->string )
      FD_StringFree( stringCache, nodeToChange->string );

   if( !newValue )
      nodeToChange->string = NULL;
   else
   {
      dup = FD_StringDup( stringCache, newValue );
      if( !dup )
      {
         nodeToChange->string = NULL;
         FD_TRACE_RETURN( FD_ALLOC_ERR );
      }
      else
         nodeToChange->string = dup;
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

/* Two very limited function to walk up/down in the Tree.
 * These functions are useful only when walking on a known linear portion
 * of the tree (when for each parent there is only one child).
 */
FD_ValueTreeNode *FD_FileIndexGoDownTreeValue( FD_FileIndexPriv *data )
{
   FD_ValueTreeNode *retValue;

   FD_ASSERT_RET( data != NULL, (FD_ValueTreeNode *)NULL );

   /* Go down using the first child only. */
   if( (!data->currentNode) || (!data->currentNode->child) )
      return NULL;

   retValue = FD_ListAccessHead( data->currentNode->child );

   /* Change data->currentNode only if we really can go down... */
   if( retValue )
      data->currentNode = retValue;

   return retValue;
}

FD_ValueTreeNode *FD_FileIndexGoUpTreeValue( FD_FileIndexPriv *data )
{
   FD_ValueTreeNode *retValue;

   FD_ASSERT_RET( data != NULL, (FD_ValueTreeNode *)NULL );

   if( !data->currentNode )
      return (FD_ValueTreeNode *)NULL;

   retValue = data->currentNode->parent;

   /* Change data->currentNode only if we can really go up... */
   if( retValue  )
      data->currentNode = retValue;

   return retValue;
}

/**** Local functions definitions.     ****/
static FD_ValueTreeNode *allocTreeNode( FD_ValueTreeNode *parent,
                                        FD_String *string )
{
   FD_ValueTreeNode *node;
   FD_RetCode retCode;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   node = (FD_ValueTreeNode *)FD_Malloc( sizeof( FD_ValueTreeNode ) );

   if( !node )
      return (FD_ValueTreeNode *)NULL;

   node->string = NULL;
   node->parent = NULL;

   node->child = FD_ListAlloc();
   if( !node->child )
   {
      freeTreeNode( node );
      return NULL;
   }

   if( string )
   {
      node->string = FD_StringDup( stringCache, string );
      if( !node->string )
      {
         freeTreeNode( node );
         return NULL;
      }
   }

   if( parent )
   {
      retCode = FD_ListAddTail( parent->child, node );
      if( retCode != FD_SUCCESS )
      {
         freeTreeNode( node );
         return NULL;
      }
      node->parent = parent;
   }

   return node;
}

static FD_RetCode freeFileIndexPriv( void *toBeFreed )
{
   FD_PROLOG
   FD_FileIndexPriv *asciiFileData;
   FD_StringCache   *stringCache;

   asciiFileData = (FD_FileIndexPriv *)toBeFreed;

   FD_TRACE_BEGIN(  freeFileIndexPriv );

   stringCache = FD_GetGlobalStringCache();

   if( !asciiFileData )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   if( freeListAndElement( asciiFileData->listLocationToken, freeTokenInfo ) != FD_SUCCESS )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   if( freeListAndElement( asciiFileData->listCategory, freeCategoryData ) != FD_SUCCESS )
   {
      FD_TRACE_RETURN( FD_ALLOC_ERR );
   }

   if( asciiFileData->root )
      FD_FileIndexFreeValueTree( asciiFileData->root );

   if( asciiFileData->scratchPad )
      FD_Free(  asciiFileData->scratchPad );

   if( asciiFileData->wildOneChar )
      FD_StringFree( stringCache, asciiFileData->wildOneChar );

   if( asciiFileData->wildZeroOrMoreChar )
      FD_StringFree( stringCache, asciiFileData->wildZeroOrMoreChar );

   if( asciiFileData->wildOneOrMoreChar )
      FD_StringFree( stringCache, asciiFileData->wildOneOrMoreChar );

   if( asciiFileData->initialCategoryString )
      FD_StringFree( stringCache, asciiFileData->initialCategoryString );

   if( asciiFileData->initialCategoryCountryString )
      FD_StringFree( stringCache, asciiFileData->initialCategoryCountryString );

   if( asciiFileData->initialCategoryExchangeString )
      FD_StringFree( stringCache, asciiFileData->initialCategoryExchangeString );

   if( asciiFileData->initialCategoryTypeString )
      FD_StringFree( stringCache, asciiFileData->initialCategoryTypeString );

   FD_Free( asciiFileData );

   FD_TRACE_RETURN( FD_SUCCESS );
}

static FD_RetCode freeTreeNode( void *toBeFreed )
{
   /* Free this node and all descendant.
    * Force to ignore the remove of itself in the parent->child list
    * by setting parent to NULL.
    * That means that the caller will clean-up itself the
    * parent list.
     */
   FD_ValueTreeNode *node = (FD_ValueTreeNode *)toBeFreed;
   node->parent = NULL;
   return FD_FileIndexFreeValueTree( node );
}

static FD_RetCode freeTokenInfo( void *toBeFreed )
{
   FD_TokenInfo *info;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   info = (FD_TokenInfo *)toBeFreed;

   if( !info )
      return FD_ALLOC_ERR;

   if( info->value )
      FD_StringFree( stringCache, info->value );

   FD_Free(  info );

   return FD_SUCCESS;
}

static FD_RetCode freeCategoryData( void *toBeFreed )
{
   FD_FileIndexCategoryData *categoryData;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   categoryData = (FD_FileIndexCategoryData *)toBeFreed;

   if( !categoryData )
      return FD_ALLOC_ERR;

   if( categoryData->string )
      FD_StringFree( stringCache, categoryData->string );

   if( freeListAndElement( categoryData->listSymbol, freeSymbolData ) != FD_SUCCESS )
      return FD_ALLOC_ERR;

   FD_Free( categoryData );

   return FD_SUCCESS;
}

static FD_RetCode freeSymbolData( void *toBeFreed )
{
   FD_FileIndexSymbolData *symbolData;
   FD_StringCache *stringCache;

   stringCache = FD_GetGlobalStringCache();

   symbolData = (FD_FileIndexSymbolData *)toBeFreed;

   if( !symbolData )
      return FD_ALLOC_ERR;

   /* Not yet im[plemented !!!
   if( symbolData->dataPerDate )
   {
      if( freeListAndElement( symbolData->dataPerDate, freeDataPerDate ) != FD_SUCCESS )
         return FD_ALLOC_ERR;
   }
   */

   if( symbolData->string )
      FD_StringFree( stringCache, symbolData->string );

   FD_Free( symbolData );

   return FD_SUCCESS;
}

static FD_RetCode freeListAndElement( FD_List *list, FD_RetCode (*freeFunc)( void *toBeFreed ) )
{
   FD_PROLOG
   FD_RetCode retCode;
   void *node;

   FD_TRACE_BEGIN( freeListAndElement );

   if( list != NULL )
   {
      while( (node = FD_ListRemoveTail( list )) != NULL )
      {
         retCode = freeFunc(  node );
         if( retCode != FD_SUCCESS )
         {
            FD_FATAL(  NULL, node, retCode );
            /* FD_TRACE_RETURN( FD_ALLOC_ERR ); */
         }
      }

      retCode = FD_ListFree( list );
      if( retCode != FD_SUCCESS )
      {
         FD_FATAL(  NULL, list, retCode );
         /*FD_TRACE_RETURN( FD_ALLOC_ERR );*/
      }
   }

   FD_TRACE_RETURN( FD_SUCCESS );
}

