"""
Mathtex is a Python library for typesetting mathematical equations written in
LaTeX.
"""

__version__ = "0.3"

#from mathtex.mathtex_main import Mathtex