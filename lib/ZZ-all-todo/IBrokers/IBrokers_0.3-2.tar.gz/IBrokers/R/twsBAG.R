twsBAG <-
function(...) {
  combolegs <- as.list(...)
  twsContract(0,"USD","BAG","SMART","","","0.0","USD","","","",NULL,combolegs,"0","","")
}

