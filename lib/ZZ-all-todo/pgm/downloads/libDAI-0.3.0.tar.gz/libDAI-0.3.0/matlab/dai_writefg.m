% dai_writefg(psi,filename)
%
%    INPUT:  psi        = linear cell array containing the factors
%                         (psi{i} should be a structure with a Member field
%                         and a P field, like a CPTAB).
%            filename   = filename of a .fg file
