/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//                INTEL CORPORATION PROPRIETARY INFORMATION                //
//   This software is supplied under the terms of a license agreement or   //
//  nondisclosure agreement with Intel Corporation and may not be copied   //
//   or disclosed except in accordance with the terms of that agreement.   //
//       Copyright (c) 2003 Intel Corporation. All Rights Reserved.        //
//                                                                         //
//  File:      pnlParNewDelete.hpp                                         //
//                                                                         //
//  Purpose:   implementation of operator new and operator delete          //
//                                                                         //
//  Author(s): (in alphabetical order)                                     //
//             Abrosimova, Chernishova, Gergel, Senin, Sysoyev, Vinogradov //
//             NNSU                                                        //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#include "pnlParConfig.hpp"

#ifdef PAR_USE_OMP_ALLOCATOR

void *operator new(size_t Size);
void operator delete (void *pPointer);

#endif // PAR_USE_OMP_ALLOCATOR
