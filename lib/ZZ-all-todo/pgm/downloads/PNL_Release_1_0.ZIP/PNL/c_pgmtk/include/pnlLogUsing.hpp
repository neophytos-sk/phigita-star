#ifndef __PNLLOGUSING_HPP__
#define __PNLLOGUSING_HPP__

PNL_BEGIN

// FORWARDS
class Log;

PNL_API void SetDump(const char *fname);
PNL_API Log* LogPotential();

PNL_END

#endif // include guard
