Warning: Do not edit and remove files in this folder!!
Otherwize the generator won't work properly!!