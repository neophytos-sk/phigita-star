#include "pnlHighConf.hpp"

#include "BNet.hpp"
#include "LIMID.hpp"
#include "DBN.hpp"
#include "MRF.hpp"

// FORWARDS
PNLW_BEGIN

class WDistribFun;
class WGraph;
class TokenCover;
class WDistributions;
class NetCallback;

PNLW_END
