#ifndef _EXAMPLE_COMMON_FUNS_HPP_
#define _EXAMPLE_COMMON_FUNS_HPP_

extern int CompareFiles(const char *name1, const char *name2);

#endif
