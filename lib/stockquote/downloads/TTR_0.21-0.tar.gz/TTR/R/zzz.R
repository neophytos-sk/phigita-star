#".onLoad" <- function(lib,pkg) {
#  message("Technical Trading Rules (version 0.20-0)\n")
#}
