Assignment 4
CS 4TF3
George A. Papayiannis
April 9 2005

The code was developed in CYGWIN (http://www.cygwin.com/) with the lastet version of GCC.
To execute the code please copy the contents of this folder into your home directory of CYGWIN.
Both k-means and the em algorithm implementation are in their respective directories.

*** This code will not execute in Windows without being run within CYGWIN.