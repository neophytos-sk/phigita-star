#ifndef LEAPSECS_H
#define LEAPSECS_H

extern int leapsecs_init();
extern int leapsecs_read();

extern void leapsecs_add();
extern int leapsecs_sub();

#endif
