#ifndef RWHCONFIG_H
#define RWHCONFIG_H

#include "strerr.h"

extern struct strerr rwhconfig_err;
extern int rwhconfig();

#endif
