#ifndef TIMEOUTREAD_H
#define TIMEOUTREAD_H

extern int timeoutread();

#endif
