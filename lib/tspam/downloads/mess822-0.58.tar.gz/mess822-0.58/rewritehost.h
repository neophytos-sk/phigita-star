#ifndef REWRITEHOST_H
#define REWRITEHOST_H

extern int rewritehost();
extern int rewritehost_addr();
extern int rewritehost_list();

#endif
