#!/bin/bash

swfmill simple player.xml player.swf
