* FLV-Scrubber 2.0
* ---------------------
* (CC) by Fabian Topfstedt, renta@topfstedt.de
*
* Creative Commons Attribution-Noncommercial-Share Alike 2.5 License
* -> http://creativecommons.org/licenses/by-nc-sa/2.0/at/deed.en
*
* Privileges to use FLV-Scrubber for commercial purposes and/or 
* without attributon are purchasable. If you miss functionality, need
* support, consultation, transcoding, ... , feel free to hire me 
* -> renta@topfstedt.de
*
* Many thanks to Jan Kneschke, Stephan Richter, Lee Brimelow, Nikolai Longolius,
* the FFmpeg-Developers, Norman Timmler and Yuji Oshimoto