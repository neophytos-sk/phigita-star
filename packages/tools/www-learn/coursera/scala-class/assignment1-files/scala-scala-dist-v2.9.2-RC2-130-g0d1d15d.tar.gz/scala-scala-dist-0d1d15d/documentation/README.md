# Requirements #

* latexmk
* pdf2ps

I had to install `okumura-clsfiles` for Book.cls  and `texlive-fonts-extra` and `texlive-latex-recommended` for fonts on Ubuntu.

You will also need non-free fonts, ugh: http://www.tug.org/fonts/getnonfreefonts/


