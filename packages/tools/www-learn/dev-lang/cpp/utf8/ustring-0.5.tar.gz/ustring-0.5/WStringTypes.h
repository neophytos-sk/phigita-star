
#ifndef _WSTRINGTYPES_H_
#define _WSTRINGTYPES_H_
#include <stdint.h>
typedef uint16_t WChar;
#define WCHAR_MAX 0xffff
#define CONVERTUNICODEINTERNAL(x) (((x>>8)&0xff) | ((x<<8)&0xff00))
#define INTERNALTOHOST(x) CONVERTUNICODEINTERNAL(x)
#define HOSTTOINTERNAL(x) CONVERTUNICODEINTERNAL(x)
#define WSTRING_INTERNAL_CHARSET "UCS-2"
#endif
